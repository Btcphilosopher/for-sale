"""
ARCADIUM OS — sessions/session.py
Session data structure. A session is one active game runtime instance.

Not a game engine — the OS manages session identity, player binding,
budget allocation, and lifecycle. Game logic is external.
"""
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

from simulation.cost_model import PerformanceMode, mode_from_player_count


class SessionState(Enum):
    CREATING  = auto()   # being instantiated
    WAITING   = auto()   # ready, waiting for minimum players
    RUNNING   = auto()   # active game loop
    PAUSED    = auto()   # suspended, state preserved
    ENDING    = auto()   # teardown in progress
    ENDED     = auto()   # fully terminated


# Human-readable game titles for simulation purposes
GAME_CATALOGUE: list[str] = [
    "IRON CIRCUIT",
    "NEBULA STRIKE",
    "VELOCITY GRID",
    "TITAN BRAWL",
    "QUANTUM DASH",
    "STEEL LEGION",
    "NEON COLOSSEUM",
    "DELTA FORCE X",
]


@dataclass
class SessionMetrics:
    """Live performance metrics tracked per session."""
    frames_run:       int   = 0
    total_cpu_us:     float = 0.0
    peak_cpu_us:      float = 0.0
    avg_cpu_us:       float = 0.0
    input_events:     int   = 0
    pauses:           int   = 0
    player_joins:     int   = 0
    player_leaves:    int   = 0
    degraded_frames:  int   = 0

    def record_frame(self, cpu_us: float, degraded: bool = False) -> None:
        self.frames_run += 1
        self.total_cpu_us += cpu_us
        self.peak_cpu_us = max(self.peak_cpu_us, cpu_us)
        self.avg_cpu_us = self.total_cpu_us / max(self.frames_run, 1)
        if degraded:
            self.degraded_frames += 1


@dataclass
class Session:
    """
    Core session data container.

    The OS creates and owns sessions. Each session has a unique ID,
    a set of active player slots, a performance budget allocation,
    and a lifecycle state.
    """
    # Identity
    session_id:   str   = field(default_factory=lambda: str(uuid.uuid4())[:8].upper())
    game_title:   str   = "UNKNOWN"
    display_name: str   = ""

    # Lifecycle
    state:        SessionState = SessionState.CREATING
    created_at:   float        = field(default_factory=time.perf_counter)
    started_at:   Optional[float] = None
    ended_at:     Optional[float] = None
    paused_at:    Optional[float] = None

    # Players: list of slot IDs currently active in this session
    player_slots: list[int] = field(default_factory=list)

    # Performance budget: share of total frame budget allocated to this session
    # 0.0–1.0 fraction of AVAILABLE_BUDGET_US
    budget_share: float = 1.0

    # Metrics
    metrics: SessionMetrics = field(default_factory=SessionMetrics)

    def __post_init__(self) -> None:
        if not self.display_name:
            self.display_name = f"{self.game_title} [{self.session_id}]"

    # ── Player management ─────────────────────────────────────────────────

    def add_player(self, slot_id: int) -> bool:
        from runtime.system_limits import MAX_PLAYERS_PER_SESSION
        if slot_id in self.player_slots:
            return False
        if len(self.player_slots) >= MAX_PLAYERS_PER_SESSION:
            return False
        self.player_slots.append(slot_id)
        self.metrics.player_joins += 1
        return True

    def remove_player(self, slot_id: int) -> bool:
        if slot_id not in self.player_slots:
            return False
        self.player_slots.remove(slot_id)
        self.metrics.player_leaves += 1
        return True

    @property
    def player_count(self) -> int:
        return len(self.player_slots)

    @property
    def performance_mode(self) -> PerformanceMode:
        return mode_from_player_count(self.player_count)

    # ── Lifecycle timing ──────────────────────────────────────────────────

    @property
    def age_seconds(self) -> float:
        return time.perf_counter() - self.created_at

    @property
    def run_seconds(self) -> float:
        if self.started_at is None:
            return 0.0
        end = self.ended_at or time.perf_counter()
        return end - self.started_at

    @property
    def is_active(self) -> bool:
        return self.state in (SessionState.RUNNING, SessionState.PAUSED)

    @property
    def is_terminal(self) -> bool:
        return self.state in (SessionState.ENDING, SessionState.ENDED)

    # ── Display ───────────────────────────────────────────────────────────

    def status_line(self) -> str:
        mode = self.performance_mode.name.replace("_", " ")
        return (
            f"[{self.session_id}] {self.game_title} "
            f"| {self.state.name} "
            f"| {self.player_count}P "
            f"| {mode} "
            f"| {self.run_seconds:.1f}s"
        )

    def to_dict(self) -> dict:
        return {
            "session_id":    self.session_id,
            "game_title":    self.game_title,
            "state":         self.state.name,
            "player_count":  self.player_count,
            "player_slots":  self.player_slots,
            "perf_mode":     self.performance_mode.name,
            "run_seconds":   round(self.run_seconds, 2),
            "budget_share":  self.budget_share,
            "frames_run":    self.metrics.frames_run,
            "avg_cpu_us":    round(self.metrics.avg_cpu_us, 1),
            "peak_cpu_us":   round(self.metrics.peak_cpu_us, 1),
            "degraded_frames": self.metrics.degraded_frames,
        }
