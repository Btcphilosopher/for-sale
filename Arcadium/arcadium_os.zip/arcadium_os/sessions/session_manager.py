"""
ARCADIUM OS — sessions/session_manager.py
Central session registry. Creates, tracks, and terminates all sessions.
Enforces concurrent session limits and budget share allocation.
"""
import random
import threading
import time
from typing import Optional

from sessions.session import Session, SessionState, GAME_CATALOGUE
from sessions.lifecycle import SessionLifecycle
from runtime.system_limits import (
    MAX_CONCURRENT_SESSIONS,
    check_session_count,
    check_player_count,
)
from utils.logging import log


class SessionManager:
    """
    OS-level session registry.

    Maintains the active session table and handles:
      - session creation with budget allocation
      - player join / leave
      - session pause / resume / end
      - session teardown and cleanup
    """

    def __init__(self) -> None:
        self._sessions:    dict[str, Session]          = {}
        self._lifecycles:  dict[str, SessionLifecycle] = {}
        self._lock = threading.Lock()
        self._game_rng = random.Random()

    # ── Session CRUD ──────────────────────────────────────────────────────

    def create_session(
        self,
        game_title: Optional[str] = None,
        initial_player_slots: Optional[list[int]] = None,
    ) -> Session:
        """
        Create a new session and register it.
        Raises ValueError if the concurrent session limit would be exceeded.
        """
        with self._lock:
            active_count = len(self._active_sessions())
            check_session_count(active_count + 1)

            if game_title is None:
                used = {s.game_title for s in self._sessions.values()}
                available = [g for g in GAME_CATALOGUE if g not in used]
                game_title = random.choice(available if available else GAME_CATALOGUE)

            session = Session(game_title=game_title)
            lifecycle = SessionLifecycle(session)

            # Allocate budget share evenly across all active sessions
            self._reallocate_budgets(active_count + 1, session)

            # Add initial players
            if initial_player_slots:
                for slot_id in initial_player_slots:
                    session.add_player(slot_id)

            self._sessions[session.session_id] = session
            self._lifecycles[session.session_id] = lifecycle

            log.session(f"Created [{session.session_id}] game={game_title} budget={session.budget_share:.2f}")

        # Attempt auto-start outside the lock
        lifecycle.start()
        return session

    def destroy_session(self, session_id: str, reason: str = "normal") -> bool:
        """
        Begin session teardown. Returns True if the session existed.
        """
        with self._lock:
            lc = self._lifecycles.get(session_id)
            if lc is None:
                return False
            lc.end(reason)
            lc.complete_teardown()

        self._cleanup_session(session_id)
        return True

    def _cleanup_session(self, session_id: str) -> None:
        with self._lock:
            session = self._sessions.pop(session_id, None)
            self._lifecycles.pop(session_id, None)
            if session:
                log.session(
                    f"Destroyed [{session_id}] after {session.run_seconds:.1f}s "
                    f"frames={session.metrics.frames_run}"
                )
            self._reallocate_budgets(len(self._active_sessions()))

    # ── Player management ─────────────────────────────────────────────────

    def add_player(self, session_id: str, slot_id: int) -> bool:
        """
        Add a player slot to a running session.
        Returns True on success.
        """
        with self._lock:
            lc = self._lifecycles.get(session_id)
            session = self._sessions.get(session_id)
            if lc is None or session is None:
                return False
            if not lc.can_add_player():
                log.warn("SESS-MGR", f"Cannot add player to {session_id} in state {session.state.name}")
                return False
            check_player_count(session.player_count + 1)
            ok = session.add_player(slot_id)
            if ok:
                log.session(f"[{session_id}] Player joined slot {slot_id} ({session.player_count} total)")
                lc.check_auto_start()
            return ok

    def remove_player(self, session_id: str, slot_id: int) -> bool:
        """
        Remove a player slot from a session.
        Ends the session if no players remain.
        """
        with self._lock:
            lc = self._lifecycles.get(session_id)
            session = self._sessions.get(session_id)
            if lc is None or session is None:
                return False
            ok = session.remove_player(slot_id)
            if ok:
                log.session(f"[{session_id}] Player left slot {slot_id} ({session.player_count} remaining)")
                if session.player_count == 0 and session.state == SessionState.RUNNING:
                    log.session(f"[{session_id}] No players remain — ending session")
                    lc.end("no players")
                    lc.complete_teardown()
            return ok

    # ── Pause / resume ────────────────────────────────────────────────────

    def pause_session(self, session_id: str, reason: str = "user") -> bool:
        with self._lock:
            lc = self._lifecycles.get(session_id)
            if lc is None:
                return False
            try:
                lc.pause(reason)
                return True
            except Exception:
                return False

    def resume_session(self, session_id: str) -> bool:
        with self._lock:
            lc = self._lifecycles.get(session_id)
            if lc is None:
                return False
            try:
                lc.resume()
                return True
            except Exception:
                return False

    # ── Query ─────────────────────────────────────────────────────────────

    def get_session(self, session_id: str) -> Optional[Session]:
        return self._sessions.get(session_id)

    def all_sessions(self) -> list[Session]:
        return list(self._sessions.values())

    def running_sessions(self) -> list[Session]:
        return [s for s in self._sessions.values() if s.state == SessionState.RUNNING]

    def _active_sessions(self) -> list[Session]:
        return [s for s in self._sessions.values() if not s.is_terminal]

    @property
    def session_count(self) -> int:
        return len(self._sessions)

    @property
    def running_count(self) -> int:
        return len(self.running_sessions())

    def total_players(self) -> int:
        return sum(s.player_count for s in self._active_sessions())

    def session_summary(self) -> list[dict]:
        return [s.to_dict() for s in self.all_sessions()]

    # ── Budget allocation ─────────────────────────────────────────────────

    def _reallocate_budgets(
        self,
        total_sessions: int,
        new_session: Optional[Session] = None,
    ) -> None:
        """Evenly redistribute budget shares across all active sessions."""
        if total_sessions <= 0:
            return
        share = 1.0 / total_sessions
        for s in self._active_sessions():
            s.budget_share = share
        if new_session:
            new_session.budget_share = share
