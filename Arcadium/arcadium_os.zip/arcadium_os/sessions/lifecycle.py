"""
ARCADIUM OS — sessions/lifecycle.py
Session state machine. Governs all valid state transitions.

Boot → Launcher → Session Create → Join Players → Run → End → Reset

Valid transitions:
  CREATING  → WAITING   (created, not enough players yet)
  CREATING  → RUNNING   (created with enough players)
  WAITING   → RUNNING   (minimum players joined)
  RUNNING   → PAUSED    (system pause or explicit pause)
  RUNNING   → ENDING    (game over or explicit end)
  PAUSED    → RUNNING   (resume)
  PAUSED    → ENDING    (end while paused)
  ENDING    → ENDED     (teardown complete)
"""
import time
from typing import Optional

from sessions.session import Session, SessionState
from utils.logging import log


# ── Transition table ──────────────────────────────────────────────────────────

_VALID_TRANSITIONS: dict[SessionState, set[SessionState]] = {
    SessionState.CREATING: {SessionState.WAITING, SessionState.RUNNING},
    SessionState.WAITING:  {SessionState.RUNNING, SessionState.ENDING},
    SessionState.RUNNING:  {SessionState.PAUSED,  SessionState.ENDING},
    SessionState.PAUSED:   {SessionState.RUNNING, SessionState.ENDING},
    SessionState.ENDING:   {SessionState.ENDED},
    SessionState.ENDED:    set(),   # terminal
}

MIN_PLAYERS_TO_START = 1


class LifecycleError(Exception):
    """Raised on invalid state transition attempt."""
    pass


class SessionLifecycle:
    """
    Manages valid state transitions for a single session.
    Applies timestamps and fires log events on each transition.
    """

    def __init__(self, session: Session) -> None:
        self._session = session

    # ── Transition methods ────────────────────────────────────────────────

    def transition(self, target: SessionState, reason: str = "") -> None:
        """
        Attempt a state transition. Raises LifecycleError if invalid.
        """
        current = self._session.state
        allowed = _VALID_TRANSITIONS.get(current, set())

        if target not in allowed:
            raise LifecycleError(
                f"Session {self._session.session_id}: "
                f"invalid transition {current.name} → {target.name}"
            )

        self._session.state = target
        self._on_enter(target, reason)
        log.session(
            f"[{self._session.session_id}] {current.name} → {target.name}"
            + (f" ({reason})" if reason else "")
        )

    def _on_enter(self, state: SessionState, reason: str) -> None:
        s = self._session
        now = time.perf_counter()

        if state == SessionState.RUNNING:
            if s.started_at is None:
                s.started_at = now

        elif state == SessionState.PAUSED:
            s.paused_at = now
            s.metrics.pauses += 1

        elif state == SessionState.ENDING:
            pass  # execution engine will call teardown

        elif state == SessionState.ENDED:
            s.ended_at = now

    # ── Convenience wrappers ──────────────────────────────────────────────

    def start(self) -> None:
        """Transition CREATING/WAITING → RUNNING."""
        if self._session.state == SessionState.CREATING:
            if self._session.player_count >= MIN_PLAYERS_TO_START:
                self.transition(SessionState.RUNNING, "players ready")
            else:
                self.transition(SessionState.WAITING, "awaiting players")
        elif self._session.state == SessionState.WAITING:
            if self._session.player_count >= MIN_PLAYERS_TO_START:
                self.transition(SessionState.RUNNING, "minimum players reached")

    def pause(self, reason: str = "explicit") -> None:
        if self._session.state == SessionState.RUNNING:
            self.transition(SessionState.PAUSED, reason)

    def resume(self, reason: str = "explicit") -> None:
        if self._session.state == SessionState.PAUSED:
            self.transition(SessionState.RUNNING, reason)

    def end(self, reason: str = "normal") -> None:
        if not self._session.is_terminal:
            try:
                self.transition(SessionState.ENDING, reason)
            except LifecycleError:
                pass

    def complete_teardown(self) -> None:
        if self._session.state == SessionState.ENDING:
            self.transition(SessionState.ENDED, "teardown complete")

    def check_auto_start(self) -> bool:
        """
        Auto-start if in WAITING and player count reaches minimum.
        Returns True if a transition occurred.
        """
        if (
            self._session.state == SessionState.WAITING
            and self._session.player_count >= MIN_PLAYERS_TO_START
        ):
            self.start()
            return True
        return False

    def can_add_player(self) -> bool:
        from runtime.system_limits import MAX_PLAYERS_PER_SESSION
        return (
            self._session.state in (SessionState.WAITING, SessionState.RUNNING)
            and self._session.player_count < MAX_PLAYERS_PER_SESSION
        )

    def can_remove_player(self) -> bool:
        return self._session.state in (
            SessionState.WAITING, SessionState.RUNNING, SessionState.PAUSED
        )

    @property
    def session(self) -> Session:
        return self._session
