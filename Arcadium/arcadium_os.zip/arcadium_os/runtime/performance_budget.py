"""
ARCADIUM OS — runtime/performance_budget.py
Per-frame performance budget tracker and enforcer.
Accounts for CPU time spent in each subsystem and fires
corrective callbacks when thresholds are crossed.
"""
import threading
from dataclasses import dataclass, field
from collections import deque
from typing import Callable, Optional

from runtime.system_limits import (
    BUDGET_WARN_THRESHOLD,
    BUDGET_DEGRADE_THRESHOLD,
    BUDGET_CRITICAL_THRESHOLD,
    BUDGET_EMERGENCY_FRAMES,
    DEGRADE_AI_COMPLEXITY_AT,
    DEGRADE_UPDATE_FREQUENCY_AT,
    DEGRADE_RENDER_QUALITY_AT,
    RESTORE_FULL_FIDELITY_AT,
)
from utils.logging import log


@dataclass
class SubsystemBudget:
    """Tracks one subsystem's budget allocation and actual spend."""
    name:         str
    allocated_us: float   # μs of frame budget allocated to this subsystem
    spent_us:     float = 0.0

    @property
    def utilisation(self) -> float:
        if self.allocated_us <= 0:
            return 0.0
        return self.spent_us / self.allocated_us

    @property
    def over_budget(self) -> bool:
        return self.spent_us > self.allocated_us

    @property
    def overrun_us(self) -> float:
        return max(0.0, self.spent_us - self.allocated_us)


@dataclass
class FrameBudgetSnapshot:
    """Immutable snapshot of one frame's budget state."""
    frame:           int
    total_budget_us: float
    total_spent_us:  float
    utilisation:     float
    over_budget:     bool
    degraded:        bool
    subsystems:      dict[str, float]   # name → spent_us


class BudgetHistory:
    """Ring buffer of recent frame snapshots for trend analysis."""

    def __init__(self, depth: int = 120) -> None:  # 2 seconds at 60fps
        self._frames: deque[FrameBudgetSnapshot] = deque(maxlen=depth)
        self._lock = threading.Lock()

    def record(self, snap: FrameBudgetSnapshot) -> None:
        with self._lock:
            self._frames.append(snap)

    def recent(self, n: int = 30) -> list[FrameBudgetSnapshot]:
        with self._lock:
            return list(self._frames)[-n:]

    def average_utilisation(self, n: int = 60) -> float:
        snaps = self.recent(n)
        if not snaps:
            return 0.0
        return sum(s.utilisation for s in snaps) / len(snaps)

    def peak_utilisation(self, n: int = 60) -> float:
        snaps = self.recent(n)
        if not snaps:
            return 0.0
        return max(s.utilisation for s in snaps)

    def over_budget_count(self, n: int = 60) -> int:
        return sum(1 for s in self.recent(n) if s.over_budget)


class PerformanceBudget:
    """
    Frame-level budget manager.
    Subsystems register expected costs; this class enforces limits
    and triggers degradation callbacks when exceeded.
    """

    def __init__(self, total_budget_us: float) -> None:
        self._total_budget_us = total_budget_us
        self._subsystems: dict[str, SubsystemBudget] = {}
        self._current_frame: int = 0
        self._over_budget_streak: int = 0
        self._degraded: bool = False
        self._history = BudgetHistory()
        self._lock = threading.Lock()

        # Degradation state flags
        self.ai_degraded: bool = False
        self.update_freq_reduced: bool = False
        self.render_simplified: bool = False

        # Callbacks — set by execution engine
        self.on_budget_warn:     Optional[Callable[[float], None]] = None
        self.on_budget_degrade:  Optional[Callable[[float], None]] = None
        self.on_budget_critical: Optional[Callable[[float], None]] = None
        self.on_budget_restored: Optional[Callable[[], None]] = None

        self._init_subsystems()

    def _init_subsystems(self) -> None:
        budget = self._total_budget_us
        self._subsystems = {
            "kernel":  SubsystemBudget("kernel",  budget * 0.05),
            "input":   SubsystemBudget("input",   budget * 0.10),
            "session": SubsystemBudget("session", budget * 0.45),
            "render":  SubsystemBudget("render",  budget * 0.25),
            "ui":      SubsystemBudget("ui",      budget * 0.05),
            "reserve": SubsystemBudget("reserve", budget * 0.10),
        }

    # ── Frame lifecycle ───────────────────────────────────────────────────

    def begin_frame(self, frame: int, budget_us: float) -> None:
        """Reset per-frame accumulators. Budget may change (thermal)."""
        with self._lock:
            self._current_frame = frame
            self._total_budget_us = budget_us
            self._init_subsystems()

    def record_spend(self, subsystem: str, spent_us: float) -> None:
        """Record actual μs spent in a subsystem this frame."""
        with self._lock:
            if subsystem in self._subsystems:
                self._subsystems[subsystem].spent_us = spent_us

    def end_frame(self) -> FrameBudgetSnapshot:
        """
        Finalize the frame, check thresholds, fire callbacks, record history.
        Returns a snapshot of this frame's budget state.
        """
        with self._lock:
            total_spent = sum(s.spent_us for s in self._subsystems.values())
            utilisation = total_spent / max(self._total_budget_us, 1.0)
            over = total_spent > self._total_budget_us

            if over:
                self._over_budget_streak += 1
            else:
                self._over_budget_streak = max(0, self._over_budget_streak - 1)

            snap = FrameBudgetSnapshot(
                frame=self._current_frame,
                total_budget_us=self._total_budget_us,
                total_spent_us=total_spent,
                utilisation=utilisation,
                over_budget=over,
                degraded=self._degraded,
                subsystems={k: v.spent_us for k, v in self._subsystems.items()},
            )
            self._history.record(snap)

        self._evaluate_thresholds(utilisation)
        return snap

    # ── Threshold evaluation ──────────────────────────────────────────────

    def _evaluate_thresholds(self, utilisation: float) -> None:
        if utilisation >= BUDGET_CRITICAL_THRESHOLD:
            self._degraded = True
            self._escalate_degradation()
            if self.on_budget_critical:
                self.on_budget_critical(utilisation)
            log.perf("BUDGET", f"CRITICAL {utilisation*100:.1f}% — emergency degradation active")

        elif utilisation >= BUDGET_DEGRADE_THRESHOLD:
            if not self._degraded:
                self._degraded = True
                if self.on_budget_degrade:
                    self.on_budget_degrade(utilisation)
                log.perf("BUDGET", f"OVER {utilisation*100:.1f}% — degradation triggered")
            self._apply_degradation(utilisation)

        elif utilisation >= BUDGET_WARN_THRESHOLD:
            if self.on_budget_warn:
                self.on_budget_warn(utilisation)
            log.perf("BUDGET", f"WARN {utilisation*100:.1f}% — approaching limit")

        elif utilisation < RESTORE_FULL_FIDELITY_AT and self._degraded:
            self._restore_fidelity()

    def _apply_degradation(self, utilisation: float) -> None:
        if utilisation >= DEGRADE_AI_COMPLEXITY_AT and not self.ai_degraded:
            self.ai_degraded = True
            log.perf("BUDGET", "Degradation L1: AI complexity reduced")

        if utilisation >= DEGRADE_UPDATE_FREQUENCY_AT and not self.update_freq_reduced:
            self.update_freq_reduced = True
            log.perf("BUDGET", "Degradation L2: Update frequency reduced")

        if utilisation >= DEGRADE_RENDER_QUALITY_AT and not self.render_simplified:
            self.render_simplified = True
            log.perf("BUDGET", "Degradation L3: Render pipeline simplified")

    def _escalate_degradation(self) -> None:
        if self._over_budget_streak >= BUDGET_EMERGENCY_FRAMES:
            self.ai_degraded = True
            self.update_freq_reduced = True
            self.render_simplified = True
            log.perf("BUDGET", f"EMERGENCY: all degradations active (streak={self._over_budget_streak})")

    def _restore_fidelity(self) -> None:
        self._degraded = False
        self.ai_degraded = False
        self.update_freq_reduced = False
        self.render_simplified = False
        self._over_budget_streak = 0
        if self.on_budget_restored:
            self.on_budget_restored()
        log.perf("BUDGET", "Full fidelity restored")

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def history(self) -> BudgetHistory:
        return self._history

    @property
    def is_degraded(self) -> bool:
        return self._degraded

    @property
    def over_budget_streak(self) -> int:
        return self._over_budget_streak

    @property
    def current_utilisation(self) -> float:
        with self._lock:
            total = sum(s.spent_us for s in self._subsystems.values())
            return total / max(self._total_budget_us, 1.0)

    def subsystem_report(self) -> dict[str, dict]:
        with self._lock:
            return {
                k: {
                    "allocated_us": v.allocated_us,
                    "spent_us": v.spent_us,
                    "utilisation_pct": round(v.utilisation * 100, 1),
                    "over": v.over_budget,
                }
                for k, v in self._subsystems.items()
            }

    def degradation_status(self) -> dict:
        return {
            "degraded":         self._degraded,
            "ai_degraded":      self.ai_degraded,
            "freq_reduced":     self.update_freq_reduced,
            "render_simplified":self.render_simplified,
            "streak":           self._over_budget_streak,
        }
