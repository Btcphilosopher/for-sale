"""
ARCADIUM OS — runtime/system_limits.py
Hard runtime limits. These are enforced by the execution engine.
Any subsystem that exceeds these values triggers a corrective action.
"""
from typing import Final

# ── Session limits ────────────────────────────────────────────────────────────
MAX_CONCURRENT_SESSIONS:  Final[int]   = 4      # maximum simultaneous game sessions
MAX_PLAYERS_PER_SESSION:  Final[int]   = 8      # hard cap
MIN_PLAYERS_PER_SESSION:  Final[int]   = 1

# ── CPU budget enforcement ────────────────────────────────────────────────────
BUDGET_WARN_THRESHOLD:    Final[float] = 0.80   # 80% → log warning
BUDGET_DEGRADE_THRESHOLD: Final[float] = 0.90   # 90% → begin degradation
BUDGET_CRITICAL_THRESHOLD:Final[float] = 0.98   # 98% → emergency reduction
BUDGET_EMERGENCY_FRAMES:  Final[int]   = 5      # frames over critical before action

# ── Memory limits ─────────────────────────────────────────────────────────────
MEM_WARN_KB:              Final[int]   = 307_200  # 300 MB → warn
MEM_CRITICAL_KB:          Final[int]   = 368_640  # 360 MB → refuse new sessions
MEM_PER_SESSION_MAX_KB:   Final[int]   = 65_536   # 64 MB hard cap per session

# ── Input system ─────────────────────────────────────────────────────────────
INPUT_QUEUE_DEPTH:        Final[int]   = 64     # max queued events per device
INPUT_QUEUE_OVERFLOW:     Final[str]   = "DROP_OLDEST"
INPUT_DEBOUNCE_FRAMES:    Final[int]   = 2      # frame minimum between same-key events
INPUT_SCAN_INTERVAL_MS:   Final[float] = 1.0    # poll devices every 1ms (simulated)

# ── Scheduler ────────────────────────────────────────────────────────────────
SCHEDULER_MAX_TASKS:      Final[int]   = 64     # max tasks in scheduler queue
SCHEDULER_PRIORITY_LEVELS:Final[int]   = 8      # 0=lowest, 7=kernel/realtime

# ── Kernel watchdog ───────────────────────────────────────────────────────────
WATCHDOG_TIMEOUT_FRAMES:  Final[int]   = 120    # 2 seconds at 60fps before reset
FRAME_SKIP_MAX:           Final[int]   = 3      # max frames that can be skipped

# ── Performance degradation thresholds ───────────────────────────────────────
DEGRADE_AI_COMPLEXITY_AT:     Final[float] = 0.88
DEGRADE_UPDATE_FREQUENCY_AT:  Final[float] = 0.93
DEGRADE_RENDER_QUALITY_AT:    Final[float] = 0.97
RESTORE_FULL_FIDELITY_AT:     Final[float] = 0.75  # restore when below this

# ── Thermal model ─────────────────────────────────────────────────────────────
THERMAL_WARNING_C:        Final[float] = 70.0
THERMAL_THROTTLE_C:       Final[float] = 80.0
THERMAL_SHUTDOWN_C:       Final[float] = 95.0
THERMAL_AMBIENT_C:        Final[float] = 25.0


class LimitViolation(Exception):
    """Raised when a hard system limit is exceeded and no recovery is possible."""
    def __init__(self, limit_name: str, value: float, limit: float) -> None:
        self.limit_name = limit_name
        self.value = value
        self.limit = limit
        super().__init__(
            f"LIMIT VIOLATION: {limit_name} = {value:.2f} exceeds hard limit {limit:.2f}"
        )


def check_session_count(count: int) -> None:
    if count > MAX_CONCURRENT_SESSIONS:
        raise LimitViolation("MAX_CONCURRENT_SESSIONS", float(count), float(MAX_CONCURRENT_SESSIONS))


def check_player_count(count: int) -> None:
    if count > MAX_PLAYERS_PER_SESSION:
        raise LimitViolation("MAX_PLAYERS_PER_SESSION", float(count), float(MAX_PLAYERS_PER_SESSION))


def check_memory(used_kb: int) -> None:
    if used_kb > MEM_CRITICAL_KB:
        raise LimitViolation("MEM_CRITICAL_KB", float(used_kb), float(MEM_CRITICAL_KB))
