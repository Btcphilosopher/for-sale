"""
ARCADIUM OS — runtime/execution_engine.py
Executes all active sessions each frame.
Enforces CPU and memory budget constraints.
Drives performance degradation when over budget.
"""
import time
from dataclasses import dataclass, field
from typing import Optional

from sessions.session import Session, SessionState
from sessions.session_manager import SessionManager
from runtime.performance_budget import PerformanceBudget
from simulation.cost_model import CostModel, FrameCostBreakdown
from simulation.hardware_profile import HardwareProfile
from simulation.load_simulator import LoadSimulator
from utils.logging import log
from utils.timing import Stopwatch


@dataclass
class ExecutionFrame:
    """Result of one execution engine frame."""
    frame:           int
    sessions_run:    int
    sessions_paused: int
    cpu_budget_us:   float
    cpu_spent_us:    float
    mem_used_kb:     int
    utilisation:     float
    degraded:        bool
    breakdown:       Optional[FrameCostBreakdown] = None


class ExecutionEngine:
    """
    Per-frame execution driver.

    Each kernel tick calls execute_frame(), which:
      1. Queries active sessions from SessionManager
      2. Computes expected CPU cost via CostModel
      3. Determines performance mode (full/balanced/optimised)
      4. Records actual spend via PerformanceBudget
      5. Updates session metrics
      6. Triggers degradation callbacks if over budget
    """

    def __init__(
        self,
        session_manager: SessionManager,
        hw_profile: HardwareProfile,
        cost_model: CostModel,
        budget: PerformanceBudget,
        load_sim: LoadSimulator,
    ) -> None:
        self._sessions  = session_manager
        self._hw        = hw_profile
        self._costs     = cost_model
        self._budget    = budget
        self._load_sim  = load_sim
        self._frame     = 0
        self._stopwatch = Stopwatch()

        # Wire budget callbacks to logger
        self._budget.on_budget_warn     = self._on_warn
        self._budget.on_budget_degrade  = self._on_degrade
        self._budget.on_budget_critical = self._on_critical
        self._budget.on_budget_restored = self._on_restored

    # ── Main frame tick ───────────────────────────────────────────────────

    def execute_frame(self, frame: int, active_device_count: int) -> ExecutionFrame:
        """
        Execute one complete frame for all active sessions.
        Called by the real-time kernel each tick.
        """
        self._frame = frame
        self._stopwatch.start()

        # Advance load simulation and update thermal model
        cpu_load, mem_load = self._load_sim.tick()
        self._hw.update_thermal(cpu_load)

        effective_budget = self._hw.effective_budget_us
        self._budget.begin_frame(frame, effective_budget)

        # Gather running sessions
        running  = self._sessions.running_sessions()
        all_sess = self._sessions.all_sessions()

        # Compute estimated cost for this frame
        breakdown = self._costs.compute_frame_cost(
            active_device_count=active_device_count,
            sessions=running,
            ui_active=True,
        )
        mem = self._costs.compute_memory_cost(running, active_device_count)

        # Scale simulated costs by actual load factor
        load_scale = 0.6 + (cpu_load * 0.8)  # [0.6, 1.4] range
        kernel_us  = breakdown.kernel_us  * load_scale
        input_us   = breakdown.input_us   * load_scale
        session_us = breakdown.session_us * load_scale
        render_us  = breakdown.render_us  * load_scale
        ui_us      = breakdown.ui_us      * load_scale

        # Apply degradation savings
        if self._costs.degradation_active:
            session_us += breakdown.degradation_us  # degradation_us is negative
            render_us  = max(render_us * 0.5, 200.0)

        # Record subsystem spends
        self._budget.record_spend("kernel",  kernel_us)
        self._budget.record_spend("input",   input_us)
        self._budget.record_spend("session", max(0.0, session_us))
        self._budget.record_spend("render",  max(0.0, render_us))
        self._budget.record_spend("ui",      ui_us)

        # Finalize frame budget accounting
        snap = self._budget.end_frame()

        # Update per-session metrics
        per_session_us = session_us / max(len(running), 1)
        for s in running:
            s.metrics.record_frame(
                cpu_us=per_session_us,
                degraded=self._costs.degradation_active,
            )

        # Thermal throttle warning
        if self._hw.is_throttling and frame % 60 == 0:
            log.warn("ENGINE", f"Thermal throttle active — load={self._hw.thermal_load*100:.1f}%")

        elapsed = self._stopwatch.stop()

        return ExecutionFrame(
            frame=frame,
            sessions_run=len(running),
            sessions_paused=sum(1 for s in all_sess if s.state == SessionState.PAUSED),
            cpu_budget_us=effective_budget,
            cpu_spent_us=snap.total_spent_us,
            mem_used_kb=mem.total_kb,
            utilisation=snap.utilisation,
            degraded=snap.degraded,
            breakdown=breakdown,
        )

    # ── Budget callbacks ──────────────────────────────────────────────────

    def _on_warn(self, util: float) -> None:
        log.perf("ENGINE", f"Budget warn: {util*100:.1f}% used")

    def _on_degrade(self, util: float) -> None:
        mode = self._costs.mode_label()
        log.perf("ENGINE", f"Degradation active [{mode}]: {util*100:.1f}% budget consumed")

    def _on_critical(self, util: float) -> None:
        log.perf("ENGINE", f"CRITICAL OVERRUN {util*100:.1f}% — emergency reduction applied")

    def _on_restored(self) -> None:
        log.perf("ENGINE", "Full fidelity restored — budget within limits")

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def is_degraded(self) -> bool:
        return self._budget.is_degraded

    @property
    def current_mode(self) -> str:
        return self._costs.mode_label()

    @property
    def budget_utilisation(self) -> float:
        return self._budget.current_utilisation

    def status(self) -> dict:
        deg = self._budget.degradation_status()
        return {
            "frame":         self._frame,
            "mode":          self.current_mode,
            "degraded":      self.is_degraded,
            "utilisation":   round(self.budget_utilisation * 100, 1),
            "thermal_pct":   round(self._hw.thermal_load * 100, 1),
            "throttling":    self._hw.is_throttling,
            "ai_degraded":   deg["ai_degraded"],
            "freq_reduced":  deg["freq_reduced"],
            "render_simple": deg["render_simplified"],
            "budget_streak": deg["streak"],
        }
