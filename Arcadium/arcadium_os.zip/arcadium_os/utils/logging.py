"""
ARCADIUM OS — utils/logging.py
Structured ring-buffer logger. Thread-safe, zero-allocation hot path.
Subsystem-tagged, frame-stamped log entries.
"""
import time
import threading
from enum import Enum
from dataclasses import dataclass, field
from collections import deque
from typing import Optional


class LogLevel(Enum):
    DEBUG    = 0
    INFO     = 1
    WARN     = 2
    ERROR    = 3
    CRITICAL = 4
    KERNEL   = 5   # RTK internal messages
    PERF     = 6   # Performance budget events
    INPUT    = 7   # Input pipeline events
    SESSION  = 8   # Session lifecycle events


LEVEL_TAG: dict[LogLevel, str] = {
    LogLevel.DEBUG:    "DBG",
    LogLevel.INFO:     "INF",
    LogLevel.WARN:     "WRN",
    LogLevel.ERROR:    "ERR",
    LogLevel.CRITICAL: "CRT",
    LogLevel.KERNEL:   "RTK",
    LogLevel.PERF:     "PRF",
    LogLevel.INPUT:    "INP",
    LogLevel.SESSION:  "SES",
}

LEVEL_COLOUR: dict[LogLevel, str] = {
    LogLevel.DEBUG:    "dim white",
    LogLevel.INFO:     "bright_white",
    LogLevel.WARN:     "yellow",
    LogLevel.ERROR:    "red",
    LogLevel.CRITICAL: "bright_red",
    LogLevel.KERNEL:   "cyan",
    LogLevel.PERF:     "magenta",
    LogLevel.INPUT:    "green",
    LogLevel.SESSION:  "gold1",
}


@dataclass(slots=True)
class LogEntry:
    level:     LogLevel
    subsystem: str
    message:   str
    timestamp: float  # seconds since logger init
    frame:     int
    thread_id: int


class ArcadiumLogger:
    """
    Singleton structured logger.
    Ring buffer of max_entries, never blocks the kernel loop.
    """
    _instance: Optional['ArcadiumLogger'] = None
    _class_lock: threading.Lock = threading.Lock()

    def __init__(self, max_entries: int = 1000) -> None:
        self._entries: deque[LogEntry] = deque(maxlen=max_entries)
        self._lock = threading.Lock()
        self._frame: int = 0
        self._start: float = time.perf_counter()

    # ── Singleton accessor ────────────────────────────────────────────────
    @classmethod
    def get(cls) -> 'ArcadiumLogger':
        if cls._instance is None:
            with cls._class_lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    # ── Kernel integration ────────────────────────────────────────────────
    def set_frame(self, frame: int) -> None:
        """Called by tick engine each frame — zero cost."""
        self._frame = frame

    # ── Core write ────────────────────────────────────────────────────────
    def log(self, level: LogLevel, subsystem: str, message: str) -> None:
        entry = LogEntry(
            level=level,
            subsystem=subsystem[:8],
            message=message,
            timestamp=time.perf_counter() - self._start,
            frame=self._frame,
            thread_id=threading.get_ident(),
        )
        with self._lock:
            self._entries.append(entry)

    # ── Convenience methods ───────────────────────────────────────────────
    def kernel(self, msg: str) -> None:
        self.log(LogLevel.KERNEL, "RTK", msg)

    def info(self, subsystem: str, msg: str) -> None:
        self.log(LogLevel.INFO, subsystem, msg)

    def debug(self, subsystem: str, msg: str) -> None:
        self.log(LogLevel.DEBUG, subsystem, msg)

    def warn(self, subsystem: str, msg: str) -> None:
        self.log(LogLevel.WARN, subsystem, msg)

    def error(self, subsystem: str, msg: str) -> None:
        self.log(LogLevel.ERROR, subsystem, msg)

    def critical(self, subsystem: str, msg: str) -> None:
        self.log(LogLevel.CRITICAL, subsystem, msg)

    def perf(self, subsystem: str, msg: str) -> None:
        self.log(LogLevel.PERF, subsystem, msg)

    def input_ev(self, msg: str) -> None:
        self.log(LogLevel.INPUT, "INPUT", msg)

    def session(self, msg: str) -> None:
        self.log(LogLevel.SESSION, "SESSION", msg)

    # ── Read access ───────────────────────────────────────────────────────
    def get_recent(
        self,
        n: int = 30,
        min_level: LogLevel = LogLevel.DEBUG,
        subsystem: Optional[str] = None,
    ) -> list[LogEntry]:
        with self._lock:
            entries = list(self._entries)
        filtered = [
            e for e in entries
            if e.level.value >= min_level.value
            and (subsystem is None or e.subsystem == subsystem)
        ]
        return filtered[-n:]

    def get_all(self) -> list[LogEntry]:
        with self._lock:
            return list(self._entries)

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()

    @property
    def entry_count(self) -> int:
        with self._lock:
            return len(self._entries)


# ── Module-level singleton shortcut ───────────────────────────────────────────
log = ArcadiumLogger.get()
