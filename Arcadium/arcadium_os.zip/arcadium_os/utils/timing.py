"""
ARCADIUM OS — utils/timing.py
High-precision frame timing and sleep utilities.
Designed for deterministic 60fps kernel loop execution.
"""
import time
from dataclasses import dataclass, field
from typing import Optional

# Frame rate constants
TARGET_FPS: int = 60
FRAME_TIME_S: float = 1.0 / TARGET_FPS           # 0.016666... seconds
FRAME_TIME_MS: float = FRAME_TIME_S * 1_000.0     # 16.666... ms
FRAME_TIME_US: float = FRAME_TIME_S * 1_000_000.0 # 16,666... μs


@dataclass
class FrameTimer:
    """
    Fixed-timestep frame timer for the real-time kernel loop.
    Tracks FPS, frame delta, and frame budget utilisation.
    """
    target_fps: int = TARGET_FPS

    _last_tick: float = field(default=0.0, init=False)
    _frame_start: float = field(default=0.0, init=False)
    _frame_count: int = field(default=0, init=False)
    _fps_sample_count: int = field(default=0, init=False)
    _fps_sample_accum: float = field(default=0.0, init=False)
    _current_fps: float = field(default=0.0, init=False)
    _total_frames: int = field(default=0, init=False)
    _last_delta: float = field(default=0.0, init=False)

    def __post_init__(self) -> None:
        self._last_tick = time.perf_counter()
        self._frame_start = self._last_tick

    @property
    def frame_time(self) -> float:
        return 1.0 / self.target_fps

    @property
    def frame_time_us(self) -> float:
        return self.frame_time * 1_000_000.0

    def begin_frame(self) -> float:
        """
        Mark frame start. Returns delta time since last frame in seconds.
        Call this at the very top of the kernel loop.
        """
        now = time.perf_counter()
        delta = now - self._last_tick
        self._last_tick = now
        self._frame_start = now
        self._last_delta = delta

        # Running FPS average (1-second window)
        self._fps_sample_accum += delta
        self._fps_sample_count += 1
        if self._fps_sample_accum >= 1.0:
            self._current_fps = self._fps_sample_count / self._fps_sample_accum
            self._fps_sample_count = 0
            self._fps_sample_accum = 0.0

        self._total_frames += 1
        self._frame_count += 1
        return delta

    def end_frame(self) -> float:
        """
        Mark frame end. Returns actual frame elapsed time in seconds.
        Sleeps for remaining budget if frame finished early.
        """
        elapsed = time.perf_counter() - self._frame_start
        remaining = self.frame_time - elapsed
        if remaining > 0.0:
            sleep_precise(remaining)
        return elapsed

    def frame_elapsed_us(self) -> float:
        """Return microseconds elapsed since this frame began."""
        return (time.perf_counter() - self._frame_start) * 1_000_000.0

    def frame_budget_remaining_us(self) -> float:
        """Return remaining frame budget in microseconds."""
        return self.frame_time_us - self.frame_elapsed_us()

    def frame_budget_pct(self) -> float:
        """Return fraction of frame budget consumed [0.0–1.0+]."""
        return self.frame_elapsed_us() / self.frame_time_us

    @property
    def current_fps(self) -> float:
        return self._current_fps if self._current_fps > 0 else float(self.target_fps)

    @property
    def total_frames(self) -> int:
        return self._total_frames

    @property
    def last_delta(self) -> float:
        return self._last_delta


def sleep_precise(seconds: float) -> None:
    """
    High-precision sleep. Uses OS sleep for the bulk, then busy-waits
    for the final ~0.5ms to hit the target with minimal overshoot.
    """
    if seconds <= 0.0:
        return
    deadline = time.perf_counter() + seconds
    coarse_sleep = seconds - 0.0005
    if coarse_sleep > 0.0:
        time.sleep(coarse_sleep)
    # Busy-wait the final 0.5ms
    while time.perf_counter() < deadline:
        pass


def monotonic_ns() -> int:
    """Monotonic nanosecond timestamp."""
    return time.monotonic_ns()


def perf_us() -> float:
    """Current performance counter in microseconds."""
    return time.perf_counter() * 1_000_000.0


class Stopwatch:
    """Simple microsecond stopwatch for profiling subsystems."""

    def __init__(self) -> None:
        self._start: float = 0.0
        self._elapsed_us: float = 0.0
        self._running: bool = False

    def start(self) -> 'Stopwatch':
        self._start = time.perf_counter()
        self._running = True
        return self

    def stop(self) -> float:
        if self._running:
            self._elapsed_us = (time.perf_counter() - self._start) * 1_000_000.0
            self._running = False
        return self._elapsed_us

    def lap_us(self) -> float:
        """Read elapsed without stopping."""
        if self._running:
            return (time.perf_counter() - self._start) * 1_000_000.0
        return self._elapsed_us

    @property
    def elapsed_us(self) -> float:
        return self.lap_us()

    def __enter__(self) -> 'Stopwatch':
        return self.start()

    def __exit__(self, *_) -> None:
        self.stop()
