"""
ARCADIUM OS — kernel/scheduler.py
Priority-based real-time task scheduler.

Tasks are registered with a priority (0=lowest, 7=kernel/realtime)
and an execution interval (every N frames). The scheduler dispatches
them in priority order within each kernel tick, respecting frame budget.
"""
import time
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Callable, Optional

from utils.logging import log


class Priority(IntEnum):
    IDLE        = 0
    BACKGROUND  = 1
    LOW         = 2
    NORMAL      = 3
    HIGH        = 4
    CRITICAL    = 5
    REALTIME    = 6
    KERNEL      = 7


@dataclass
class ScheduledTask:
    """A recurring task managed by the scheduler."""
    name:          str
    callback:      Callable[[], None]
    priority:      Priority
    interval:      int    = 1        # execute every N frames
    budget_us:     float  = 1000.0  # expected execution time
    enabled:       bool   = True
    # Runtime state
    last_frame:    int    = field(default=0, init=False)
    exec_count:    int    = field(default=0, init=False)
    total_us:      float  = field(default=0.0, init=False)
    last_us:       float  = field(default=0.0, init=False)
    overruns:      int    = field(default=0, init=False)

    def should_run(self, frame: int) -> bool:
        if not self.enabled:
            return False
        return (frame - self.last_frame) >= self.interval

    def record_run(self, frame: int, elapsed_us: float) -> None:
        self.last_frame = frame
        self.exec_count += 1
        self.total_us += elapsed_us
        self.last_us = elapsed_us
        if elapsed_us > self.budget_us * 1.2:
            self.overruns += 1

    @property
    def avg_us(self) -> float:
        if self.exec_count == 0:
            return 0.0
        return self.total_us / self.exec_count


class Scheduler:
    """
    Fixed-priority preemptive scheduler simulation.
    Tasks at higher priority always run before lower priority tasks.
    Tasks are skipped if their interval hasn't elapsed.
    """

    def __init__(self) -> None:
        self._tasks: list[ScheduledTask] = []
        self._frame: int = 0
        self._dispatch_count: int = 0
        self._total_dispatch_us: float = 0.0

    def register(
        self,
        name: str,
        callback: Callable[[], None],
        priority: Priority = Priority.NORMAL,
        interval: int = 1,
        budget_us: float = 1000.0,
    ) -> ScheduledTask:
        """Register a task with the scheduler."""
        task = ScheduledTask(
            name=name,
            callback=callback,
            priority=priority,
            interval=interval,
            budget_us=budget_us,
        )
        self._tasks.append(task)
        # Keep sorted highest priority first
        self._tasks.sort(key=lambda t: t.priority, reverse=True)
        log.kernel(f"Scheduler: registered task [{name}] prio={priority.name} interval={interval}")
        return task

    def unregister(self, name: str) -> bool:
        before = len(self._tasks)
        self._tasks = [t for t in self._tasks if t.name != name]
        return len(self._tasks) < before

    def tick(self, frame: int) -> int:
        """
        Execute all due tasks for this frame in priority order.
        Returns the number of tasks dispatched.
        """
        self._frame = frame
        dispatched = 0

        for task in self._tasks:
            if not task.should_run(frame):
                continue

            t_start = time.perf_counter()
            try:
                task.callback()
            except Exception as exc:
                log.error("SCHEDULER", f"Task [{task.name}] raised: {exc}")
            elapsed_us = (time.perf_counter() - t_start) * 1_000_000.0
            task.record_run(frame, elapsed_us)
            dispatched += 1
            self._dispatch_count += 1
            self._total_dispatch_us += elapsed_us

        return dispatched

    def enable(self, name: str) -> None:
        for t in self._tasks:
            if t.name == name:
                t.enabled = True

    def disable(self, name: str) -> None:
        for t in self._tasks:
            if t.name == name:
                t.enabled = False

    def get_task(self, name: str) -> Optional[ScheduledTask]:
        for t in self._tasks:
            if t.name == name:
                return t
        return None

    def task_report(self) -> list[dict]:
        return [
            {
                "name":      t.name,
                "priority":  t.priority.name,
                "interval":  t.interval,
                "enabled":   t.enabled,
                "runs":      t.exec_count,
                "last_us":   round(t.last_us, 1),
                "avg_us":    round(t.avg_us, 1),
                "overruns":  t.overruns,
            }
            for t in self._tasks
        ]

    @property
    def task_count(self) -> int:
        return len(self._tasks)

    @property
    def dispatch_count(self) -> int:
        return self._dispatch_count
