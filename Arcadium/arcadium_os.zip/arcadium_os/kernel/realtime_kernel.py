"""
ARCADIUM OS — kernel/realtime_kernel.py
Top-level OS kernel. Wires all subsystems together and drives the
fixed-timestep loop.

Boot sequence:
  1. Initialise hardware profile
  2. Initialise cost model + budget
  3. Initialise input pipeline
  4. Initialise session manager
  5. Initialise execution engine
  6. Register scheduler tasks
  7. Start tick engine

The kernel exposes a clean API to the UI layer — it never calls UI code
directly, keeping the OS/UI boundary clean.
"""
import threading
import time
from dataclasses import dataclass
from typing import Optional

from simulation.hardware_profile import HardwareProfile
from simulation.cost_model import CostModel
from simulation.load_simulator import LoadSimulator, LoadPattern
from runtime.performance_budget import PerformanceBudget
from runtime.execution_engine import ExecutionEngine
from input.device_layer import DeviceRegistry, DeviceType, InputDevice
from input.intent_system import IntentMapper
from input.player_slot_manager import PlayerSlotManager
from input.input_router import InputRouter
from sessions.session import Session
from sessions.session_manager import SessionManager
from kernel.scheduler import Scheduler, Priority
from kernel.tick_engine import TickEngine
from utils.logging import log


@dataclass
class KernelState:
    """Snapshot of kernel state for UI consumption."""
    frame:           int
    fps:             float
    uptime_s:        float
    sessions:        int
    total_players:   int
    devices:         int
    budget_pct:      float
    degraded:        bool
    perf_mode:       str
    thermal_pct:     float
    throttling:      bool
    mem_used_kb:     int


class RealtimeKernel:
    """
    Arcadium OS Real-Time Kernel (RTK).

    All subsystems are instantiated and wired here.
    The kernel owns the tick engine and scheduler.
    """

    def __init__(self) -> None:
        log.kernel("RTK: initialising Arcadium OS")

        # ── Hardware layer ────────────────────────────────────────────────
        self.hw          = HardwareProfile()
        self.load_sim    = LoadSimulator()
        self.cost_model  = CostModel(self.hw)
        self.budget      = PerformanceBudget(self.hw.available_budget_us)

        # ── Input pipeline ────────────────────────────────────────────────
        self.device_reg  = DeviceRegistry()
        self.intent_map  = IntentMapper()
        self.slot_mgr    = PlayerSlotManager()
        self.input_router = InputRouter(self.device_reg, self.intent_map, self.slot_mgr)

        # ── Session layer ─────────────────────────────────────────────────
        self.session_mgr = SessionManager()

        # ── Execution engine ──────────────────────────────────────────────
        self.exec_engine = ExecutionEngine(
            session_manager=self.session_mgr,
            hw_profile=self.hw,
            cost_model=self.cost_model,
            budget=self.budget,
            load_sim=self.load_sim,
        )

        # ── Kernel scheduler ──────────────────────────────────────────────
        self.scheduler   = Scheduler()
        self._register_tasks()

        # ── Tick engine ───────────────────────────────────────────────────
        self.tick_engine = TickEngine(target_fps=60)
        self.tick_engine.add_callback(self._kernel_tick, priority=0)

        # ── Runtime state ─────────────────────────────────────────────────
        self._last_exec_us: float = 0.0
        self._last_mem_kb:  int   = 0
        self._running       = False
        self._lock          = threading.Lock()

        log.kernel("RTK: initialisation complete")

    # ── Boot / shutdown ───────────────────────────────────────────────────

    def boot(self) -> None:
        """Start the kernel. Non-blocking."""
        if self._running:
            return
        self._running = True
        self.load_sim.set_pattern(LoadPattern.IDLE, "boot")
        self.tick_engine.start(blocking=False)
        log.kernel("RTK: kernel boot complete — tick engine running")

    def shutdown(self) -> None:
        """Clean shutdown of all subsystems."""
        log.kernel("RTK: shutdown initiated")
        # End all sessions
        for s in self.session_mgr.all_sessions():
            self.session_mgr.destroy_session(s.session_id, "shutdown")
        self.tick_engine.stop()
        self._running = False
        log.kernel("RTK: shutdown complete")

    # ── Per-frame kernel tick (called by TickEngine) ───────────────────────

    def _kernel_tick(self, frame: int, delta_s: float) -> None:
        """Main kernel tick — runs every frame inside the tick engine thread."""
        # 1. Scheduler dispatch
        self.scheduler.tick(frame)

    # ── Scheduled tasks ───────────────────────────────────────────────────

    def _register_tasks(self) -> None:
        self.scheduler.register(
            "input.tick",
            self._task_input,
            priority=Priority.REALTIME,
            interval=1,
            budget_us=1_500.0,
        )
        self.scheduler.register(
            "execution.tick",
            self._task_execution,
            priority=Priority.KERNEL,
            interval=1,
            budget_us=12_000.0,
        )
        self.scheduler.register(
            "session.housekeep",
            self._task_session_housekeep,
            priority=Priority.HIGH,
            interval=60,   # once per second
            budget_us=500.0,
        )
        self.scheduler.register(
            "load.pattern_rotate",
            self._task_load_pattern,
            priority=Priority.BACKGROUND,
            interval=600,   # every 10 seconds
            budget_us=50.0,
        )

    def _task_input(self) -> None:
        self.input_router.tick()

    def _task_execution(self) -> None:
        frame = self.tick_engine.frame
        result = self.exec_engine.execute_frame(
            frame=frame,
            active_device_count=self.input_router.active_device_count(),
        )
        self._last_exec_us = result.cpu_spent_us
        self._last_mem_kb  = result.mem_used_kb

    def _task_session_housekeep(self) -> None:
        """Remove fully ended sessions from the registry."""
        from sessions.session import SessionState
        for s in list(self.session_mgr.all_sessions()):
            if s.state == SessionState.ENDED:
                self.session_mgr._sessions.pop(s.session_id, None)
                self.session_mgr._lifecycles.pop(s.session_id, None)

    _LOAD_CYCLE = [
        LoadPattern.IDLE,
        LoadPattern.RAMP_UP,
        LoadPattern.BURST,
        LoadPattern.WAVE,
        LoadPattern.SUSTAINED,
        LoadPattern.RANDOM_SPIKE,
        LoadPattern.PLAYER_JOIN,
    ]
    _load_idx = 0

    def _task_load_pattern(self) -> None:
        """Rotate through load patterns to exercise the cost model."""
        pattern = self._LOAD_CYCLE[self._load_idx % len(self._LOAD_CYCLE)]
        self.load_sim.set_pattern(pattern)
        self._load_idx += 1

    # ── High-level OS API (called by UI) ──────────────────────────────────

    def create_session(self, game_title: Optional[str] = None) -> Optional[Session]:
        try:
            return self.session_mgr.create_session(game_title=game_title)
        except Exception as e:
            log.error("RTK", f"create_session failed: {e}")
            return None

    def end_session(self, session_id: str) -> bool:
        return self.session_mgr.destroy_session(session_id, "user request")

    def pause_session(self, session_id: str) -> bool:
        return self.session_mgr.pause_session(session_id)

    def resume_session(self, session_id: str) -> bool:
        return self.session_mgr.resume_session(session_id)

    def add_device(
        self,
        device_type: DeviceType,
        session_id: Optional[str] = None,
        preferred_slot: Optional[int] = None,
    ) -> tuple[InputDevice, int]:
        device, slot = self.input_router.connect_device(
            device_type, session_id=session_id, preferred_slot=preferred_slot
        )
        if session_id and slot > 0:
            self.session_mgr.add_player(session_id, slot)
        return device, slot

    def remove_device(self, device_id: str, session_id: Optional[str] = None) -> None:
        slot = self.slot_mgr.slot_for_device(device_id)
        if slot and session_id:
            self.session_mgr.remove_player(session_id, slot)
        self.input_router.disconnect_device(device_id)

    def inject_load_spike(self, magnitude: float = 0.9) -> None:
        self.load_sim.inject_spike(magnitude, duration_s=1.0)
        log.kernel(f"RTK: manual load spike injected magnitude={magnitude:.2f}")

    # ── State snapshot (thread-safe, for UI) ──────────────────────────────

    def state(self) -> KernelState:
        ts = self.tick_engine.stats
        return KernelState(
            frame=self.tick_engine.frame,
            fps=round(ts.current_fps, 1),
            uptime_s=round(self.tick_engine.uptime, 1),
            sessions=self.session_mgr.session_count,
            total_players=self.session_mgr.total_players(),
            devices=self.input_router.active_device_count(),
            budget_pct=round(self.budget.current_utilisation * 100, 1),
            degraded=self.exec_engine.is_degraded,
            perf_mode=self.exec_engine.current_mode,
            thermal_pct=round(self.hw.thermal_load * 100, 1),
            throttling=self.hw.is_throttling,
            mem_used_kb=self._last_mem_kb,
        )

    @property
    def is_running(self) -> bool:
        return self._running
