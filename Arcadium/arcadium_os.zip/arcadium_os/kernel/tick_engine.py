"""
ARCADIUM OS — kernel/tick_engine.py
Fixed-timestep kernel loop. Drives the entire OS at a stable 60 FPS.

Design principles:
  - No frame drift: uses accumulated-time model for stability
  - Watchdog: detects and recovers from frozen loops
  - Frame budget tracking: reports overruns to performance system
  - Clean shutdown: cooperative stop signal
"""
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

from utils.timing import FrameTimer, sleep_precise, FRAME_TIME_US
from utils.logging import log, ArcadiumLogger
from runtime.system_limits import WATCHDOG_TIMEOUT_FRAMES, FRAME_SKIP_MAX


@dataclass
class TickStats:
    """Aggregate tick engine statistics."""
    total_frames:    int   = 0
    overrun_frames:  int   = 0
    skipped_frames:  int   = 0
    avg_frame_us:    float = 0.0
    peak_frame_us:   float = 0.0
    current_fps:     float = 0.0
    uptime_s:        float = 0.0


TickCallback = Callable[[int, float], None]
"""Signature: callback(frame_number: int, delta_s: float)"""


class TickEngine:
    """
    Fixed-timestep tick loop running at TARGET_FPS (60).

    Usage:
        engine = TickEngine()
        engine.add_callback(my_system.tick)
        engine.start()   # non-blocking, runs in background thread
        ...
        engine.stop()
    """

    def __init__(self, target_fps: int = 60) -> None:
        self._timer      = FrameTimer(target_fps=target_fps)
        self._callbacks: list[tuple[int, TickCallback]] = []  # (priority, cb)
        self._running    = False
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._frame      = 0
        self._start_time = 0.0
        self._stats      = TickStats()
        self._lock       = threading.Lock()

        # Watchdog
        self._last_tick_time = time.perf_counter()
        self._watchdog_fire_count = 0

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def start(self, blocking: bool = False) -> None:
        """Start the tick loop. Non-blocking by default (background thread)."""
        if self._running:
            return
        self._running    = True
        self._start_time = time.perf_counter()
        self._stop_event.clear()
        log.kernel("TickEngine: starting fixed-timestep loop @ 60 FPS")

        if blocking:
            self._run_loop()
        else:
            self._thread = threading.Thread(
                target=self._run_loop,
                name="ArcadiumOS-TickEngine",
                daemon=True,
            )
            self._thread.start()

    def stop(self) -> None:
        """Signal the tick loop to stop cleanly."""
        self._running = False
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        log.kernel(f"TickEngine: stopped at frame {self._frame}")

    def is_running(self) -> bool:
        return self._running

    # ── Callback registration ─────────────────────────────────────────────

    def add_callback(self, cb: TickCallback, priority: int = 50) -> None:
        """
        Register a per-frame callback.
        Lower priority number = runs earlier in the frame.
        """
        with self._lock:
            self._callbacks.append((priority, cb))
            self._callbacks.sort(key=lambda x: x[0])
        log.kernel(f"TickEngine: registered callback {cb.__name__} prio={priority}")

    def remove_callback(self, cb: TickCallback) -> None:
        with self._lock:
            self._callbacks = [(p, c) for p, c in self._callbacks if c is not cb]

    # ── Main loop ─────────────────────────────────────────────────────────

    def _run_loop(self) -> None:
        logger = ArcadiumLogger.get()
        accumulated_us = 0.0
        peak_us = 0.0
        total_us = 0.0

        while self._running and not self._stop_event.is_set():
            # Begin frame timing
            delta_s = self._timer.begin_frame()
            self._frame += 1
            frame = self._frame
            logger.set_frame(frame)
            self._last_tick_time = time.perf_counter()

            # Cap delta to prevent spiral-of-death after pause/lag
            delta_s = min(delta_s, FRAME_TIME_US * 3 / 1_000_000.0)

            # Execute all registered callbacks in priority order
            frame_start = time.perf_counter()
            with self._lock:
                cbs = list(self._callbacks)
            for _, cb in cbs:
                try:
                    cb(frame, delta_s)
                except Exception as exc:
                    log.error("TICK", f"Callback {cb.__name__} frame {frame}: {exc}")

            # Measure frame time
            elapsed_us = (time.perf_counter() - frame_start) * 1_000_000.0
            total_us  += elapsed_us
            peak_us    = max(peak_us, elapsed_us)
            overrun    = elapsed_us > FRAME_TIME_US

            # Update stats
            self._stats = TickStats(
                total_frames=frame,
                overrun_frames=self._stats.overrun_frames + (1 if overrun else 0),
                avg_frame_us=total_us / frame,
                peak_frame_us=peak_us,
                current_fps=self._timer.current_fps,
                uptime_s=time.perf_counter() - self._start_time,
            )

            # Log significant overruns (>50% over budget) every 60 frames max
            if overrun and elapsed_us > FRAME_TIME_US * 1.5 and frame % 60 == 0:
                log.perf("TICK", f"Frame {frame} overrun {elapsed_us:.0f}μs (budget={FRAME_TIME_US:.0f}μs)")

            # Yield remaining frame time
            self._timer.end_frame()

    # ── Watchdog ──────────────────────────────────────────────────────────

    def check_watchdog(self) -> bool:
        """
        Returns True if the tick engine appears frozen.
        Call from an external monitor thread if needed.
        """
        elapsed = time.perf_counter() - self._last_tick_time
        if elapsed > (WATCHDOG_TIMEOUT_FRAMES / 60.0):
            self._watchdog_fire_count += 1
            log.error("WATCHDOG", f"Tick engine stall detected! {elapsed:.2f}s since last tick")
            return True
        return False

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def frame(self) -> int:
        return self._frame

    @property
    def stats(self) -> TickStats:
        return self._stats

    @property
    def uptime(self) -> float:
        if not self._running:
            return 0.0
        return time.perf_counter() - self._start_time
