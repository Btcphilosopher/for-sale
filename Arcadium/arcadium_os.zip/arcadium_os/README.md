# ARCADIUM OS

**Low-Cost $100 Arcade Console Operating System**

A deterministic, session-based arcade operating system simulation for a constrained $100 embedded hardware platform.

---

## Architecture

```
arcadium_os/
├── kernel/
│   ├── realtime_kernel.py    # Top-level OS coordinator
│   ├── scheduler.py          # Priority-based task scheduler (8 levels)
│   └── tick_engine.py        # Fixed-timestep 60 FPS kernel loop
├── input/
│   ├── device_layer.py       # Controller / Keyboard / Arcade Stick / Wheel
│   ├── intent_system.py      # Raw events → device-agnostic intents
│   ├── input_router.py       # Full pipeline: device → intent → slot
│   └── player_slot_manager.py# 8 dynamic player slots
├── sessions/
│   ├── session.py            # Session dataclass + metrics
│   ├── lifecycle.py          # State machine (CREATING→WAITING→RUNNING→ENDED)
│   └── session_manager.py    # CRUD + budget allocation
├── runtime/
│   ├── execution_engine.py   # Per-frame session execution + cost enforcement
│   ├── performance_budget.py # Frame-level μs budget tracker
│   └── system_limits.py      # Hard constraints and thresholds
├── simulation/
│   ├── hardware_profile.py   # $100 hardware spec (ARM Cortex-A55 class)
│   ├── cost_model.py         # CPU/memory cost per operation
│   └── load_simulator.py     # Synthetic load patterns
├── ui/
│   ├── launcher.py           # Rich terminal dashboard + command loop
│   └── session_overlay.py    # Session/slot Rich panels
├── utils/
│   ├── logging.py            # Ring-buffer structured logger
│   └── timing.py             # High-precision frame timer
└── main.py                   # Entry point
```

---

## Hardware Target

| Component | Spec |
|-----------|------|
| CPU | 4× ARM Cortex-A55 @ 1.8 GHz |
| RAM | 1 GB LPDDR4 (~400 MB usable) |
| GPU | Mali-G52 class, 720p |
| Storage | 32 GB eMMC |
| Wi-Fi | 802.11n (updates/store only) |
| Frame budget | 16,666 μs @ 60 FPS |

---

## Running

```bash
# Interactive terminal dashboard (requires Rich)
pip install rich
python main.py

# Headless stress test (30 seconds)
python main.py --headless --duration 30

# Extended stress test to trigger full degradation cascade
python main.py --headless --duration 90
```

---

## Performance Modes

| Players | Mode |
|---------|------|
| 1–2 | FULL FIDELITY |
| 3–5 | BALANCED |
| 6–8 | OPTIMISED |

**Degradation cascade** (triggered when budget > threshold):
1. **88%** — AI complexity reduced (~250 μs savings per session)
2. **93%** — Update frequency reduced (~300 μs savings)
3. **97%** — Render pipeline simplified (~500 μs savings)
4. **98% × 5 frames** — Emergency: all degradations active

---

## Interactive Commands

| Key | Action |
|-----|--------|
| `C` | Create session |
| `E` | End session |
| `P` | Pause first running session |
| `R` | Resume first paused session |
| `D` | Connect device (prompts type + session) |
| `K` | Disconnect device |
| `S` | Inject load spike (0.95 magnitude) |
| `L` | List all sessions |
| `Q` | Quit |
