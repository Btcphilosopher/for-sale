"""
ARCADIUM OS — main.py
Entry point. Boots the kernel, seeds demo content, launches the terminal UI.

Usage:
    python main.py [--headless] [--duration N]

    --headless    Run without interactive UI (stress-test mode, N seconds)
    --duration N  Headless run duration in seconds (default: 30)
"""
import argparse
import sys
import time
import os

# Ensure the arcadium_os directory is on the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from kernel.realtime_kernel import RealtimeKernel
from input.device_layer import DeviceType
from sessions.session import GAME_CATALOGUE
from simulation.load_simulator import LoadPattern
from utils.logging import log, ArcadiumLogger, LogLevel


# ── Demo seed ─────────────────────────────────────────────────────────────────

def seed_demo_content(kernel: RealtimeKernel) -> None:
    """
    Creates a realistic starting state:
      - 2 active sessions
      - 4 connected devices spread across both sessions
    """
    log.kernel("DEMO: seeding initial sessions and devices")
    time.sleep(0.3)  # allow kernel to stabilise

    # Session 1: 2-player fighter
    s1 = kernel.create_session("TITAN BRAWL")
    if s1:
        _, slot1 = kernel.add_device(DeviceType.CONTROLLER, session_id=s1.session_id)
        _, slot2 = kernel.add_device(DeviceType.ARCADE_STICK, session_id=s1.session_id)
        log.kernel(f"DEMO: {s1.game_title} — slots {slot1},{slot2}")

    # Session 2: racing game with wheel + keyboard spectator
    s2 = kernel.create_session("VELOCITY GRID")
    if s2:
        _, slot3 = kernel.add_device(DeviceType.STEERING_WHEEL, session_id=s2.session_id)
        _, slot4 = kernel.add_device(DeviceType.KEYBOARD, session_id=s2.session_id)
        log.kernel(f"DEMO: {s2.game_title} — slots {slot3},{slot4}")

    log.kernel(
        f"DEMO: seed complete — "
        f"{kernel.session_mgr.session_count} sessions, "
        f"{kernel.session_mgr.total_players()} players, "
        f"{kernel.input_router.active_device_count()} devices"
    )


# ── Headless stress runner ────────────────────────────────────────────────────

def run_headless(kernel: RealtimeKernel, duration: float) -> None:
    """
    Headless stress test: creates/destroys sessions, adds/removes devices,
    injects load spikes. Useful for verifying cost model without the UI.
    """
    from rich.console import Console
    from rich.live import Live
    from rich.table import Table
    from rich.panel import Panel
    from rich import box

    console = Console()
    console.print("[bold #C9A84C]Arcadium OS — Headless Stress Test[/]")
    console.print(f"Duration: {duration:.0f}s | Target: 60 FPS\n")

    seed_demo_content(kernel)

    start = time.perf_counter()
    phase = 0

    try:
        with Live(console=console, refresh_per_second=4) as live:
            while time.perf_counter() - start < duration:
                elapsed = time.perf_counter() - start
                ks = kernel.state()

                # Build status table
                t = Table(box=box.SIMPLE, show_header=True, header_style="bold #C9A84C")
                t.add_column("METRIC",  style="#C9A84C", width=20)
                t.add_column("VALUE",   style="#E0E0E0", width=20)
                t.add_column("METRIC",  style="#C9A84C", width=20)
                t.add_column("VALUE",   style="#E0E0E0", width=20)

                budget_col = "#44FF88" if ks.budget_pct < 75 else "#FFAA00" if ks.budget_pct < 92 else "#FF4444"
                t.add_row("ELAPSED",   f"{elapsed:.1f}s",
                           "FRAME",     f"{ks.frame:,}")
                t.add_row("FPS",        f"{ks.fps:.1f}",
                           "BUDGET",    f"[{budget_col}]{ks.budget_pct:.1f}%[/]")
                t.add_row("SESSIONS",   str(ks.sessions),
                           "PLAYERS",   str(ks.total_players))
                t.add_row("DEVICES",    str(ks.devices),
                           "MODE",      ks.perf_mode)
                t.add_row("DEGRADED",   str(ks.degraded),
                           "THERMAL",   f"{ks.thermal_pct:.1f}%")
                t.add_row("MEM USED",   f"{ks.mem_used_kb//1024}MB",
                           "PATTERN",   kernel.load_sim.current_pattern.name)

                # Recent log entries
                logger = ArcadiumLogger.get()
                recent = logger.get_recent(8, min_level=LogLevel.PERF)
                log_lines = []
                for e in recent:
                    log_lines.append(f"[dim]{e.timestamp:6.1f}s[/] [{e.level.name}] {e.message[:55]}")

                from rich.console import Group
                from rich.text import Text
                content = Group(
                    Panel(t, title="[bold #C9A84C]◈ ARCADIUM OS — STRESS TEST[/]", border_style="#C9A84C"),
                    Panel("\n".join(log_lines) or "...", title="[bold #C9A84C]◈ PERF LOG[/]", border_style="#444444"),
                )
                live.update(content)

                # Phase-based scenario progression
                new_phase = int(elapsed / 8)
                if new_phase != phase:
                    phase = new_phase
                    _run_stress_phase(kernel, phase)

                time.sleep(0.25)

    except KeyboardInterrupt:
        pass

    # Final report
    ts = kernel.tick_engine.stats
    console.print(f"\n[bold #C9A84C]── STRESS TEST COMPLETE ──────────────────────────[/]")
    console.print(f"Total frames:     {ts.total_frames:,}")
    console.print(f"Overrun frames:   {ts.overrun_frames:,} ({ts.overrun_frames/max(ts.total_frames,1)*100:.1f}%)")
    console.print(f"Avg frame time:   {ts.avg_frame_us:.0f}μs (budget={16_666:.0f}μs)")
    console.print(f"Peak frame time:  {ts.peak_frame_us:.0f}μs")
    console.print(f"Sessions created: {kernel.session_mgr._sessions.__len__() + 2}")
    console.print(f"Total log entries:{ArcadiumLogger.get().entry_count}")

    _print_final_log(console)


def _run_stress_phase(kernel: RealtimeKernel, phase: int) -> None:
    """Execute a stress scenario phase."""
    if phase == 1:
        log.kernel("STRESS: adding 3rd session")
        s = kernel.create_session("NEON COLOSSEUM")
        if s:
            kernel.add_device(DeviceType.CONTROLLER, session_id=s.session_id)
            kernel.add_device(DeviceType.KEYBOARD,   session_id=s.session_id)

    elif phase == 2:
        log.kernel("STRESS: injecting heavy load spike")
        kernel.inject_load_spike(0.98)

    elif phase == 3:
        log.kernel("STRESS: adding players to max out slots")
        sessions = kernel.session_mgr.running_sessions()
        if sessions:
            for dtype in [DeviceType.CONTROLLER, DeviceType.ARCADE_STICK, DeviceType.CONTROLLER]:
                kernel.add_device(dtype, session_id=sessions[0].session_id)

    elif phase == 4:
        log.kernel("STRESS: adding 4th session")
        s = kernel.create_session("IRON CIRCUIT")
        if s:
            kernel.add_device(DeviceType.ARCADE_STICK, session_id=s.session_id)

    elif phase == 5:
        log.kernel("STRESS: pausing session 1")
        sessions = kernel.session_mgr.running_sessions()
        if sessions:
            kernel.pause_session(sessions[0].session_id)

    elif phase == 6:
        log.kernel("STRESS: resuming + load wave")
        from sessions.session import SessionState
        paused = [s for s in kernel.session_mgr.all_sessions() if s.state == SessionState.PAUSED]
        for s in paused:
            kernel.resume_session(s.session_id)
        kernel.load_sim.set_pattern(LoadPattern.WAVE, "stress-wave")

    elif phase == 7:
        log.kernel("STRESS: destroying oldest session")
        sessions = kernel.session_mgr.all_sessions()
        if sessions:
            kernel.end_session(sessions[0].session_id)


def _print_final_log(console) -> None:
    logger = ArcadiumLogger.get()
    entries = logger.get_recent(20, min_level=LogLevel.PERF)
    if not entries:
        return
    console.print(f"\n[bold #C9A84C]── FINAL PERF LOG ──────────────────────────────[/]")
    for e in entries:
        console.print(f"  [{e.timestamp:6.1f}s] [{e.level.name:<8}] {e.subsystem:<8} {e.message}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="Arcadium OS — Arcade Console Operating System")
    parser.add_argument("--headless", action="store_true", help="Run headless stress test")
    parser.add_argument("--duration", type=float, default=60.0, help="Headless run duration (seconds)")
    args = parser.parse_args()

    # Initialise and boot the kernel
    kernel = RealtimeKernel()
    kernel.boot()

    try:
        if args.headless:
            run_headless(kernel, args.duration)
        else:
            # Seed demo content then launch interactive UI
            seed_demo_content(kernel)
            from ui.launcher import launch
            launch(kernel)
    except KeyboardInterrupt:
        pass
    finally:
        kernel.shutdown()
        print("\nArcadium OS offline.")


if __name__ == "__main__":
    main()
