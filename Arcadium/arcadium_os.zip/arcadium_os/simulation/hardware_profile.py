"""
ARCADIUM OS — simulation/hardware_profile.py
Simulated $100 arcade console hardware specification.

Based on a realistic low-cost SoC (ARM Cortex-A55 quad-core @ 1.8GHz class):
  - Approx. retail: $85–$105 BOM with casing + PSU
  - CPU budget expressed in simulated microseconds per frame
  - Memory expressed in kilobytes
  - GPU expressed as render units (RU) — simplified tile-based model
"""
from dataclasses import dataclass, field
from typing import Final


# ── Physical hardware spec (read-only constants) ──────────────────────────────

# CPU: 4x Cortex-A55 @ 1.8 GHz ≈ 7.2 GHz effective
# At 60 FPS: 7,200,000,000 / 60 ≈ 120,000,000 cycles per frame
# Simulated as microseconds (16,666 μs total per frame)
CPU_CORES:            Final[int]   = 4
CPU_CLOCK_MHZ:        Final[int]   = 1800
FRAME_BUDGET_US:      Final[float] = 16_666.0   # μs available per frame
OS_OVERHEAD_US:       Final[float] = 800.0      # kernel/scheduler fixed cost
AVAILABLE_BUDGET_US:  Final[float] = FRAME_BUDGET_US - OS_OVERHEAD_US  # 15,866 μs

# Memory: 1 GB LPDDR4, ~400 MB usable after OS/display buffer reservation
TOTAL_RAM_KB:         Final[int]   = 1_048_576  # 1 GB
OS_RESERVED_KB:       Final[int]   = 614_400    # ~600 MB OS + display
USABLE_RAM_KB:        Final[int]   = TOTAL_RAM_KB - OS_RESERVED_KB  # ~400 MB
SESSION_RAM_LIMIT_KB: Final[int]   = 65_536     # 64 MB max per session
MAX_TOTAL_SESSION_KB: Final[int]   = 393_216    # 384 MB total session pool

# GPU: Mali-G52 class, 720p target, tile-based
GPU_RENDER_UNITS:     Final[int]   = 2
GPU_TARGET_RES:       Final[str]   = "1280x720"
GPU_RENDER_BUDGET_US: Final[float] = 4_000.0   # μs of frame budget for rendering
GPU_TILE_SIZE:        Final[int]   = 16         # pixels per tile

# Input: up to 8 simultaneous devices
MAX_INPUT_DEVICES:    Final[int]   = 8
MAX_PLAYER_SLOTS:     Final[int]   = 8
INPUT_POLL_BUDGET_US: Final[float] = 200.0      # μs per device per frame

# Network: onboard Wi-Fi for updates/store only (NOT real-time game)
WIFI_ENABLED:         Final[bool]  = True
WIFI_CLASS:           Final[str]   = "802.11n 2.4GHz"
WIFI_MAX_MBPS:        Final[int]   = 72
WIFI_USE_CASE:        Final[str]   = "OTA updates and store downloads only"

# Storage: eMMC 5.1 class
STORAGE_GB:           Final[int]   = 32
STORAGE_SPEED_MBPS:   Final[int]   = 150

# Thermal throttle: ARM boards throttle at 80°C, simulated as load ceiling
THERMAL_THROTTLE_LOAD: Final[float] = 0.92     # throttle kicks in at 92% load


# ── Per-operation CPU cost model (μs) ────────────────────────────────────────
# These are the simulated costs of each OS operation per frame.

@dataclass(frozen=True)
class OperationCosts:
    """
    Simulated microsecond costs for each OS subsystem operation.
    Derived from ARM Cortex-A55 profiling data scaled to this platform.
    """
    # Kernel
    tick_engine_base:     float = 45.0    # fixed-timestep loop overhead
    scheduler_dispatch:   float = 30.0    # task dispatch per scheduled item

    # Input pipeline
    device_poll:          float = 85.0    # poll one physical device
    intent_mapping:       float = 25.0    # raw → intent for one device
    slot_assignment:      float = 15.0    # route intent to player slot
    input_queue_flush:    float = 20.0    # drain one device's queue

    # Session operations
    session_create:       float = 1_200.0  # instantiate a new session
    session_destroy:      float = 600.0    # clean session teardown
    session_update_base:  float = 800.0    # base update cost per session
    session_update_player: float = 180.0   # extra cost per active player
    session_pause:        float = 60.0     # pause state transition
    session_resume:       float = 60.0     # resume state transition

    # Rendering (GPU-side, μs of frame budget consumed)
    render_base:          float = 1_200.0  # base render pass
    render_per_player:    float = 420.0    # additional render per player
    ui_overlay_draw:      float = 350.0    # draw session overlay

    # Performance model transitions
    degrade_ai:           float = -250.0   # savings when AI complexity drops
    reduce_update_freq:   float = -300.0   # savings from update freq reduction
    simplify_render:      float = -500.0   # savings from render simplification

    # Memory (KB allocated)
    session_base_kb:      float = 8_192.0  # 8 MB base per session
    session_per_player_kb: float = 1_024.0 # 1 MB extra per player


OP_COSTS = OperationCosts()


@dataclass
class HardwareProfile:
    """
    Runtime hardware profile instance.
    Contains both static spec and dynamic thermal/throttle state.
    """
    # Static spec
    cpu_cores:            int   = CPU_CORES
    cpu_clock_mhz:        int   = CPU_CLOCK_MHZ
    frame_budget_us:      float = FRAME_BUDGET_US
    os_overhead_us:       float = OS_OVERHEAD_US
    available_budget_us:  float = AVAILABLE_BUDGET_US
    total_ram_kb:         int   = TOTAL_RAM_KB
    usable_ram_kb:        int   = USABLE_RAM_KB
    max_player_slots:     int   = MAX_PLAYER_SLOTS
    max_input_devices:    int   = MAX_INPUT_DEVICES
    gpu_render_budget_us: float = GPU_RENDER_BUDGET_US
    wifi_enabled:         bool  = WIFI_ENABLED

    # Dynamic thermal state [0.0 = cool, 1.0 = throttled]
    thermal_load: float = field(default=0.0)

    @property
    def effective_budget_us(self) -> float:
        """Available frame budget after thermal throttle derating."""
        if self.thermal_load >= THERMAL_THROTTLE_LOAD:
            throttle_factor = 1.0 - ((self.thermal_load - THERMAL_THROTTLE_LOAD) * 2.0)
            throttle_factor = max(0.5, throttle_factor)
            return self.available_budget_us * throttle_factor
        return self.available_budget_us

    @property
    def is_throttling(self) -> bool:
        return self.thermal_load >= THERMAL_THROTTLE_LOAD

    def update_thermal(self, cpu_load: float) -> None:
        """Slowly update thermal state based on CPU load."""
        # Thermal lags behind load (simplified RC model)
        target = cpu_load
        self.thermal_load += (target - self.thermal_load) * 0.05
        self.thermal_load = max(0.0, min(1.0, self.thermal_load))

    def summary(self) -> dict:
        return {
            "cpu": f"{self.cpu_cores}x A55 @ {self.cpu_clock_mhz}MHz",
            "frame_budget_us": self.frame_budget_us,
            "effective_budget_us": round(self.effective_budget_us, 1),
            "ram_usable_mb": self.usable_ram_kb // 1024,
            "max_players": self.max_player_slots,
            "thermal_load_pct": round(self.thermal_load * 100, 1),
            "throttling": self.is_throttling,
            "wifi": self.wifi_enabled,
        }
