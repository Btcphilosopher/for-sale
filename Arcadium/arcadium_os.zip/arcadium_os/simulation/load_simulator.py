"""
ARCADIUM OS — simulation/load_simulator.py
Synthetic load generator. Injects realistic CPU/memory pressure
to stress-test the cost model and performance degradation cascade.

Patterns: idle, ramp-up, burst, sustained-high, wave, random-spike.
"""
import math
import random
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Optional


class LoadPattern(Enum):
    IDLE         = auto()   # 5–15% baseline
    RAMP_UP      = auto()   # linear 0→100% over N seconds
    BURST        = auto()   # random short spikes above 90%
    SUSTAINED    = auto()   # held at 70–85% for extended period
    WAVE         = auto()   # sinusoidal oscillation
    RANDOM_SPIKE = auto()   # random instant spikes
    PLAYER_JOIN  = auto()   # simulates players joining over time


@dataclass
class LoadEvent:
    """A discrete load event record for analysis."""
    timestamp: float
    pattern:   LoadPattern
    cpu_load:  float        # [0.0–1.0]
    mem_load:  float        # [0.0–1.0]
    note:      str = ""


class LoadSimulator:
    """
    Generates synthetic load values each frame to simulate
    realistic usage patterns on the $100 hardware platform.
    """

    def __init__(self) -> None:
        self._pattern = LoadPattern.IDLE
        self._start_time = time.perf_counter()
        self._pattern_start = self._start_time
        self._event_log: list[LoadEvent] = []
        self._injected_spike: float = 0.0
        self._spike_decay: float = 0.0
        self._base_cpu: float = 0.08
        self._base_mem: float = 0.12
        self._noise_amplitude: float = 0.03
        self._rng = random.Random(42)  # deterministic for reproducibility

    # ── Pattern control ───────────────────────────────────────────────────

    def set_pattern(self, pattern: LoadPattern, note: str = "") -> None:
        self._pattern = pattern
        self._pattern_start = time.perf_counter()
        self._log_event(note or f"Pattern → {pattern.name}")

    def inject_spike(self, magnitude: float = 0.8, duration_s: float = 0.5) -> None:
        """Inject an immediate CPU spike (magnitude [0–1])."""
        self._injected_spike = magnitude
        self._spike_decay = magnitude / max(duration_s, 0.01) * (1.0 / 60.0)
        self._log_event(f"SPIKE magnitude={magnitude:.2f}")

    # ── Per-frame tick ────────────────────────────────────────────────────

    def tick(self) -> tuple[float, float]:
        """
        Returns (cpu_load, mem_load) in range [0.0, 1.0] for this frame.
        Call once per kernel frame.
        """
        now = time.perf_counter()
        elapsed = now - self._pattern_start
        noise = self._noise_amplitude * (self._rng.random() * 2 - 1)

        cpu = self._compute_cpu(elapsed) + noise
        mem = self._compute_mem(elapsed)

        # Decay any injected spike
        if self._injected_spike > 0:
            cpu = max(cpu, self._injected_spike)
            self._injected_spike = max(0.0, self._injected_spike - self._spike_decay)

        cpu = max(0.0, min(1.0, cpu))
        mem = max(0.0, min(1.0, mem))
        return cpu, mem

    def _compute_cpu(self, elapsed: float) -> float:
        p = self._pattern

        if p == LoadPattern.IDLE:
            return self._base_cpu + 0.05 * math.sin(elapsed * 0.3)

        elif p == LoadPattern.RAMP_UP:
            ramp_duration = 10.0  # 10 seconds to full load
            return min(0.95, elapsed / ramp_duration)

        elif p == LoadPattern.BURST:
            # High base with occasional 100% bursts
            base = 0.60
            cycle = elapsed % 3.0
            if cycle < 0.3:
                return 0.95
            return base + 0.05 * math.sin(elapsed * 2.0)

        elif p == LoadPattern.SUSTAINED:
            return 0.72 + 0.08 * math.sin(elapsed * 0.5)

        elif p == LoadPattern.WAVE:
            freq = 0.15  # Hz
            return 0.35 + 0.45 * (0.5 + 0.5 * math.sin(2 * math.pi * freq * elapsed))

        elif p == LoadPattern.RANDOM_SPIKE:
            base = 0.35
            spike_prob = 0.02  # 2% chance per frame
            if self._rng.random() < spike_prob:
                self.inject_spike(self._rng.uniform(0.5, 0.95), 0.3)
            return base

        elif p == LoadPattern.PLAYER_JOIN:
            # Simulate 1 player joining every 5 seconds
            players = min(8, int(elapsed / 5.0) + 1)
            return min(0.95, 0.12 * players + 0.04)

        return self._base_cpu

    def _compute_mem(self, elapsed: float) -> float:
        p = self._pattern

        if p == LoadPattern.IDLE:
            return self._base_mem

        elif p in (LoadPattern.RAMP_UP, LoadPattern.PLAYER_JOIN):
            return min(0.85, self._base_mem + elapsed * 0.015)

        elif p == LoadPattern.BURST:
            return 0.55 + 0.10 * math.sin(elapsed * 0.4)

        elif p == LoadPattern.SUSTAINED:
            return 0.65

        elif p == LoadPattern.WAVE:
            return 0.40 + 0.20 * (0.5 + 0.5 * math.sin(2 * math.pi * 0.08 * elapsed))

        elif p == LoadPattern.RANDOM_SPIKE:
            return 0.38 + 0.05 * math.sin(elapsed * 0.2)

        return self._base_mem

    # ── Event log ────────────────────────────────────────────────────────

    def _log_event(self, note: str) -> None:
        cpu, mem = self.tick()
        self._event_log.append(LoadEvent(
            timestamp=time.perf_counter() - self._start_time,
            pattern=self._pattern,
            cpu_load=cpu,
            mem_load=mem,
            note=note,
        ))

    def get_events(self, last_n: int = 20) -> list[LoadEvent]:
        return self._event_log[-last_n:]

    @property
    def current_pattern(self) -> LoadPattern:
        return self._pattern

    def pattern_elapsed(self) -> float:
        return time.perf_counter() - self._pattern_start
