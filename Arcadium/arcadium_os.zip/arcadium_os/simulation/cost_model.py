"""
ARCADIUM OS — simulation/cost_model.py
Per-frame CPU and memory cost calculator.
Maps OS operations to simulated μs consumption.
Drives the performance degradation cascade.
"""
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

from simulation.hardware_profile import HardwareProfile, OP_COSTS, OperationCosts


class PerformanceMode(Enum):
    """
    System-wide performance mode, determined by player count and CPU load.
    Maps to the spec table: 1–2 = FULL, 3–5 = BALANCED, 6–8 = OPTIMISED.
    """
    FULL_FIDELITY   = auto()  # 1–2 players: everything maxed
    BALANCED        = auto()  # 3–5 players: moderate tradeoffs
    OPTIMISED       = auto()  # 6–8 players: aggressive cost reduction
    THROTTLED       = auto()  # over-budget: emergency reduction


def mode_from_player_count(n: int) -> PerformanceMode:
    if n <= 2:
        return PerformanceMode.FULL_FIDELITY
    elif n <= 5:
        return PerformanceMode.BALANCED
    else:
        return PerformanceMode.OPTIMISED


@dataclass
class FrameCostBreakdown:
    """
    Detailed breakdown of CPU cost (μs) for one frame.
    Used for logging, UI display, and budget enforcement decisions.
    """
    kernel_us:       float = 0.0
    input_us:        float = 0.0
    session_us:      float = 0.0
    render_us:       float = 0.0
    ui_us:           float = 0.0
    degradation_us:  float = 0.0   # negative = savings from degradation

    @property
    def total_us(self) -> float:
        return (
            self.kernel_us
            + self.input_us
            + self.session_us
            + self.render_us
            + self.ui_us
            + self.degradation_us
        )

    def budget_utilisation(self, budget_us: float) -> float:
        if budget_us <= 0:
            return 1.0
        return min(self.total_us / budget_us, 1.5)


@dataclass
class MemoryCostBreakdown:
    """RAM usage (KB) tracked per session and OS subsystem."""
    os_reserved_kb:    int = 0
    sessions_kb:       int = 0
    input_buffers_kb:  int = 0
    render_buffers_kb: int = 0

    @property
    def total_kb(self) -> int:
        return (
            self.os_reserved_kb
            + self.sessions_kb
            + self.input_buffers_kb
            + self.render_buffers_kb
        )


class CostModel:
    """
    Central cost accounting system.
    Called each frame by the execution engine to compute expected
    CPU budget usage and determine if degradation is required.
    """

    def __init__(self, hw: HardwareProfile, costs: OperationCosts = OP_COSTS) -> None:
        self._hw = hw
        self._costs = costs
        self._mode = PerformanceMode.FULL_FIDELITY
        self._last_breakdown = FrameCostBreakdown()
        self._last_mem = MemoryCostBreakdown()
        self._consecutive_over_budget: int = 0
        self._degradation_active: bool = False

    # ── Public API ────────────────────────────────────────────────────────

    def compute_frame_cost(
        self,
        active_device_count: int,
        sessions: list,            # list of session-like objects with .player_count
        ui_active: bool = True,
    ) -> FrameCostBreakdown:
        """
        Estimate CPU cost (μs) for this frame.
        Updates internal mode based on total player count.
        """
        total_players = sum(getattr(s, 'player_count', 1) for s in sessions)
        self._mode = mode_from_player_count(total_players)

        b = FrameCostBreakdown()

        # Kernel + scheduler
        b.kernel_us = (
            self._costs.tick_engine_base
            + self._costs.scheduler_dispatch * max(1, len(sessions))
        )

        # Input pipeline: poll + map + route each device
        b.input_us = active_device_count * (
            self._costs.device_poll
            + self._costs.intent_mapping
            + self._costs.slot_assignment
            + self._costs.input_queue_flush
        )

        # Session update: base + per-player
        for s in sessions:
            pc = getattr(s, 'player_count', 1)
            b.session_us += (
                self._costs.session_update_base
                + self._costs.session_update_player * pc
            )

        # Render: base + per-player
        for s in sessions:
            pc = getattr(s, 'player_count', 1)
            b.render_us += (
                self._costs.render_base
                + self._costs.render_per_player * pc
            )

        # UI overlay
        if ui_active:
            b.ui_us = self._costs.ui_overlay_draw

        # Apply degradation savings if over budget
        budget = self._hw.effective_budget_us
        if b.total_us > budget:
            b.degradation_us = self._apply_degradation(b.total_us, budget, total_players)
            self._consecutive_over_budget += 1
            self._degradation_active = True
        else:
            self._consecutive_over_budget = max(0, self._consecutive_over_budget - 1)
            if self._consecutive_over_budget == 0:
                self._degradation_active = False

        self._last_breakdown = b
        return b

    def compute_memory_cost(
        self,
        sessions: list,
        active_device_count: int,
    ) -> MemoryCostBreakdown:
        m = MemoryCostBreakdown()
        m.os_reserved_kb = 8_192  # 8 MB OS runtime

        for s in sessions:
            pc = getattr(s, 'player_count', 1)
            m.sessions_kb += int(
                self._costs.session_base_kb
                + self._costs.session_per_player_kb * pc
            )

        m.input_buffers_kb = active_device_count * 64    # 64 KB ring buffer per device
        m.render_buffers_kb = 2 * 1_800                  # double-buffer 720p = ~3.6 MB

        self._last_mem = m
        return m

    # ── Degradation cascade ───────────────────────────────────────────────

    def _apply_degradation(
        self,
        current_us: float,
        budget_us: float,
        total_players: int,
    ) -> float:
        """
        Determine degradation savings. Returns negative μs (cost reduction).
        Cascade: AI first → update frequency → render quality.
        """
        overshoot = current_us - budget_us
        savings = 0.0

        # Level 1: reduce AI complexity (~250μs per session)
        if overshoot > 0:
            sessions_with_ai = max(1, total_players // 2)
            savings += self._costs.degrade_ai * sessions_with_ai  # negative
            overshoot += savings  # savings is negative so this reduces overshoot

        # Level 2: reduce update frequency
        if overshoot > 0:
            savings += self._costs.reduce_update_freq
            overshoot += self._costs.reduce_update_freq

        # Level 3: simplify render pipeline
        if overshoot > 0:
            savings += self._costs.simplify_render

        return savings  # negative value

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def current_mode(self) -> PerformanceMode:
        return self._mode

    @property
    def degradation_active(self) -> bool:
        return self._degradation_active

    @property
    def consecutive_over_budget(self) -> int:
        return self._consecutive_over_budget

    @property
    def last_breakdown(self) -> FrameCostBreakdown:
        return self._last_breakdown

    @property
    def last_memory(self) -> MemoryCostBreakdown:
        return self._last_mem

    def budget_utilisation(self) -> float:
        return self._last_breakdown.budget_utilisation(
            self._hw.effective_budget_us
        )

    def mode_label(self) -> str:
        return {
            PerformanceMode.FULL_FIDELITY: "FULL FIDELITY",
            PerformanceMode.BALANCED:      "BALANCED",
            PerformanceMode.OPTIMISED:     "OPTIMISED",
            PerformanceMode.THROTTLED:     "THROTTLED",
        }[self._mode]
