"""
ARCADIUM OS — ui/session_overlay.py
Rich-rendered session status overlay.
Produces renderable panels for the live dashboard.
"""
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.columns import Columns
from rich import box
from rich.progress import BarColumn, Progress, TextColumn
from rich.console import Group

from sessions.session import Session, SessionState
from input.player_slot_manager import PlayerSlot, SlotState

# Anglo-futurist palette
C_GOLD   = "#C9A84C"
C_CYAN   = "#00E5FF"
C_DIM    = "#444444"
C_WHITE  = "#E0E0E0"
C_RED    = "#FF4444"
C_GREEN  = "#44FF88"
C_AMBER  = "#FFAA00"


STATE_COLOUR: dict[SessionState, str] = {
    SessionState.CREATING: C_DIM,
    SessionState.WAITING:  C_AMBER,
    SessionState.RUNNING:  C_GREEN,
    SessionState.PAUSED:   C_AMBER,
    SessionState.ENDING:   C_RED,
    SessionState.ENDED:    C_DIM,
}

SLOT_COLOUR: dict[SlotState, str] = {
    SlotState.EMPTY:    C_DIM,
    SlotState.ASSIGNED: C_AMBER,
    SlotState.ACTIVE:   C_GREEN,
    SlotState.IDLE:     C_WHITE,
}


def render_sessions_panel(sessions: list[Session]) -> Panel:
    """Render all sessions as a Rich table inside a panel."""
    table = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style=f"bold {C_GOLD}",
        border_style=C_DIM,
        expand=True,
    )
    table.add_column("ID",      style=C_GOLD,  width=8)
    table.add_column("GAME",    style=C_WHITE, width=18)
    table.add_column("STATE",   width=10)
    table.add_column("PLAYERS", justify="center", width=8)
    table.add_column("MODE",    style=C_CYAN,  width=14)
    table.add_column("RUNTIME", justify="right", width=9)
    table.add_column("CPU AVG", justify="right", width=10)
    table.add_column("FRAMES",  justify="right", width=8)

    if not sessions:
        table.add_row(
            "—", "No active sessions", "—", "—", "—", "—", "—", "—",
        )
    else:
        for s in sessions:
            colour = STATE_COLOUR.get(s.state, C_WHITE)
            state_txt = Text(s.state.name, style=f"bold {colour}")
            mode_name = s.performance_mode.name.replace("_", " ")
            table.add_row(
                s.session_id,
                s.game_title[:18],
                state_txt,
                str(s.player_count),
                mode_name,
                f"{s.run_seconds:.1f}s",
                f"{s.metrics.avg_cpu_us:.0f}μs",
                str(s.metrics.frames_run),
            )

    return Panel(
        table,
        title=f"[bold {C_GOLD}]◈ ACTIVE SESSIONS[/]",
        border_style=C_GOLD,
    )


def render_slots_panel(slots: list[PlayerSlot]) -> Panel:
    """Render all 8 player slots as a grid."""
    rows = []
    row_cells = []

    for slot in sorted(slots, key=lambda s: s.slot_id):
        colour = SLOT_COLOUR.get(slot.state, C_DIM)
        if slot.state == SlotState.EMPTY:
            cell = Text(f"P{slot.slot_id}\n──────\nEMPTY", style=C_DIM, justify="center")
        else:
            dt  = slot.device_type.name[:8] if slot.device_type else "?"
            sid = (slot.session_id or "—")[:6]
            active_marker = "●" if slot.state == SlotState.ACTIVE else "○"
            cell = Text(
                f"P{slot.slot_id} {active_marker}\n{dt}\nSES:{sid}",
                style=f"bold {colour}",
                justify="center",
            )
        row_cells.append(
            Panel(cell, border_style=colour, width=16, height=5)
        )

    return Panel(
        Columns(row_cells, equal=True, expand=True),
        title=f"[bold {C_GOLD}]◈ PLAYER SLOTS [8 MAX][/]",
        border_style=C_GOLD,
    )


def render_session_detail(session: Session) -> Panel:
    """Detailed panel for one selected session."""
    lines = [
        f"[{C_GOLD}]ID:[/]        {session.session_id}",
        f"[{C_GOLD}]GAME:[/]      {session.game_title}",
        f"[{C_GOLD}]STATE:[/]     [{STATE_COLOUR[session.state]}]{session.state.name}[/]",
        f"[{C_GOLD}]PLAYERS:[/]   {session.player_count} (slots: {session.player_slots})",
        f"[{C_GOLD}]MODE:[/]      {session.performance_mode.name}",
        f"[{C_GOLD}]RUNTIME:[/]   {session.run_seconds:.2f}s",
        f"[{C_GOLD}]FRAMES:[/]    {session.metrics.frames_run}",
        f"[{C_GOLD}]CPU AVG:[/]   {session.metrics.avg_cpu_us:.1f}μs",
        f"[{C_GOLD}]CPU PEAK:[/]  {session.metrics.peak_cpu_us:.1f}μs",
        f"[{C_GOLD}]DEGRADED:[/]  {session.metrics.degraded_frames} frames",
        f"[{C_GOLD}]BUDGET:[/]    {session.budget_share*100:.0f}% share",
    ]
    return Panel(
        "\n".join(lines),
        title=f"[bold {C_GOLD}]◈ SESSION DETAIL[/]",
        border_style=C_CYAN,
    )
