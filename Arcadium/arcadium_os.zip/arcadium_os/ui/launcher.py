"""
ARCADIUM OS — ui/launcher.py
Rich terminal dashboard and interactive launcher.

Layout:
  ┌─ HEADER ──────────────────────────────────────────────────┐
  │  Kernel status bar: FPS | Frame | Uptime | Budget | Mode  │
  ├─ LEFT ────────────────┬─ RIGHT ──────────────────────────┐
  │  Performance metrics  │  Sessions + Player slots         │
  │  Budget bars          │  Log tail                        │
  ├─ BOTTOM ─────────────────────────────────────────────────┘
  │  Command prompt                                          │
  └──────────────────────────────────────────────────────────┘
"""
import sys
import threading
import time
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console, Group
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.text import Text
from rich.prompt import Prompt

from kernel.realtime_kernel import RealtimeKernel, KernelState
from input.device_layer import DeviceType
from sessions.session import GAME_CATALOGUE
from ui.session_overlay import (
    render_sessions_panel, render_slots_panel,
    C_GOLD, C_CYAN, C_DIM, C_WHITE, C_RED, C_GREEN, C_AMBER
)
from utils.logging import LogLevel, LEVEL_COLOUR, LEVEL_TAG

console = Console()

ARCADIUM_BANNER = r"""
   ▄████████    ▄████████  ▄████████    ▄████████ ████████▄   ▄█  ███    █▄    ▄▄▄▄███▄▄▄▄
  ███    ███   ███    ███ ███    ███   ███    ███ ███   ▀███ ███  ███    ███ ▄██▀▀▀███▀▀▀██▄
  ███    ███   ███    ███ ███    █▀    ███    ███ ███    ███ ███▌ ███    ███ ███   ███   ███
 ▄███▄▄▄▄██▀  ███    ███ ███          ███    ███ ███    ███ ███▌ ███    ███ ███   ███   ███
▀▀███▀▀▀▀▀   ▀███████████ ███        ▀███████████ ███    ███ ███▌ ███    ███ ███   ███   ███
▀███████████   ███    ███ ███    █▄    ███    ███ ███    ███ ███  ███    ███ ███   ███   ███
  ███    ███   ███    ███ ███    ███   ███    ███ ███   ▄███ ███  ███    ███ ███   ███   ███
  ███    ███   ███    █▀  ████████▀    ███    █▀  ████████▀  █▀   ████████▀   ▀█   ███   █▀
  ███    ███
"""


def _bar(value: float, width: int = 20, fill: str = "█", empty: str = "░") -> str:
    """Simple ASCII progress bar."""
    filled = int(value * width)
    return fill * filled + empty * (width - filled)


def _budget_colour(pct: float) -> str:
    if pct < 75:
        return C_GREEN
    elif pct < 92:
        return C_AMBER
    return C_RED


def _mode_colour(mode: str) -> str:
    if "FULL" in mode:
        return C_GREEN
    elif "BALANCED" in mode:
        return C_AMBER
    elif "THROTTLE" in mode:
        return C_RED
    return C_CYAN


def build_header(ks: KernelState) -> Panel:
    fps_colour  = C_GREEN if ks.fps >= 55 else C_AMBER if ks.fps >= 45 else C_RED
    budget_col  = _budget_colour(ks.budget_pct)
    mode_col    = _mode_colour(ks.perf_mode)
    degrade_str = f"[{C_RED}]DEGRADED[/]" if ks.degraded else f"[{C_GREEN}]NOMINAL[/]"
    throttle    = f"[{C_RED}] ⚠ THERMAL[/]" if ks.throttling else ""

    items = [
        f"[{C_GOLD}]FRAME[/] [{C_WHITE}]{ks.frame:>8,}[/]",
        f"[{C_GOLD}]FPS[/] [{fps_colour}]{ks.fps:>5.1f}[/]",
        f"[{C_GOLD}]UP[/] [{C_WHITE}]{ks.uptime_s:>6.1f}s[/]",
        f"[{C_GOLD}]BUDGET[/] [{budget_col}]{ks.budget_pct:>5.1f}%[/]",
        f"[{C_GOLD}]MODE[/] [{mode_col}]{ks.perf_mode}[/]",
        f"[{C_GOLD}]STATUS[/] {degrade_str}{throttle}",
        f"[{C_GOLD}]SESS[/] [{C_CYAN}]{ks.sessions}[/]",
        f"[{C_GOLD}]PLAYERS[/] [{C_CYAN}]{ks.total_players}[/]",
        f"[{C_GOLD}]DEVS[/] [{C_CYAN}]{ks.devices}[/]",
    ]
    return Panel(
        "  ·  ".join(items),
        title=f"[bold {C_GOLD}]◈ ARCADIUM OS — REAL-TIME KERNEL[/]",
        border_style=C_GOLD,
    )


def build_perf_panel(kernel: RealtimeKernel) -> Panel:
    ks  = kernel.state()
    hw  = kernel.hw
    bud = kernel.budget
    eng = kernel.exec_engine
    ts  = kernel.tick_engine.stats

    budget_pct = ks.budget_pct / 100.0
    mem_pct    = kernel._last_mem_kb / max(hw.usable_ram_kb, 1)
    thermal_pct = ks.thermal_pct / 100.0

    lines = [
        f"[{C_GOLD}]── FRAME BUDGET ──────────────────[/]",
        f"[{C_CYAN}]CPU [/][{_budget_colour(ks.budget_pct)}]{_bar(budget_pct)}[/] [{C_WHITE}]{ks.budget_pct:.1f}%[/]",
        "",
        f"[{C_GOLD}]── MEMORY ────────────────────────[/]",
        f"[{C_CYAN}]RAM [/][{_budget_colour(mem_pct*100)}]{_bar(mem_pct)}[/] [{C_WHITE}]{kernel._last_mem_kb//1024}MB/{hw.usable_ram_kb//1024}MB[/]",
        "",
        f"[{C_GOLD}]── THERMAL ───────────────────────[/]",
        f"[{C_CYAN}]TMP [/][{_budget_colour(ks.thermal_pct)}]{_bar(thermal_pct)}[/] [{C_WHITE}]{ks.thermal_pct:.1f}%[/]",
        "",
        f"[{C_GOLD}]── DEGRADATION ───────────────────[/]",
        f"  AI COMPLEXITY  [{C_RED if bud.ai_degraded else C_GREEN}]{'REDUCED' if bud.ai_degraded else 'FULL   '}[/]",
        f"  UPDATE FREQ    [{C_RED if bud.update_freq_reduced else C_GREEN}]{'REDUCED' if bud.update_freq_reduced else 'FULL   '}[/]",
        f"  RENDER QUALITY [{C_RED if bud.render_simplified else C_GREEN}]{'REDUCED' if bud.render_simplified else 'FULL   '}[/]",
        "",
        f"[{C_GOLD}]── TICK ENGINE ───────────────────[/]",
        f"  OVERRUNS  [{C_WHITE}]{ts.overrun_frames}[/]",
        f"  AVG FRAME [{C_WHITE}]{ts.avg_frame_us:.0f}μs[/]",
        f"  PEAK      [{C_WHITE}]{ts.peak_frame_us:.0f}μs[/]",
        "",
        f"[{C_GOLD}]── LOAD PATTERN ──────────────────[/]",
        f"  [{C_CYAN}]{kernel.load_sim.current_pattern.name}[/]",
        f"  elapsed {kernel.load_sim.pattern_elapsed():.1f}s",
    ]
    return Panel(
        "\n".join(lines),
        title=f"[bold {C_GOLD}]◈ PERFORMANCE[/]",
        border_style=C_GOLD,
    )


def build_log_panel(kernel: RealtimeKernel, n: int = 14) -> Panel:
    entries = kernel.exec_engine._sessions  # just need logger
    from utils.logging import ArcadiumLogger
    logger = ArcadiumLogger.get()
    recent = logger.get_recent(n, min_level=LogLevel.INFO)

    lines = []
    for e in recent[-n:]:
        col = LEVEL_COLOUR.get(e.level, C_WHITE)
        tag = LEVEL_TAG.get(e.level, "???")
        t   = f"{e.timestamp:>7.2f}s"
        msg = e.message[:60]
        lines.append(f"[{C_DIM}]{t}[/] [{col}]{tag}[/] [{C_DIM}]{e.subsystem:<8}[/] {msg}")

    if not lines:
        lines = [f"[{C_DIM}]No log entries yet...[/]"]

    return Panel(
        "\n".join(lines),
        title=f"[bold {C_GOLD}]◈ SYSTEM LOG[/]",
        border_style=C_DIM,
    )


def build_commands_panel() -> Panel:
    cmds = [
        ("[C]reate session",   C_GREEN),
        ("[E]nd session",      C_RED),
        ("[P]ause/[R]esume",   C_AMBER),
        ("[D]evice: add",      C_CYAN),
        ("[K]ick device",      C_CYAN),
        ("[S]pike load",       C_RED),
        ("[L]ist sessions",    C_GOLD),
        ("[Q]uit",             C_DIM),
    ]
    parts = [f"[{c}]{label}[/]" for label, c in cmds]
    return Panel(
        "  |  ".join(parts),
        border_style=C_DIM,
        height=3,
    )


def build_full_layout(kernel: RealtimeKernel) -> Group:
    ks       = kernel.state()
    sessions = kernel.session_mgr.all_sessions()
    slots    = kernel.slot_mgr.all_slots()

    header   = build_header(ks)
    perf     = build_perf_panel(kernel)
    sess_pan = render_sessions_panel(sessions)
    slot_pan = render_slots_panel(slots)
    log_pan  = build_log_panel(kernel)
    cmd_pan  = build_commands_panel()

    right = Group(sess_pan, slot_pan, log_pan)
    cols  = Columns([perf, right], expand=True, equal=False)

    return Group(header, cols, cmd_pan)


# ── Interactive command handler ───────────────────────────────────────────────

DEVICE_TYPE_MAP = {
    "1": DeviceType.CONTROLLER,
    "2": DeviceType.KEYBOARD,
    "3": DeviceType.ARCADE_STICK,
    "4": DeviceType.STEERING_WHEEL,
}


def run_command(kernel: RealtimeKernel, cmd: str, live: Live) -> Optional[str]:
    """
    Process one command character from the interactive prompt.
    Returns an optional status message.
    """
    cmd = cmd.strip().upper()

    if cmd == "C":
        session = kernel.create_session()
        if session:
            return f"Created session [{session.session_id}] — {session.game_title}"
        return "ERROR: session limit reached"

    elif cmd == "E":
        sessions = kernel.session_mgr.all_sessions()
        if not sessions:
            return "No active sessions"
        live.stop()
        console.print("\n[bold]Active sessions:[/]")
        for s in sessions:
            console.print(f"  [{C_GOLD}]{s.session_id}[/] — {s.game_title} ({s.state.name})")
        sid = Prompt.ask("Session ID to end").strip().upper()
        live.start()
        ok = kernel.end_session(sid)
        return f"Ended {sid}" if ok else f"Session {sid} not found"

    elif cmd == "P":
        sessions = kernel.session_mgr.running_sessions()
        if sessions:
            s = sessions[0]
            kernel.pause_session(s.session_id)
            return f"Paused [{s.session_id}]"
        return "No running sessions to pause"

    elif cmd == "R":
        from sessions.session import SessionState
        paused = [s for s in kernel.session_mgr.all_sessions() if s.state == SessionState.PAUSED]
        if paused:
            s = paused[0]
            kernel.resume_session(s.session_id)
            return f"Resumed [{s.session_id}]"
        return "No paused sessions"

    elif cmd == "D":
        live.stop()
        console.print("\n[bold]Device types:[/]")
        for k, v in DEVICE_TYPE_MAP.items():
            console.print(f"  {k}) {v.name}")
        dtype_key = Prompt.ask("Device type").strip()
        dtype = DEVICE_TYPE_MAP.get(dtype_key, DeviceType.CONTROLLER)

        sessions = kernel.session_mgr.all_sessions()
        session_id = None
        if sessions:
            console.print("\nAvailable sessions:")
            for s in sessions:
                console.print(f"  [{C_GOLD}]{s.session_id}[/] — {s.game_title}")
            sid_in = Prompt.ask("Assign to session ID (blank=none)").strip().upper()
            if sid_in and kernel.session_mgr.get_session(sid_in):
                session_id = sid_in
        live.start()
        _, slot = kernel.add_device(dtype, session_id=session_id)
        return f"Connected {dtype.name} → slot {slot}" + (f" session={session_id}" if session_id else "")

    elif cmd == "K":
        devices = kernel.device_reg.connected_devices
        if not devices:
            return "No devices connected"
        live.stop()
        console.print("\nConnected devices:")
        for did, dev in devices.items():
            slot = kernel.slot_mgr.slot_for_device(did)
            console.print(f"  {did} ({dev.device_type.name}) → slot {slot}")
        did = Prompt.ask("Device ID to remove").strip()
        live.start()
        sessions = [s for s in kernel.session_mgr.all_sessions()
                    if kernel.slot_mgr.slot_for_device(did) in s.player_slots]
        sid = sessions[0].session_id if sessions else None
        kernel.remove_device(did, session_id=sid)
        return f"Removed device {did}"

    elif cmd == "S":
        kernel.inject_load_spike(0.95)
        return "Load spike injected (magnitude=0.95)"

    elif cmd == "L":
        sessions = kernel.session_mgr.all_sessions()
        lines = [f"\n{'ID':<10} {'GAME':<20} {'STATE':<10} {'P':>3} {'RUNTIME':>9}"]
        lines.append("─" * 55)
        for s in sessions:
            lines.append(
                f"{s.session_id:<10} {s.game_title:<20} {s.state.name:<10} "
                f"{s.player_count:>3} {s.run_seconds:>8.1f}s"
            )
        return "\n".join(lines) if sessions else "No sessions"

    return None


# ── Main launcher entry point ─────────────────────────────────────────────────

def launch(kernel: RealtimeKernel) -> None:
    """Start the Arcadium OS terminal UI."""
    console.clear()
    console.print(Text(ARCADIUM_BANNER, style=f"bold {C_GOLD}"))
    console.print(f"[{C_CYAN}]Arcadium OS — Low-Cost $100 Arcade Console Platform[/]")
    console.print(f"[{C_DIM}]Booting kernel...[/]\n")
    time.sleep(0.5)

    status_msg = ""

    with Live(
        build_full_layout(kernel),
        console=console,
        refresh_per_second=8,
        screen=True,
    ) as live:
        while True:
            live.update(build_full_layout(kernel))

            # Non-blocking command input using a thread
            cmd_event = threading.Event()
            cmd_result: list[str] = []

            def get_input():
                try:
                    c = input()
                    cmd_result.append(c)
                except EOFError:
                    cmd_result.append("Q")
                finally:
                    cmd_event.set()

            t = threading.Thread(target=get_input, daemon=True)
            t.start()
            cmd_event.wait(timeout=0.15)

            if cmd_result:
                cmd = cmd_result[0]
                if cmd.strip().upper() == "Q":
                    break
                try:
                    result = run_command(kernel, cmd, live)
                    if result:
                        live.console.print(f"[{C_CYAN}]▸ {result}[/]")
                except Exception as e:
                    live.console.print(f"[{C_RED}]ERROR: {e}[/]")

    console.print(f"\n[{C_GOLD}]Arcadium OS shutdown initiated.[/]")
