"""
ARCADIUM OS — input/player_slot_manager.py
8-slot dynamic player assignment system.

Slots are runtime entities, not persistent identities.
Any device can occupy any free slot. Mid-session joins and
leaves are fully supported without disrupting other slots.
"""
import threading
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

from input.device_layer import InputDevice, DeviceType
from input.intent_system import PlayerIntent
from runtime.system_limits import MAX_PLAYERS_PER_SESSION as MAX_PLAYER_SLOTS
from utils.logging import log


class SlotState(Enum):
    EMPTY    = auto()   # no device assigned
    ASSIGNED = auto()   # device connected, ready
    ACTIVE   = auto()   # device actively sending input this frame
    IDLE     = auto()   # assigned but no recent input


@dataclass
class PlayerSlot:
    """
    One of 8 player slots. Tracks assigned device, session binding,
    and per-frame intent buffer.
    """
    slot_id:       int                          # 1–8
    state:         SlotState = SlotState.EMPTY
    device_id:     Optional[str]   = None
    device_type:   Optional[DeviceType] = None
    session_id:    Optional[str]   = None       # which session this slot belongs to
    assigned_at:   Optional[float] = None
    last_input_at: Optional[float] = None
    input_count:   int = 0

    # Per-frame intent buffer (cleared each frame)
    _intents: list[PlayerIntent] = field(default_factory=list, repr=False)

    def push_intents(self, intents: list[PlayerIntent]) -> None:
        self._intents.extend(intents)
        if intents:
            self.last_input_at = time.perf_counter()
            self.input_count += len(intents)
            self.state = SlotState.ACTIVE

    def consume_intents(self) -> list[PlayerIntent]:
        """Drain this frame's intents."""
        result = self._intents[:]
        self._intents.clear()
        if self.state == SlotState.ACTIVE:
            self.state = SlotState.ASSIGNED
        return result

    @property
    def is_occupied(self) -> bool:
        return self.state != SlotState.EMPTY

    @property
    def idle_seconds(self) -> float:
        if self.last_input_at is None:
            return float('inf')
        return time.perf_counter() - self.last_input_at

    def label(self) -> str:
        if self.state == SlotState.EMPTY:
            return f"P{self.slot_id} [EMPTY]"
        dt = self.device_type.name if self.device_type else "?"
        return f"P{self.slot_id} [{dt}]"


class PlayerSlotManager:
    """
    Manages all 8 player slots.

    Responsibilities:
      - assign devices to slots on connection
      - release slots on disconnect
      - route intents from device_id → slot
      - report slot occupancy per session
    """

    def __init__(self) -> None:
        self._slots: dict[int, PlayerSlot] = {
            i: PlayerSlot(slot_id=i) for i in range(1, MAX_PLAYER_SLOTS + 1)
        }
        # Reverse lookup: device_id → slot_id
        self._device_to_slot: dict[str, int] = {}
        self._lock = threading.Lock()

    # ── Assignment ────────────────────────────────────────────────────────

    def assign(
        self,
        device: InputDevice,
        session_id: Optional[str] = None,
        preferred_slot: Optional[int] = None,
    ) -> Optional[int]:
        """
        Assign a device to a free slot.
        Returns the slot number (1–8) or None if all slots are full.
        """
        with self._lock:
            if device.device_id in self._device_to_slot:
                # Already assigned — idempotent
                return self._device_to_slot[device.device_id]

            slot_id = self._find_free_slot(preferred_slot)
            if slot_id is None:
                log.warn("SLOTS", f"No free slot for device {device.device_id}")
                return None

            slot = self._slots[slot_id]
            slot.device_id   = device.device_id
            slot.device_type = device.device_type
            slot.session_id  = session_id
            slot.state       = SlotState.ASSIGNED
            slot.assigned_at = time.perf_counter()
            slot.last_input_at = None
            slot.input_count = 0
            slot._intents.clear()

            self._device_to_slot[device.device_id] = slot_id
            log.input_ev(
                f"Slot {slot_id} ← {device.device_id} ({device.device_type.name})"
                + (f" session={session_id}" if session_id else "")
            )
            return slot_id

    def release(self, device_id: str) -> Optional[int]:
        """Release the slot held by this device. Returns released slot number."""
        with self._lock:
            slot_id = self._device_to_slot.pop(device_id, None)
            if slot_id is None:
                return None
            slot = self._slots[slot_id]
            log.input_ev(f"Slot {slot_id} released (device {device_id} disconnected)")
            slot.device_id   = None
            slot.device_type = None
            slot.session_id  = None
            slot.state       = SlotState.EMPTY
            slot.assigned_at = None
            slot._intents.clear()
            return slot_id

    def release_session(self, session_id: str) -> list[int]:
        """Release all slots belonging to a session. Returns list of freed slot IDs."""
        freed = []
        with self._lock:
            for slot in self._slots.values():
                if slot.session_id == session_id and slot.is_occupied:
                    did = slot.device_id
                    if did:
                        self._device_to_slot.pop(did, None)
                    slot.device_id   = None
                    slot.device_type = None
                    slot.session_id  = None
                    slot.state       = SlotState.EMPTY
                    slot.assigned_at = None
                    slot._intents.clear()
                    freed.append(slot.slot_id)
        if freed:
            log.input_ev(f"Session {session_id}: released slots {freed}")
        return freed

    # ── Intent routing ────────────────────────────────────────────────────

    def route_intents(self, device_id: str, intents: list[PlayerIntent]) -> Optional[int]:
        """
        Route a batch of intents from a device to its assigned slot.
        Returns the slot_id or None if device has no slot.
        """
        with self._lock:
            slot_id = self._device_to_slot.get(device_id)
            if slot_id is None:
                return None
            self._slots[slot_id].push_intents(intents)
            return slot_id

    def consume_slot_intents(self, slot_id: int) -> list[PlayerIntent]:
        """Drain and return this frame's intents for the given slot."""
        with self._lock:
            return self._slots[slot_id].consume_intents()

    def consume_session_intents(self, session_id: str) -> dict[int, list[PlayerIntent]]:
        """
        Drain intents for all slots in a session.
        Returns {slot_id: [intents]}.
        """
        result: dict[int, list[PlayerIntent]] = {}
        with self._lock:
            for slot in self._slots.values():
                if slot.session_id == session_id and slot.is_occupied:
                    result[slot.slot_id] = slot.consume_intents()
        return result

    # ── Query ─────────────────────────────────────────────────────────────

    def slot_for_device(self, device_id: str) -> Optional[int]:
        return self._device_to_slot.get(device_id)

    def get_slot(self, slot_id: int) -> Optional[PlayerSlot]:
        return self._slots.get(slot_id)

    def occupied_slots(self) -> list[PlayerSlot]:
        return [s for s in self._slots.values() if s.is_occupied]

    def free_slot_count(self) -> int:
        return sum(1 for s in self._slots.values() if not s.is_occupied)

    def session_slots(self, session_id: str) -> list[PlayerSlot]:
        return [s for s in self._slots.values() if s.session_id == session_id]

    def session_player_count(self, session_id: str) -> int:
        return len(self.session_slots(session_id))

    def all_slots(self) -> list[PlayerSlot]:
        return list(self._slots.values())

    def snapshot(self) -> list[dict]:
        """Serialisable snapshot of all slots for UI display."""
        result = []
        for slot in self._slots.values():
            result.append({
                "slot_id":    slot.slot_id,
                "state":      slot.state.name,
                "device_id":  slot.device_id,
                "device_type": slot.device_type.name if slot.device_type else None,
                "session_id": slot.session_id,
                "input_count": slot.input_count,
                "idle_s":     round(slot.idle_seconds, 1) if slot.is_occupied else None,
            })
        return result

    # ── Internal ──────────────────────────────────────────────────────────

    def _find_free_slot(self, preferred: Optional[int] = None) -> Optional[int]:
        """Return first free slot number, respecting preference."""
        if preferred and 1 <= preferred <= MAX_PLAYER_SLOTS:
            if not self._slots[preferred].is_occupied:
                return preferred
        for i in range(1, MAX_PLAYER_SLOTS + 1):
            if not self._slots[i].is_occupied:
                return i
        return None
