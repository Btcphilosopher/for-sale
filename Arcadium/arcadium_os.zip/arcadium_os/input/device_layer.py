"""
ARCADIUM OS — input/device_layer.py
Physical device abstraction layer.
Simulates raw hardware input from controllers, keyboards,
arcade sticks, and steering wheels.

Each device generates a stream of RawInputEvent objects
that are consumed by the input router.
"""
import random
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

from runtime.system_limits import INPUT_QUEUE_DEPTH


# ── Device taxonomy ───────────────────────────────────────────────────────────

class DeviceType(Enum):
    KEYBOARD       = auto()
    CONTROLLER     = auto()   # standard gamepad (D-pad + 6 buttons + 2 triggers)
    ARCADE_STICK   = auto()   # 8-way joystick + 6–8 buttons, no analog
    STEERING_WHEEL = auto()   # analog wheel + pedals + paddle shifters


class DeviceState(Enum):
    DISCONNECTED = auto()
    CONNECTED    = auto()
    ACTIVE       = auto()    # connected and generating input
    ERROR        = auto()


# ── Raw event types ───────────────────────────────────────────────────────────

class RawEventType(Enum):
    KEY_DOWN    = auto()
    KEY_UP      = auto()
    AXIS_MOVE   = auto()   # analog axis value changed
    HAT_CHANGE  = auto()   # D-pad / 8-way hat state
    CONNECT     = auto()
    DISCONNECT  = auto()


@dataclass(slots=True)
class RawInputEvent:
    """
    Lowest-level input event. Comes directly from the device driver layer.
    Not yet mapped to player intent — that happens in intent_system.py.
    """
    device_id:   str
    device_type: DeviceType
    event_type:  RawEventType
    code:        str           # "BTN_A", "AXIS_LX", "KEY_UP", etc.
    value:       float         # digital: 1.0/0.0, analog: [-1.0, 1.0]
    timestamp:   float = field(default_factory=time.perf_counter)


# ── Button / axis code maps per device type ───────────────────────────────────

CONTROLLER_BUTTONS = [
    "BTN_A", "BTN_B", "BTN_X", "BTN_Y",
    "BTN_LB", "BTN_RB", "BTN_START", "BTN_SELECT",
    "BTN_LSTICK", "BTN_RSTICK",
]
CONTROLLER_AXES = ["AXIS_LX", "AXIS_LY", "AXIS_RX", "AXIS_RY", "AXIS_LT", "AXIS_RT"]

ARCADE_BUTTONS = [
    "BTN_1", "BTN_2", "BTN_3", "BTN_4",
    "BTN_5", "BTN_6", "BTN_COIN", "BTN_START",
]
ARCADE_HAT_VALUES = [
    (0, 0), (0, 1), (0, -1), (1, 0), (-1, 0),
    (1, 1), (1, -1), (-1, 1), (-1, -1),
]

KEYBOARD_KEYS = [
    "KEY_W", "KEY_A", "KEY_S", "KEY_D",
    "KEY_UP", "KEY_DOWN", "KEY_LEFT", "KEY_RIGHT",
    "KEY_SPACE", "KEY_ENTER", "KEY_LSHIFT", "KEY_Z", "KEY_X", "KEY_C",
]

WHEEL_AXES   = ["AXIS_WHEEL", "AXIS_THROTTLE", "AXIS_BRAKE", "AXIS_CLUTCH"]
WHEEL_BUTTONS = ["BTN_SHIFT_UP", "BTN_SHIFT_DOWN", "BTN_VIEW", "BTN_MENU"]


# ── Base device ───────────────────────────────────────────────────────────────

class InputDevice:
    """
    Abstract simulated input device.
    Subclasses implement _generate_events() to produce RawInputEvents
    based on their hardware type.
    """

    def __init__(self, device_id: str, device_type: DeviceType) -> None:
        self.device_id   = device_id
        self.device_type = device_type
        self.state       = DeviceState.CONNECTED
        self._queue: deque[RawInputEvent] = deque(maxlen=INPUT_QUEUE_DEPTH)
        self._rng        = random.Random()
        self._connected_at = time.perf_counter()
        self._event_count  = 0
        self._last_event_t = 0.0

    # ── Public interface ──────────────────────────────────────────────────

    def poll(self) -> list[RawInputEvent]:
        """
        Called each frame by the device layer.
        Generates new simulated events and returns them.
        """
        if self.state not in (DeviceState.CONNECTED, DeviceState.ACTIVE):
            return []
        new_events = self._generate_events()
        for ev in new_events:
            self._queue.append(ev)
            self._event_count += 1
        self.state = DeviceState.ACTIVE if new_events else DeviceState.CONNECTED
        return new_events

    def drain(self) -> list[RawInputEvent]:
        """Drain the full event queue. Called by input router."""
        events = list(self._queue)
        self._queue.clear()
        return events

    def disconnect(self) -> None:
        self.state = DeviceState.DISCONNECTED
        self._queue.clear()

    @property
    def queue_depth(self) -> int:
        return len(self._queue)

    @property
    def event_count(self) -> int:
        return self._event_count

    # ── Subclass hook ─────────────────────────────────────────────────────

    def _generate_events(self) -> list[RawInputEvent]:
        raise NotImplementedError

    def _make_event(self, event_type: RawEventType, code: str, value: float) -> RawInputEvent:
        return RawInputEvent(
            device_id=self.device_id,
            device_type=self.device_type,
            event_type=event_type,
            code=code,
            value=value,
        )


# ── Concrete device types ─────────────────────────────────────────────────────

class ControllerDevice(InputDevice):
    """
    Standard gamepad: D-pad, 2 analog sticks, 6 face buttons, 2 triggers.
    Simulates realistic intermittent input with analog drift.
    """

    def __init__(self, device_id: str) -> None:
        super().__init__(device_id, DeviceType.CONTROLLER)
        self._analog_state: dict[str, float] = {ax: 0.0 for ax in CONTROLLER_AXES}
        self._button_state: dict[str, bool]  = {btn: False for btn in CONTROLLER_BUTTONS}
        self._frame = 0

    def _generate_events(self) -> list[RawInputEvent]:
        self._frame += 1
        events: list[RawInputEvent] = []

        # Button press simulation: ~8% chance per frame some button changes
        if self._rng.random() < 0.08:
            btn = self._rng.choice(CONTROLLER_BUTTONS)
            pressed = not self._button_state[btn]
            self._button_state[btn] = pressed
            events.append(self._make_event(
                RawEventType.KEY_DOWN if pressed else RawEventType.KEY_UP,
                btn, 1.0 if pressed else 0.0,
            ))

        # Analog axis drift simulation: small noise on sticks
        if self._rng.random() < 0.30:
            axis = self._rng.choice(["AXIS_LX", "AXIS_LY", "AXIS_RX", "AXIS_RY"])
            drift = self._rng.uniform(-0.15, 0.15)
            new_val = max(-1.0, min(1.0, self._analog_state[axis] + drift))
            # Deadzone: values under 0.1 snap to zero
            if abs(new_val) < 0.10:
                new_val = 0.0
            if abs(new_val - self._analog_state[axis]) > 0.05:
                self._analog_state[axis] = new_val
                events.append(self._make_event(RawEventType.AXIS_MOVE, axis, new_val))

        # Trigger pressure
        if self._rng.random() < 0.05:
            axis = self._rng.choice(["AXIS_LT", "AXIS_RT"])
            value = self._rng.uniform(0.0, 1.0)
            self._analog_state[axis] = value
            events.append(self._make_event(RawEventType.AXIS_MOVE, axis, value))

        return events


class KeyboardDevice(InputDevice):
    """
    USB or PS/2 keyboard. Digital only — no analog.
    Simulates WASD + arrow keys + action keys.
    """

    def __init__(self, device_id: str) -> None:
        super().__init__(device_id, DeviceType.KEYBOARD)
        self._key_state: dict[str, bool] = {k: False for k in KEYBOARD_KEYS}
        self._held_keys: set[str] = set()

    def _generate_events(self) -> list[RawInputEvent]:
        events: list[RawInputEvent] = []

        # Key press: ~6% chance
        if self._rng.random() < 0.06:
            key = self._rng.choice(KEYBOARD_KEYS)
            if key not in self._held_keys:
                self._held_keys.add(key)
                self._key_state[key] = True
                events.append(self._make_event(RawEventType.KEY_DOWN, key, 1.0))

        # Key release: ~10% chance for each held key
        to_release = [k for k in self._held_keys if self._rng.random() < 0.10]
        for key in to_release:
            self._held_keys.discard(key)
            self._key_state[key] = False
            events.append(self._make_event(RawEventType.KEY_UP, key, 0.0))

        return events


class ArcadeStickDevice(InputDevice):
    """
    8-way arcade joystick + 6–8 buttons.
    Simulates tournament-style input: clean directionals, deliberate buttons.
    No analog output — everything is digital.
    """

    def __init__(self, device_id: str) -> None:
        super().__init__(device_id, DeviceType.ARCADE_STICK)
        self._hat_state = (0, 0)
        self._btn_state: dict[str, bool] = {b: False for b in ARCADE_BUTTONS}

    def _generate_events(self) -> list[RawInputEvent]:
        events: list[RawInputEvent] = []

        # Hat (joystick direction): 12% change chance
        if self._rng.random() < 0.12:
            new_hat = self._rng.choice(ARCADE_HAT_VALUES)
            if new_hat != self._hat_state:
                self._hat_state = new_hat
                events.append(self._make_event(
                    RawEventType.HAT_CHANGE, "HAT_8WAY",
                    float(new_hat[0] * 10 + new_hat[1]),  # encode as single float
                ))

        # Button press: 7% chance
        if self._rng.random() < 0.07:
            btn = self._rng.choice(ARCADE_BUTTONS)
            pressed = not self._btn_state[btn]
            self._btn_state[btn] = pressed
            events.append(self._make_event(
                RawEventType.KEY_DOWN if pressed else RawEventType.KEY_UP,
                btn, 1.0 if pressed else 0.0,
            ))

        return events


class SteeringWheelDevice(InputDevice):
    """
    Analog steering wheel with force-feedback (simulated).
    Wheel axis [-1.0, 1.0], throttle/brake [0.0, 1.0], paddle shifters.
    """

    def __init__(self, device_id: str) -> None:
        super().__init__(device_id, DeviceType.STEERING_WHEEL)
        self._wheel_pos: float = 0.0
        self._throttle:  float = 0.0
        self._brake:     float = 0.0
        self._gear: int = 1

    def _generate_events(self) -> list[RawInputEvent]:
        events: list[RawInputEvent] = []

        # Steering: smooth sinusoidal sweep to simulate driving
        t = time.perf_counter()
        target_wheel = 0.6 * (0.5 * (1 + self._rng.gauss(
            0.3 * (1 if (int(t) % 6 < 3) else -1), 0.1
        )))
        target_wheel = max(-1.0, min(1.0, target_wheel))
        if abs(target_wheel - self._wheel_pos) > 0.02:
            self._wheel_pos += (target_wheel - self._wheel_pos) * 0.15
            events.append(self._make_event(RawEventType.AXIS_MOVE, "AXIS_WHEEL", self._wheel_pos))

        # Throttle / brake: mutually exclusive, realistic driving pattern
        if self._rng.random() < 0.15:
            if self._rng.random() < 0.7:
                self._throttle = min(1.0, self._throttle + self._rng.uniform(0, 0.2))
                self._brake = max(0.0, self._brake - 0.3)
            else:
                self._brake = min(1.0, self._brake + self._rng.uniform(0, 0.3))
                self._throttle = max(0.0, self._throttle - 0.4)
            events.append(self._make_event(RawEventType.AXIS_MOVE, "AXIS_THROTTLE", self._throttle))
            events.append(self._make_event(RawEventType.AXIS_MOVE, "AXIS_BRAKE", self._brake))

        # Gear shifts: occasional
        if self._rng.random() < 0.02:
            shift = "BTN_SHIFT_UP" if self._rng.random() < 0.6 else "BTN_SHIFT_DOWN"
            events.append(self._make_event(RawEventType.KEY_DOWN, shift, 1.0))

        return events


# ── Device registry ───────────────────────────────────────────────────────────

class DeviceRegistry:
    """
    Manages all connected physical devices.
    Provides discovery, polling, and disconnection.
    """

    _TYPE_MAP: dict[DeviceType, type] = {
        DeviceType.CONTROLLER:     ControllerDevice,
        DeviceType.KEYBOARD:       KeyboardDevice,
        DeviceType.ARCADE_STICK:   ArcadeStickDevice,
        DeviceType.STEERING_WHEEL: SteeringWheelDevice,
    }

    def __init__(self) -> None:
        self._devices: dict[str, InputDevice] = {}
        self._counter = 0

    def connect(self, device_type: DeviceType, device_id: Optional[str] = None) -> InputDevice:
        self._counter += 1
        did = device_id or f"{device_type.name.lower()}_{self._counter:02d}"
        cls = self._TYPE_MAP[device_type]
        device = cls(did)
        self._devices[did] = device
        from utils.logging import log
        log.input_ev(f"Device CONNECT: [{did}] type={device_type.name}")
        return device

    def disconnect(self, device_id: str) -> None:
        if device_id in self._devices:
            self._devices[device_id].disconnect()
            del self._devices[device_id]
            from utils.logging import log
            log.input_ev(f"Device DISCONNECT: [{device_id}]")

    def poll_all(self) -> dict[str, list[RawInputEvent]]:
        """Poll every connected device. Returns {device_id: [events]}."""
        return {
            did: device.poll()
            for did, device in self._devices.items()
            if device.state != DeviceState.DISCONNECTED
        }

    def drain_all(self) -> dict[str, list[RawInputEvent]]:
        """Drain queues from all devices."""
        return {
            did: device.drain()
            for did, device in self._devices.items()
        }

    @property
    def connected_devices(self) -> dict[str, InputDevice]:
        return {k: v for k, v in self._devices.items() if v.state != DeviceState.DISCONNECTED}

    @property
    def device_count(self) -> int:
        return len(self.connected_devices)

    def get_device(self, device_id: str) -> Optional[InputDevice]:
        return self._devices.get(device_id)
