"""
ARCADIUM OS — input/input_router.py
Full input pipeline: DeviceRegistry → IntentMapper → PlayerSlotManager.

This is the single frame-tick entry point for all input processing.
Called once per kernel frame, it polls all devices, maps events to
intents, and routes intents to their assigned player slots.
"""
import time
from dataclasses import dataclass, field
from typing import Optional

from input.device_layer import DeviceRegistry, InputDevice, DeviceType, RawInputEvent
from input.intent_system import IntentMapper, PlayerIntent
from input.player_slot_manager import PlayerSlotManager
from utils.logging import log
from utils.timing import Stopwatch


@dataclass
class InputFrameStats:
    """Per-frame statistics from the input pipeline."""
    frame:           int   = 0
    devices_polled:  int   = 0
    raw_events:      int   = 0
    intents_mapped:  int   = 0
    slots_active:    int   = 0
    pipeline_us:     float = 0.0   # total time in μs


class InputRouter:
    """
    Wires DeviceRegistry → IntentMapper → PlayerSlotManager.

    Frame tick sequence:
      1. poll_all() — ask every device for new raw events
      2. map_all()  — convert raw events to intents via IntentMapper
      3. route_all() — deliver intents to player slots
    """

    def __init__(
        self,
        registry: DeviceRegistry,
        mapper: IntentMapper,
        slots: PlayerSlotManager,
    ) -> None:
        self._registry = registry
        self._mapper   = mapper
        self._slots    = slots
        self._frame    = 0
        self._stats    = InputFrameStats()
        self._stopwatch = Stopwatch()

    # ── Main frame tick ───────────────────────────────────────────────────

    def tick(self) -> InputFrameStats:
        """
        Execute one full input frame.
        Returns statistics for budget accounting.
        """
        self._frame += 1
        self._stopwatch.start()

        raw_events_total = 0
        intents_total = 0
        active_devices = 0

        # 1. Poll all connected devices for raw events
        device_events: dict[str, list[RawInputEvent]] = self._registry.poll_all()

        for device_id, raw_events in device_events.items():
            if not raw_events:
                continue

            active_devices += 1
            raw_events_total += len(raw_events)

            # 2. Map raw events → intents
            intents: list[PlayerIntent] = self._mapper.map_many(raw_events)
            intents_total += len(intents)

            if not intents:
                continue

            # 3. Route intents to assigned player slot
            slot_id = self._slots.route_intents(device_id, intents)
            if slot_id is None:
                # Device has no slot — log first occurrence only
                log.debug("ROUTER", f"Unrouted intents from {device_id} (no slot assigned)")

        elapsed_us = self._stopwatch.stop()

        # Update stats
        active_slot_count = sum(
            1 for s in self._slots.occupied_slots()
            if s.state.name == "ACTIVE"
        )

        self._stats = InputFrameStats(
            frame=self._frame,
            devices_polled=len(device_events),
            raw_events=raw_events_total,
            intents_mapped=intents_total,
            slots_active=active_slot_count,
            pipeline_us=elapsed_us,
        )

        if raw_events_total > 0:
            log.debug(
                "ROUTER",
                f"frame={self._frame} devices={len(device_events)} "
                f"raw={raw_events_total} intents={intents_total} "
                f"us={elapsed_us:.1f}"
            )

        return self._stats

    # ── Device management helpers ─────────────────────────────────────────

    def connect_device(
        self,
        device_type: DeviceType,
        session_id: Optional[str] = None,
        preferred_slot: Optional[int] = None,
        device_id: Optional[str] = None,
    ) -> tuple[InputDevice, int]:
        """
        Connect a new device and immediately assign it to a player slot.
        Returns (device, slot_id).
        """
        device = self._registry.connect(device_type, device_id=device_id)
        slot_id = self._slots.assign(device, session_id=session_id, preferred_slot=preferred_slot)
        if slot_id is None:
            log.warn("ROUTER", f"Device {device.device_id} connected but no free slot available")
            return device, -1
        return device, slot_id

    def disconnect_device(self, device_id: str) -> None:
        """Disconnect a device and free its slot."""
        self._slots.release(device_id)
        self._registry.disconnect(device_id)

    # ── Query ─────────────────────────────────────────────────────────────

    @property
    def stats(self) -> InputFrameStats:
        return self._stats

    @property
    def registry(self) -> DeviceRegistry:
        return self._registry

    @property
    def slots(self) -> PlayerSlotManager:
        return self._slots

    @property
    def mapper(self) -> IntentMapper:
        return self._mapper

    def active_device_count(self) -> int:
        return self._registry.device_count

    def active_player_count(self) -> int:
        return len(self._slots.occupied_slots())
