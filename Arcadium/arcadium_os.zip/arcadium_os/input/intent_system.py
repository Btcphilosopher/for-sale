"""
ARCADIUM OS — input/intent_system.py
Raw device events → device-agnostic player intents.

Once an event enters this layer, its physical origin is irrelevant.
A BTN_A on a controller, KEY_SPACE on a keyboard, and BTN_1 on an
arcade stick can all map to Intent.ACTION_A — the game sees only intents.
"""
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional
import time

from input.device_layer import (
    RawInputEvent, RawEventType, DeviceType,
    CONTROLLER_BUTTONS, ARCADE_HAT_VALUES,
)


# ── Intent vocabulary ─────────────────────────────────────────────────────────

class Intent(Enum):
    """
    Complete set of device-agnostic player intents understood by the OS.
    Games receive these — never raw hardware codes.
    """
    # Directional
    DIR_UP      = auto()
    DIR_DOWN    = auto()
    DIR_LEFT    = auto()
    DIR_RIGHT   = auto()
    DIR_UP_LEFT    = auto()
    DIR_UP_RIGHT   = auto()
    DIR_DOWN_LEFT  = auto()
    DIR_DOWN_RIGHT = auto()
    DIR_NEUTRAL    = auto()

    # Actions (face buttons)
    ACTION_A    = auto()   # primary confirm / jump
    ACTION_B    = auto()   # secondary / cancel
    ACTION_X    = auto()   # tertiary
    ACTION_Y    = auto()   # quaternary

    # Shoulder / trigger
    SHOULDER_L  = auto()
    SHOULDER_R  = auto()
    TRIGGER_L   = auto()   # analog [0–1] encoded in value
    TRIGGER_R   = auto()

    # System
    START       = auto()
    SELECT      = auto()
    COIN_INSERT = auto()

    # Analog (value carries magnitude [-1.0, 1.0])
    ANALOG_LX   = auto()
    ANALOG_LY   = auto()
    ANALOG_RX   = auto()
    ANALOG_RY   = auto()
    ANALOG_WHEEL = auto()
    ANALOG_THROTTLE = auto()
    ANALOG_BRAKE = auto()

    # Meta
    UNKNOWN     = auto()


class IntentState(Enum):
    PRESSED  = auto()
    HELD     = auto()
    RELEASED = auto()
    ANALOG   = auto()   # continuous value, no press/release semantics


@dataclass(slots=True)
class PlayerIntent:
    """
    A single resolved, device-agnostic intent for a player.
    This is what the session/game logic receives.
    """
    intent:      Intent
    state:       IntentState
    value:       float          # 1.0 for digital press, [-1,1] for analog
    device_id:   str
    device_type: DeviceType
    timestamp:   float = field(default_factory=time.perf_counter)


# ── Per-device intent maps ────────────────────────────────────────────────────

_CONTROLLER_BUTTON_MAP: dict[str, Intent] = {
    "BTN_A":      Intent.ACTION_A,
    "BTN_B":      Intent.ACTION_B,
    "BTN_X":      Intent.ACTION_X,
    "BTN_Y":      Intent.ACTION_Y,
    "BTN_LB":     Intent.SHOULDER_L,
    "BTN_RB":     Intent.SHOULDER_R,
    "BTN_START":  Intent.START,
    "BTN_SELECT": Intent.SELECT,
    "BTN_LSTICK": Intent.UNKNOWN,
    "BTN_RSTICK": Intent.UNKNOWN,
}

_CONTROLLER_AXIS_MAP: dict[str, Intent] = {
    "AXIS_LX": Intent.ANALOG_LX,
    "AXIS_LY": Intent.ANALOG_LY,
    "AXIS_RX": Intent.ANALOG_RX,
    "AXIS_RY": Intent.ANALOG_RY,
    "AXIS_LT": Intent.TRIGGER_L,
    "AXIS_RT": Intent.TRIGGER_R,
}

_KEYBOARD_MAP: dict[str, Intent] = {
    "KEY_W":      Intent.DIR_UP,
    "KEY_S":      Intent.DIR_DOWN,
    "KEY_A":      Intent.DIR_LEFT,
    "KEY_D":      Intent.DIR_RIGHT,
    "KEY_UP":     Intent.DIR_UP,
    "KEY_DOWN":   Intent.DIR_DOWN,
    "KEY_LEFT":   Intent.DIR_LEFT,
    "KEY_RIGHT":  Intent.DIR_RIGHT,
    "KEY_SPACE":  Intent.ACTION_A,
    "KEY_ENTER":  Intent.START,
    "KEY_LSHIFT": Intent.ACTION_B,
    "KEY_Z":      Intent.ACTION_X,
    "KEY_X":      Intent.ACTION_Y,
    "KEY_C":      Intent.SHOULDER_L,
}

_ARCADE_BUTTON_MAP: dict[str, Intent] = {
    "BTN_1":     Intent.ACTION_A,
    "BTN_2":     Intent.ACTION_B,
    "BTN_3":     Intent.ACTION_X,
    "BTN_4":     Intent.ACTION_Y,
    "BTN_5":     Intent.SHOULDER_L,
    "BTN_6":     Intent.SHOULDER_R,
    "BTN_COIN":  Intent.COIN_INSERT,
    "BTN_START": Intent.START,
}

# Hat value → intent  (encoded as x*10+y)
_HAT_INTENT_MAP: dict[float, Intent] = {
    0.0:    Intent.DIR_NEUTRAL,
    10.0:   Intent.DIR_RIGHT,
    -10.0:  Intent.DIR_LEFT,
    1.0:    Intent.DIR_UP,
    -1.0:   Intent.DIR_DOWN,
    11.0:   Intent.DIR_UP_RIGHT,
    9.0:    Intent.DIR_UP_LEFT,   # x=-1, y=1 → -10+1 = -9? No: (-1)*10+1=-9
    -9.0:   Intent.DIR_DOWN_RIGHT,  # 1*10+(-1)=9 → up_right... let me redo
}

# Recalculate: value = x*10 + y
# (0,0)=0, (1,0)=10, (-1,0)=-10, (0,1)=1, (0,-1)=-1
# (1,1)=11, (1,-1)=9, (-1,1)=-9, (-1,-1)=-11
_HAT_INTENT_MAP = {
     0.0:  Intent.DIR_NEUTRAL,
    10.0:  Intent.DIR_RIGHT,
   -10.0:  Intent.DIR_LEFT,
     1.0:  Intent.DIR_UP,
    -1.0:  Intent.DIR_DOWN,
    11.0:  Intent.DIR_UP_RIGHT,
     9.0:  Intent.DIR_DOWN_RIGHT,
    -9.0:  Intent.DIR_UP_LEFT,
   -11.0:  Intent.DIR_DOWN_LEFT,
}

_WHEEL_AXIS_MAP: dict[str, Intent] = {
    "AXIS_WHEEL":    Intent.ANALOG_WHEEL,
    "AXIS_THROTTLE": Intent.ANALOG_THROTTLE,
    "AXIS_BRAKE":    Intent.ANALOG_BRAKE,
    "AXIS_CLUTCH":   Intent.UNKNOWN,
}

_WHEEL_BUTTON_MAP: dict[str, Intent] = {
    "BTN_SHIFT_UP":   Intent.SHOULDER_R,
    "BTN_SHIFT_DOWN": Intent.SHOULDER_L,
    "BTN_VIEW":       Intent.SELECT,
    "BTN_MENU":       Intent.START,
}


# ── Intent mapper ─────────────────────────────────────────────────────────────

class IntentMapper:
    """
    Stateless intent translation engine.
    Converts RawInputEvent → PlayerIntent for any supported device type.
    """

    def map(self, event: RawInputEvent) -> Optional[PlayerIntent]:
        """
        Translate one raw event to a player intent.
        Returns None if the event has no meaningful intent mapping.
        """
        dt = event.device_type

        if dt == DeviceType.CONTROLLER:
            return self._map_controller(event)
        elif dt == DeviceType.KEYBOARD:
            return self._map_keyboard(event)
        elif dt == DeviceType.ARCADE_STICK:
            return self._map_arcade(event)
        elif dt == DeviceType.STEERING_WHEEL:
            return self._map_wheel(event)
        return None

    def map_many(self, events: list[RawInputEvent]) -> list[PlayerIntent]:
        """Map a batch of raw events to intents, filtering None."""
        result = []
        for ev in events:
            intent = self.map(ev)
            if intent is not None and intent.intent != Intent.UNKNOWN:
                result.append(intent)
        return result

    # ── Per-device mappers ────────────────────────────────────────────────

    def _map_controller(self, ev: RawInputEvent) -> Optional[PlayerIntent]:
        if ev.event_type in (RawEventType.KEY_DOWN, RawEventType.KEY_UP):
            intent = _CONTROLLER_BUTTON_MAP.get(ev.code, Intent.UNKNOWN)
            state  = IntentState.PRESSED if ev.value == 1.0 else IntentState.RELEASED
            return self._make(intent, state, ev.value, ev)

        elif ev.event_type == RawEventType.AXIS_MOVE:
            intent = _CONTROLLER_AXIS_MAP.get(ev.code, Intent.UNKNOWN)
            # D-pad digital from left stick
            if ev.code == "AXIS_LX":
                if ev.value > 0.5:
                    return self._make(Intent.DIR_RIGHT, IntentState.PRESSED, 1.0, ev)
                elif ev.value < -0.5:
                    return self._make(Intent.DIR_LEFT, IntentState.PRESSED, 1.0, ev)
                elif abs(ev.value) < 0.1:
                    return self._make(Intent.DIR_NEUTRAL, IntentState.RELEASED, 0.0, ev)
            elif ev.code == "AXIS_LY":
                if ev.value > 0.5:
                    return self._make(Intent.DIR_DOWN, IntentState.PRESSED, 1.0, ev)
                elif ev.value < -0.5:
                    return self._make(Intent.DIR_UP, IntentState.PRESSED, 1.0, ev)
            return self._make(intent, IntentState.ANALOG, ev.value, ev)

        return None

    def _map_keyboard(self, ev: RawInputEvent) -> Optional[PlayerIntent]:
        if ev.event_type not in (RawEventType.KEY_DOWN, RawEventType.KEY_UP):
            return None
        intent = _KEYBOARD_MAP.get(ev.code, Intent.UNKNOWN)
        state  = IntentState.PRESSED if ev.event_type == RawEventType.KEY_DOWN else IntentState.RELEASED
        return self._make(intent, state, ev.value, ev)

    def _map_arcade(self, ev: RawInputEvent) -> Optional[PlayerIntent]:
        if ev.event_type == RawEventType.HAT_CHANGE:
            intent = _HAT_INTENT_MAP.get(ev.value, Intent.DIR_NEUTRAL)
            return self._make(intent, IntentState.PRESSED, ev.value, ev)

        elif ev.event_type in (RawEventType.KEY_DOWN, RawEventType.KEY_UP):
            intent = _ARCADE_BUTTON_MAP.get(ev.code, Intent.UNKNOWN)
            state  = IntentState.PRESSED if ev.value == 1.0 else IntentState.RELEASED
            return self._make(intent, state, ev.value, ev)

        return None

    def _map_wheel(self, ev: RawInputEvent) -> Optional[PlayerIntent]:
        if ev.event_type == RawEventType.AXIS_MOVE:
            intent = _WHEEL_AXIS_MAP.get(ev.code, Intent.UNKNOWN)
            return self._make(intent, IntentState.ANALOG, ev.value, ev)

        elif ev.event_type in (RawEventType.KEY_DOWN, RawEventType.KEY_UP):
            intent = _WHEEL_BUTTON_MAP.get(ev.code, Intent.UNKNOWN)
            state  = IntentState.PRESSED if ev.value == 1.0 else IntentState.RELEASED
            return self._make(intent, state, ev.value, ev)

        return None

    @staticmethod
    def _make(
        intent: Intent,
        state: IntentState,
        value: float,
        ev: RawInputEvent,
    ) -> PlayerIntent:
        return PlayerIntent(
            intent=intent,
            state=state,
            value=value,
            device_id=ev.device_id,
            device_type=ev.device_type,
            timestamp=ev.timestamp,
        )
