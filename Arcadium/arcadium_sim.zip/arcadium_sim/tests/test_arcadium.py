"""
tests/test_arcadium.py
Comprehensive test suite for Arcadium Sim — 35 tests across all modules.
Run with: python -m pytest tests/ -v
Or:        python tests/test_arcadium.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import unittest
from core.system_architecture import CPUSpec, CPUArchitecture, MemorySpec, MemoryTechnology, BusWidth, IOBusSpec, PowerSpec, SystemArchitecture
from core.design_loop import score_architecture, DesignLoop
from core.scheduler import build_scheduler, DEFAULT_TASKS

from components.cpu_model import CPU_CATALOGUE, get_cpu, recommend_cpu, rank_by_perf_per_dollar
from components.memory_model import RAM_CATALOGUE, STORAGE_CATALOGUE, get_ram, get_storage, recommend_ram, memory_saturation_pct
from components.io_bus import BUS_CATALOGUE, get_bus, recommend_bus, simulate_bus_load

from input_system.controller_design import budget_controller, mid_range_controller, premium_controller
from input_system.device_profiles import DEVICE_PROFILES, get_profile
from input_system.signal_processing import (build_digital_button_pipeline,
    build_analog_stick_pipeline, aggregate_pipelines)

from devices.arcade_stick import budget_arcade_stick, standard_arcade_stick, pro_arcade_stick
from devices.controller import attach_budget_controller, attach_standard_controller
from devices.keyboard_matrix import menu_matrix, full_matrix, KeyboardMatrixInstance
from devices.steering_wheel_module import budget_wheel, standard_wheel, pro_wheel

from engineering.cost_model import BOMReport, BOMLineItem, CostCategory, suggest_optimisations
from engineering.thermal_model import build_console_thermal_model, throttling_simulation, CoolingMethod
from engineering.performance_model import compute_system_metrics, run_benchmark_suite, CostPerformanceAnalysis

from simulation.system_testbench import build_console_testbench
from simulation.stress_testing import StressTester, stress_normal_play, stress_4player_peak

from prototyping.console_builder import build_console, console_v1_prototype, console_v1_budget, console_v1_premium
from prototyping.iteration_engine import run_iteration_engine

from analytics.cost_report import generate_cost_report, MultiConfigCostComparison
from analytics.performance_report import generate_performance_report, PerformanceSweep


def _make_arch() -> SystemArchitecture:
    cpu = get_cpu("ARC-500")
    ram = get_ram("RAM-DRAM-4M")
    storage = get_storage("STOR-FLASH-32M")
    bus = get_bus("BUS-SPI-16")
    power = PowerSpec(5.0, 1000.0, 0.88)
    return SystemArchitecture("Test Console", "0.1", cpu, ram, storage, bus, power)


# ═══════════════════════════════════════════════════════════════ #
# 1. Core Architecture
# ═══════════════════════════════════════════════════════════════ #

class TestSystemArchitecture(unittest.TestCase):

    def setUp(self):
        self.arch = _make_arch()

    def test_bom_hardware_cost_positive(self):
        self.assertGreater(self.arch.bom_hardware_usd, 0)

    def test_effective_mips_positive(self):
        self.assertGreater(self.arch.effective_mips, 0)

    def test_effective_mips_less_than_raw(self):
        self.assertLess(self.arch.effective_mips, self.arch.cpu.throughput_mips)

    def test_summary_keys(self):
        s = self.arch.summary()
        for key in ("name", "version", "bom_hardware_usd", "effective_mips"):
            self.assertIn(key, s)


# ═══════════════════════════════════════════════════════════════ #
# 2. CPU Model
# ═══════════════════════════════════════════════════════════════ #

class TestCPUModel(unittest.TestCase):

    def test_catalogue_not_empty(self):
        self.assertGreater(len(CPU_CATALOGUE), 0)

    def test_get_cpu_found(self):
        cpu = get_cpu("ARC-500")
        self.assertIsNotNone(cpu)

    def test_get_cpu_not_found(self):
        self.assertIsNone(get_cpu("NONEXISTENT"))

    def test_recommend_cpu_within_budget(self):
        cpu = recommend_cpu(budget_usd=6.0, min_mips=100)
        self.assertIsNotNone(cpu)
        self.assertLessEqual(cpu.unit_cost_usd, 6.0)

    def test_throughput_positive(self):
        for cpu in CPU_CATALOGUE:
            self.assertGreater(cpu.throughput_mips, 0)

    def test_perf_per_dollar_ranking(self):
        ranked = rank_by_perf_per_dollar()
        self.assertEqual(len(ranked), len(CPU_CATALOGUE))


# ═══════════════════════════════════════════════════════════════ #
# 3. Memory Model
# ═══════════════════════════════════════════════════════════════ #

class TestMemoryModel(unittest.TestCase):

    def test_ram_catalogue_not_empty(self):
        self.assertGreater(len(RAM_CATALOGUE), 0)

    def test_get_ram(self):
        self.assertIsNotNone(get_ram("RAM-DRAM-4M"))

    def test_get_storage(self):
        self.assertIsNotNone(get_storage("STOR-FLASH-32M"))

    def test_memory_saturation_full(self):
        ram = get_ram("RAM-DRAM-4M")
        pct = memory_saturation_pct(ram, ram.capacity_kb * 2)
        self.assertEqual(pct, 100.0)

    def test_memory_saturation_partial(self):
        ram = get_ram("RAM-DRAM-4M")
        pct = memory_saturation_pct(ram, ram.capacity_kb * 0.5)
        self.assertAlmostEqual(pct, 50.0)


# ═══════════════════════════════════════════════════════════════ #
# 4. I/O Bus
# ═══════════════════════════════════════════════════════════════ #

class TestIOBus(unittest.TestCase):

    def test_bus_catalogue_not_empty(self):
        self.assertGreater(len(BUS_CATALOGUE), 0)

    def test_get_bus(self):
        self.assertIsNotNone(get_bus("BUS-SPI-16"))

    def test_bandwidth_positive(self):
        for bus in BUS_CATALOGUE:
            self.assertGreater(bus.bandwidth_mbps, 0)

    def test_bus_load_no_congestion_low_devices(self):
        bus = get_bus("BUS-USB-HS")
        report = simulate_bus_load(bus, 1, poll_hz=100.0)
        self.assertFalse(report.congestion)


# ═══════════════════════════════════════════════════════════════ #
# 5. Controller Design
# ═══════════════════════════════════════════════════════════════ #

class TestControllerDesign(unittest.TestCase):

    def test_budget_controller_bom(self):
        c = budget_controller()
        self.assertGreater(c.bom_cost_usd, 0)

    def test_premium_lower_latency_than_budget(self):
        self.assertLess(premium_controller().input_latency_us,
                        budget_controller().input_latency_us)

    def test_signal_fidelity_range(self):
        for ctrl in [budget_controller(), mid_range_controller(), premium_controller()]:
            self.assertBetween(ctrl.signal_fidelity_score, 0, 100)

    def assertBetween(self, value, lo, hi):
        self.assertGreaterEqual(value, lo)
        self.assertLessEqual(value, hi)


# ═══════════════════════════════════════════════════════════════ #
# 6. Signal Processing
# ═══════════════════════════════════════════════════════════════ #

class TestSignalProcessing(unittest.TestCase):

    def test_digital_pipeline_latency_positive(self):
        p = build_digital_button_pipeline("tactile")
        self.assertGreater(p.total_latency_us, 0)

    def test_optical_faster_than_membrane(self):
        opt = build_digital_button_pipeline("optical")
        mem = build_digital_button_pipeline("membrane")
        self.assertLess(opt.total_latency_us, mem.total_latency_us)

    def test_aggregate_pipeline(self):
        pipes = [build_digital_button_pipeline("tactile") for _ in range(4)]
        agg = aggregate_pipelines(pipes, cpu_mhz=500.0)
        self.assertEqual(agg.device_count, 4)
        self.assertGreater(agg.worst_latency_us, 0)


# ═══════════════════════════════════════════════════════════════ #
# 7. Devices
# ═══════════════════════════════════════════════════════════════ #

class TestDevices(unittest.TestCase):

    def test_arcade_stick_bom(self):
        stick = standard_arcade_stick()
        self.assertGreater(stick.bom_cost_usd, 0)

    def test_pro_stick_lower_latency(self):
        self.assertLess(pro_arcade_stick().latency_us, budget_arcade_stick().latency_us)

    def test_steering_wheel_fidelity_order(self):
        self.assertGreater(pro_wheel().signal_fidelity, budget_wheel().signal_fidelity)

    def test_keyboard_matrix_key_count(self):
        mat = full_matrix()
        self.assertEqual(mat.key_count, mat.rows * mat.cols)

    def test_controller_instance_buttons(self):
        ctrl = attach_budget_controller(port=1)
        ctrl.press_button(0)
        self.assertTrue(ctrl.button_states[0])
        ctrl.release_button(0)
        self.assertFalse(ctrl.button_states[0])


# ═══════════════════════════════════════════════════════════════ #
# 8. Cost Model
# ═══════════════════════════════════════════════════════════════ #

class TestCostModel(unittest.TestCase):

    def _build_bom(self) -> BOMReport:
        bom = BOMReport("Test Product")
        bom.add_item(BOMLineItem("CPU", CostCategory.SILICON, 1, 6.20))
        bom.add_item(BOMLineItem("RAM", CostCategory.SILICON, 1, 3.20))
        bom.add_item(BOMLineItem("PCB", CostCategory.PCB, 1, 4.50))
        return bom

    def test_raw_total(self):
        bom = self._build_bom()
        self.assertAlmostEqual(bom.raw_total_usd, 13.90, places=1)

    def test_total_higher_than_raw(self):
        bom = self._build_bom()
        self.assertGreater(bom.total_manufacturing_cost_usd, bom.raw_total_usd)

    def test_margin_at_target(self):
        bom = self._build_bom()
        self.assertGreater(bom.margin_at_target(100.0), 0)

    def test_suggest_optimisations_returns_list(self):
        bom = self._build_bom()
        opts = suggest_optimisations(bom)
        self.assertIsInstance(opts, list)


# ═══════════════════════════════════════════════════════════════ #
# 9. Thermal Model
# ═══════════════════════════════════════════════════════════════ #

class TestThermalModel(unittest.TestCase):

    def test_thermal_ok_low_load(self):
        model = build_console_thermal_model(500)
        self.assertTrue(model.system_ok({c.name: 0.2 for c in model.components}))

    def test_throttle_sim_returns_steps(self):
        model = build_console_thermal_model(450)
        results = throttling_simulation(model, load_steps=5)
        self.assertEqual(len(results), 6)   # 0..5 inclusive


# ═══════════════════════════════════════════════════════════════ #
# 10. Console Builder & Iteration
# ═══════════════════════════════════════════════════════════════ #

class TestConsoleBuilder(unittest.TestCase):

    def test_build_v1_prototype(self):
        design = build_console(console_v1_prototype())
        self.assertIsNotNone(design)
        self.assertGreater(design.architecture.effective_mips, 0)

    def test_build_budget(self):
        design = build_console(console_v1_budget())
        self.assertGreater(design.bom.raw_total_usd, 0)

    def test_iteration_engine_runs(self):
        result = run_iteration_engine(console_v1_prototype(),
                                      max_iterations=4,
                                      verbose=False)
        self.assertGreater(len(result.iterations), 0)

    def test_iteration_best_is_valid(self):
        result = run_iteration_engine(console_v1_prototype(),
                                      max_iterations=4,
                                      verbose=False)
        best = result.best_iteration()
        self.assertIsNotNone(best)
        self.assertGreater(best.score.composite, 0)


# ═══════════════════════════════════════════════════════════════ #
# 11. Testbench & Stress Tests
# ═══════════════════════════════════════════════════════════════ #

class TestTestbench(unittest.TestCase):

    def test_testbench_runs(self):
        arch = _make_arch()
        suite = build_console_testbench()
        report = suite.run_all(arch)
        self.assertGreater(report.total, 0)

    def test_stress_normal_play(self):
        tester = StressTester(820, 4096, 2.5)
        result = tester.run(stress_normal_play())
        self.assertGreaterEqual(result.stability_score(), 0)
        self.assertLessEqual(result.stability_score(), 100)

    def test_stress_4player_runs(self):
        tester = StressTester(820, 4096, 2.5)
        result = tester.run(stress_4player_peak())
        self.assertIsNotNone(result)


if __name__ == "__main__":
    loader = unittest.TestLoader()
    suite  = loader.loadTestsFromModule(sys.modules[__name__])
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
