"""
performance_model.py
System performance modelling: throughput, latency, bottleneck detection,
and cost/performance trade-off scoring for Arcadium Sim.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from enum import Enum


class BottleneckType(Enum):
    NONE            = "No bottleneck"
    CPU_SATURATED   = "CPU saturated"
    MEMORY_BANDWIDTH = "Memory bandwidth limited"
    MEMORY_CAPACITY  = "Memory capacity exhausted"
    BUS_CONGESTION  = "I/O bus congestion"
    INPUT_LATENCY   = "Input latency excessive"
    THERMAL         = "Thermal throttling"


@dataclass
class PerformanceMetrics:
    effective_mips: float
    memory_bandwidth_mbps: float
    memory_capacity_kb: float
    bus_bandwidth_mbps: float
    bus_latency_us: float
    input_latency_us: float
    cpu_load_pct: float
    memory_used_pct: float
    bus_utilisation_pct: float
    thermal_ok: bool

    def bottlenecks(self) -> List[BottleneckType]:
        found = []
        if self.cpu_load_pct >= 92:
            found.append(BottleneckType.CPU_SATURATED)
        if self.memory_bandwidth_mbps < 200 and self.effective_mips > 400:
            found.append(BottleneckType.MEMORY_BANDWIDTH)
        if self.memory_used_pct >= 90:
            found.append(BottleneckType.MEMORY_CAPACITY)
        if self.bus_utilisation_pct >= 80:
            found.append(BottleneckType.BUS_CONGESTION)
        if self.input_latency_us > 500:
            found.append(BottleneckType.INPUT_LATENCY)
        if not self.thermal_ok:
            found.append(BottleneckType.THERMAL)
        return found if found else [BottleneckType.NONE]

    def performance_score(self) -> float:
        """
        Composite 0–100 performance score.
        Penalised by each bottleneck class detected.
        """
        score = 100.0
        penalties = {
            BottleneckType.CPU_SATURATED:    -25.0,
            BottleneckType.MEMORY_BANDWIDTH: -15.0,
            BottleneckType.MEMORY_CAPACITY:  -20.0,
            BottleneckType.BUS_CONGESTION:   -18.0,
            BottleneckType.INPUT_LATENCY:    -12.0,
            BottleneckType.THERMAL:          -30.0,
        }
        for bt in self.bottlenecks():
            score += penalties.get(bt, 0.0)
        return max(0.0, score)

    def report(self) -> Dict[str, Any]:
        bns = self.bottlenecks()
        return {
            "effective_mips": round(self.effective_mips, 1),
            "memory_bw_mbps": round(self.memory_bandwidth_mbps, 1),
            "memory_used_pct": round(self.memory_used_pct, 1),
            "bus_util_pct": round(self.bus_utilisation_pct, 1),
            "input_latency_us": round(self.input_latency_us, 1),
            "cpu_load_pct": round(self.cpu_load_pct, 1),
            "thermal_ok": self.thermal_ok,
            "bottlenecks": [b.value for b in bns],
            "performance_score": round(self.performance_score(), 1),
        }


@dataclass
class CostPerformanceAnalysis:
    """
    Compares multiple design configurations on cost vs performance.
    """
    entries: List[Dict[str, Any]] = field(default_factory=list)

    def add_entry(self, name: str, bom_usd: float, perf_score: float,
                  notes: str = "") -> None:
        self.entries.append({
            "name": name,
            "bom_usd": round(bom_usd, 2),
            "perf_score": round(perf_score, 1),
            "efficiency": round(perf_score / bom_usd, 3) if bom_usd > 0 else 0.0,
            "notes": notes,
        })

    def ranked(self, by: str = "efficiency") -> List[Dict[str, Any]]:
        return sorted(self.entries, key=lambda e: e.get(by, 0), reverse=True)

    def best(self) -> Optional[Dict[str, Any]]:
        ranked = self.ranked()
        return ranked[0] if ranked else None

    def print_table(self) -> None:
        print(f"\n{'='*72}")
        print(f"  COST/PERFORMANCE ANALYSIS")
        print(f"{'='*72}")
        print(f"  {'Config':<25} {'BOM $':>8}  {'Perf':>6}  {'Efficiency':>10}  Notes")
        print(f"  {'-'*68}")
        for e in self.ranked():
            print(f"  {e['name']:<25} ${e['bom_usd']:>7.2f}  {e['perf_score']:>6.1f}  "
                  f"{e['efficiency']:>10.3f}  {e['notes'][:25]}")
        best = self.best()
        if best:
            print(f"\n  ✓ BEST EFFICIENCY: {best['name']}  "
                  f"(score {best['perf_score']} / ${best['bom_usd']})")
        print(f"{'='*72}\n")


# ---------------------------------------------------------------------- #
# Benchmark workload definitions
# ---------------------------------------------------------------------- #

@dataclass
class BenchmarkWorkload:
    name: str
    description: str
    min_mips_required: float
    min_ram_kb: float
    max_bus_latency_us: float
    max_input_latency_us: float

    def meets_requirements(self, metrics: PerformanceMetrics) -> bool:
        return (metrics.effective_mips >= self.min_mips_required and
                metrics.memory_capacity_kb * (1 - metrics.memory_used_pct/100)
                    >= self.min_ram_kb and
                metrics.bus_latency_us <= self.max_bus_latency_us and
                metrics.input_latency_us <= self.max_input_latency_us)


BENCHMARK_WORKLOADS: List[BenchmarkWorkload] = [
    BenchmarkWorkload(
        name="Simple_2D_Sprite",
        description="Classic 2D sprite game, 60Hz, 64 sprites on screen",
        min_mips_required=50,   min_ram_kb=128,
        max_bus_latency_us=50,  max_input_latency_us=1000,
    ),
    BenchmarkWorkload(
        name="Scrolling_Platformer",
        description="Multi-layer scrolling platformer with audio",
        min_mips_required=120,  min_ram_kb=512,
        max_bus_latency_us=20,  max_input_latency_us=500,
    ),
    BenchmarkWorkload(
        name="Beat_Em_Up_4Player",
        description="4-player co-op beat-em-up, complex AI, full audio",
        min_mips_required=280,  min_ram_kb=2048,
        max_bus_latency_us=10,  max_input_latency_us=200,
    ),
    BenchmarkWorkload(
        name="Racing_Sim_1Player",
        description="Physics-based racing, FFB output, 3D transforms",
        min_mips_required=600,  min_ram_kb=8192,
        max_bus_latency_us=5,   max_input_latency_us=80,
    ),
    BenchmarkWorkload(
        name="Fighting_Game_2P",
        description="2P frame-perfect fighting game",
        min_mips_required=200,  min_ram_kb=1024,
        max_bus_latency_us=5,   max_input_latency_us=100,
    ),
]


def run_benchmark_suite(metrics: PerformanceMetrics) -> List[Dict[str, Any]]:
    results = []
    for wl in BENCHMARK_WORKLOADS:
        passed = wl.meets_requirements(metrics)
        results.append({
            "workload": wl.name,
            "description": wl.description,
            "passed": passed,
            "status": "✓ PASS" if passed else "✗ FAIL",
        })
    return results


def compute_system_metrics(
    effective_mips: float,
    ram: Any,                    # MemorySpec
    bus: Any,                    # IOBusSpec
    cpu_load_pct: float,
    memory_used_pct: float,
    bus_util_pct: float,
    input_latency_us: float,
    thermal_ok: bool = True,
) -> PerformanceMetrics:
    return PerformanceMetrics(
        effective_mips=effective_mips,
        memory_bandwidth_mbps=ram.bandwidth_mbps,
        memory_capacity_kb=ram.capacity_kb,
        bus_bandwidth_mbps=bus.bandwidth_mbps,
        bus_latency_us=bus.latency_us,
        input_latency_us=input_latency_us,
        cpu_load_pct=cpu_load_pct,
        memory_used_pct=memory_used_pct,
        bus_utilisation_pct=bus_util_pct,
        thermal_ok=thermal_ok,
    )
