"""
cost_model.py
Full BOM and manufacturing cost model for Arcadium Sim.
Tracks every cost centre: silicon, passives, assembly, testing, packaging.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from enum import Enum


class CostCategory(Enum):
    SILICON       = "Silicon / ICs"
    PASSIVE       = "Passive Components"
    PCB           = "PCB Fabrication"
    ASSEMBLY      = "PCB Assembly (SMT/THT)"
    INPUT_DEVICES = "Input Device Hardware"
    MECHANICAL    = "Mechanical / Enclosure"
    CABLES        = "Cables & Connectors"
    THERMAL       = "Thermal Management"
    POWER         = "Power Supply"
    TESTING       = "QC / Functional Testing"
    PACKAGING     = "Retail Packaging"
    LOGISTICS     = "Shipping / Import Duty"
    OVERHEAD      = "Factory Overhead"


@dataclass
class BOMLineItem:
    description: str
    category: CostCategory
    quantity: int
    unit_cost_usd: float
    notes: str = ""

    @property
    def line_total_usd(self) -> float:
        return self.quantity * self.unit_cost_usd


@dataclass
class BOMReport:
    product_name: str
    items: List[BOMLineItem] = field(default_factory=list)
    yield_factor: float = 0.97          # manufacturing yield (3% waste)
    overhead_pct: float = 0.12          # 12% factory overhead
    logistics_pct: float = 0.08         # 8% logistics

    def add_item(self, item: BOMLineItem) -> "BOMReport":
        self.items.append(item)
        return self

    @property
    def raw_total_usd(self) -> float:
        return sum(i.line_total_usd for i in self.items)

    @property
    def yield_adjusted_usd(self) -> float:
        return self.raw_total_usd / self.yield_factor

    @property
    def overhead_usd(self) -> float:
        return self.yield_adjusted_usd * self.overhead_pct

    @property
    def logistics_usd(self) -> float:
        return self.yield_adjusted_usd * self.logistics_pct

    @property
    def total_manufacturing_cost_usd(self) -> float:
        return self.yield_adjusted_usd + self.overhead_usd + self.logistics_usd

    def by_category(self) -> Dict[str, float]:
        totals: Dict[str, float] = {}
        for item in self.items:
            key = item.category.value
            totals[key] = totals.get(key, 0.0) + item.line_total_usd
        return {k: round(v, 2) for k, v in sorted(totals.items(), key=lambda x: -x[1])}

    def margin_at_target(self, target_usd: float = 100.0) -> float:
        """Gross margin percentage if sold at target_usd."""
        cost = self.total_manufacturing_cost_usd
        if target_usd <= 0:
            return 0.0
        return ((target_usd - cost) / target_usd) * 100.0

    def over_budget(self, budget_usd: float = 100.0) -> float:
        return max(0.0, self.total_manufacturing_cost_usd - budget_usd)

    def report(self) -> Dict[str, Any]:
        return {
            "product": self.product_name,
            "line_items": len(self.items),
            "raw_bom_usd": round(self.raw_total_usd, 2),
            "yield_adjusted_usd": round(self.yield_adjusted_usd, 2),
            "overhead_usd": round(self.overhead_usd, 2),
            "logistics_usd": round(self.logistics_usd, 2),
            "total_mfr_cost_usd": round(self.total_manufacturing_cost_usd, 2),
            "margin_at_100usd_pct": round(self.margin_at_target(100.0), 1),
            "over_budget_usd": round(self.over_budget(100.0), 2),
            "by_category": self.by_category(),
        }

    def print_bom(self) -> None:
        print(f"\n{'='*62}")
        print(f"  BOM REPORT: {self.product_name}")
        print(f"{'='*62}")
        print(f"  {'Description':<30} {'Category':<20} {'Qty':>4}  {'Unit':>7}  {'Total':>8}")
        print(f"  {'-'*60}")
        for item in sorted(self.items, key=lambda x: -x.line_total_usd):
            print(f"  {item.description:<30} {item.category.value[:18]:<20} "
                  f"{item.quantity:>4}  ${item.unit_cost_usd:>6.2f}  ${item.line_total_usd:>7.2f}")
        print(f"  {'-'*60}")
        print(f"  {'Raw BOM Total':<50} ${self.raw_total_usd:>8.2f}")
        print(f"  {'Yield-adjusted (÷0.97)':<50} ${self.yield_adjusted_usd:>8.2f}")
        print(f"  {'Factory Overhead (+12%)':<50} ${self.overhead_usd:>8.2f}")
        print(f"  {'Logistics (+8%)':<50} ${self.logistics_usd:>8.2f}")
        print(f"  {'─'*60}")
        print(f"  {'TOTAL MFR COST':<50} ${self.total_manufacturing_cost_usd:>8.2f}")
        print(f"  {'Gross Margin @ $100 MSRP':<50} {self.margin_at_target(100.0):>7.1f}%")
        over = self.over_budget(100.0)
        if over > 0:
            print(f"  ⚠  OVER BUDGET by ${over:.2f}")
        print(f"{'='*62}\n")


# ------------------------------------------------------------------ #
# Optimisation helpers
# ------------------------------------------------------------------ #

@dataclass
class CostOptimisationResult:
    action: str
    delta_cost_usd: float
    delta_perf_pct: float
    feasible: bool
    notes: str


def suggest_optimisations(report: BOMReport) -> List[CostOptimisationResult]:
    """
    Analyse BOM and suggest cost-reduction options with trade-off notes.
    """
    results = []
    by_cat = report.by_category()

    # Silicon dominates?
    silicon_cost = by_cat.get(CostCategory.SILICON.value, 0)
    if silicon_cost > 20:
        results.append(CostOptimisationResult(
            action="Downgrade CPU to lower clock / fewer cores",
            delta_cost_usd=-3.50, delta_perf_pct=-18.0, feasible=True,
            notes="Reduces silicon cost but may cause frame-rate drops under load."
        ))

    # Input device heavy?
    input_cost = by_cat.get(CostCategory.INPUT_DEVICES.value, 0)
    if input_cost > 12:
        results.append(CostOptimisationResult(
            action="Switch premium controllers to mid-range",
            delta_cost_usd=-4.20, delta_perf_pct=-5.0, feasible=True,
            notes="Input latency increases ~180µs. Acceptable for casual titles."
        ))

    # PCB assembly expensive?
    assy_cost = by_cat.get(CostCategory.ASSEMBLY.value, 0)
    if assy_cost > 8:
        results.append(CostOptimisationResult(
            action="Consolidate PCBs (mainboard + IO on single board)",
            delta_cost_usd=-2.80, delta_perf_pct=0.0, feasible=True,
            notes="Reduces assembly cost but increases NRE for PCB redesign."
        ))

    # Packaging can be trimmed
    pkg_cost = by_cat.get(CostCategory.PACKAGING.value, 0)
    if pkg_cost > 4:
        results.append(CostOptimisationResult(
            action="Switch to minimal retail packaging (brown box)",
            delta_cost_usd=-2.10, delta_perf_pct=0.0, feasible=True,
            notes="Cosmetic change only. Reduces unboxing appeal."
        ))

    # RAM upgrade opportunity
    ram_cost = by_cat.get(CostCategory.SILICON.value, 0)
    if report.margin_at_target() > 20:
        results.append(CostOptimisationResult(
            action="Upgrade RAM to next tier (budget headroom available)",
            delta_cost_usd=+2.40, delta_perf_pct=+8.0, feasible=True,
            notes="Improves multitasking headroom. Still within budget."
        ))

    return results
