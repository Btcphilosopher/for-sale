"""
thermal_model.py
Simplified thermal and power constraint simulation for Arcadium Sim.
Models heat dissipation, junction temperatures, and throttling thresholds.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from enum import Enum


class CoolingMethod(Enum):
    PASSIVE_PCB   = "Passive PCB Copper Pour"
    HEATSINK      = "Passive Heatsink"
    THERMAL_PAD   = "Thermal Pad + Case"
    ACTIVE_FAN    = "Active Fan"
    HEATPIPE      = "Heatpipe + Heatsink"


class ThermalStatus(Enum):
    NORMAL    = "Normal"
    WARM      = "Warm"
    HOT       = "Hot — throttle risk"
    CRITICAL  = "Critical — shutdown imminent"


@dataclass
class ThermalComponent:
    name: str
    tdp_mw: float                    # thermal design power in milliwatts
    junction_temp_max_c: float        # Tj_max
    thermal_resistance_jc: float      # K/W junction-to-case
    thermal_resistance_ca: float      # K/W case-to-ambient (cooling dependent)

    def junction_temp_c(self, ambient_c: float = 35.0,
                        load_fraction: float = 1.0) -> float:
        power_w = (self.tdp_mw / 1000.0) * load_fraction
        return ambient_c + power_w * (self.thermal_resistance_jc + self.thermal_resistance_ca)

    def headroom_c(self, ambient_c: float = 35.0,
                   load_fraction: float = 1.0) -> float:
        return self.junction_temp_max_c - self.junction_temp_c(ambient_c, load_fraction)

    def status(self, ambient_c: float = 35.0, load_fraction: float = 1.0) -> ThermalStatus:
        tj = self.junction_temp_c(ambient_c, load_fraction)
        ratio = tj / self.junction_temp_max_c
        if ratio < 0.70:
            return ThermalStatus.NORMAL
        elif ratio < 0.85:
            return ThermalStatus.WARM
        elif ratio < 0.95:
            return ThermalStatus.HOT
        return ThermalStatus.CRITICAL


@dataclass
class ThermalModel:
    """
    Full system thermal model.
    Components: CPU, RAM, power regulator, IO bridge, etc.
    """
    ambient_c: float = 35.0          # worst-case ambient (e.g. arcade cabinet)
    cooling: CoolingMethod = CoolingMethod.THERMAL_PAD
    components: List[ThermalComponent] = field(default_factory=list)

    def add_component(self, comp: ThermalComponent) -> "ThermalModel":
        self.components.append(comp)
        return self

    def simulate(self, load_fractions: Optional[Dict[str, float]] = None) -> List[dict]:
        results = []
        for comp in self.components:
            lf = (load_fractions or {}).get(comp.name, 1.0)
            tj = comp.junction_temp_c(self.ambient_c, lf)
            status = comp.status(self.ambient_c, lf)
            results.append({
                "component": comp.name,
                "load_pct": round(lf * 100, 1),
                "tj_c": round(tj, 1),
                "tj_max_c": comp.junction_temp_max_c,
                "headroom_c": round(comp.headroom_c(self.ambient_c, lf), 1),
                "status": status.value,
            })
        return results

    def worst_case(self, load_fractions: Optional[Dict[str, float]] = None) -> dict:
        results = self.simulate(load_fractions)
        if not results:
            return {}
        return max(results, key=lambda r: r["tj_c"] / r["tj_max_c"])

    def system_ok(self, load_fractions: Optional[Dict[str, float]] = None) -> bool:
        worst = self.worst_case(load_fractions)
        return worst.get("status") not in (ThermalStatus.HOT.value,
                                           ThermalStatus.CRITICAL.value)

    def total_system_power_mw(self, load_fractions: Optional[Dict[str, float]] = None) -> float:
        total = 0.0
        for comp in self.components:
            lf = (load_fractions or {}).get(comp.name, 1.0)
            total += comp.tdp_mw * lf
        return total

    def report(self, load_fractions: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
        results = self.simulate(load_fractions)
        return {
            "cooling_method": self.cooling.value,
            "ambient_c": self.ambient_c,
            "total_power_mw": round(self.total_system_power_mw(load_fractions), 1),
            "components": results,
            "system_ok": self.system_ok(load_fractions),
        }


# ---------------------------------------------------------------------- #
# Preset thermal models for Arcadium Console v1
# ---------------------------------------------------------------------- #

def _cooling_resistance(method: CoolingMethod) -> float:
    """Case-to-ambient thermal resistance (K/W) by cooling method."""
    return {
        CoolingMethod.PASSIVE_PCB:  35.0,
        CoolingMethod.HEATSINK:     15.0,
        CoolingMethod.THERMAL_PAD:  20.0,
        CoolingMethod.ACTIVE_FAN:    8.0,
        CoolingMethod.HEATPIPE:      5.0,
    }.get(method, 20.0)


def build_console_thermal_model(
    cpu_tdp_mw: float,
    ram_tdp_mw: float = 120.0,
    io_tdp_mw: float = 80.0,
    pmic_tdp_mw: float = 150.0,
    cooling: CoolingMethod = CoolingMethod.THERMAL_PAD,
    ambient_c: float = 35.0,
) -> ThermalModel:

    rca = _cooling_resistance(cooling)

    model = ThermalModel(ambient_c=ambient_c, cooling=cooling)
    model.add_component(ThermalComponent(
        name="CPU", tdp_mw=cpu_tdp_mw,
        junction_temp_max_c=85.0,
        thermal_resistance_jc=8.0,
        thermal_resistance_ca=rca,
    ))
    model.add_component(ThermalComponent(
        name="RAM", tdp_mw=ram_tdp_mw,
        junction_temp_max_c=95.0,
        thermal_resistance_jc=15.0,
        thermal_resistance_ca=rca * 1.2,
    ))
    model.add_component(ThermalComponent(
        name="IO_Bridge", tdp_mw=io_tdp_mw,
        junction_temp_max_c=105.0,
        thermal_resistance_jc=20.0,
        thermal_resistance_ca=rca * 1.5,
    ))
    model.add_component(ThermalComponent(
        name="PMIC", tdp_mw=pmic_tdp_mw,
        junction_temp_max_c=125.0,
        thermal_resistance_jc=10.0,
        thermal_resistance_ca=rca * 0.8,
    ))
    return model


def throttling_simulation(
    model: ThermalModel,
    load_steps: int = 10,
) -> List[dict]:
    """
    Simulate system behaviour as CPU load increases from 0% to 100%.
    Returns list of dicts showing thermal state at each load step.
    """
    results = []
    for step in range(load_steps + 1):
        load = step / load_steps
        load_fracs = {comp.name: load for comp in model.components}
        # CPU runs hottest at full load, others scale differently
        load_fracs["RAM"]      = load * 0.7
        load_fracs["IO_Bridge"] = load * 0.5
        load_fracs["PMIC"]     = load * 0.85

        worst = model.worst_case(load_fracs)
        power = model.total_system_power_mw(load_fracs)
        results.append({
            "load_pct": round(load * 100, 0),
            "worst_component": worst.get("component", "N/A"),
            "worst_tj_c": worst.get("tj_c", 0),
            "total_power_mw": round(power, 1),
            "system_ok": model.system_ok(load_fracs),
        })
    return results
