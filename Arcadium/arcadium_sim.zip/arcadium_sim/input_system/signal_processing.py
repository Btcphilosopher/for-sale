"""
signal_processing.py
Input signal pipeline simulation for Arcadium Sim.
Models debounce, ADC sampling, interrupt dispatch, and latency chains.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from enum import Enum
import math


class FilterStage(Enum):
    DEBOUNCE    = "Debounce Filter"
    ADC_SAMPLE  = "ADC Sampling"
    NORMALISE   = "Value Normalise"
    DEADZONE    = "Deadzone Clamp"
    INTR_LATCH  = "Interrupt Latch"
    DMA_XFER    = "DMA Transfer"
    BUS_ENCODE  = "Bus Encode"
    CPU_INTR    = "CPU Interrupt"


@dataclass
class PipelineStage:
    stage: FilterStage
    latency_us: float
    cpu_cycles: int             # CPU cycles consumed
    drops_invalid: bool = False
    notes: str = ""


@dataclass
class SignalPipeline:
    """
    A complete input signal processing pipeline from switch actuation
    to CPU-side value availability.
    """
    name: str
    stages: List[PipelineStage] = field(default_factory=list)

    @property
    def total_latency_us(self) -> float:
        return sum(s.latency_us for s in self.stages)

    @property
    def total_cpu_cycles(self) -> int:
        return sum(s.cpu_cycles for s in self.stages)

    def add_stage(self, stage: PipelineStage) -> "SignalPipeline":
        self.stages.append(stage)
        return self

    def report(self) -> dict:
        return {
            "pipeline": self.name,
            "total_latency_us": round(self.total_latency_us, 2),
            "total_cpu_cycles": self.total_cpu_cycles,
            "stages": [
                {
                    "stage": s.stage.value,
                    "latency_us": s.latency_us,
                    "cpu_cycles": s.cpu_cycles,
                }
                for s in self.stages
            ]
        }


# ------------------------------------------------------------------ #
# Pipeline factories
# ------------------------------------------------------------------ #

def build_digital_button_pipeline(switch_type: str = "tactile") -> SignalPipeline:
    """
    Digital button press → CPU notification pipeline.
    """
    debounce_us = {
        "membrane": 15000.0,   # 15 ms software debounce
        "tactile":   1000.0,   # 1 ms
        "microswitch": 500.0,
        "optical":      50.0,
        "hall":         20.0,
    }.get(switch_type.lower(), 1000.0)

    p = SignalPipeline(name=f"Digital_{switch_type}_Pipeline")
    p.add_stage(PipelineStage(FilterStage.DEBOUNCE,   debounce_us, cpu_cycles=0,  drops_invalid=True))
    p.add_stage(PipelineStage(FilterStage.INTR_LATCH, 1.0,         cpu_cycles=4))
    p.add_stage(PipelineStage(FilterStage.BUS_ENCODE, 2.0,         cpu_cycles=8))
    p.add_stage(PipelineStage(FilterStage.CPU_INTR,   5.0,         cpu_cycles=32))
    return p


def build_analog_stick_pipeline(bits: int = 10, deadzone_pct: float = 5.0) -> SignalPipeline:
    """
    Analog stick → normalised float pipeline.
    """
    adc_us = (1.0 / (bits * 50_000)) * 1_000_000   # rough ADC conversion time
    p = SignalPipeline(name=f"Analog_{bits}bit_Pipeline")
    p.add_stage(PipelineStage(FilterStage.ADC_SAMPLE,  adc_us,  cpu_cycles=bits * 2))
    p.add_stage(PipelineStage(FilterStage.NORMALISE,   1.0,     cpu_cycles=6))
    p.add_stage(PipelineStage(FilterStage.DEADZONE,    0.5,     cpu_cycles=4,  notes=f"{deadzone_pct}% deadzone"))
    p.add_stage(PipelineStage(FilterStage.DMA_XFER,    2.0,     cpu_cycles=0))
    p.add_stage(PipelineStage(FilterStage.CPU_INTR,    5.0,     cpu_cycles=24))
    return p


def build_wheel_pipeline(bits: int = 12, has_ffb: bool = False) -> SignalPipeline:
    adc_us = (1.0 / (bits * 50_000)) * 1_000_000
    p = SignalPipeline(name="SteeringWheel_Pipeline")
    p.add_stage(PipelineStage(FilterStage.ADC_SAMPLE,  adc_us,  cpu_cycles=bits * 2))
    p.add_stage(PipelineStage(FilterStage.NORMALISE,   0.8,     cpu_cycles=6))
    p.add_stage(PipelineStage(FilterStage.DEADZONE,    0.5,     cpu_cycles=4))
    p.add_stage(PipelineStage(FilterStage.DMA_XFER,    2.0,     cpu_cycles=0))
    if has_ffb:
        # FFB output path adds round-trip latency
        p.add_stage(PipelineStage(FilterStage.BUS_ENCODE, 3.0,  cpu_cycles=12, notes="FFB command encode"))
    p.add_stage(PipelineStage(FilterStage.CPU_INTR,    5.0,     cpu_cycles=32))
    return p


# ------------------------------------------------------------------ #
# Multi-device pipeline aggregator
# ------------------------------------------------------------------ #

@dataclass
class AggregatedPipelineResult:
    device_count: int
    pipelines: List[SignalPipeline]
    worst_latency_us: float
    average_latency_us: float
    total_cpu_cycles_per_frame: int
    cpu_load_pct: float             # fraction of a 16.67ms frame

    def report(self) -> dict:
        return {
            "device_count": self.device_count,
            "worst_latency_us": round(self.worst_latency_us, 2),
            "average_latency_us": round(self.average_latency_us, 2),
            "total_cpu_cycles_per_frame": self.total_cpu_cycles_per_frame,
            "cpu_load_pct": round(self.cpu_load_pct, 2),
        }


def aggregate_pipelines(pipelines: List[SignalPipeline], cpu_mhz: float,
                        frame_hz: float = 60.0) -> AggregatedPipelineResult:
    latencies = [p.total_latency_us for p in pipelines]
    total_cycles = sum(p.total_cpu_cycles for p in pipelines)
    cycles_per_frame = int(cpu_mhz * 1_000_000 / frame_hz)
    cpu_load = (total_cycles / cycles_per_frame * 100.0) if cycles_per_frame else 0.0
    return AggregatedPipelineResult(
        device_count=len(pipelines),
        pipelines=pipelines,
        worst_latency_us=max(latencies) if latencies else 0.0,
        average_latency_us=sum(latencies) / len(latencies) if latencies else 0.0,
        total_cpu_cycles_per_frame=total_cycles,
        cpu_load_pct=min(100.0, cpu_load),
    )
