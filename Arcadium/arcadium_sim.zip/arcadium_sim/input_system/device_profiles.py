"""
device_profiles.py
Electronics profiles for all input device types.
Each profile captures the key electrical and mechanical parameters.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any
from enum import Enum


class DeviceClass(Enum):
    CONTROLLER      = "Controller"
    ARCADE_STICK    = "Arcade Stick"
    STEERING_WHEEL  = "Steering Wheel"
    KEYBOARD_MATRIX = "Keyboard Matrix"
    LIGHTGUN        = "Light Gun"
    TRACKBALL       = "Trackball"


@dataclass
class DeviceProfile:
    name: str
    device_class: DeviceClass
    supply_voltage_v: float
    idle_current_ma: float
    peak_current_ma: float
    poll_rate_hz: float
    data_bytes_per_poll: int
    latency_us: float           # hardware-side latency
    bom_cost_usd: float
    durability_score: float     # 0–100 abstract
    signal_fidelity: float      # 0–100 abstract
    notes: str = ""

    @property
    def bandwidth_bps(self) -> float:
        return self.data_bytes_per_poll * self.poll_rate_hz * 8

    @property
    def power_mw(self) -> float:
        return self.supply_voltage_v * self.peak_current_ma

    def profile_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "class": self.device_class.value,
            "voltage_v": self.supply_voltage_v,
            "peak_current_ma": self.peak_current_ma,
            "poll_hz": self.poll_rate_hz,
            "latency_us": self.latency_us,
            "bandwidth_bps": round(self.bandwidth_bps, 1),
            "bom_cost_usd": self.bom_cost_usd,
            "durability": self.durability_score,
            "fidelity": self.signal_fidelity,
        }


# ------------------------------------------------------------------ #
# Standard device profile catalogue
# ------------------------------------------------------------------ #

DEVICE_PROFILES: Dict[str, DeviceProfile] = {

    "budget_controller": DeviceProfile(
        name="ARC-CTRL-BUDGET", device_class=DeviceClass.CONTROLLER,
        supply_voltage_v=3.3, idle_current_ma=2.0, peak_current_ma=45.0,
        poll_rate_hz=125, data_bytes_per_poll=4, latency_us=200,
        bom_cost_usd=3.10, durability_score=42, signal_fidelity=48,
        notes="Budget membrane controller. Acceptable for casual play."
    ),

    "standard_controller": DeviceProfile(
        name="ARC-CTRL-STD", device_class=DeviceClass.CONTROLLER,
        supply_voltage_v=3.3, idle_current_ma=3.0, peak_current_ma=180.0,
        poll_rate_hz=500, data_bytes_per_poll=8, latency_us=50,
        bom_cost_usd=5.80, durability_score=68, signal_fidelity=72,
        notes="Standard tactile controller with rumble."
    ),

    "pro_controller": DeviceProfile(
        name="ARC-CTRL-PRO", device_class=DeviceClass.CONTROLLER,
        supply_voltage_v=3.3, idle_current_ma=4.0, peak_current_ma=280.0,
        poll_rate_hz=1000, data_bytes_per_poll=12, latency_us=5,
        bom_cost_usd=12.40, durability_score=95, signal_fidelity=96,
        notes="Hall-effect pro controller. Near-zero latency."
    ),

    "arcade_stick_budget": DeviceProfile(
        name="ARC-STICK-BUDGET", device_class=DeviceClass.ARCADE_STICK,
        supply_voltage_v=5.0, idle_current_ma=5.0, peak_current_ma=60.0,
        poll_rate_hz=250, data_bytes_per_poll=4, latency_us=120,
        bom_cost_usd=8.50, durability_score=55, signal_fidelity=62,
        notes="Budget arcade stick with square gate."
    ),

    "arcade_stick_pro": DeviceProfile(
        name="ARC-STICK-PRO", device_class=DeviceClass.ARCADE_STICK,
        supply_voltage_v=5.0, idle_current_ma=6.0, peak_current_ma=80.0,
        poll_rate_hz=1000, data_bytes_per_poll=6, latency_us=15,
        bom_cost_usd=18.90, durability_score=88, signal_fidelity=90,
        notes="Optical microswitches. Tournament-grade."
    ),

    "steering_wheel_budget": DeviceProfile(
        name="ARC-WHEEL-BUDGET", device_class=DeviceClass.STEERING_WHEEL,
        supply_voltage_v=5.0, idle_current_ma=80.0, peak_current_ma=600.0,
        poll_rate_hz=250, data_bytes_per_poll=8, latency_us=80,
        bom_cost_usd=14.20, durability_score=50, signal_fidelity=55,
        notes="Potentiometer steering, no FFB."
    ),

    "steering_wheel_ffb": DeviceProfile(
        name="ARC-WHEEL-FFB", device_class=DeviceClass.STEERING_WHEEL,
        supply_voltage_v=12.0, idle_current_ma=150.0, peak_current_ma=2000.0,
        poll_rate_hz=1000, data_bytes_per_poll=12, latency_us=8,
        bom_cost_usd=32.50, durability_score=78, signal_fidelity=88,
        notes="Force-feedback wheel. Significant power draw."
    ),

    "keyboard_matrix_16": DeviceProfile(
        name="ARC-KBD-16", device_class=DeviceClass.KEYBOARD_MATRIX,
        supply_voltage_v=3.3, idle_current_ma=1.0, peak_current_ma=20.0,
        poll_rate_hz=500, data_bytes_per_poll=3, latency_us=30,
        bom_cost_usd=2.40, durability_score=70, signal_fidelity=80,
        notes="16-key matrix. Suitable for menu/text entry."
    ),

    "keyboard_matrix_full": DeviceProfile(
        name="ARC-KBD-FULL", device_class=DeviceClass.KEYBOARD_MATRIX,
        supply_voltage_v=3.3, idle_current_ma=2.0, peak_current_ma=35.0,
        poll_rate_hz=1000, data_bytes_per_poll=8, latency_us=15,
        bom_cost_usd=5.60, durability_score=72, signal_fidelity=85,
        notes="Full 80-key matrix with anti-ghosting."
    ),
}


def get_profile(key: str) -> DeviceProfile:
    if key not in DEVICE_PROFILES:
        raise KeyError(f"Unknown device profile: '{key}'")
    return DEVICE_PROFILES[key]


def list_profiles() -> list:
    return [p.profile_dict() for p in DEVICE_PROFILES.values()]
