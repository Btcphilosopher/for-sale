"""
controller_design.py
Hardware model for designing arcade console controllers.
Covers button matrix, analog inputs, rumble, and PCB cost.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from enum import Enum


class SwitchType(Enum):
    TACTILE        = "Tactile"         # cheap dome switch
    MICROSWITCH    = "Microswitch"     # arcade-grade, durable
    OPTICAL        = "Optical"         # zero-wear, higher cost
    MEMBRANE       = "Membrane"        # cheapest, short lifespan
    HALL_EFFECT    = "Hall-Effect"     # analog + no wear


class AnalogInputType(Enum):
    NONE           = "None"
    POTENTIOMETER  = "Potentiometer"   # cheap, wears out
    HALL_STICK     = "Hall-Effect Stick"
    OPTICAL_STICK  = "Optical Stick"


@dataclass
class ButtonSpec:
    count: int
    switch_type: SwitchType
    unit_cost_usd: float            # per button
    actuation_force_g: float
    travel_mm: float
    rated_cycles: int               # lifetime in actuations

    @property
    def total_cost(self) -> float:
        return self.count * self.unit_cost_usd

    @property
    def durability_score(self) -> float:
        """0–100 based on rated cycles."""
        return min(100.0, self.rated_cycles / 10_000_000 * 100)


@dataclass
class AnalogSpec:
    input_type: AnalogInputType
    count: int
    resolution_bits: int
    deadzone_pct: float
    unit_cost_usd: float

    @property
    def total_cost(self) -> float:
        return self.count * self.unit_cost_usd

    @property
    def precision_score(self) -> float:
        return min(100.0, (self.resolution_bits / 12.0) * 80.0 +
                   (1 - self.deadzone_pct / 100.0) * 20.0)


@dataclass
class RumbleSpec:
    enabled: bool
    motor_count: int = 0
    unit_cost_usd: float = 0.0
    power_draw_ma: float = 0.0

    @property
    def total_cost(self) -> float:
        return self.motor_count * self.unit_cost_usd if self.enabled else 0.0


@dataclass
class ControllerDesign:
    name: str
    buttons: ButtonSpec
    analog: AnalogSpec
    rumble: RumbleSpec
    pcb_cost_usd: float         # PCB + passives + housing
    cable_cost_usd: float
    firmware_overhead_kb: float = 2.0   # firmware RAM footprint

    @property
    def bom_cost_usd(self) -> float:
        return (self.buttons.total_cost + self.analog.total_cost +
                self.rumble.total_cost + self.pcb_cost_usd + self.cable_cost_usd)

    @property
    def input_latency_us(self) -> float:
        """
        Heuristic latency model:
          - membrane: +200 µs (debounce)
          - optical:  +10  µs
          - hall:     +5   µs
          - tactile / microswitch: +50 µs
        """
        base = {
            SwitchType.MEMBRANE:     200.0,
            SwitchType.TACTILE:       50.0,
            SwitchType.MICROSWITCH:   40.0,
            SwitchType.OPTICAL:       10.0,
            SwitchType.HALL_EFFECT:    5.0,
        }.get(self.buttons.switch_type, 50.0)
        if self.analog.input_type != AnalogInputType.NONE:
            base += 15.0      # ADC sampling overhead
        return base

    @property
    def signal_fidelity_score(self) -> float:
        """Composite signal quality 0–100."""
        lat_score = max(0.0, 100.0 - self.input_latency_us / 3.0)
        return (lat_score * 0.6 + self.buttons.durability_score * 0.2 +
                self.analog.precision_score * 0.2)

    def summary(self) -> dict:
        return {
            "name": self.name,
            "buttons": f"{self.buttons.count}× {self.buttons.switch_type.value}",
            "analog": f"{self.analog.count}× {self.analog.input_type.value} ({self.analog.resolution_bits}-bit)",
            "rumble": f"{self.rumble.motor_count} motors" if self.rumble.enabled else "None",
            "bom_cost_usd": round(self.bom_cost_usd, 2),
            "input_latency_us": round(self.input_latency_us, 1),
            "signal_fidelity": round(self.signal_fidelity_score, 1),
            "durability_score": round(self.buttons.durability_score, 1),
        }


# ------------------------------------------------------------------ #
# Preset controller designs
# ------------------------------------------------------------------ #

def budget_controller() -> ControllerDesign:
    return ControllerDesign(
        name="ARC-PAD-BUDGET",
        buttons=ButtonSpec(count=8, switch_type=SwitchType.MEMBRANE,
                           unit_cost_usd=0.04, actuation_force_g=120,
                           travel_mm=0.2, rated_cycles=500_000),
        analog=AnalogSpec(AnalogInputType.POTENTIOMETER, count=2,
                          resolution_bits=8, deadzone_pct=8.0, unit_cost_usd=0.35),
        rumble=RumbleSpec(enabled=False),
        pcb_cost_usd=1.20,
        cable_cost_usd=0.40,
    )


def mid_range_controller() -> ControllerDesign:
    return ControllerDesign(
        name="ARC-PAD-STANDARD",
        buttons=ButtonSpec(count=10, switch_type=SwitchType.TACTILE,
                           unit_cost_usd=0.12, actuation_force_g=65,
                           travel_mm=1.5, rated_cycles=2_000_000),
        analog=AnalogSpec(AnalogInputType.POTENTIOMETER, count=2,
                          resolution_bits=10, deadzone_pct=5.0, unit_cost_usd=0.55),
        rumble=RumbleSpec(enabled=True, motor_count=1, unit_cost_usd=0.80, power_draw_ma=120),
        pcb_cost_usd=1.80,
        cable_cost_usd=0.55,
    )


def premium_controller() -> ControllerDesign:
    return ControllerDesign(
        name="ARC-PAD-PRO",
        buttons=ButtonSpec(count=12, switch_type=SwitchType.HALL_EFFECT,
                           unit_cost_usd=0.60, actuation_force_g=45,
                           travel_mm=1.8, rated_cycles=10_000_000),
        analog=AnalogSpec(AnalogInputType.HALL_STICK, count=2,
                          resolution_bits=12, deadzone_pct=2.0, unit_cost_usd=1.80),
        rumble=RumbleSpec(enabled=True, motor_count=2, unit_cost_usd=0.80, power_draw_ma=200),
        pcb_cost_usd=3.20,
        cable_cost_usd=0.80,
    )
