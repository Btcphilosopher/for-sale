"""
console_builder.py
Full console design assembly for Arcadium Sim.
Constructs complete SystemArchitecture instances from component selections.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import copy

from core.system_architecture import (
    SystemArchitecture, PowerSpec
)
from components.cpu_model import CPU_CATALOGUE, get_cpu
from components.memory_model import RAM_CATALOGUE, STORAGE_CATALOGUE, get_ram, get_storage
from components.io_bus import BUS_CATALOGUE, get_bus
from engineering.cost_model import (
    BOMReport, BOMLineItem, CostCategory
)


@dataclass
class ConsoleConfig:
    """
    High-level configuration spec for building a ConsoleDesign.
    Named component references resolved against catalogues.
    """
    name: str
    version: str
    cpu_name: str
    ram_name: str
    storage_name: str
    bus_name: str
    supply_voltage_v: float = 5.0
    peak_current_ma: float = 1200.0
    regulator_efficiency: float = 0.88
    max_input_devices: int = 4
    target_bom_usd: float = 100.0
    # BOM extras
    pcb_cost_usd: float = 4.50
    assembly_cost_usd: float = 7.00
    enclosure_cost_usd: float = 5.00
    power_supply_cost_usd: float = 3.00
    thermal_cost_usd: float = 1.50
    cables_cost_usd: float = 1.20
    testing_cost_usd: float = 2.50
    packaging_cost_usd: float = 3.80


@dataclass
class ConsoleDesign:
    config: ConsoleConfig
    architecture: SystemArchitecture
    bom: BOMReport

    @property
    def name(self) -> str:
        return self.config.name

    def summary(self) -> Dict[str, Any]:
        arch_s = self.architecture.summary()
        bom_r  = self.bom.report()
        return {
            "console": self.name,
            "version": self.config.version,
            "architecture": arch_s,
            "bom": bom_r,
        }

    def print_summary(self) -> None:
        print(f"\n{'═'*64}")
        print(f"  CONSOLE DESIGN: {self.name}  (v{self.config.version})")
        print(f"{'═'*64}")
        arch = self.architecture.summary()
        print(f"  CPU        : {arch['cpu']}")
        print(f"  RAM        : {arch['ram']}")
        print(f"  Storage    : {arch['storage']}")
        print(f"  I/O Bus    : {arch['io_bus']}")
        print(f"  MIPS       : {arch['effective_mips']}")
        print(f"  Peak Power : {arch['peak_power_mw']}mW")
        print(f"  Max Inputs : {arch['max_input_devices']}")
        self.bom.print_bom()


def build_console(config: ConsoleConfig) -> ConsoleDesign:
    """
    Resolve component names from catalogues, build SystemArchitecture,
    assemble full BOM report, return ConsoleDesign.
    """
    # ── Resolve components ──────────────────────────────────────── #
    cpu = get_cpu(config.cpu_name)
    if cpu is None:
        raise ValueError(f"CPU not found: {config.cpu_name}")

    ram = get_ram(config.ram_name)
    if ram is None:
        raise ValueError(f"RAM not found: {config.ram_name}")

    storage = get_storage(config.storage_name)
    if storage is None:
        raise ValueError(f"Storage not found: {config.storage_name}")

    bus = get_bus(config.bus_name)
    if bus is None:
        raise ValueError(f"Bus not found: {config.bus_name}")

    power = PowerSpec(
        supply_voltage_v=config.supply_voltage_v,
        peak_current_ma=config.peak_current_ma,
        regulator_efficiency=config.regulator_efficiency,
    )

    arch = SystemArchitecture(
        name=config.name,
        version=config.version,
        cpu=cpu,
        ram=ram,
        storage=storage,
        io_bus=bus,
        power=power,
        max_input_devices=config.max_input_devices,
        target_bom_usd=config.target_bom_usd,
    )

    # ── Build BOM ───────────────────────────────────────────────── #
    bom = BOMReport(product_name=config.name)

    bom.add_item(BOMLineItem("CPU — " + cpu.name, CostCategory.SILICON,
                             1, cpu.unit_cost_usd, cpu.notes))
    bom.add_item(BOMLineItem("RAM — " + ram.name, CostCategory.SILICON,
                             1, ram.unit_cost_usd, ram.notes))
    bom.add_item(BOMLineItem("Storage — " + storage.name, CostCategory.SILICON,
                             1, storage.unit_cost_usd, storage.notes))
    bom.add_item(BOMLineItem("I/O Bus — " + bus.name, CostCategory.SILICON,
                             1, bus.unit_cost_usd, bus.notes))
    bom.add_item(BOMLineItem("Passive Components (caps, resistors, ferrites)",
                             CostCategory.PASSIVE, 1, 1.80))
    bom.add_item(BOMLineItem("Mainboard PCB (4-layer)",
                             CostCategory.PCB, 1, config.pcb_cost_usd))
    bom.add_item(BOMLineItem("SMT + THT Assembly",
                             CostCategory.ASSEMBLY, 1, config.assembly_cost_usd))
    bom.add_item(BOMLineItem("Console Enclosure + Buttons",
                             CostCategory.MECHANICAL, 1, config.enclosure_cost_usd))
    bom.add_item(BOMLineItem("SMPS Power Supply",
                             CostCategory.POWER, 1, config.power_supply_cost_usd))
    bom.add_item(BOMLineItem("Thermal Pad + Heatspreader",
                             CostCategory.THERMAL, 1, config.thermal_cost_usd))
    bom.add_item(BOMLineItem("AV / USB / Power Cables",
                             CostCategory.CABLES, 1, config.cables_cost_usd))
    bom.add_item(BOMLineItem("Functional Test (per unit)",
                             CostCategory.TESTING, 1, config.testing_cost_usd))
    bom.add_item(BOMLineItem("Retail Box + Foam Inserts",
                             CostCategory.PACKAGING, 1, config.packaging_cost_usd))

    return ConsoleDesign(config=config, architecture=arch, bom=bom)


# ------------------------------------------------------------------ #
# Preset console configurations
# ------------------------------------------------------------------ #

def console_v1_prototype() -> ConsoleConfig:
    """First prototype — spec'd to hit $100 BOM with reasonable performance."""
    return ConsoleConfig(
        name="Arcadium Console v1",
        version="1.0-PROTO",
        cpu_name="ARC-500",
        ram_name="RAM-DRAM-4M",
        storage_name="STOR-FLASH-32M",
        bus_name="BUS-SPI-16",
        supply_voltage_v=5.0,
        peak_current_ma=1000.0,
        max_input_devices=4,
        target_bom_usd=100.0,
    )


def console_v1_budget() -> ConsoleConfig:
    """Budget variant — cut to minimum viable."""
    return ConsoleConfig(
        name="Arcadium Console v1 BUDGET",
        version="1.0-BDG",
        cpu_name="ARC-200",
        ram_name="RAM-DRAM-1M",
        storage_name="STOR-FLASH-8M",
        bus_name="BUS-SPI-8",
        supply_voltage_v=3.3,
        peak_current_ma=600.0,
        max_input_devices=2,
        target_bom_usd=100.0,
        pcb_cost_usd=3.20,
        assembly_cost_usd=5.50,
        enclosure_cost_usd=3.50,
        power_supply_cost_usd=2.20,
        packaging_cost_usd=2.40,
    )


def console_v1_premium() -> ConsoleConfig:
    """Premium variant — stretches budget for better silicon."""
    return ConsoleConfig(
        name="Arcadium Console v1 PREMIUM",
        version="1.0-PRE",
        cpu_name="ARC-A53-LITE",
        ram_name="RAM-DRAM-16M",
        storage_name="STOR-EMMC-1G",
        bus_name="BUS-USB-FS",
        supply_voltage_v=5.0,
        peak_current_ma=1800.0,
        max_input_devices=8,
        target_bom_usd=100.0,
        assembly_cost_usd=9.50,
        enclosure_cost_usd=7.00,
        packaging_cost_usd=5.20,
    )
