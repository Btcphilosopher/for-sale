"""
iteration_engine.py
Product development iteration engine for Arcadium Sim.
Drives the Design → Prototype → Simulate → Analyse → Optimise → Redesign cycle.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import copy

from core.system_architecture import SystemArchitecture
from core.design_loop import (
    DesignLoop, DesignScore, DesignEvent, IterationResult,
    score_architecture
)
from prototyping.console_builder import ConsoleConfig, ConsoleDesign, build_console
from components.cpu_model import CPU_CATALOGUE
from components.memory_model import RAM_CATALOGUE, STORAGE_CATALOGUE
from components.io_bus import BUS_CATALOGUE


# ------------------------------------------------------------------ #
# Optimiser logic: rule-based cost/performance balancer
# ------------------------------------------------------------------ #

def _next_cpu(current_name: str, direction: str) -> Optional[str]:
    """Move one step up or down the CPU catalogue by cost."""
    sorted_cpus = sorted(CPU_CATALOGUE, key=lambda c: c.unit_cost_usd)
    names = [c.name for c in sorted_cpus]
    idx = next((i for i, n in enumerate(names) if n == current_name), None)
    if idx is None:
        return None
    if direction == "up" and idx < len(names) - 1:
        return names[idx + 1]
    if direction == "down" and idx > 0:
        return names[idx - 1]
    return None


def _next_ram(current_name: str, direction: str) -> Optional[str]:
    sorted_ram = sorted(RAM_CATALOGUE, key=lambda m: m.capacity_kb)
    names = [m.name for m in sorted_ram]
    idx = next((i for i, n in enumerate(names) if n == current_name), None)
    if idx is None:
        return None
    if direction == "up" and idx < len(names) - 1:
        return names[idx + 1]
    if direction == "down" and idx > 0:
        return names[idx - 1]
    return None


def console_optimiser(arch: SystemArchitecture, score: DesignScore,
                      iteration: int) -> tuple[SystemArchitecture, list[DesignEvent]]:
    """
    Rule-based optimiser that adjusts component selection each iteration.
    Returns updated arch + list of design events describing changes.
    """
    events: List[DesignEvent] = []
    new_arch = copy.deepcopy(arch)

    # ── Rule 1: BOM over budget — downgrade CPU ─────────────────── #
    if score.cost_score < 45 and iteration <= 5:
        candidate = _next_cpu(new_arch.cpu.name, "down")
        if candidate:
            from components.cpu_model import get_cpu
            new_cpu = get_cpu(candidate)
            if new_cpu:
                delta_cost = new_arch.cpu.unit_cost_usd - new_cpu.unit_cost_usd
                delta_perf = ((new_cpu.throughput_mips - new_arch.cpu.throughput_mips)
                              / new_arch.cpu.throughput_mips * 100.0)
                new_arch.cpu = new_cpu
                events.append(DesignEvent(
                    iteration=iteration,
                    description=f"CPU downgrade: {candidate}",
                    delta_cost_usd=-delta_cost,
                    delta_perf_pct=delta_perf,
                    delta_power_mw=-(new_arch.cpu.tdp_mw - new_cpu.tdp_mw),
                    notes="Downgraded to reduce BOM cost."
                ))

    # ── Rule 2: Performance headroom is critical — upgrade CPU ───── #
    elif score.performance_score < 30 and score.cost_score > 55 and iteration <= 7:
        candidate = _next_cpu(new_arch.cpu.name, "up")
        if candidate:
            from components.cpu_model import get_cpu
            new_cpu = get_cpu(candidate)
            if new_cpu and (new_cpu.unit_cost_usd <=
                            new_arch.target_bom_usd * 0.18):
                delta_cost = new_cpu.unit_cost_usd - new_arch.cpu.unit_cost_usd
                delta_perf = ((new_cpu.throughput_mips - new_arch.cpu.throughput_mips)
                              / new_arch.cpu.throughput_mips * 100.0)
                new_arch.cpu = new_cpu
                events.append(DesignEvent(
                    iteration=iteration,
                    description=f"CPU upgrade: {candidate}",
                    delta_cost_usd=delta_cost,
                    delta_perf_pct=delta_perf,
                    delta_power_mw=new_cpu.tdp_mw - new_arch.cpu.tdp_mw,
                    notes="Upgraded for performance headroom."
                ))

    # ── Rule 3: RAM too small — upgrade if budget allows ─────────── #
    if score.performance_score < 50 and score.cost_score > 50 and iteration % 2 == 0:
        candidate = _next_ram(new_arch.ram.name, "up")
        if candidate:
            from components.memory_model import get_ram
            new_ram = get_ram(candidate)
            if new_ram and new_arch.bom_hardware_usd + (new_ram.unit_cost_usd
                    - new_arch.ram.unit_cost_usd) <= new_arch.target_bom_usd * 0.55:
                delta = new_ram.unit_cost_usd - new_arch.ram.unit_cost_usd
                new_arch.ram = new_ram
                events.append(DesignEvent(
                    iteration=iteration,
                    description=f"RAM upgrade: {candidate}",
                    delta_cost_usd=delta,
                    delta_perf_pct=+6.0,
                    delta_power_mw=+30.0,
                    notes="Increased RAM for better multitasking capacity."
                ))

    # ── Rule 4: Bus latency too high — upgrade bus ───────────────── #
    if score.input_stability < 40 and new_arch.io_bus.latency_us > 10.0:
        sorted_buses = sorted(BUS_CATALOGUE, key=lambda b: b.latency_us)
        better = next((b for b in sorted_buses
                       if b.latency_us < new_arch.io_bus.latency_us
                       and b.unit_cost_usd <= new_arch.io_bus.unit_cost_usd * 1.5
                       and b.max_devices >= new_arch.max_input_devices), None)
        if better:
            delta = better.unit_cost_usd - new_arch.io_bus.unit_cost_usd
            new_arch.io_bus = better
            events.append(DesignEvent(
                iteration=iteration,
                description=f"Bus upgrade: {better.name}",
                delta_cost_usd=delta,
                delta_perf_pct=+3.0,
                delta_power_mw=+10.0,
                notes="Lower latency bus for improved input stability."
            ))

    # ── Rule 5: Idle optimisation — log no change ────────────────── #
    if not events:
        events.append(DesignEvent(
            iteration=iteration,
            description="No redesign required — design converging",
            delta_cost_usd=0.0,
            delta_perf_pct=0.0,
            delta_power_mw=0.0,
            notes="Architecture stable at this iteration."
        ))

    return new_arch, events


# ------------------------------------------------------------------ #
# High-level Iteration Engine
# ------------------------------------------------------------------ #

@dataclass
class IterationEngineResult:
    initial_config: ConsoleConfig
    iterations: List[IterationResult]
    final_design: Optional[ConsoleDesign] = None

    def best_iteration(self) -> Optional[IterationResult]:
        if not self.iterations:
            return None
        return max(self.iterations, key=lambda r: r.score.composite)

    def convergence_table(self) -> List[Dict[str, Any]]:
        rows = []
        for r in self.iterations:
            rows.append({
                "iteration": r.iteration,
                "cpu": r.architecture.cpu.name,
                "ram": r.architecture.ram.name,
                "bom_usd": round(r.architecture.bom_hardware_usd, 2),
                "mips": round(r.architecture.effective_mips, 1),
                "composite": round(r.score.composite, 2),
                "events": "; ".join(e.description for e in r.events),
            })
        return rows

    def print_convergence(self) -> None:
        print(f"\n{'='*80}")
        print(f"  DESIGN ITERATION CONVERGENCE TABLE")
        print(f"  Initial Config: {self.initial_config.name}")
        print(f"{'='*80}")
        print(f"  {'Iter':>4}  {'CPU':<18}  {'RAM':<16}  "
              f"{'BOM $':>7}  {'MIPS':>6}  {'Score':>6}  Events")
        print(f"  {'-'*76}")
        for r in self.convergence_table():
            events_short = r["events"][:35] + "…" if len(r["events"]) > 35 else r["events"]
            print(f"  {r['iteration']:>4}  {r['cpu']:<18}  {r['ram']:<16}  "
                  f"${r['bom_usd']:>6.2f}  {r['mips']:>6.1f}  {r['composite']:>6.2f}  "
                  f"{events_short}")
        best = self.best_iteration()
        if best:
            print(f"\n  ★ BEST DESIGN: Iteration {best.iteration}  "
                  f"Score={best.score.composite:.2f}  "
                  f"CPU={best.architecture.cpu.name}  "
                  f"BOM=${best.architecture.bom_hardware_usd:.2f}")
        print(f"{'='*80}\n")


def run_iteration_engine(
    initial_config: ConsoleConfig,
    max_iterations: int = 12,
    target_score: float = 72.0,
    attached_devices: int = 4,
    verbose: bool = True,
) -> IterationEngineResult:
    """
    Main entry point for the design iteration engine.
    Builds initial console, runs optimiser loop, returns full result.
    """
    initial_design = build_console(initial_config)
    arch = initial_design.architecture

    if verbose:
        print(f"\n  ▶ Starting iteration engine: {initial_config.name}")
        print(f"    Target composite score ≥ {target_score}")

    loop = DesignLoop(
        initial_architecture=arch,
        optimiser=console_optimiser,
        max_iterations=max_iterations,
        attached_devices=attached_devices,
        target_composite_score=target_score,
        verbose=verbose,
    )

    iterations = loop.run()

    # Build final console from best architecture
    best = loop.best()
    final_design: Optional[ConsoleDesign] = None
    if best:
        # Patch config to match best architecture names
        final_cfg = copy.deepcopy(initial_config)
        final_cfg.cpu_name = best.architecture.cpu.name
        final_cfg.ram_name = best.architecture.ram.name
        final_cfg.version  = f"{initial_config.version}-OPT"
        final_design = build_console(final_cfg)

    return IterationEngineResult(
        initial_config=initial_config,
        iterations=iterations,
        final_design=final_design,
    )
