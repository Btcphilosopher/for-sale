"""
arcade_stick.py
Arcade stick hardware device model for Arcadium Sim.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from enum import Enum


class GateType(Enum):
    SQUARE    = "Square Gate"
    CIRCLE    = "Circle Gate"
    OCTAGONAL = "Octagonal Gate"


class StickMechanism(Enum):
    LEAF_SWITCH    = "Leaf Switch"
    MICROSWITCH    = "Microswitch"
    OPTICAL        = "Optical"
    HALL_EFFECT    = "Hall-Effect"


@dataclass
class ArcadeStickSpec:
    name: str
    gate: GateType
    mechanism: StickMechanism
    directions: int                 # 4 or 8
    button_count: int
    button_switch: str              # "microswitch", "optical", etc.
    stick_travel_mm: float
    actuator_diameter_mm: float
    rated_cycles_stick: int
    rated_cycles_buttons: int
    pcb_cost_usd: float
    stick_cost_usd: float
    button_cost_usd: float          # per button
    enclosure_cost_usd: float
    cable_cost_usd: float

    @property
    def bom_cost_usd(self) -> float:
        return (self.pcb_cost_usd + self.stick_cost_usd +
                self.button_cost_usd * self.button_count +
                self.enclosure_cost_usd + self.cable_cost_usd)

    @property
    def latency_us(self) -> float:
        base = {
            StickMechanism.LEAF_SWITCH:  500.0,
            StickMechanism.MICROSWITCH:  350.0,
            StickMechanism.OPTICAL:       30.0,
            StickMechanism.HALL_EFFECT:   10.0,
        }.get(self.mechanism, 350.0)
        # 8-way has slightly lower diagonal detection latency than 4-way
        if self.directions == 8:
            base *= 0.9
        return base

    @property
    def durability_score(self) -> float:
        stick_score = min(100.0, self.rated_cycles_stick / 5_000_000 * 100)
        btn_score   = min(100.0, self.rated_cycles_buttons / 5_000_000 * 100)
        return (stick_score * 0.5 + btn_score * 0.5)

    def summary(self) -> dict:
        return {
            "name": self.name,
            "gate": self.gate.value,
            "mechanism": self.mechanism.value,
            "directions": self.directions,
            "buttons": self.button_count,
            "bom_cost_usd": round(self.bom_cost_usd, 2),
            "latency_us": round(self.latency_us, 1),
            "durability_score": round(self.durability_score, 1),
        }


# ------------------------------------------------------------------ #
# Preset arcade stick designs
# ------------------------------------------------------------------ #

def budget_arcade_stick() -> ArcadeStickSpec:
    return ArcadeStickSpec(
        name="ARC-STICK-V1-BUDGET",
        gate=GateType.SQUARE,
        mechanism=StickMechanism.MICROSWITCH,
        directions=8,
        button_count=8,
        button_switch="microswitch",
        stick_travel_mm=3.0,
        actuator_diameter_mm=23.0,
        rated_cycles_stick=500_000,
        rated_cycles_buttons=1_000_000,
        pcb_cost_usd=1.50,
        stick_cost_usd=2.80,
        button_cost_usd=0.30,
        enclosure_cost_usd=2.00,
        cable_cost_usd=0.40,
    )


def standard_arcade_stick() -> ArcadeStickSpec:
    return ArcadeStickSpec(
        name="ARC-STICK-V1-STANDARD",
        gate=GateType.OCTAGONAL,
        mechanism=StickMechanism.MICROSWITCH,
        directions=8,
        button_count=8,
        button_switch="microswitch",
        stick_travel_mm=2.5,
        actuator_diameter_mm=25.0,
        rated_cycles_stick=2_000_000,
        rated_cycles_buttons=5_000_000,
        pcb_cost_usd=2.20,
        stick_cost_usd=4.50,
        button_cost_usd=0.55,
        enclosure_cost_usd=3.80,
        cable_cost_usd=0.60,
    )


def pro_arcade_stick() -> ArcadeStickSpec:
    return ArcadeStickSpec(
        name="ARC-STICK-V1-PRO",
        gate=GateType.OCTAGONAL,
        mechanism=StickMechanism.OPTICAL,
        directions=8,
        button_count=10,
        button_switch="optical",
        stick_travel_mm=2.2,
        actuator_diameter_mm=26.0,
        rated_cycles_stick=10_000_000,
        rated_cycles_buttons=10_000_000,
        pcb_cost_usd=3.80,
        stick_cost_usd=9.20,
        button_cost_usd=1.20,
        enclosure_cost_usd=6.00,
        cable_cost_usd=0.80,
    )
