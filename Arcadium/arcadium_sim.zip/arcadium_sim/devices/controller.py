"""
controller.py
Gamepad/controller device models for Arcadium Sim.
Thin wrapper over controller_design presets with runtime state.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any
from input_system.controller_design import (
    ControllerDesign, budget_controller, mid_range_controller, premium_controller
)


@dataclass
class ControllerInstance:
    """
    A live instance of a ControllerDesign attached to a console port.
    Tracks runtime state: connected, button presses, analog values.
    """
    port_id: int
    design: ControllerDesign
    connected: bool = True
    button_states: Dict[int, bool] = field(default_factory=dict)
    analog_values: Dict[str, float] = field(default_factory=dict)

    def __post_init__(self):
        for i in range(self.design.buttons.count):
            self.button_states[i] = False
        for i in range(self.design.analog.count):
            self.analog_values[f"axis_{i}"] = 0.0

    def press_button(self, index: int) -> None:
        if index in self.button_states:
            self.button_states[index] = True

    def release_button(self, index: int) -> None:
        if index in self.button_states:
            self.button_states[index] = False

    def set_axis(self, axis: str, value: float) -> None:
        value = max(-1.0, min(1.0, value))
        if axis in self.analog_values:
            self.analog_values[axis] = value

    def snapshot(self) -> Dict[str, Any]:
        return {
            "port": self.port_id,
            "design": self.design.name,
            "connected": self.connected,
            "buttons_pressed": sum(1 for v in self.button_states.values() if v),
            "analog_values": dict(self.analog_values),
            "bom_usd": self.design.bom_cost_usd,
            "latency_us": self.design.input_latency_us,
        }


# ------------------------------------------------------------------ #
# Factory helpers
# ------------------------------------------------------------------ #

def attach_budget_controller(port: int) -> ControllerInstance:
    return ControllerInstance(port_id=port, design=budget_controller())


def attach_standard_controller(port: int) -> ControllerInstance:
    return ControllerInstance(port_id=port, design=mid_range_controller())


def attach_pro_controller(port: int) -> ControllerInstance:
    return ControllerInstance(port_id=port, design=premium_controller())


def controller_bom_total(controllers: list) -> float:
    return sum(c.design.bom_cost_usd for c in controllers)
