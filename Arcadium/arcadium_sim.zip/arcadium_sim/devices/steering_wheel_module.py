"""
steering_wheel_module.py
Steering wheel hardware module model for Arcadium Sim.
Covers potentiometer vs hall-effect sensing, FFB motor, pedal pod.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from enum import Enum


class SteeringType(Enum):
    POTENTIOMETER   = "Potentiometer"
    HALL_EFFECT     = "Hall-Effect"
    OPTICAL_ENCODER = "Optical Encoder"


class FFBType(Enum):
    NONE    = "No FFB"
    DC_GEAR = "DC Gear Motor"
    DD_BELT = "Direct-Drive Belt"
    DD_TORQUE = "Direct-Drive Torque"


@dataclass
class PedalPod:
    pedal_count: int            # 2 = gas/brake, 3 = + clutch
    spring_type: str            # "coil", "rubber", "load_cell"
    resolution_bits: int
    cost_usd: float

    @property
    def latency_us(self) -> float:
        return 1_000_000 / (self.resolution_bits * 50_000)

    def summary(self) -> dict:
        return {
            "pedals": self.pedal_count,
            "spring": self.spring_type,
            "resolution": f"{self.resolution_bits}-bit",
            "cost_usd": self.cost_usd,
        }


@dataclass
class SteeringWheelSpec:
    name: str
    steering_type: SteeringType
    wheel_diameter_mm: float
    rotation_degrees: float     # lock-to-lock
    resolution_bits: int
    ffb_type: FFBType
    ffb_motor_cost_usd: float
    wheel_cost_usd: float
    pcb_cost_usd: float
    pedal_pod: Optional[PedalPod]
    cable_cost_usd: float

    @property
    def bom_cost_usd(self) -> float:
        pedal = self.pedal_pod.cost_usd if self.pedal_pod else 0.0
        return (self.wheel_cost_usd + self.ffb_motor_cost_usd +
                self.pcb_cost_usd + pedal + self.cable_cost_usd)

    @property
    def base_latency_us(self) -> float:
        return {
            SteeringType.POTENTIOMETER:   80.0,
            SteeringType.HALL_EFFECT:     10.0,
            SteeringType.OPTICAL_ENCODER:  5.0,
        }.get(self.steering_type, 40.0)

    @property
    def power_draw_ma(self) -> float:
        base = 50.0
        if self.ffb_type == FFBType.DC_GEAR:
            base += 800.0
        elif self.ffb_type == FFBType.DD_BELT:
            base += 1500.0
        elif self.ffb_type == FFBType.DD_TORQUE:
            base += 3000.0
        return base

    @property
    def signal_fidelity(self) -> float:
        type_score = {
            SteeringType.POTENTIOMETER:   45.0,
            SteeringType.HALL_EFFECT:     80.0,
            SteeringType.OPTICAL_ENCODER: 95.0,
        }.get(self.steering_type, 60.0)
        res_bonus = min(15.0, (self.resolution_bits - 8) * 1.5)
        return min(100.0, type_score + res_bonus)

    def summary(self) -> dict:
        return {
            "name": self.name,
            "steering": self.steering_type.value,
            "diameter_mm": self.wheel_diameter_mm,
            "rotation_deg": self.rotation_degrees,
            "resolution": f"{self.resolution_bits}-bit",
            "ffb": self.ffb_type.value,
            "pedals": self.pedal_pod.summary() if self.pedal_pod else "None",
            "bom_cost_usd": round(self.bom_cost_usd, 2),
            "latency_us": round(self.base_latency_us, 1),
            "power_draw_ma": round(self.power_draw_ma, 1),
            "signal_fidelity": round(self.signal_fidelity, 1),
        }


# ------------------------------------------------------------------ #
# Presets
# ------------------------------------------------------------------ #

def budget_wheel() -> SteeringWheelSpec:
    return SteeringWheelSpec(
        name="ARC-WHEEL-BUDGET",
        steering_type=SteeringType.POTENTIOMETER,
        wheel_diameter_mm=270, rotation_degrees=270,
        resolution_bits=8,
        ffb_type=FFBType.NONE, ffb_motor_cost_usd=0.0,
        wheel_cost_usd=4.50, pcb_cost_usd=1.20,
        pedal_pod=PedalPod(2, "rubber", 8, 2.80),
        cable_cost_usd=0.60,
    )


def standard_wheel() -> SteeringWheelSpec:
    return SteeringWheelSpec(
        name="ARC-WHEEL-STD",
        steering_type=SteeringType.HALL_EFFECT,
        wheel_diameter_mm=300, rotation_degrees=540,
        resolution_bits=12,
        ffb_type=FFBType.DC_GEAR, ffb_motor_cost_usd=6.50,
        wheel_cost_usd=8.00, pcb_cost_usd=2.40,
        pedal_pod=PedalPod(2, "coil", 10, 4.20),
        cable_cost_usd=1.00,
    )


def pro_wheel() -> SteeringWheelSpec:
    return SteeringWheelSpec(
        name="ARC-WHEEL-PRO",
        steering_type=SteeringType.OPTICAL_ENCODER,
        wheel_diameter_mm=320, rotation_degrees=900,
        resolution_bits=14,
        ffb_type=FFBType.DD_BELT, ffb_motor_cost_usd=18.00,
        wheel_cost_usd=14.00, pcb_cost_usd=4.50,
        pedal_pod=PedalPod(3, "load_cell", 12, 8.50),
        cable_cost_usd=1.50,
    )
