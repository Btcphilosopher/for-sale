"""
keyboard_matrix.py
Keyboard matrix device model for Arcadium Sim.
Models scan matrix, anti-ghosting, and debounce behaviour.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Set, List, Tuple
import math


@dataclass
class KeyboardMatrixSpec:
    name: str
    rows: int
    cols: int
    diode_per_key: bool         # anti-ghosting diodes
    scan_freq_hz: float
    switch_type: str            # "membrane", "tactile", "mechanical"
    pcb_cost_usd: float
    switch_cost_usd: float      # per key
    controller_ic_cost_usd: float
    cable_cost_usd: float

    @property
    def key_count(self) -> int:
        return self.rows * self.cols

    @property
    def bom_cost_usd(self) -> float:
        diode_cost = 0.01 * self.key_count if self.diode_per_key else 0.0
        return (self.pcb_cost_usd + self.switch_cost_usd * self.key_count +
                diode_cost + self.controller_ic_cost_usd + self.cable_cost_usd)

    @property
    def scan_latency_us(self) -> float:
        """Time to scan the full matrix once."""
        return (1.0 / self.scan_freq_hz) * 1_000_000

    @property
    def ghosting_risk(self) -> bool:
        return not self.diode_per_key

    @property
    def max_simultaneous_keys(self) -> int:
        """N-key rollover if diodes present, else typically 6."""
        return self.key_count if self.diode_per_key else 6

    def summary(self) -> dict:
        return {
            "name": self.name,
            "keys": self.key_count,
            "matrix": f"{self.rows}×{self.cols}",
            "anti_ghosting": self.diode_per_key,
            "max_simultaneous": self.max_simultaneous_keys,
            "scan_latency_us": round(self.scan_latency_us, 1),
            "bom_cost_usd": round(self.bom_cost_usd, 2),
        }


@dataclass
class KeyboardMatrixInstance:
    spec: KeyboardMatrixSpec
    port_id: int
    pressed_keys: Set[Tuple[int, int]] = field(default_factory=set)

    def press(self, row: int, col: int) -> bool:
        """Returns False if ghosting would occur."""
        if (self.spec.ghosting_risk and
                len(self.pressed_keys) >= self.spec.max_simultaneous_keys):
            return False
        self.pressed_keys.add((row, col))
        return True

    def release(self, row: int, col: int) -> None:
        self.pressed_keys.discard((row, col))

    def scan(self) -> List[Tuple[int, int]]:
        return list(self.pressed_keys)


# ------------------------------------------------------------------ #
# Presets
# ------------------------------------------------------------------ #

def menu_matrix() -> KeyboardMatrixSpec:
    return KeyboardMatrixSpec(
        name="ARC-KBD-4x4",
        rows=4, cols=4,
        diode_per_key=False,
        scan_freq_hz=500,
        switch_type="membrane",
        pcb_cost_usd=0.60,
        switch_cost_usd=0.04,
        controller_ic_cost_usd=0.35,
        cable_cost_usd=0.20,
    )


def full_matrix() -> KeyboardMatrixSpec:
    return KeyboardMatrixSpec(
        name="ARC-KBD-8x10",
        rows=8, cols=10,
        diode_per_key=True,
        scan_freq_hz=1000,
        switch_type="tactile",
        pcb_cost_usd=2.20,
        switch_cost_usd=0.12,
        controller_ic_cost_usd=0.80,
        cable_cost_usd=0.40,
    )
