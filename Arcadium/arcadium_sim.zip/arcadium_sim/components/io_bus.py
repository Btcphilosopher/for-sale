"""
io_bus.py
I/O bus catalogue and bandwidth/latency modelling for Arcadium Sim.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional
from core.system_architecture import IOBusSpec, BusWidth


# ------------------------------------------------------------------ #
# Bus Catalogue
# ------------------------------------------------------------------ #

BUS_CATALOGUE: List[IOBusSpec] = [
    IOBusSpec(
        name="BUS-GPIO-8",
        bus_width=BusWidth.BIT_8,
        max_devices=4,
        clock_mhz=1.0,
        latency_us=50.0,
        unit_cost_usd=0.10,
        notes="Raw GPIO. Dirt cheap. Very low throughput. Polling only."
    ),
    IOBusSpec(
        name="BUS-SPI-8",
        bus_width=BusWidth.BIT_8,
        max_devices=4,
        clock_mhz=20.0,
        latency_us=5.0,
        unit_cost_usd=0.20,
        notes="SPI bus. Simple daisy-chain. Good for button matrices."
    ),
    IOBusSpec(
        name="BUS-SPI-16",
        bus_width=BusWidth.BIT_16,
        max_devices=8,
        clock_mhz=40.0,
        latency_us=2.5,
        unit_cost_usd=0.35,
        notes="16-bit SPI. Supports up to 8 devices at decent throughput."
    ),
    IOBusSpec(
        name="BUS-I2C-FAST",
        bus_width=BusWidth.BIT_8,
        max_devices=8,
        clock_mhz=0.4,
        latency_us=20.0,
        unit_cost_usd=0.15,
        notes="I2C Fast-mode 400kHz. Good for slow peripherals and sensors."
    ),
    IOBusSpec(
        name="BUS-UART-MULTI",
        bus_width=BusWidth.BIT_8,
        max_devices=4,
        clock_mhz=0.115,
        latency_us=87.0,
        unit_cost_usd=0.08,
        notes="Multi-port UART. Low cost, moderate latency."
    ),
    IOBusSpec(
        name="BUS-PARALLEL-16",
        bus_width=BusWidth.BIT_16,
        max_devices=8,
        clock_mhz=25.0,
        latency_us=1.0,
        unit_cost_usd=0.60,
        notes="16-bit parallel bus. Low latency. PCB complexity increases."
    ),
    IOBusSpec(
        name="BUS-USB-FS",
        bus_width=BusWidth.BIT_8,
        max_devices=8,
        clock_mhz=12.0,
        latency_us=0.5,
        unit_cost_usd=1.20,
        notes="USB Full-Speed. Excellent latency. Requires host controller IC."
    ),
    IOBusSpec(
        name="BUS-USB-HS",
        bus_width=BusWidth.BIT_32,
        max_devices=16,
        clock_mhz=480.0,
        latency_us=0.125,
        unit_cost_usd=2.80,
        notes="USB High-Speed. Near-zero latency. Most expensive bus option."
    ),
]


def get_bus(name: str) -> Optional[IOBusSpec]:
    for b in BUS_CATALOGUE:
        if b.name.lower() == name.lower():
            return b
    return None


def filter_bus_by_budget(max_cost: float) -> List[IOBusSpec]:
    return [b for b in BUS_CATALOGUE if b.unit_cost_usd <= max_cost]


def recommend_bus(budget_usd: float, min_devices: int = 4, max_latency_us: float = 10.0) -> Optional[IOBusSpec]:
    candidates = [b for b in BUS_CATALOGUE
                  if b.unit_cost_usd <= budget_usd
                  and b.max_devices >= min_devices
                  and b.latency_us <= max_latency_us]
    if not candidates:
        return None
    return min(candidates, key=lambda b: b.latency_us)


@dataclass
class BusLoadReport:
    bus: IOBusSpec
    attached_devices: int
    total_transactions_per_sec: float
    utilisation_pct: float
    congestion: bool
    bottleneck_description: str


def simulate_bus_load(bus: IOBusSpec, attached_devices: int,
                      poll_hz: float = 1000.0) -> BusLoadReport:
    """
    Model bus utilisation given device count and polling frequency.
    Each device sends 2 bytes per poll cycle.
    """
    bytes_per_sec = attached_devices * poll_hz * 2
    capacity_bps = (bus.bus_width.value / 8) * bus.clock_mhz * 1_000_000
    util_pct = min(100.0, (bytes_per_sec / capacity_bps) * 100.0) if capacity_bps > 0 else 100.0
    congestion = util_pct > 80.0
    desc = (f"{util_pct:.1f}% utilisation across {attached_devices} devices "
            f"@ {poll_hz:.0f} Hz poll rate.")
    if congestion:
        desc += "  ⚠ BUS CONGESTION — reduce poll rate or upgrade bus."
    return BusLoadReport(bus, attached_devices, attached_devices * poll_hz, util_pct, congestion, desc)
