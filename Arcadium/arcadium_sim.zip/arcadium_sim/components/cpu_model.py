"""
cpu_model.py
CPU catalogue and selection/comparison engine for Arcadium Sim.
"""

from __future__ import annotations
from typing import List, Optional
from core.system_architecture import CPUSpec, CPUArchitecture


# ------------------------------------------------------------------ #
# CPU Catalogue — ordered by ascending cost
# ------------------------------------------------------------------ #

CPU_CATALOGUE: List[CPUSpec] = [
    CPUSpec(
        name="ARC-100",
        architecture=CPUArchitecture.RISC_V,
        clock_mhz=100, cores=1, pipeline_depth=5, ipc=0.8,
        unit_cost_usd=2.50, tdp_mw=180,
        notes="Bare-minimum budget option. Single-core 32-bit RISC-V."
    ),
    CPUSpec(
        name="ARC-200",
        architecture=CPUArchitecture.RISC_V,
        clock_mhz=200, cores=1, pipeline_depth=7, ipc=0.9,
        unit_cost_usd=3.80, tdp_mw=240,
        notes="Mid-budget RISC-V. Good for lightweight arcade titles."
    ),
    CPUSpec(
        name="ARC-500",
        architecture=CPUArchitecture.RISC_V,
        clock_mhz=500, cores=2, pipeline_depth=9, ipc=1.0,
        unit_cost_usd=6.20, tdp_mw=450,
        notes="Dual-core. Sufficient for smooth 2D with audio."
    ),
    CPUSpec(
        name="ARC-CORTEX-M4",
        architecture=CPUArchitecture.ARM_M4,
        clock_mhz=168, cores=1, pipeline_depth=6, ipc=1.25,
        unit_cost_usd=3.40, tdp_mw=150,
        notes="ARM Cortex-M4 with FPU. Very power-efficient."
    ),
    CPUSpec(
        name="ARC-A53-LITE",
        architecture=CPUArchitecture.ARM_A53,
        clock_mhz=800, cores=2, pipeline_depth=8, ipc=2.1,
        unit_cost_usd=9.50, tdp_mw=700,
        notes="Dual A53 cluster. Handles complex logic + audio + video."
    ),
    CPUSpec(
        name="ARC-A53-FULL",
        architecture=CPUArchitecture.ARM_A53,
        clock_mhz=1200, cores=4, pipeline_depth=8, ipc=2.1,
        unit_cost_usd=14.80, tdp_mw=1200,
        notes="Quad A53. Significant headroom. Pushes BOM budget hard."
    ),
    CPUSpec(
        name="ARC-MIPS-1",
        architecture=CPUArchitecture.MIPS,
        clock_mhz=300, cores=1, pipeline_depth=5, ipc=1.0,
        unit_cost_usd=4.10, tdp_mw=310,
        notes="MIPS32 derivative. Proven in retro arcade hardware."
    ),
    CPUSpec(
        name="ARC-ASIC-1",
        architecture=CPUArchitecture.CUSTOM_ASIC,
        clock_mhz=400, cores=2, pipeline_depth=6, ipc=1.8,
        unit_cost_usd=7.90, tdp_mw=380,
        notes="Custom ASIC. Optimised for arcade I/O. NRE cost excluded."
    ),
]


def get_cpu(name: str) -> Optional[CPUSpec]:
    for cpu in CPU_CATALOGUE:
        if cpu.name.lower() == name.lower():
            return cpu
    return None


def filter_by_budget(max_cost_usd: float) -> List[CPUSpec]:
    return [c for c in CPU_CATALOGUE if c.unit_cost_usd <= max_cost_usd]


def rank_by_perf_per_dollar() -> List[CPUSpec]:
    return sorted(CPU_CATALOGUE,
                  key=lambda c: c.throughput_mips / c.unit_cost_usd,
                  reverse=True)


def recommend_cpu(budget_usd: float, min_mips: float = 200.0) -> Optional[CPUSpec]:
    """
    Return the best cost-efficiency CPU that fits budget and MIPS floor.
    """
    candidates = [c for c in CPU_CATALOGUE
                  if c.unit_cost_usd <= budget_usd and c.throughput_mips >= min_mips]
    if not candidates:
        return None
    return max(candidates, key=lambda c: c.throughput_mips / c.unit_cost_usd)


def compare_cpus(names: List[str]) -> List[dict]:
    results = []
    for name in names:
        cpu = get_cpu(name)
        if cpu:
            results.append({
                "name": cpu.name,
                "arch": cpu.architecture.value,
                "clock_mhz": cpu.clock_mhz,
                "cores": cpu.cores,
                "throughput_mips": round(cpu.throughput_mips, 1),
                "cost_usd": cpu.unit_cost_usd,
                "tdp_mw": cpu.tdp_mw,
                "perf_per_dollar": round(cpu.throughput_mips / cpu.unit_cost_usd, 1),
            })
    return results
