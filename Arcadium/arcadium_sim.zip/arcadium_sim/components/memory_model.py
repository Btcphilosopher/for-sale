"""
memory_model.py
RAM and storage catalogue and constraint engine for Arcadium Sim.
"""

from __future__ import annotations
from typing import List, Optional
from core.system_architecture import MemorySpec, MemoryTechnology, BusWidth


# ------------------------------------------------------------------ #
# RAM Catalogue
# ------------------------------------------------------------------ #

RAM_CATALOGUE: List[MemorySpec] = [
    MemorySpec("RAM-SRAM-32K",  MemoryTechnology.SRAM,  capacity_kb=32,
               bus_width=BusWidth.BIT_16, access_ns=10.0, unit_cost_usd=0.80,
               bandwidth_mbps=200,  notes="Tiny on-chip SRAM. Suitable for microcontroller class."),
    MemorySpec("RAM-SRAM-128K", MemoryTechnology.SRAM,  capacity_kb=128,
               bus_width=BusWidth.BIT_16, access_ns=8.0,  unit_cost_usd=1.90,
               bandwidth_mbps=400,  notes="128KB SRAM. Fine for simple sprite engines."),
    MemorySpec("RAM-PSRAM-512K",MemoryTechnology.PSRAM, capacity_kb=512,
               bus_width=BusWidth.BIT_16, access_ns=35.0, unit_cost_usd=1.20,
               bandwidth_mbps=150,  notes="Budget pseudo-SRAM. High latency."),
    MemorySpec("RAM-DRAM-1M",   MemoryTechnology.DRAM,  capacity_kb=1024,
               bus_width=BusWidth.BIT_16, access_ns=60.0, unit_cost_usd=1.50,
               bandwidth_mbps=320,  notes="1MB DRAM. Classic retro arcade class."),
    MemorySpec("RAM-DRAM-4M",   MemoryTechnology.DRAM,  capacity_kb=4096,
               bus_width=BusWidth.BIT_32, access_ns=50.0, unit_cost_usd=3.20,
               bandwidth_mbps=800,  notes="4MB DRAM. Comfortable for 2D multi-sprite."),
    MemorySpec("RAM-DRAM-16M",  MemoryTechnology.DRAM,  capacity_kb=16384,
               bus_width=BusWidth.BIT_32, access_ns=45.0, unit_cost_usd=5.60,
               bandwidth_mbps=1600, notes="16MB DRAM. Modern embedded baseline."),
    MemorySpec("RAM-DRAM-64M",  MemoryTechnology.DRAM,  capacity_kb=65536,
               bus_width=BusWidth.BIT_64, access_ns=40.0, unit_cost_usd=9.80,
               bandwidth_mbps=4000, notes="64MB DRAM. Generous. Tight on BOM budget."),
]


# ------------------------------------------------------------------ #
# Storage Catalogue
# ------------------------------------------------------------------ #

STORAGE_CATALOGUE: List[MemorySpec] = [
    MemorySpec("STOR-FLASH-1M",  MemoryTechnology.FLASH, capacity_kb=1024,
               bus_width=BusWidth.BIT_8, access_ns=80.0,  unit_cost_usd=0.30,
               bandwidth_mbps=40,   notes="1MB NOR Flash. ROM-class. Minimal assets."),
    MemorySpec("STOR-FLASH-8M",  MemoryTechnology.FLASH, capacity_kb=8192,
               bus_width=BusWidth.BIT_8, access_ns=70.0,  unit_cost_usd=0.90,
               bandwidth_mbps=50,   notes="8MB NOR. Simple 2D arcade game data."),
    MemorySpec("STOR-FLASH-32M", MemoryTechnology.FLASH, capacity_kb=32768,
               bus_width=BusWidth.BIT_16, access_ns=60.0, unit_cost_usd=1.80,
               bandwidth_mbps=80,   notes="32MB. Comfortable for multiple game titles."),
    MemorySpec("STOR-EMMC-1G",   MemoryTechnology.EEPROM, capacity_kb=1048576,
               bus_width=BusWidth.BIT_32, access_ns=200.0, unit_cost_usd=3.50,
               bandwidth_mbps=200,  notes="1GB eMMC. Software library + updates."),
    MemorySpec("STOR-EMMC-4G",   MemoryTechnology.EEPROM, capacity_kb=4194304,
               bus_width=BusWidth.BIT_32, access_ns=180.0, unit_cost_usd=6.20,
               bandwidth_mbps=300,  notes="4GB eMMC. Full platform class storage."),
]


def get_ram(name: str) -> Optional[MemorySpec]:
    for m in RAM_CATALOGUE:
        if m.name.lower() == name.lower():
            return m
    return None


def get_storage(name: str) -> Optional[MemorySpec]:
    for m in STORAGE_CATALOGUE:
        if m.name.lower() == name.lower():
            return m
    return None


def filter_ram_by_budget(max_cost: float) -> List[MemorySpec]:
    return [m for m in RAM_CATALOGUE if m.unit_cost_usd <= max_cost]


def filter_storage_by_budget(max_cost: float) -> List[MemorySpec]:
    return [m for m in STORAGE_CATALOGUE if m.unit_cost_usd <= max_cost]


def recommend_ram(budget_usd: float, min_capacity_kb: int = 1024) -> Optional[MemorySpec]:
    candidates = [m for m in RAM_CATALOGUE
                  if m.unit_cost_usd <= budget_usd and m.capacity_kb >= min_capacity_kb]
    if not candidates:
        return None
    return max(candidates, key=lambda m: m.bandwidth_mbps / m.unit_cost_usd)


def recommend_storage(budget_usd: float, min_capacity_kb: int = 8192) -> Optional[MemorySpec]:
    candidates = [m for m in STORAGE_CATALOGUE
                  if m.unit_cost_usd <= budget_usd and m.capacity_kb >= min_capacity_kb]
    if not candidates:
        return None
    return max(candidates, key=lambda m: m.capacity_kb / m.unit_cost_usd)


def memory_saturation_pct(ram: MemorySpec, used_kb: float) -> float:
    """Returns percentage of RAM used."""
    return min(100.0, (used_kb / ram.capacity_kb) * 100.0)
