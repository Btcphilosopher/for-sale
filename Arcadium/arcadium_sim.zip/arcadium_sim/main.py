"""
main.py
Arcadium Systems Lab — Full Simulation Entry Point
Runs the complete "Arcadium Console v1 Prototype" design scenario.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.scheduler import build_scheduler
from components.cpu_model import recommend_cpu, compare_cpus
from components.memory_model import recommend_ram, recommend_storage
from components.io_bus import recommend_bus

from input_system.signal_processing import (
    build_digital_button_pipeline, build_analog_stick_pipeline,
    build_wheel_pipeline, aggregate_pipelines
)

from devices.arcade_stick import standard_arcade_stick, pro_arcade_stick
from devices.controller import attach_standard_controller, attach_pro_controller
from devices.keyboard_matrix import full_matrix
from devices.steering_wheel_module import standard_wheel

from engineering.cost_model import suggest_optimisations
from engineering.thermal_model import (
    build_console_thermal_model, throttling_simulation, CoolingMethod
)
from engineering.performance_model import (
    CostPerformanceAnalysis, run_benchmark_suite
)

from simulation.system_testbench import build_console_testbench
from simulation.stress_testing import (
    StressTester, stress_normal_play, stress_4player_peak,
    stress_thermal_soak, stress_input_flood
)

from prototyping.console_builder import (
    build_console, console_v1_prototype, console_v1_budget, console_v1_premium
)
from prototyping.iteration_engine import run_iteration_engine

from analytics.cost_report import print_cost_report, MultiConfigCostComparison
from analytics.performance_report import (
    print_performance_report, generate_performance_report, PerformanceSweep
)


DIVIDER = "═" * 68


def section(title: str) -> None:
    print(f"\n{DIVIDER}")
    print(f"  ▶  {title}")
    print(f"{DIVIDER}")


def main() -> None:
    print(f"\n{'█'*68}")
    print(f"  ARCADIUM SYSTEMS LAB  ─  Hardware Design Simulator v1.0")
    print(f"  Scenario: Arcadium Console v1 — $100 BOM Target")
    print(f"{'█'*68}")

    # ═══════════════════════════════════════════════════════════════ #
    # PHASE 1 — COMPONENT SELECTION
    # ═══════════════════════════════════════════════════════════════ #

    section("PHASE 1 — COMPONENT SELECTION & RECOMMENDATION")

    print("\n  CPU candidates (budget $8, floor 200 MIPS):")
    cpu = recommend_cpu(budget_usd=8.0, min_mips=200)
    if cpu:
        print(f"  → Recommended: {cpu}")

    print("\n  CPU comparison — top 3 options:")
    for row in compare_cpus(["ARC-500", "ARC-A53-LITE", "ARC-MIPS-1"]):
        print(f"    {row['name']:<18} {row['throughput_mips']:>6.0f} MIPS  "
              f"${row['cost_usd']:>5.2f}  eff={row['perf_per_dollar']:.1f}")

    ram = recommend_ram(budget_usd=4.0, min_capacity_kb=2048)
    print(f"\n  RAM recommendation (≤$4, ≥2MB): {ram}")

    storage = recommend_storage(budget_usd=2.0, min_capacity_kb=8192)
    print(f"  Storage recommendation (≤$2, ≥8MB): {storage}")

    bus = recommend_bus(budget_usd=1.0, min_devices=4, max_latency_us=5.0)
    print(f"  Bus recommendation (≤$1, ≥4 devices, ≤5µs latency): {bus}")

    # ═══════════════════════════════════════════════════════════════ #
    # PHASE 2 — INPUT SYSTEM DESIGN
    # ═══════════════════════════════════════════════════════════════ #

    section("PHASE 2 — INPUT DEVICE HARDWARE DESIGN")

    # Controllers
    ctrl1 = attach_standard_controller(port=1)
    ctrl2 = attach_standard_controller(port=2)
    ctrl3 = attach_pro_controller(port=3)
    ctrl4 = attach_pro_controller(port=4)
    print(f"\n  Port 1: {ctrl1.design.name}  BOM=${ctrl1.design.bom_cost_usd:.2f}  "
          f"latency={ctrl1.design.input_latency_us:.0f}µs")
    print(f"  Port 2: {ctrl2.design.name}  BOM=${ctrl2.design.bom_cost_usd:.2f}  "
          f"latency={ctrl2.design.input_latency_us:.0f}µs")
    print(f"  Port 3: {ctrl3.design.name}  BOM=${ctrl3.design.bom_cost_usd:.2f}  "
          f"latency={ctrl3.design.input_latency_us:.0f}µs")
    print(f"  Port 4: {ctrl4.design.name}  BOM=${ctrl4.design.bom_cost_usd:.2f}  "
          f"latency={ctrl4.design.input_latency_us:.0f}µs")

    # Devices
    stick = standard_arcade_stick()
    wheel = standard_wheel()
    kbd   = full_matrix()
    print(f"\n  Arcade Stick : {stick.name}  BOM=${stick.bom_cost_usd:.2f}  "
          f"latency={stick.latency_us:.0f}µs  durability={stick.durability_score:.0f}/100")
    print(f"  Steering Wheel: {wheel.name}  BOM=${wheel.bom_cost_usd:.2f}  "
          f"latency={wheel.base_latency_us:.0f}µs  fidelity={wheel.signal_fidelity:.0f}/100")
    print(f"  Keyboard Matrix: {kbd.name}  BOM=${kbd.bom_cost_usd:.2f}  "
          f"keys={kbd.key_count}  latency={kbd.scan_latency_us:.0f}µs")

    # Signal pipelines
    print(f"\n  Signal pipeline analysis (4 standard controllers):")
    pipelines = [build_digital_button_pipeline("tactile") for _ in range(4)]
    pipelines += [build_analog_stick_pipeline(bits=10) for _ in range(4)]
    agg = aggregate_pipelines(pipelines, cpu_mhz=500.0)
    r = agg.report()
    print(f"    Worst latency  : {r['worst_latency_us']:.2f} µs")
    print(f"    Average latency: {r['average_latency_us']:.2f} µs")
    print(f"    CPU load (input): {r['cpu_load_pct']:.2f}%")

    # ═══════════════════════════════════════════════════════════════ #
    # PHASE 3 — CONSOLE BUILDS
    # ═══════════════════════════════════════════════════════════════ #

    section("PHASE 3 — CONSOLE DESIGN ASSEMBLY (3 VARIANTS)")

    proto   = build_console(console_v1_prototype())
    budget  = build_console(console_v1_budget())
    premium = build_console(console_v1_premium())

    for design in (budget, proto, premium):
        design.print_summary()

    # ═══════════════════════════════════════════════════════════════ #
    # PHASE 4 — COST ENGINEERING ANALYSIS
    # ═══════════════════════════════════════════════════════════════ #

    section("PHASE 4 — COST ENGINEERING & BOM ANALYSIS")

    print_cost_report(proto.bom, title="Arcadium Console v1 — Cost Report")

    compare = MultiConfigCostComparison()
    compare.add("v1 Budget",   budget.bom)
    compare.add("v1 Prototype", proto.bom)
    compare.add("v1 Premium",  premium.bom)
    compare.print_comparison()

    # ═══════════════════════════════════════════════════════════════ #
    # PHASE 5 — PERFORMANCE SIMULATION
    # ═══════════════════════════════════════════════════════════════ #

    section("PHASE 5 — SYSTEM PERFORMANCE SIMULATION")

    print_performance_report(proto.architecture, attached_devices=4,
                             device_type="standard_controller")

    print("\n  Device count scaling sweep (prototype):")
    sweep = PerformanceSweep(proto.architecture)
    sweep.run(max_devices=8, device_type="standard_controller")
    sweep.print_sweep()

    # Cost/performance comparison
    cpa = CostPerformanceAnalysis()
    for label, design in [("Budget", budget), ("Prototype", proto), ("Premium", premium)]:
        rpt = generate_performance_report(design.architecture, 4)
        cpa.add_entry(
            label,
            design.bom.total_manufacturing_cost_usd,
            rpt["performance_metrics"]["performance_score"],
            notes=design.architecture.cpu.name,
        )
    cpa.print_table()

    # ═══════════════════════════════════════════════════════════════ #
    # PHASE 6 — THERMAL ANALYSIS
    # ═══════════════════════════════════════════════════════════════ #

    section("PHASE 6 — THERMAL & POWER ANALYSIS")

    thermal = build_console_thermal_model(
        cpu_tdp_mw=proto.architecture.cpu.tdp_mw,
        cooling=CoolingMethod.THERMAL_PAD,
        ambient_c=35.0,
    )
    print(f"\n  Cooling method: {thermal.cooling.value}")
    print(f"  Total system power @ 100% load: "
          f"{thermal.total_system_power_mw():.0f}mW")
    results = thermal.simulate()
    for comp in results:
        flag = "⚠" if comp["headroom_c"] < 10 else "✓"
        print(f"  {flag} {comp['component']:<12}  Tj={comp['tj_c']:.1f}°C  "
              f"headroom={comp['headroom_c']:.1f}°C  [{comp['status']}]")

    print(f"\n  Throttling simulation (10% → 100% CPU load):")
    steps = throttling_simulation(thermal, load_steps=10)
    for s in steps:
        ok = "✓" if s["system_ok"] else "✗"
        print(f"  {ok} load={s['load_pct']:>4.0f}%  "
              f"Tj={s['worst_tj_c']:.1f}°C  power={s['total_power_mw']:.0f}mW")

    # ═══════════════════════════════════════════════════════════════ #
    # PHASE 7 — HARDWARE TESTBENCH
    # ═══════════════════════════════════════════════════════════════ #

    section("PHASE 7 — HARDWARE TESTBENCH VALIDATION")

    for label, design in [("Budget", budget), ("Prototype", proto), ("Premium", premium)]:
        suite = build_console_testbench()
        report = suite.run_all(design.architecture)
        report.suite_name = f"{label} Console Testbench"
        report.print_report()

    # ═══════════════════════════════════════════════════════════════ #
    # PHASE 8 — STRESS TESTING
    # ═══════════════════════════════════════════════════════════════ #

    section("PHASE 8 — STRESS TEST SUITE")

    tester = StressTester(
        effective_mips=proto.architecture.effective_mips,
        ram_kb=proto.architecture.ram.capacity_kb,
        bus_latency_us=proto.architecture.io_bus.latency_us,
        cpu_tdp_mw=proto.architecture.cpu.tdp_mw,
    )

    for cfg in [stress_normal_play(), stress_4player_peak(),
                stress_input_flood(), stress_thermal_soak()]:
        result = tester.run(cfg)
        result.print_report()

    # ═══════════════════════════════════════════════════════════════ #
    # PHASE 9 — DESIGN ITERATION ENGINE
    # ═══════════════════════════════════════════════════════════════ #

    section("PHASE 9 — AUTOMATED DESIGN ITERATION & OPTIMISATION")

    print(f"\n  Running iteration engine on prototype configuration...")
    eng_result = run_iteration_engine(
        console_v1_prototype(),
        max_iterations=12,
        target_score=72.0,
        attached_devices=4,
        verbose=True,
    )
    eng_result.print_convergence()

    if eng_result.final_design:
        print(f"\n  OPTIMISED FINAL DESIGN:")
        eng_result.final_design.print_summary()

    # ═══════════════════════════════════════════════════════════════ #
    # FINAL SUMMARY
    # ═══════════════════════════════════════════════════════════════ #

    print(f"\n{'█'*68}")
    print(f"  ARCADIUM SYSTEMS LAB — SIMULATION COMPLETE")
    print(f"{'█'*68}")
    print(f"\n  Phases completed : 9")
    print(f"  Configs evaluated: 3 (Budget / Prototype / Premium)")
    print(f"  Stress tests run : 4")

    if eng_result.final_design:
        fd = eng_result.final_design
        best_it = eng_result.best_iteration()
        print(f"\n  ★ Recommended Design  : {fd.architecture.name}")
        print(f"    CPU                 : {fd.architecture.cpu.name}")
        print(f"    RAM                 : {fd.architecture.ram.name}")
        print(f"    Effective MIPS      : {fd.architecture.effective_mips:.0f}")
        print(f"    Mfr Cost (est.)     : ${fd.bom.total_manufacturing_cost_usd:.2f}")
        print(f"    Gross Margin @ $100 : {fd.bom.margin_at_target(100.0):.1f}%")
        if best_it:
            print(f"    Best Composite Score: {best_it.score.composite:.2f}/100")
    print()


if __name__ == "__main__":
    main()
