"""
stress_testing.py
Load and failure simulation for Arcadium Sim.
Simulates edge-case overload, input floods, memory pressure, bus saturation.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum
import random


class FailureMode(Enum):
    NONE               = "No failure"
    CPU_OVERLOAD       = "CPU overload — frame drops"
    MEMORY_OVERFLOW    = "Memory overflow — corruption risk"
    BUS_SATURATION     = "I/O bus saturated — input loss"
    INPUT_STORM        = "Input storm — buffer overflow"
    THERMAL_THROTTLE   = "Thermal throttle — performance drop"
    POWER_BROWN_OUT    = "Power brown-out — instability"
    WATCHDOG_RESET     = "Watchdog triggered — system reset"


@dataclass
class StressEvent:
    tick: int
    description: str
    failure: FailureMode
    severity: float          # 0.0 – 1.0
    recovered: bool


@dataclass
class StressTestConfig:
    name: str
    duration_ticks: int       # simulation ticks (each = 1 frame @ 60Hz)
    cpu_load_profile: List[float]        # per-tick CPU load fraction
    bus_device_count: int
    input_events_per_tick: int           # extra input events injected
    memory_pressure_mb: float            # additional memory pressure
    enable_input_storm: bool = False
    enable_thermal_spike: bool = False
    rng_seed: int = 42


@dataclass
class StressTestResult:
    config_name: str
    total_ticks: int
    events: List[StressEvent] = field(default_factory=list)
    max_cpu_load_pct: float = 0.0
    total_frame_drops: int = 0
    total_input_losses: int = 0
    memory_overflow_events: int = 0
    thermal_throttle_events: int = 0
    system_resets: int = 0

    def stability_score(self) -> float:
        """0–100 stability score; 100 = no failures."""
        penalty = (
            self.total_frame_drops    * 1.5 +
            self.total_input_losses   * 2.0 +
            self.memory_overflow_events * 5.0 +
            self.thermal_throttle_events * 3.0 +
            self.system_resets        * 20.0
        )
        return max(0.0, 100.0 - penalty)

    def summary(self) -> Dict[str, Any]:
        return {
            "config": self.config_name,
            "ticks": self.total_ticks,
            "max_cpu_load_pct": round(self.max_cpu_load_pct, 1),
            "frame_drops": self.total_frame_drops,
            "input_losses": self.total_input_losses,
            "memory_overflows": self.memory_overflow_events,
            "thermal_events": self.thermal_throttle_events,
            "system_resets": self.system_resets,
            "stability_score": round(self.stability_score(), 1),
        }

    def print_report(self) -> None:
        s = self.summary()
        print(f"\n{'='*60}")
        print(f"  STRESS TEST: {s['config']}")
        print(f"{'='*60}")
        print(f"  Ticks simulated     : {s['ticks']}")
        print(f"  Max CPU load        : {s['max_cpu_load_pct']}%")
        print(f"  Frame drops         : {s['frame_drops']}")
        print(f"  Input losses        : {s['input_losses']}")
        print(f"  Memory overflows    : {s['memory_overflows']}")
        print(f"  Thermal events      : {s['thermal_events']}")
        print(f"  System resets       : {s['system_resets']}")
        print(f"  {'─'*40}")
        print(f"  Stability Score     : {s['stability_score']}/100")
        if self.events:
            print(f"\n  Notable Events:")
            for e in self.events[-8:]:
                flag = "⚠" if e.severity > 0.5 else "·"
                print(f"  {flag} [t={e.tick:04d}] {e.description}")
        print(f"{'='*60}\n")


class StressTester:
    """
    Runs configurable stress tests against a hardware system description.
    """

    def __init__(self, effective_mips: float, ram_kb: float,
                 bus_latency_us: float, thermal_limit_c: float = 85.0,
                 cpu_tdp_mw: float = 500.0):
        self.effective_mips = effective_mips
        self.ram_kb = ram_kb
        self.bus_latency_us = bus_latency_us
        self.thermal_limit_c = thermal_limit_c
        self.cpu_tdp_mw = cpu_tdp_mw

    def _simulate_thermal(self, load: float) -> float:
        """Estimate junction temperature at given load fraction."""
        ambient = 35.0
        rth = 28.0       # combined thermal resistance K/W
        return ambient + (self.cpu_tdp_mw / 1000.0) * load * rth

    def run(self, config: StressTestConfig) -> StressTestResult:
        rng = random.Random(config.rng_seed)
        result = StressTestResult(config_name=config.name,
                                  total_ticks=config.duration_ticks)

        # Extend or truncate CPU profile to duration
        profile = config.cpu_load_profile
        if len(profile) < config.duration_ticks:
            profile = profile * (config.duration_ticks // len(profile) + 1)
        profile = profile[:config.duration_ticks]

        used_ram_kb = config.memory_pressure_mb * 1024.0

        for tick, base_load in enumerate(profile):
            # Inject random spikes
            load = base_load
            if config.enable_input_storm and rng.random() < 0.05:
                load = min(1.0, load + 0.35)
                result.total_input_losses += config.input_events_per_tick
                result.events.append(StressEvent(
                    tick, "Input storm — buffer overflow spike",
                    FailureMode.INPUT_STORM, severity=0.7, recovered=True))

            if config.enable_thermal_spike and rng.random() < 0.03:
                load = 1.0
                result.events.append(StressEvent(
                    tick, "Thermal spike injected",
                    FailureMode.THERMAL_THROTTLE, severity=0.8, recovered=False))

            cpu_pct = load * 100.0
            result.max_cpu_load_pct = max(result.max_cpu_load_pct, cpu_pct)

            # CPU overload
            if cpu_pct > 95.0:
                result.total_frame_drops += 1
                if rng.random() < 0.15:
                    result.events.append(StressEvent(
                        tick, f"CPU overload {cpu_pct:.0f}% — frame dropped",
                        FailureMode.CPU_OVERLOAD, severity=0.6, recovered=True))

            # Memory pressure
            if used_ram_kb > self.ram_kb * 0.92:
                result.memory_overflow_events += 1
                if rng.random() < 0.20:
                    result.events.append(StressEvent(
                        tick, f"Memory {used_ram_kb:.0f}KB / {self.ram_kb:.0f}KB",
                        FailureMode.MEMORY_OVERFLOW, severity=0.9, recovered=False))

            # Thermal check
            tj = self._simulate_thermal(load)
            if tj > self.thermal_limit_c * 0.92:
                result.thermal_throttle_events += 1
                if rng.random() < 0.10:
                    result.events.append(StressEvent(
                        tick, f"Thermal {tj:.1f}°C — throttling",
                        FailureMode.THERMAL_THROTTLE, severity=0.75, recovered=True))

            # Watchdog reset at critical overload
            if cpu_pct >= 100.0 and tj > self.thermal_limit_c:
                result.system_resets += 1
                result.events.append(StressEvent(
                    tick, "Watchdog triggered — system reset",
                    FailureMode.WATCHDOG_RESET, severity=1.0, recovered=False))

        return result


# ------------------------------------------------------------------ #
# Pre-built stress test configurations
# ------------------------------------------------------------------ #

def stress_normal_play() -> StressTestConfig:
    """Simulate a typical 10-second gaming session at 60Hz."""
    ticks = 600
    profile = [0.55 + 0.10 * (i % 30) / 30.0 for i in range(ticks)]
    return StressTestConfig(
        name="Normal_Play_10s",
        duration_ticks=ticks,
        cpu_load_profile=profile,
        bus_device_count=2,
        input_events_per_tick=4,
        memory_pressure_mb=1.5,
    )


def stress_4player_peak() -> StressTestConfig:
    """4-player peak load with simultaneous input events."""
    ticks = 300
    profile = [0.80 + 0.15 * (i % 10) / 10.0 for i in range(ticks)]
    return StressTestConfig(
        name="4Player_Peak_5s",
        duration_ticks=ticks,
        cpu_load_profile=profile,
        bus_device_count=4,
        input_events_per_tick=12,
        memory_pressure_mb=3.5,
        enable_input_storm=True,
    )


def stress_thermal_soak() -> StressTestConfig:
    """Sustained 100% load thermal soak test (5 minutes)."""
    ticks = 18000
    profile = [0.98 for _ in range(ticks)]
    return StressTestConfig(
        name="Thermal_Soak_5min",
        duration_ticks=ticks,
        cpu_load_profile=profile,
        bus_device_count=4,
        input_events_per_tick=8,
        memory_pressure_mb=4.0,
        enable_thermal_spike=True,
    )


def stress_input_flood() -> StressTestConfig:
    """Simulate continuous button mashing and axis waggling."""
    ticks = 600
    profile = [0.70 for _ in range(ticks)]
    return StressTestConfig(
        name="Input_Flood_10s",
        duration_ticks=ticks,
        cpu_load_profile=profile,
        bus_device_count=4,
        input_events_per_tick=32,
        memory_pressure_mb=2.0,
        enable_input_storm=True,
    )
