"""
system_testbench.py
Hardware validation and simulation testbench for Arcadium Sim.
Runs structured validation tests against a SystemArchitecture.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Callable, Optional, Any, Dict
from enum import Enum


class TestResult(Enum):
    PASS    = "PASS"
    FAIL    = "FAIL"
    WARN    = "WARN"
    SKIP    = "SKIP"


@dataclass
class TestCase:
    name: str
    description: str
    category: str
    test_fn: Callable[..., tuple[TestResult, str]]   # returns (result, message)

    def run(self, *args, **kwargs) -> "TestOutcome":
        try:
            result, message = self.test_fn(*args, **kwargs)
        except Exception as exc:
            result, message = TestResult.FAIL, f"Exception: {exc}"
        return TestOutcome(self.name, self.category, result, message)


@dataclass
class TestOutcome:
    test_name: str
    category: str
    result: TestResult
    message: str

    def __str__(self) -> str:
        sym = {"PASS": "✓", "FAIL": "✗", "WARN": "⚠", "SKIP": "○"}.get(self.result.value, "?")
        return f"  [{sym}] {self.test_name:<40} {self.result.value:<5}  {self.message}"


@dataclass
class TestSuite:
    name: str
    cases: List[TestCase] = field(default_factory=list)
    outcomes: List[TestOutcome] = field(default_factory=list)

    def add(self, case: TestCase) -> "TestSuite":
        self.cases.append(case)
        return self

    def run_all(self, *args, **kwargs) -> "TestSuiteReport":
        self.outcomes.clear()
        for case in self.cases:
            outcome = case.run(*args, **kwargs)
            self.outcomes.append(outcome)
        return TestSuiteReport(self.name, self.outcomes)


@dataclass
class TestSuiteReport:
    suite_name: str
    outcomes: List[TestOutcome]

    @property
    def passed(self) -> int:
        return sum(1 for o in self.outcomes if o.result == TestResult.PASS)

    @property
    def failed(self) -> int:
        return sum(1 for o in self.outcomes if o.result == TestResult.FAIL)

    @property
    def warned(self) -> int:
        return sum(1 for o in self.outcomes if o.result == TestResult.WARN)

    @property
    def total(self) -> int:
        return len(self.outcomes)

    @property
    def pass_rate_pct(self) -> float:
        return (self.passed / self.total * 100.0) if self.total else 0.0

    def print_report(self) -> None:
        print(f"\n{'='*68}")
        print(f"  TESTBENCH REPORT: {self.suite_name}")
        print(f"{'='*68}")
        current_cat = ""
        for o in self.outcomes:
            if o.category != current_cat:
                print(f"\n  ── {o.category} ──")
                current_cat = o.category
            print(str(o))
        print(f"\n  {'-'*64}")
        print(f"  RESULTS: {self.passed} passed / {self.failed} failed / "
              f"{self.warned} warnings  ({self.pass_rate_pct:.1f}% pass rate)")
        if self.failed == 0:
            print("  ✓ ALL TESTS PASSED")
        else:
            print(f"  ✗ {self.failed} FAILURE(S) — design requires revision")
        print(f"{'='*68}\n")

    def summary(self) -> Dict[str, Any]:
        return {
            "suite": self.suite_name,
            "total": self.total,
            "passed": self.passed,
            "failed": self.failed,
            "warned": self.warned,
            "pass_rate_pct": round(self.pass_rate_pct, 1),
        }


# ---------------------------------------------------------------------- #
# Standard testbench for Arcadium Console
# ---------------------------------------------------------------------- #

def build_console_testbench() -> TestSuite:
    suite = TestSuite("Arcadium Console v1 Hardware Testbench")

    # ── BOM / Cost Tests ──────────────────────────────────────────── #

    def test_bom_within_budget(arch, **_):
        total = arch.bom_hardware_usd
        if total <= arch.target_bom_usd * 0.80:
            return TestResult.PASS, f"BOM ${total:.2f} is within 80% of target"
        if total <= arch.target_bom_usd:
            return TestResult.WARN, f"BOM ${total:.2f} tight (within target but above 80%)"
        return TestResult.FAIL, f"BOM ${total:.2f} exceeds ${arch.target_bom_usd:.2f} target"

    suite.add(TestCase("BOM_Within_Budget",
                       "BOM raw cost must not exceed target",
                       "Cost Engineering", test_bom_within_budget))

    def test_silicon_cost_ratio(arch, **_):
        silicon = arch.cpu.unit_cost_usd + arch.ram.unit_cost_usd
        ratio = silicon / arch.bom_hardware_usd
        if ratio <= 0.55:
            return TestResult.PASS, f"Silicon ratio {ratio:.1%} — acceptable"
        if ratio <= 0.70:
            return TestResult.WARN, f"Silicon ratio {ratio:.1%} — dominates BOM"
        return TestResult.FAIL, f"Silicon ratio {ratio:.1%} — too high"

    suite.add(TestCase("Silicon_Cost_Ratio",
                       "Silicon must not dominate BOM >70%",
                       "Cost Engineering", test_silicon_cost_ratio))

    # ── CPU / Performance Tests ───────────────────────────────────── #

    def test_minimum_mips(arch, **_):
        if arch.effective_mips >= 200:
            return TestResult.PASS, f"{arch.effective_mips:.0f} MIPS available"
        if arch.effective_mips >= 100:
            return TestResult.WARN, f"{arch.effective_mips:.0f} MIPS — marginal for 2D titles"
        return TestResult.FAIL, f"{arch.effective_mips:.0f} MIPS — insufficient"

    suite.add(TestCase("CPU_Minimum_MIPS",
                       "System must provide ≥200 effective MIPS",
                       "CPU Performance", test_minimum_mips))

    def test_cpu_pipeline_depth(arch, **_):
        depth = arch.cpu.pipeline_depth
        if depth >= 6:
            return TestResult.PASS, f"Pipeline depth {depth} — good IPC potential"
        return TestResult.WARN, f"Pipeline depth {depth} — low IPC"

    suite.add(TestCase("CPU_Pipeline_Depth",
                       "Pipeline depth ≥6 recommended",
                       "CPU Performance", test_cpu_pipeline_depth))

    # ── Memory Tests ──────────────────────────────────────────────── #

    def test_ram_minimum(arch, **_):
        cap = arch.ram.capacity_kb
        if cap >= 4096:
            return TestResult.PASS, f"{cap}KB RAM — comfortable"
        if cap >= 1024:
            return TestResult.WARN, f"{cap}KB RAM — tight for complex titles"
        return TestResult.FAIL, f"{cap}KB RAM — insufficient"

    suite.add(TestCase("RAM_Minimum_Capacity",
                       "RAM must be ≥1MB for arcade workloads",
                       "Memory", test_ram_minimum))

    def test_ram_bandwidth(arch, **_):
        bw = arch.ram.bandwidth_mbps
        mips = arch.effective_mips
        # Heuristic: need ~1 MB/s per 10 MIPS
        required = mips / 10.0
        if bw >= required * 1.5:
            return TestResult.PASS, f"{bw:.0f} MB/s bandwidth — sufficient"
        if bw >= required:
            return TestResult.WARN, f"{bw:.0f} MB/s bandwidth — borderline"
        return TestResult.FAIL, f"{bw:.0f} MB/s bandwidth too low for {mips:.0f} MIPS CPU"

    suite.add(TestCase("RAM_Bandwidth_CPU_Match",
                       "RAM bandwidth must match CPU throughput",
                       "Memory", test_ram_bandwidth))

    def test_storage_capacity(arch, **_):
        cap = arch.storage.capacity_kb
        if cap >= 8192:
            return TestResult.PASS, f"{cap}KB storage — adequate"
        return TestResult.WARN, f"{cap}KB storage — may limit title library"

    suite.add(TestCase("Storage_Minimum",
                       "Storage capacity ≥8MB recommended",
                       "Memory", test_storage_capacity))

    # ── I/O Bus Tests ─────────────────────────────────────────────── #

    def test_bus_device_capacity(arch, **_):
        if arch.io_bus.max_devices >= arch.max_input_devices:
            return TestResult.PASS, (f"Bus supports {arch.io_bus.max_devices} devices, "
                                     f"need {arch.max_input_devices}")
        return TestResult.FAIL, (f"Bus only supports {arch.io_bus.max_devices} devices — "
                                 f"need {arch.max_input_devices}")

    suite.add(TestCase("Bus_Device_Capacity",
                       "I/O bus must support all input devices",
                       "I/O System", test_bus_device_capacity))

    def test_bus_latency(arch, **_):
        lat = arch.io_bus.latency_us
        if lat <= 5.0:
            return TestResult.PASS, f"{lat}µs bus latency — excellent"
        if lat <= 20.0:
            return TestResult.WARN, f"{lat}µs bus latency — acceptable"
        return TestResult.FAIL, f"{lat}µs bus latency — too high for responsive input"

    suite.add(TestCase("Bus_Latency",
                       "Bus round-trip latency must be ≤20µs",
                       "I/O System", test_bus_latency))

    # ── Power Tests ───────────────────────────────────────────────── #

    def test_power_budget(arch, **_):
        pw = arch.power.peak_power_mw
        if pw <= 2000:
            return TestResult.PASS, f"{pw:.0f}mW peak — low power design"
        if pw <= 5000:
            return TestResult.WARN, f"{pw:.0f}mW peak — moderate power"
        return TestResult.FAIL, f"{pw:.0f}mW peak — excessive for passive cooling"

    suite.add(TestCase("Power_Budget",
                       "Peak power must be ≤5W for passive cooling",
                       "Power", test_power_budget))

    def test_supply_voltage(arch, **_):
        v = arch.power.supply_voltage_v
        if v in (3.3, 5.0):
            return TestResult.PASS, f"{v}V supply — standard"
        if v == 1.8:
            return TestResult.WARN, f"{v}V supply — requires careful level shifting"
        return TestResult.WARN, f"{v}V supply — non-standard"

    suite.add(TestCase("Supply_Voltage_Standard",
                       "Supply voltage should be 3.3V or 5V",
                       "Power", test_supply_voltage))

    return suite
