"""
design_loop.py
Manages iterative engineering redesign cycles for the Arcadium Sim.
Each cycle evaluates cost, performance, manufacturability, and power.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Callable, Optional
import copy, time

from core.system_architecture import SystemArchitecture


@dataclass
class DesignScore:
    """Normalised scoring vector for one design iteration (all 0–100)."""
    cost_score: float           # higher = cheaper (closer to target BOM)
    performance_score: float    # higher = faster/more headroom
    manufacturability: float    # higher = simpler to produce
    power_efficiency: float     # higher = lower power consumption
    input_stability: float      # higher = more robust I/O system
    iteration: int = 0

    @property
    def composite(self) -> float:
        weights = dict(cost=0.30, perf=0.25, mfr=0.20, pwr=0.12, inp=0.13)
        return (
            self.cost_score         * weights["cost"] +
            self.performance_score  * weights["perf"] +
            self.manufacturability  * weights["mfr"] +
            self.power_efficiency   * weights["pwr"] +
            self.input_stability    * weights["inp"]
        )

    def __str__(self) -> str:
        return (f"[iter {self.iteration:02d}] "
                f"cost={self.cost_score:.1f}  perf={self.performance_score:.1f}  "
                f"mfr={self.manufacturability:.1f}  pwr={self.power_efficiency:.1f}  "
                f"inp={self.input_stability:.1f}  → COMPOSITE={self.composite:.2f}")


@dataclass
class DesignEvent:
    iteration: int
    description: str
    delta_cost_usd: float
    delta_perf_pct: float
    delta_power_mw: float
    notes: str = ""


@dataclass
class IterationResult:
    iteration: int
    architecture: SystemArchitecture
    score: DesignScore
    events: List[DesignEvent] = field(default_factory=list)
    elapsed_ms: float = 0.0


# ---------------------------------------------------------------------- #
# Scoring helpers
# ---------------------------------------------------------------------- #

def _cost_score(arch: SystemArchitecture) -> float:
    """Score based on how far below the BOM target we are."""
    ratio = arch.bom_hardware_usd / arch.target_bom_usd
    # 100 if at 0 cost (hypothetical), 0 if at 2× target
    return max(0.0, min(100.0, (2.0 - ratio) * 50.0))


def _performance_score(arch: SystemArchitecture) -> float:
    """Score MIPS headroom; 500 MIPS = 50 pts, 2000 MIPS = 100 pts."""
    mips = arch.effective_mips
    return max(0.0, min(100.0, (mips / 20.0)))


def _manufacturability_score(arch: SystemArchitecture) -> float:
    """Fewer I/O channels, lower BOM complexity → higher score."""
    component_count = 4 + arch.max_input_devices   # heuristic
    return max(0.0, min(100.0, 100.0 - component_count * 3.5))


def _power_efficiency_score(arch: SystemArchitecture) -> float:
    """Lower peak power = higher score; 2000 mW = 50 pts, 500 mW = 100 pts."""
    pw = arch.power.peak_power_mw
    return max(0.0, min(100.0, max(0, (3000.0 - pw) / 25.0)))


def _input_stability_score(arch: SystemArchitecture, attached_devices: int) -> float:
    """Score based on I/O bus headroom and device count."""
    headroom = max(0.0, arch.max_input_devices - attached_devices)
    latency_factor = max(0.0, 100.0 - arch.io_bus.latency_us * 5)
    return min(100.0, (headroom * 12.5) + (latency_factor * 0.5))


def score_architecture(arch: SystemArchitecture, attached_devices: int = 2) -> DesignScore:
    return DesignScore(
        cost_score=_cost_score(arch),
        performance_score=_performance_score(arch),
        manufacturability=_manufacturability_score(arch),
        power_efficiency=_power_efficiency_score(arch),
        input_stability=_input_stability_score(arch, attached_devices),
    )


# ---------------------------------------------------------------------- #
# Design Loop
# ---------------------------------------------------------------------- #

OptimiserFn = Callable[[SystemArchitecture, DesignScore, int], tuple[SystemArchitecture, list[DesignEvent]]]


class DesignLoop:
    """
    Drives iterative redesign cycles.

    Usage:
        loop = DesignLoop(initial_arch, optimiser_fn, max_iterations=10)
        results = loop.run()
    """

    def __init__(
        self,
        initial_architecture: SystemArchitecture,
        optimiser: OptimiserFn,
        max_iterations: int = 10,
        attached_devices: int = 2,
        target_composite_score: float = 78.0,
        verbose: bool = True,
    ):
        self.initial = initial_architecture
        self.optimiser = optimiser
        self.max_iterations = max_iterations
        self.attached_devices = attached_devices
        self.target_score = target_composite_score
        self.verbose = verbose
        self.history: List[IterationResult] = []

    def run(self) -> List[IterationResult]:
        arch = copy.deepcopy(self.initial)
        for i in range(1, self.max_iterations + 1):
            t0 = time.perf_counter()
            score = score_architecture(arch, self.attached_devices)
            score.iteration = i
            if self.verbose:
                print(f"  {score}")
            arch_new, events = self.optimiser(arch, score, i)
            for e in events:
                e.iteration = i
            elapsed = (time.perf_counter() - t0) * 1000
            result = IterationResult(i, copy.deepcopy(arch_new), score, events, elapsed)
            self.history.append(result)
            arch = arch_new
            if score.composite >= self.target_score:
                if self.verbose:
                    print(f"  ✓ Target composite score {self.target_score} reached at iteration {i}.")
                break
        return self.history

    def best(self) -> Optional[IterationResult]:
        if not self.history:
            return None
        return max(self.history, key=lambda r: r.score.composite)

    def summary_table(self) -> List[dict]:
        rows = []
        for r in self.history:
            rows.append({
                "iteration": r.iteration,
                "bom_usd": round(r.architecture.bom_hardware_usd, 2),
                "effective_mips": round(r.architecture.effective_mips, 1),
                "composite_score": round(r.score.composite, 2),
                "events": len(r.events),
                "elapsed_ms": round(r.elapsed_ms, 2),
            })
        return rows
