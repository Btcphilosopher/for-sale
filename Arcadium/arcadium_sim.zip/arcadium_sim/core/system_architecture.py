"""
system_architecture.py
Core hardware system model for Arcadium Sim.
Defines the SystemArchitecture dataclass and all subsystem descriptors.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum


class BusWidth(Enum):
    BIT_8  = 8
    BIT_16 = 16
    BIT_32 = 32
    BIT_64 = 64


class MemoryTechnology(Enum):
    SRAM   = "SRAM"
    DRAM   = "DRAM"
    PSRAM  = "PSRAM"
    FLASH  = "FLASH"
    EEPROM = "EEPROM"


class CPUArchitecture(Enum):
    RISC_V  = "RISC-V"
    ARM_M4  = "ARM Cortex-M4"
    ARM_A53 = "ARM Cortex-A53"
    MIPS    = "MIPS32"
    X86_ATOM = "x86 Atom"
    CUSTOM_ASIC = "Custom ASIC"


@dataclass
class CPUSpec:
    name: str
    architecture: CPUArchitecture
    clock_mhz: float
    cores: int
    pipeline_depth: int
    ipc: float                    # instructions per clock
    unit_cost_usd: float
    tdp_mw: float                 # milliwatts
    notes: str = ""

    @property
    def throughput_mips(self) -> float:
        return self.clock_mhz * self.cores * self.ipc

    def __str__(self) -> str:
        return (f"{self.name} [{self.architecture.value}] "
                f"{self.clock_mhz:.0f}MHz x{self.cores}c "
                f"→ {self.throughput_mips:.0f} MIPS  ${self.unit_cost_usd:.2f}")


@dataclass
class MemorySpec:
    name: str
    technology: MemoryTechnology
    capacity_kb: int
    bus_width: BusWidth
    access_ns: float              # nanoseconds
    unit_cost_usd: float
    bandwidth_mbps: float
    notes: str = ""

    def __str__(self) -> str:
        return (f"{self.name} [{self.technology.value}] "
                f"{self.capacity_kb}KB  {self.access_ns:.1f}ns  "
                f"{self.bandwidth_mbps:.0f}MB/s  ${self.unit_cost_usd:.2f}")


@dataclass
class IOBusSpec:
    name: str
    bus_width: BusWidth
    max_devices: int
    clock_mhz: float
    latency_us: float             # microseconds per transaction
    unit_cost_usd: float
    notes: str = ""

    @property
    def bandwidth_mbps(self) -> float:
        return (self.bus_width.value / 8) * self.clock_mhz

    def __str__(self) -> str:
        return (f"{self.name} {self.bus_width.value}-bit  "
                f"{self.clock_mhz:.0f}MHz  max {self.max_devices} devices  "
                f"${self.unit_cost_usd:.2f}")


@dataclass
class PowerSpec:
    supply_voltage_v: float
    peak_current_ma: float
    regulator_efficiency: float   # 0.0 – 1.0
    battery_capacity_mah: Optional[float] = None

    @property
    def peak_power_mw(self) -> float:
        return self.supply_voltage_v * self.peak_current_ma

    @property
    def effective_power_mw(self) -> float:
        return self.peak_power_mw * self.regulator_efficiency


@dataclass
class SystemArchitecture:
    """
    Top-level container for a complete console hardware design.
    Holds references to every subsystem and computes aggregate metrics.
    """
    name: str
    version: str
    cpu: CPUSpec
    ram: MemorySpec
    storage: MemorySpec
    io_bus: IOBusSpec
    power: PowerSpec
    max_input_devices: int = 4
    target_bom_usd: float = 100.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------ #
    # Computed properties
    # ------------------------------------------------------------------ #
    @property
    def bom_hardware_usd(self) -> float:
        """Raw silicon/component cost (CPU + RAM + storage + bus chip)."""
        return (self.cpu.unit_cost_usd
                + self.ram.unit_cost_usd
                + self.storage.unit_cost_usd
                + self.io_bus.unit_cost_usd)

    @property
    def cpu_utilisation_headroom(self) -> float:
        """Fraction of CPU MIPS reserved for OS/overhead (heuristic)."""
        return max(0.0, 1.0 - 0.18)           # 18 % overhead assumption

    @property
    def effective_mips(self) -> float:
        return self.cpu.throughput_mips * self.cpu_utilisation_headroom

    @property
    def memory_latency_ns(self) -> float:
        return self.ram.access_ns

    @property
    def bus_bandwidth_mbps(self) -> float:
        return self.io_bus.bandwidth_mbps

    def summary(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "cpu": str(self.cpu),
            "ram": str(self.ram),
            "storage": str(self.storage),
            "io_bus": str(self.io_bus),
            "bom_hardware_usd": round(self.bom_hardware_usd, 2),
            "effective_mips": round(self.effective_mips, 1),
            "memory_latency_ns": self.memory_latency_ns,
            "bus_bandwidth_mbps": round(self.bus_bandwidth_mbps, 2),
            "max_input_devices": self.max_input_devices,
            "peak_power_mw": round(self.power.peak_power_mw, 1),
        }

    def __str__(self) -> str:
        s = self.summary()
        lines = [f"=== {s['name']} v{s['version']} ==="]
        for k, v in s.items():
            if k not in ("name", "version"):
                lines.append(f"  {k:<25}: {v}")
        return "\n".join(lines)
