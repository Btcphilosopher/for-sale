"""
scheduler.py
System resource allocation and task scheduling model for Arcadium Sim.
Models how the CPU distributes cycles across subsystems.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum


class TaskPriority(Enum):
    REALTIME = 0    # input polling, interrupt handling
    HIGH     = 1    # audio/video sync
    NORMAL   = 2    # game logic
    LOW      = 3    # background maintenance
    IDLE     = 4


@dataclass
class SystemTask:
    name: str
    priority: TaskPriority
    mips_demand: float          # MIPS required by this task
    memory_kb: float            # KB of RAM required
    is_periodic: bool = True
    period_ms: float = 16.67    # default: 60 Hz frame period
    notes: str = ""

    def load_fraction(self, total_mips: float) -> float:
        return min(1.0, self.mips_demand / total_mips) if total_mips > 0 else 1.0


# ------------------------------------------------------------------ #
# Default system task catalogue
# ------------------------------------------------------------------ #

DEFAULT_TASKS: List[SystemTask] = [
    SystemTask("Input_Polling",        TaskPriority.REALTIME, mips_demand=8,   memory_kb=4,   period_ms=1.0),
    SystemTask("Interrupt_Handler",    TaskPriority.REALTIME, mips_demand=5,   memory_kb=2,   period_ms=0.5),
    SystemTask("Audio_Sync",           TaskPriority.HIGH,     mips_demand=25,  memory_kb=64,  period_ms=5.0),
    SystemTask("Video_Sync",           TaskPriority.HIGH,     mips_demand=40,  memory_kb=128, period_ms=16.67),
    SystemTask("Game_Logic",           TaskPriority.NORMAL,   mips_demand=80,  memory_kb=256, period_ms=16.67),
    SystemTask("Physics_Sim",          TaskPriority.NORMAL,   mips_demand=60,  memory_kb=128, period_ms=16.67),
    SystemTask("Asset_Streaming",      TaskPriority.LOW,      mips_demand=20,  memory_kb=512, period_ms=100.0),
    SystemTask("OS_Overhead",          TaskPriority.LOW,      mips_demand=15,  memory_kb=128, period_ms=10.0),
    SystemTask("Idle_Housekeeping",    TaskPriority.IDLE,     mips_demand=2,   memory_kb=16,  period_ms=1000.0),
]


@dataclass
class SchedulerState:
    total_mips: float
    total_memory_kb: float
    tasks: List[SystemTask] = field(default_factory=list)

    # Results populated after scheduling
    allocated: Dict[str, float] = field(default_factory=dict)   # task_name → actual MIPS given
    memory_used_kb: float = 0.0
    cpu_load_pct: float = 0.0
    overloaded_tasks: List[str] = field(default_factory=list)
    memory_overflow_kb: float = 0.0

    def schedule(self) -> "SchedulerState":
        """
        Simple fixed-priority preemptive scheduler simulation.
        Tasks at higher priority are served first; remainder distributed to lower.
        """
        remaining_mips = self.total_mips
        remaining_mem = self.total_memory_kb
        self.allocated.clear()
        self.overloaded_tasks.clear()
        total_demand = 0.0

        for priority in TaskPriority:
            tier = [t for t in self.tasks if t.priority == priority]
            for task in sorted(tier, key=lambda x: x.mips_demand, reverse=True):
                if remaining_mips >= task.mips_demand:
                    self.allocated[task.name] = task.mips_demand
                    remaining_mips -= task.mips_demand
                else:
                    self.allocated[task.name] = remaining_mips
                    self.overloaded_tasks.append(task.name)
                    remaining_mips = 0.0
                total_demand += task.mips_demand
                remaining_mem -= task.memory_kb

        self.cpu_load_pct = min(100.0, (total_demand / self.total_mips) * 100.0)
        self.memory_used_kb = sum(t.memory_kb for t in self.tasks)
        self.memory_overflow_kb = max(0.0, self.memory_used_kb - self.total_memory_kb)
        return self

    def report(self) -> dict:
        return {
            "total_mips": self.total_mips,
            "cpu_load_pct": round(self.cpu_load_pct, 1),
            "tasks_scheduled": len(self.tasks),
            "overloaded_tasks": self.overloaded_tasks,
            "memory_used_kb": round(self.memory_used_kb, 1),
            "memory_overflow_kb": round(self.memory_overflow_kb, 1),
            "allocations": {k: round(v, 2) for k, v in self.allocated.items()},
        }


def build_scheduler(effective_mips: float, ram_kb: float,
                    extra_tasks: Optional[List[SystemTask]] = None) -> SchedulerState:
    tasks = list(DEFAULT_TASKS)
    if extra_tasks:
        tasks.extend(extra_tasks)
    state = SchedulerState(total_mips=effective_mips, total_memory_kb=ram_kb, tasks=tasks)
    return state.schedule()
