"""
cost_report.py
Manufacturing cost breakdown reports and analytics for Arcadium Sim.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

from engineering.cost_model import BOMReport, CostCategory, suggest_optimisations


def generate_cost_report(bom: BOMReport, title: str = "Cost Analysis Report") -> Dict[str, Any]:
    """
    Generate a full cost breakdown report from a BOMReport.
    Returns a structured dict suitable for display or export.
    """
    report = bom.report()
    optimisations = suggest_optimisations(bom)

    return {
        "title": title,
        "product": report["product"],
        "bom_summary": {
            "line_items": report["line_items"],
            "raw_bom_usd": report["raw_bom_usd"],
            "yield_adjusted_usd": report["yield_adjusted_usd"],
            "overhead_usd": report["overhead_usd"],
            "logistics_usd": report["logistics_usd"],
            "total_mfr_cost_usd": report["total_mfr_cost_usd"],
            "gross_margin_pct": report["margin_at_100usd_pct"],
            "over_budget_usd": report["over_budget_usd"],
        },
        "by_category": report["by_category"],
        "optimisation_options": [
            {
                "action": o.action,
                "delta_cost_usd": o.delta_cost_usd,
                "delta_perf_pct": o.delta_perf_pct,
                "feasible": o.feasible,
                "notes": o.notes,
            }
            for o in optimisations
        ],
    }


def print_cost_report(bom: BOMReport, title: str = "Cost Analysis Report") -> None:
    report = generate_cost_report(bom, title)
    bom.print_bom()

    print(f"{'='*62}")
    print(f"  COST BREAKDOWN BY CATEGORY")
    print(f"{'='*62}")
    for cat, cost in report["by_category"].items():
        bar = "█" * int(cost / 2)
        print(f"  {cat:<28} ${cost:>6.2f}  {bar}")

    opts = report["optimisation_options"]
    if opts:
        print(f"\n{'='*62}")
        print(f"  OPTIMISATION RECOMMENDATIONS")
        print(f"{'='*62}")
        for i, opt in enumerate(opts, 1):
            delta_str = (f"+${opt['delta_cost_usd']:.2f}" if opt["delta_cost_usd"] > 0
                         else f"-${abs(opt['delta_cost_usd']):.2f}")
            perf_str = (f"+{opt['delta_perf_pct']:.0f}%" if opt["delta_perf_pct"] > 0
                        else f"{opt['delta_perf_pct']:.0f}%")
            print(f"  [{i}] {opt['action']}")
            print(f"      Cost delta: {delta_str}  |  Perf delta: {perf_str}")
            print(f"      {opt['notes']}")
        print(f"{'='*62}\n")


@dataclass
class MultiConfigCostComparison:
    """Compare BOM costs across multiple console configurations."""
    entries: List[Dict[str, Any]] = field(default_factory=list)

    def add(self, label: str, bom: BOMReport) -> None:
        r = bom.report()
        self.entries.append({
            "label": label,
            "raw_bom": r["raw_bom_usd"],
            "total_mfr": r["total_mfr_cost_usd"],
            "margin_pct": r["margin_at_100usd_pct"],
            "over_budget": r["over_budget_usd"],
        })

    def print_comparison(self) -> None:
        print(f"\n{'='*72}")
        print(f"  MULTI-CONFIG COST COMPARISON")
        print(f"{'='*72}")
        print(f"  {'Config':<30} {'Raw BOM':>9}  {'Mfr Cost':>9}  "
              f"{'Margin %':>9}  {'Over?':>8}")
        print(f"  {'-'*68}")
        for e in sorted(self.entries, key=lambda x: x["total_mfr"]):
            over = f"+${e['over_budget']:.2f}" if e["over_budget"] > 0 else "OK"
            print(f"  {e['label']:<30} ${e['raw_bom']:>8.2f}  "
                  f"${e['total_mfr']:>8.2f}  {e['margin_pct']:>8.1f}%  {over:>8}")
        print(f"{'='*72}\n")
