"""
performance_report.py
System benchmarking and performance reporting for Arcadium Sim.
Integrates all subsystems into a unified performance output.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

from core.system_architecture import SystemArchitecture
from core.scheduler import build_scheduler
from engineering.performance_model import (
    compute_system_metrics, run_benchmark_suite,
    CostPerformanceAnalysis, PerformanceMetrics
)
from engineering.thermal_model import (
    build_console_thermal_model, throttling_simulation, CoolingMethod
)
from components.io_bus import simulate_bus_load
from input_system.signal_processing import (
    build_digital_button_pipeline, build_analog_stick_pipeline, aggregate_pipelines
)


def generate_performance_report(
    arch: SystemArchitecture,
    attached_devices: int = 2,
    device_type: str = "standard_controller",
) -> Dict[str, Any]:
    """
    Run a full performance analysis against a SystemArchitecture.
    """
    # ── Scheduler ───────────────────────────────────────────────── #
    sched = build_scheduler(arch.effective_mips, arch.ram.capacity_kb)
    cpu_load_pct = sched.cpu_load_pct
    memory_used_pct = (sched.memory_used_kb / arch.ram.capacity_kb * 100.0
                       if arch.ram.capacity_kb > 0 else 100.0)

    # ── Bus load ────────────────────────────────────────────────── #
    bus_report = simulate_bus_load(arch.io_bus, attached_devices, poll_hz=500.0)

    # ── Signal pipeline ─────────────────────────────────────────── #
    switch_map = {
        "budget_controller":   "membrane",
        "standard_controller": "tactile",
        "pro_controller":      "hall",
        "arcade_stick_budget": "microswitch",
        "arcade_stick_pro":    "optical",
    }
    sw = switch_map.get(device_type, "tactile")
    pipelines = [build_digital_button_pipeline(sw) for _ in range(attached_devices)]
    if device_type in ("standard_controller", "pro_controller"):
        pipelines += [build_analog_stick_pipeline(bits=10) for _ in range(attached_devices)]
    agg = aggregate_pipelines(pipelines, arch.cpu.clock_mhz)

    # ── Thermal model ───────────────────────────────────────────── #
    thermal = build_console_thermal_model(
        cpu_tdp_mw=arch.cpu.tdp_mw,
        cooling=CoolingMethod.THERMAL_PAD,
    )
    thermal_ok = thermal.system_ok()

    # ── Metrics object ──────────────────────────────────────────── #
    metrics = compute_system_metrics(
        effective_mips=arch.effective_mips,
        ram=arch.ram,
        bus=arch.io_bus,
        cpu_load_pct=cpu_load_pct,
        memory_used_pct=memory_used_pct,
        bus_util_pct=bus_report.utilisation_pct,
        input_latency_us=agg.worst_latency_us,
        thermal_ok=thermal_ok,
    )

    # ── Benchmark suite ─────────────────────────────────────────── #
    benchmarks = run_benchmark_suite(metrics)

    return {
        "architecture": arch.name,
        "attached_devices": attached_devices,
        "device_type": device_type,
        "scheduler": sched.report(),
        "bus": {
            "name": arch.io_bus.name,
            "utilisation_pct": round(bus_report.utilisation_pct, 1),
            "congestion": bus_report.congestion,
            "description": bus_report.bottleneck_description,
        },
        "signal_pipeline": agg.report(),
        "thermal": thermal.report(),
        "performance_metrics": metrics.report(),
        "benchmarks": benchmarks,
    }


def print_performance_report(arch: SystemArchitecture,
                              attached_devices: int = 2,
                              device_type: str = "standard_controller") -> None:
    rpt = generate_performance_report(arch, attached_devices, device_type)
    pm  = rpt["performance_metrics"]
    sched = rpt["scheduler"]
    bus   = rpt["bus"]
    pipe  = rpt["signal_pipeline"]

    print(f"\n{'='*64}")
    print(f"  PERFORMANCE REPORT: {rpt['architecture']}")
    print(f"  Devices: {attached_devices}× {device_type}")
    print(f"{'='*64}")
    print(f"  {'CPU Load':<30}: {pm['cpu_load_pct']}%")
    print(f"  {'Effective MIPS':<30}: {pm['effective_mips']}")
    print(f"  {'Memory Used':<30}: {pm['memory_used_pct']}%")
    print(f"  {'Memory BW':<30}: {pm['memory_bw_mbps']} MB/s")
    print(f"  {'Bus Utilisation':<30}: {bus['utilisation_pct']}%")
    print(f"  {'Bus Congestion':<30}: {'YES ⚠' if bus['congestion'] else 'No'}")
    print(f"  {'Worst Input Latency':<30}: {pm['input_latency_us']}µs")
    print(f"  {'Thermal OK':<30}: {'Yes ✓' if pm['thermal_ok'] else 'NO ⚠'}")
    print(f"  {'Performance Score':<30}: {pm['performance_score']}/100")
    print(f"\n  Bottlenecks: {', '.join(pm['bottlenecks'])}")

    print(f"\n  ── BENCHMARK SUITE ──")
    for bm in rpt["benchmarks"]:
        print(f"  {bm['status']}  {bm['workload']:<28}  {bm['description']}")

    print(f"\n  ── OVERLOADED SCHEDULER TASKS ──")
    overloaded = sched.get("overloaded_tasks", [])
    if overloaded:
        for t in overloaded:
            print(f"  ⚠ {t}")
    else:
        print(f"  ✓ No tasks overloaded")
    print(f"{'='*64}\n")


@dataclass
class PerformanceSweep:
    """
    Sweep across device counts to find the system's scaling limit.
    """
    arch: SystemArchitecture
    results: List[Dict[str, Any]] = field(default_factory=list)

    def run(self, max_devices: int = 8, device_type: str = "standard_controller") -> "PerformanceSweep":
        self.results.clear()
        for n in range(1, max_devices + 1):
            rpt = generate_performance_report(self.arch, n, device_type)
            pm = rpt["performance_metrics"]
            self.results.append({
                "devices": n,
                "cpu_load_pct": pm["cpu_load_pct"],
                "bus_util_pct": pm["bus_utilisation_pct"] if "bus_utilisation_pct" in pm else rpt["bus"]["utilisation_pct"],
                "input_latency_us": pm["input_latency_us"],
                "perf_score": pm["performance_score"],
                "bottlenecks": pm["bottlenecks"],
            })
        return self

    def print_sweep(self) -> None:
        print(f"\n{'='*70}")
        print(f"  DEVICE COUNT SCALING SWEEP: {self.arch.name}")
        print(f"{'='*70}")
        print(f"  {'Devices':>7}  {'CPU%':>6}  {'Bus%':>6}  "
              f"{'Latency µs':>11}  {'Score':>6}  Bottlenecks")
        print(f"  {'-'*66}")
        for r in self.results:
            bns = r["bottlenecks"]
            bn_str = bns[0] if bns else "None"
            print(f"  {r['devices']:>7}  {r['cpu_load_pct']:>6.1f}  "
                  f"{r['bus_util_pct']:>6.1f}  {r['input_latency_us']:>11.1f}  "
                  f"{r['perf_score']:>6.1f}  {bn_str}")
        print(f"{'='*70}\n")
