export type Language = 'zh-TW' | 'en' | 'nan';

export type CategoryId = 
  | 'all'
  | 'trending'
  | 'taiwan-select'
  | 'smart-tech'
  | 'consumer-electronics'
  | 'beauty'
  | 'fashion'
  | 'food'
  | 'home-living'
  | 'brand-stores'
  | 'offers';

export interface Specification {
  label: {
    'zh-TW': string;
    en: string;
    nan: string;
  };
  value: string;
}

export interface ProductTechSpecs {
  cpu?: string;
  memory?: string;
  storage?: string;
  power?: string;
  display?: string;
  connectivity?: string;
  warranty?: string;
  origin?: string;
  certId?: string;
  customSpecs?: Specification[];
}

export interface Product {
  id: string;
  name: {
    'zh-TW': string;
    en: string;
    nan: string;
  };
  brand: string;
  category: CategoryId;
  price: number;
  originalPrice?: number;
  memberPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  gallery?: string[];
  inStock: boolean;
  stockCount: number;
  isMIT: boolean; // Made in Taiwan
  isNew?: boolean;
  isFeatured?: boolean;
  isHot?: boolean;
  discountPercentage?: number;
  deliveryEstimate: string; // e.g., "本島 24hr 到貨"
  warrantyText: string;
  description: {
    'zh-TW': string;
    en: string;
    nan: string;
  };
  specs?: ProductTechSpecs;
  tags: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedSpec?: string;
}

export interface WishlistItem {
  productId: string;
  addedAt: string;
}

export interface OrderItem {
  id: string;
  productId: string;
  productName: string;
  productImage: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string;
  date: string;
  items: OrderItem[];
  totalAmount: number;
  status: 'processing' | 'shipped' | 'delivered' | 'cancelled';
  trackingNumber: string;
  shippingAddress: {
    recipientName: string;
    phone: string;
    city: string;
    district: string;
    address: string;
  };
  paymentMethod: string;
}

export interface MembershipTier {
  name: {
    'zh-TW': string;
    en: string;
    nan: string;
  };
  code: 'SILICON' | 'EMERALD' | 'PLATINUM' | 'TAIPEI_101';
  points: number;
  nextTierPoints: number;
  discountRate: number;
  perks: string[];
}

export interface CouponCode {
  code: string;
  title: string;
  value: number;
  discountType: 'fixed' | 'percentage';
  minSpend: number;
}

export interface Coupon {
  code: string;
  title: string;
  discountValue: number;
  discountType: 'fixed' | 'percentage';
  minSpend: number;
  expiresAt: string;
}

export interface AnalyticsMetric {
  gmv: number;
  revenue: number;
  ordersCount: number;
  conversionRate: number;
  avgOrderValue: number;
  activeUsers: number;
  inventoryTurnover: number;
}

export interface PromotionCampaign {
  id: string;
  title: {
    'zh-TW': string;
    en: string;
    nan: string;
  };
  subtitle: {
    'zh-TW': string;
    en: string;
    nan: string;
  };
  badge: string;
  image: string;
  linkCategory: CategoryId;
  ctaText: {
    'zh-TW': string;
    en: string;
    nan: string;
  };
  bgColor: string;
}
