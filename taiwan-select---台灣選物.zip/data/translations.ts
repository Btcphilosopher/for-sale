import { Language } from '@/types/ecommerce';

export interface Translations {
  appName: string;
  tagline: string;
  searchPlaceholder: string;
  searchButton: string;
  login: string;
  register: string;
  cart: string;
  wishlist: string;
  notifications: string;
  demoDataLabel: string;
  madeInTaiwanBadge: string;
  adminMode: string;
  exitAdminMode: string;
  
  // Navigation
  nav: {
    home: string;
    trending: string;
    taiwanSelect: string;
    smartTech: string;
    consumerElectronics: string;
    beauty: string;
    fashion: string;
    food: string;
    homeLiving: string;
    brandStores: string;
    offers: string;
    membership: string;
    orders: string;
    wishlistNav: string;
    rewards: string;
    tier: string;
    analytics: string;
  };

  // Service Highlights
  serviceHighlights: {
    fastDeliveryTitle: string;
    fastDeliverySub: string;
    warrantyTitle: string;
    warrantySub: string;
    localBrandsTitle: string;
    localBrandsSub: string;
    paymentTitle: string;
    paymentSub: string;
    rewardsTitle: string;
    rewardsSub: string;
  };

  // Hero Section
  hero: {
    headline: string;
    subheadline: string;
    englishTag: string;
    exploreBtn: string;
    shopNowBtn: string;
  };

  // Product Specs
  specs: {
    cpu: string;
    memory: string;
    storage: string;
    power: string;
    display: string;
    connectivity: string;
    warranty: string;
    origin: string;
    availability: string;
    inStock: string;
    lowStock: string;
    outOfStock: string;
  };

  // Actions & Labels
  actions: {
    addToCart: string;
    buyNow: string;
    compare: string;
    viewDetails: string;
    filter: string;
    sort: string;
    clearFilter: string;
    checkout: string;
    applyCoupon: string;
    remove: string;
    saveWishlist: string;
    compareSpecs: string;
  };

  // Supply Chain MIT
  mitSection: {
    title: string;
    subtitle: string;
    step1: string;
    step2: string;
    step3: string;
    step4: string;
    manufacturersTitle: string;
  };

  // Section titles
  sections: {
    featuredCategories: string;
    exploreTaiwanGoods: string;
    trendingOffers: string;
    smartTechnologyHub: string;
    recommendedForYou: string;
    liveInventoryTracker: string;
    techComparisonTitle: string;
  };

  // Cart & Checkout
  checkout: {
    cartTitle: string;
    shippingTitle: string;
    paymentTitle: string;
    confirmTitle: string;
    total: string;
    shippingFee: string;
    discount: string;
    subtotal: string;
    placeOrder: string;
    orderSuccess: string;
    trackingCode: string;
  };

  // Membership
  membership: {
    tierTitle: string;
    points: string;
    couponsCount: string;
    history: string;
    perksTitle: string;
  };
}

export const translations: Record<Language, Translations> = {
  'zh-TW': {
    appName: 'TAIWAN SELECT',
    tagline: '台灣選物・世界視野',
    searchPlaceholder: '搜尋商品、品牌、規格、台灣製造...',
    searchButton: '搜尋',
    login: '登入 / 註冊',
    register: '註冊帳號',
    cart: '購物車',
    wishlist: '收藏清單',
    notifications: '通知訊息',
    demoDataLabel: 'DEMO 數據模式',
    madeInTaiwanBadge: '台灣製造・安心品質 MADE IN TAIWAN',
    adminMode: '切換至商家管理後台',
    exitAdminMode: '回到消費者商城',
    nav: {
      home: '首頁',
      trending: '熱門推薦',
      taiwanSelect: '台灣特色館',
      smartTech: '智慧科技',
      consumerElectronics: '3C 科技',
      beauty: '美妝保養',
      fashion: '時尚生活',
      food: '食品生鮮',
      homeLiving: '居家選物',
      brandStores: '品牌旗艦店',
      offers: '優惠活動',
      membership: '會員專區',
      orders: '訂單查詢',
      wishlistNav: '我的收藏',
      rewards: '紅利點數',
      tier: '會員等級',
      analytics: '營運數據中心',
    },
    serviceHighlights: {
      fastDeliveryTitle: '快速到貨',
      fastDeliverySub: '全台 24hr 極速送達',
      warrantyTitle: '安心保證',
      warrantySub: '15 天原廠鑑賞期',
      localBrandsTitle: '台灣在地品牌',
      localBrandsSub: '嚴選高科技與頂級工藝',
      paymentTitle: '多元付款',
      paymentSub: '支援 Apple Pay, LINE Pay, 信用卡',
      rewardsTitle: '會員回饋',
      rewardsSub: '紅利點數無限累計加碼',
    },
    hero: {
      headline: '台灣好物・世界看見',
      subheadline: '科技・設計・美學・生活',
      englishTag: 'Taiwanese excellence, seen by the world.',
      exploreBtn: '探索更多',
      shopNowBtn: '立即購物',
    },
    specs: {
      cpu: '處理器 CPU',
      memory: '記憶體 Memory',
      storage: '儲存空間 Storage',
      power: '功耗/電源 Power',
      display: '螢幕規格 Display',
      connectivity: '傳輸介面 Connectivity',
      warranty: '保固條款 Warranty',
      origin: '產地 Origin',
      availability: '庫存狀態 Availability',
      inStock: '庫存充足',
      lowStock: '存量有限',
      outOfStock: '暫時缺貨',
    },
    actions: {
      addToCart: '加入購物車',
      buyNow: '立即購買',
      compare: '規格對比',
      viewDetails: '檢視產品詳情',
      filter: '篩選條件',
      sort: '排序方式',
      clearFilter: '重置篩選',
      checkout: '前往結帳',
      applyCoupon: '套用折價券',
      remove: '移除',
      saveWishlist: '加入收藏',
      compareSpecs: '加入產品比較表',
    },
    mitSection: {
      title: '台灣製造・極致工藝',
      subtitle: '從新竹科學園區的高精密度半導體，到阿里山的頂級揉茶工藝',
      step1: 'DESIGNED IN TAIWAN',
      step2: 'ENGINEERED IN TAIWAN',
      step3: 'MANUFACTURED IN TAIWAN',
      step4: 'SHIPPED WORLDWIDE',
      manufacturersTitle: '認證台灣優質製造商夥伴',
    },
    sections: {
      featuredCategories: '精選分類',
      exploreTaiwanGoods: '探索台灣的美好事物',
      trendingOffers: '熱銷推薦',
      smartTechnologyHub: '智慧科技核心區',
      recommendedForYou: '為您推薦',
      liveInventoryTracker: '實時庫存監控網',
      techComparisonTitle: '旗艦硬體規格比對表',
    },
    checkout: {
      cartTitle: '購物車清單',
      shippingTitle: '配送資訊',
      paymentTitle: '付款方式',
      confirmTitle: '訂單完成確認',
      total: '結帳總計',
      shippingFee: '運費',
      discount: '優惠折抵',
      subtotal: '商品小計',
      placeOrder: '確認下單並付款',
      orderSuccess: '訂單建立成功！',
      trackingCode: '物流追蹤碼',
    },
    membership: {
      tierTitle: '尊榮矽谷會員等級',
      points: '可用紅利點數',
      couponsCount: '專屬折價券',
      history: '歷史訂單紀錄',
      perksTitle: '專屬會員禮遇',
    },
  },
  en: {
    appName: 'TAIWAN SELECT',
    tagline: 'Taiwan Select — Global Vision',
    searchPlaceholder: 'Search products, brands, tech specs, MIT...',
    searchButton: 'Search',
    login: 'Sign In / Register',
    register: 'Create Account',
    cart: 'Cart',
    wishlist: 'Wishlist',
    notifications: 'Notifications',
    demoDataLabel: 'DEMO DATA MODE',
    madeInTaiwanBadge: 'MADE IN TAIWAN — QUALITY ASSURED',
    adminMode: 'Switch to Merchant Dashboard',
    exitAdminMode: 'Back to Consumer Store',
    nav: {
      home: 'Home',
      trending: 'Trending',
      taiwanSelect: 'Taiwan Select',
      smartTech: 'Smart Tech',
      consumerElectronics: '3C Electronics',
      beauty: 'Beauty & Care',
      fashion: 'Fashion & Style',
      food: 'Fresh & Food',
      homeLiving: 'Home & Living',
      brandStores: 'Brand Flagships',
      offers: 'Promotions',
      membership: 'Membership',
      orders: 'Order History',
      wishlistNav: 'My Wishlist',
      rewards: 'Reward Points',
      tier: 'Membership Tier',
      analytics: 'Analytics Center',
    },
    serviceHighlights: {
      fastDeliveryTitle: 'Fast Shipping',
      fastDeliverySub: '24hr Islandwide Delivery',
      warrantyTitle: 'Quality Warranty',
      warrantySub: '15-Day Return Guarantee',
      localBrandsTitle: 'Taiwanese Local Brands',
      localBrandsSub: 'Engineering & Premium Crafts',
      paymentTitle: 'Flexible Payment',
      paymentSub: 'Apple Pay, LINE Pay, Credit Cards',
      rewardsTitle: 'Member Cashback',
      rewardsSub: 'Earn Reward Points on Orders',
    },
    hero: {
      headline: 'Taiwanese Excellence, Seen By The World',
      subheadline: 'Technology · Design · Aesthetics · Life',
      englishTag: 'Next-Generation Taiwanese Ecommerce Platform',
      exploreBtn: 'Explore More',
      shopNowBtn: 'Shop Now',
    },
    specs: {
      cpu: 'CPU Processor',
      memory: 'RAM Memory',
      storage: 'Storage',
      power: 'Power Spec',
      display: 'Display Spec',
      connectivity: 'Connectivity',
      warranty: 'Warranty',
      origin: 'Origin',
      availability: 'Availability',
      inStock: 'In Stock',
      lowStock: 'Low Stock',
      outOfStock: 'Out of Stock',
    },
    actions: {
      addToCart: 'Add to Cart',
      buyNow: 'Buy Now',
      compare: 'Compare Specs',
      viewDetails: 'View Specifications',
      filter: 'Filter',
      sort: 'Sort By',
      clearFilter: 'Reset Filter',
      checkout: 'Proceed to Checkout',
      applyCoupon: 'Apply Coupon',
      remove: 'Remove',
      saveWishlist: 'Save to Wishlist',
      compareSpecs: 'Add to Spec Matrix',
    },
    mitSection: {
      title: 'Made in Taiwan — Precision Engineering',
      subtitle: 'From Hsinchu Science Park microchips to Alishan artisanal tea mastery',
      step1: 'DESIGNED IN TAIWAN',
      step2: 'ENGINEERED IN TAIWAN',
      step3: 'MANUFACTURED IN TAIWAN',
      step4: 'SHIPPED WORLDWIDE',
      manufacturersTitle: 'Certified Taiwanese Manufacturing Partners',
    },
    sections: {
      featuredCategories: 'Featured Categories',
      exploreTaiwanGoods: 'Explore Taiwan’s Finest Products',
      trendingOffers: 'Trending Products',
      smartTechnologyHub: 'Smart Technology Core',
      recommendedForYou: 'Recommended for You',
      liveInventoryTracker: 'Live Inventory Matrix',
      techComparisonTitle: 'Hardware Specification Matrix',
    },
    checkout: {
      cartTitle: 'Shopping Cart',
      shippingTitle: 'Shipping Details',
      paymentTitle: 'Payment Method',
      confirmTitle: 'Order Confirmation',
      total: 'Total Amount',
      shippingFee: 'Shipping Fee',
      discount: 'Discount',
      subtotal: 'Subtotal',
      placeOrder: 'Place Order & Pay',
      orderSuccess: 'Order Successfully Placed!',
      trackingCode: 'Tracking Code',
    },
    membership: {
      tierTitle: 'Platinum Tier Status',
      points: 'Reward Points Balance',
      couponsCount: 'Active Coupons',
      history: 'Purchase History',
      perksTitle: 'Member Perks & Privileges',
    },
  },
  nan: {
    appName: 'TAIWAN SELECT',
    tagline: '台灣選物・世界視野 (尚好台灣尚好物)',
    searchPlaceholder: '尋找物件、品牌、規格、台灣製造...',
    searchButton: '搜看覓',
    login: '登入 / 註冊',
    register: '建立帳號',
    cart: '購物車',
    wishlist: '收藏清單',
    notifications: '通知訊息',
    demoDataLabel: 'DEMO 數據模式',
    madeInTaiwanBadge: '台灣製造・品質尚讚 MADE IN TAIWAN',
    adminMode: '切換至店家管理系統',
    exitAdminMode: '轉轉來賣場',
    nav: {
      home: '首頁',
      trending: '尚夯推薦',
      taiwanSelect: '台灣特色館',
      smartTech: '智慧科技',
      consumerElectronics: '3C 電子',
      beauty: '美妝保養',
      fashion: '時尚生活',
      food: '尚好食尚',
      homeLiving: '居家選物',
      brandStores: '品牌旗艦店',
      offers: '好康優惠',
      membership: '會員專區',
      orders: '查訂單',
      wishlistNav: '我的收藏',
      rewards: '紅利點數',
      tier: '會員等級',
      analytics: '營運數據中心',
    },
    serviceHighlights: {
      fastDeliveryTitle: '極速出貨',
      fastDeliverySub: '全台 24 小時內寄達',
      warrantyTitle: '品質保證',
      warrantySub: '15 天原廠保固滿意期',
      localBrandsTitle: '台灣在地品牌',
      localBrandsSub: '嚴選高科技與頂級工藝',
      paymentTitle: '多元付款',
      paymentSub: '支援 Apple Pay, LINE Pay, 刷卡',
      rewardsTitle: '會員積點',
      rewardsSub: '買越多積越多點數',
    },
    hero: {
      headline: '台灣好物・世界看見',
      subheadline: '科技・設計・美學・生活',
      englishTag: 'Taiwanese excellence, seen by the world.',
      exploreBtn: '參觀看覓',
      shopNowBtn: '馬上買',
    },
    specs: {
      cpu: '處理器 CPU',
      memory: '記憶體 RAM',
      storage: '硬碟空間 SSD',
      power: '電壓功耗 Power',
      display: '螢幕 Display',
      connectivity: '傳輸介面',
      warranty: '保固條款',
      origin: '產地 Origin',
      availability: '現貨庫存',
      inStock: '庫存充足',
      lowStock: '剩不多',
      outOfStock: '暫時缺貨',
    },
    actions: {
      addToCart: '放進購物車',
      buyNow: '馬上買',
      compare: '規格對比',
      viewDetails: '看詳細內容',
      filter: '篩選',
      sort: '排序',
      clearFilter: '清除條件',
      checkout: '準備結帳',
      applyCoupon: '用折價券',
      remove: '拿掉',
      saveWishlist: '加到收藏',
      compareSpecs: '加入比較',
    },
    mitSection: {
      title: '台灣製造・極致工藝',
      subtitle: '對新竹科學園區到阿里山頂級高山茶',
      step1: 'DESIGNED IN TAIWAN',
      step2: 'ENGINEERED IN TAIWAN',
      step3: 'MANUFACTURED IN TAIWAN',
      step4: 'SHIPPED WORLDWIDE',
      manufacturersTitle: '認證台灣優質製造商夥伴',
    },
    sections: {
      featuredCategories: '精選分類',
      exploreTaiwanGoods: '探索台灣尚好的物件',
      trendingOffers: '熱銷推薦',
      smartTechnologyHub: '智慧科技核心區',
      recommendedForYou: '為你推薦',
      liveInventoryTracker: '實時庫存監控網',
      techComparisonTitle: '旗艦硬體規格比對表',
    },
    checkout: {
      cartTitle: '購物車清單',
      shippingTitle: '寄送地址',
      paymentTitle: '付款方式',
      confirmTitle: '訂單成立',
      total: '總共費用',
      shippingFee: '運費',
      discount: '扣除折扣',
      subtotal: '小計',
      placeOrder: '下單付錢',
      orderSuccess: '訂單建立成功！',
      trackingCode: '包裹追蹤號碼',
    },
    membership: {
      tierTitle: '尊榮矽谷會員等級',
      points: '可用紅利點數',
      couponsCount: '專屬折價券',
      history: '過去買的紀錄',
      perksTitle: '專屬會員禮遇',
    },
  },
};

export const TRANSLATIONS = translations;

