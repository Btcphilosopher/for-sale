export interface MITManufacturer {
  id: string;
  name: {
    'zh-TW': string;
    en: string;
    nan: string;
  };
  region: string;
  specialty: string;
  certCode: string;
  yearEstablished: number;
  logoText: string;
  image: string;
  description: string;
}

export const MIT_MANUFACTURERS: MITManufacturer[] = [
  {
    id: 'mfg-01',
    name: {
      'zh-TW': '新竹晶片微電子實驗室',
      en: 'Hsinchu Microelectronics Lab',
      nan: '新竹晶片科技',
    },
    region: '新竹科學園區 (Hsinchu Science Park)',
    specialty: '3nm / 2nm 半導體晶片設計與封裝 (Semiconductor Packaging)',
    certCode: 'MIT-TW-IC-2026',
    yearEstablished: 1987,
    logoText: 'TSMC-COOP',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=1000&auto=format&fit=crop',
    description: '全球半導體製造核心，代表台灣高科技工藝的最高殿堂。',
  },
  {
    id: 'mfg-02',
    name: {
      'zh-TW': '台南蘭谷生物科技園區',
      en: 'Tainan Orchid Biotech Valley',
      nan: '台南蘭花生技',
    },
    region: '台南後壁蘭花園區 (Tainan Orchid Park)',
    specialty: '高純度蝴蝶蘭胚胎精粹與醫美級保養品萃取',
    certCode: 'MIT-TW-BIO-8820',
    yearEstablished: 2004,
    logoText: 'ORCHID-BIO',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=1000&auto=format&fit=crop',
    description: '結合台灣農業生技優勢與精密萃取技術，研發頂級護膚精華。',
  },
  {
    id: 'mfg-03',
    name: {
      'zh-TW': '阿里山有機揉茶合作社',
      en: 'Alishan Organic Tea Cooperative',
      nan: '阿里山高山茶社',
    },
    region: '嘉義阿里山鄉 (Alishan, Chiayi)',
    specialty: '高海拔特級烏龍茶與低溫冷烘焙工藝',
    certCode: 'MIT-TW-TEA-1992',
    yearEstablished: 1992,
    logoText: 'ALISHAN-TEA',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?q=80&w=1000&auto=format&fit=crop',
    description: '傳承三十年手揉工藝，每批茶葉皆具備獨一無二無農藥殘留與履歷認證。',
  },
  {
    id: 'mfg-04',
    name: {
      'zh-TW': '鶯歌天青陶瓷工藝坊',
      en: 'Yingge Celestial Ceramics Studio',
      nan: '鶯歌陶瓷工藝坊',
    },
    region: '新北鶯歌老街 (Yingge, New Taipei)',
    specialty: '1,280度開片青瓷與金絲工藝茶具手作',
    certCode: 'MIT-TW-POTTERY-1976',
    yearEstablished: 1976,
    logoText: 'YINGGE-MASTER',
    image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?q=80&w=1000&auto=format&fit=crop',
    description: '國寶級陶藝大師親自開窯，將傳統青瓷藝術化為當代質感生活體驗。',
  },
];
