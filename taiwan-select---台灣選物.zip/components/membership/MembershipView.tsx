'use client';

import React from 'react';
import { ShieldCheck, Award, Coins, Ticket, PackageCheck, Heart, Sparkles, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { useWishlist } from '@/context/WishlistContext';
import { Product } from '@/types/ecommerce';
import { ProductCard } from '@/components/products/ProductCard';

interface MembershipViewProps {
  orders: any[];
  allProducts: Product[];
  onSelectProduct: (productId: string) => void;
}

export const MembershipView: React.FC<MembershipViewProps> = ({
  orders,
  allProducts,
  onSelectProduct,
}) => {
  const { t, getText } = useLanguage();
  const { wishlistIds } = useWishlist();

  const userTier = {
    name: '矽谷極速尊榮會員 (Platinum Silicon Tier)',
    points: 1280,
    nextTierPoints: 2000,
    discountRate: 10,
    perks: [
      '全館台灣製造商品享 9 折獨家專屬價',
      '全台 24hr 送達享無條件免運費服務',
      '每年生日禮金 $1,000 購物金點數',
      '優先體驗 TSMC 晶片夥伴限量首發新品',
    ],
  };

  const wishlistProducts = allProducts.filter(p => wishlistIds.includes(p.id));

  return (
    <div className="space-y-8 my-6 font-sans">
      {/* Tier Overview Hero Card */}
      <div className="p-6 sm:p-8 rounded-xl bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950/60 border border-slate-800 text-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="space-y-3 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-mono font-bold">
            <Award className="w-4 h-4" />
            <span>{userTier.name}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            歡迎回到 TAIWAN SELECT 尊榮會館
          </h2>

          <div className="flex flex-wrap items-center gap-6 font-mono text-xs text-slate-300 pt-1">
            <div className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>{t.membership.points}: <strong className="text-amber-400 text-base font-bold">{userTier.points} PTS</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Ticket className="w-4 h-4 text-cyan-400" />
              <span>{t.membership.couponsCount}: <strong className="text-cyan-400 text-base font-bold">2 張</strong></span>
            </div>
          </div>
        </div>

        {/* Tier Progress */}
        <div className="w-full md:w-64 p-4 bg-slate-950/90 rounded-lg border border-slate-800 space-y-2 font-mono text-xs relative z-10">
          <div className="flex justify-between text-slate-400 text-[11px]">
            <span>距離下一等級 TAIPEI 101 VIP</span>
            <span className="text-emerald-400 font-bold">{userTier.points} / {userTier.nextTierPoints}</span>
          </div>
          <div className="w-full h-2 bg-slate-800 rounded overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400"
              style={{ width: `${(userTier.points / userTier.nextTierPoints) * 100}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-500">再累積 720 點即可升等獲取 VIP 獨家禮遇</p>
        </div>
      </div>

      {/* Perks List */}
      <div className="p-6 bg-slate-950 border border-slate-800 rounded-xl space-y-4">
        <h3 className="text-base font-bold text-slate-100 font-mono flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>{t.membership.perksTitle}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {userTier.perks.map((perk, idx) => (
            <div
              key={idx}
              className="p-3.5 bg-slate-900 border border-slate-800/80 rounded-lg text-xs text-slate-300 leading-relaxed font-sans"
            >
              <div className="font-mono text-emerald-400 font-bold mb-1">PERK 0{idx + 1}</div>
              {perk}
            </div>
          ))}
        </div>
      </div>

      {/* Order History */}
      <div className="p-6 bg-slate-950 border border-slate-800 rounded-xl space-y-4 font-mono">
        <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <PackageCheck className="w-4 h-4 text-emerald-400" />
          <span>{t.membership.history} ({orders.length})</span>
        </h3>

        {orders.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500">
            尚無過去歷史訂單紀錄。
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map(order => (
              <div
                key={order.id}
                className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-2 text-xs text-slate-300"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                  <span className="font-bold text-slate-100">單號: {order.id}</span>
                  <span className="text-slate-500">{order.date}</span>
                  <span className="text-emerald-400 font-bold">
                    追蹤碼: {order.trackingNumber}
                  </span>
                </div>

                <div className="space-y-1">
                  {order.items.map((it: any, i: number) => (
                    <div key={i} className="flex justify-between text-slate-400">
                      <span>{it.productName} x {it.quantity}</span>
                      <span>NT$ {(it.price * it.quantity).toLocaleString()}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex justify-between font-bold text-slate-200">
                  <span>總計金額 Paid:</span>
                  <span className="text-emerald-400">NT$ {order.totalAmount.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Wishlist Grid */}
      {wishlistProducts.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-slate-100 font-mono flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-500 fill-current" />
            <span>收藏清單商品 ({wishlistProducts.length})</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {wishlistProducts.map(p => (
              <ProductCard key={p.id} product={p} onSelect={onSelectProduct} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
