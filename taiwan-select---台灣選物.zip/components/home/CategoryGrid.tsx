'use client';

import React from 'react';
import { ArrowRight, Cpu, Sparkles, ShoppingBag, Utensils, Award, Home } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { CategoryId } from '@/types/ecommerce';

interface CategoryGridProps {
  onSelectCategory: (catId: CategoryId) => void;
}

export const CategoryGrid: React.FC<CategoryGridProps> = ({ onSelectCategory }) => {
  const { t } = useLanguage();

  const categories: {
    id: CategoryId;
    title: string;
    sub: string;
    image: string;
    icon: React.ElementType;
    badge: string;
  }[] = [
    {
      id: 'smart-tech',
      title: '3C 智慧科技',
      sub: '未來生活 · 智慧選擇',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=800&auto=format&fit=crop',
      icon: Cpu,
      badge: 'TSMC 晶片特區',
    },
    {
      id: 'beauty',
      title: '美妝保養',
      sub: '自然美學 · 台灣製造',
      image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=800&auto=format&fit=crop',
      icon: Sparkles,
      badge: '蘭花精萃萃取',
    },
    {
      id: 'fashion',
      title: '時尚生活',
      sub: '設計選品 · 品味生活',
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=800&auto=format&fit=crop',
      icon: ShoppingBag,
      badge: 'Taipei 101 工藝',
    },
    {
      id: 'food',
      title: '食品生鮮',
      sub: '在地食材 · 新鮮直送',
      image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=800&auto=format&fit=crop',
      icon: Utensils,
      badge: '關廟鳳梨酥 / 國宴',
    },
    {
      id: 'taiwan-select',
      title: '台灣特色館',
      sub: '文創設計 · 台灣之美',
      image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?q=80&w=800&auto=format&fit=crop',
      icon: Award,
      badge: '阿里山高山茶',
    },
    {
      id: 'home-living',
      title: '居家選物',
      sub: '質感家居 · 智慧生活',
      image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?q=80&w=800&auto=format&fit=crop',
      icon: Home,
      badge: '鶯歌陶藝精品',
    },
  ];

  return (
    <section className="space-y-4 my-8">
      <div className="flex items-center justify-between font-sans">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-100 flex items-center gap-2">
            <span>{t.sections.featuredCategories}</span>
            <span className="text-xs font-mono text-emerald-400 font-normal border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 rounded">
              MIT CERTIFIED
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">{t.sections.exploreTaiwanGoods}</p>
        </div>
        <button
          onClick={() => onSelectCategory('all')}
          className="text-xs font-mono text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition-colors cursor-pointer"
        >
          <span>查看全部</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {categories.map(cat => {
          const IconComp = cat.icon;
          return (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className="group relative h-48 sm:h-56 rounded-lg overflow-hidden border border-slate-800 hover:border-emerald-500/60 bg-slate-900 cursor-pointer transition-all duration-300 shadow-md hover:shadow-[0_0_20px_rgba(16,185,129,0.2)] flex flex-col justify-end p-3 sm:p-4"
            >
              {/* Background Image */}
              <img
                src={cat.image}
                alt={cat.title}
                className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-80 group-hover:scale-105 transition-all duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />

              {/* Category Content */}
              <div className="relative z-10 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono bg-slate-950/90 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-500/30">
                    {cat.badge}
                  </span>
                  <IconComp className="w-4 h-4 text-slate-300 group-hover:text-emerald-400 transition-colors" />
                </div>
                <h3 className="text-sm sm:text-base font-bold text-slate-100 group-hover:text-emerald-300 transition-colors">
                  {cat.title}
                </h3>
                <p className="text-[11px] text-slate-400 line-clamp-1">{cat.sub}</p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
