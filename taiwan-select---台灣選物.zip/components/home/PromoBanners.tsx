'use client';

import React from 'react';
import { ArrowRight, Sparkles, Tag } from 'lucide-react';
import { PROMOTION_CAMPAIGNS } from '@/data/products';
import { useLanguage } from '@/context/LanguageContext';
import { CategoryId } from '@/types/ecommerce';

interface PromoBannersProps {
  onSelectCategory: (cat: CategoryId) => void;
}

export const PromoBanners: React.FC<PromoBannersProps> = ({ onSelectCategory }) => {
  const { getText } = useLanguage();

  return (
    <section className="grid grid-cols-1 md:grid-cols-3 gap-4 my-8">
      {PROMOTION_CAMPAIGNS.map(promo => (
        <div
          key={promo.id}
          onClick={() => onSelectCategory(promo.linkCategory)}
          className={`relative rounded-lg overflow-hidden border border-slate-800 hover:border-emerald-500/50 p-5 bg-gradient-to-br ${promo.bgColor} text-slate-100 flex flex-col justify-between h-52 cursor-pointer transition-all shadow-xl group hover:scale-[1.01]`}
        >
          {/* Background Image Effect */}
          <img
            src={promo.image}
            alt={getText(promo.title)}
            className="absolute inset-0 w-full h-full object-cover opacity-20 mix-blend-overlay group-hover:scale-105 transition-transform duration-500"
          />

          <div className="relative z-10 space-y-2">
            <span className="inline-flex items-center gap-1 font-mono text-[10px] bg-red-600/90 text-white font-bold px-2 py-0.5 rounded shadow-[0_0_8px_#d92b2b]">
              <Tag className="w-3 h-3" />
              {promo.badge}
            </span>
            <h3 className="text-lg font-bold group-hover:text-emerald-300 transition-colors leading-snug">
              {getText(promo.title)}
            </h3>
            <p className="text-xs text-slate-300 line-clamp-2">{getText(promo.subtitle)}</p>
          </div>

          <div className="relative z-10 pt-2 flex items-center justify-between">
            <button className="px-3.5 py-1.5 rounded bg-slate-900/90 group-hover:bg-emerald-500 group-hover:text-slate-950 border border-slate-700 text-xs font-mono font-bold text-emerald-400 flex items-center gap-1.5 transition-all">
              <span>{getText(promo.ctaText)}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <Sparkles className="w-4 h-4 text-emerald-400/50 group-hover:text-emerald-400" />
          </div>
        </div>
      ))}
    </section>
  );
};
