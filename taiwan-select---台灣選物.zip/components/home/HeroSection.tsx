'use client';

import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, ShoppingCart, Sparkles, ShieldCheck, Cpu } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { CategoryId } from '@/types/ecommerce';

interface HeroSectionProps {
  onExploreClick: () => void;
  onShopClick: (cat: CategoryId) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onExploreClick, onShopClick }) => {
  const { t } = useLanguage();

  return (
    <section className="relative w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800 shadow-2xl my-4">
      {/* Background Image: Modern Taipei Skyline at Night with Taipei 101 */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1543158266-0066955047b1?q=80&w=2000&auto=format&fit=crop"
          alt="Taipei Skyline at Night with Taipei 101"
          className="w-[#100%] h-full object-cover opacity-40 mix-blend-luminosity scale-105"
        />
        {/* Tech Grid Overlay & Dark Gradients */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/90 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950/60" />
        <div className="absolute inset-0 tech-grid-bg opacity-30" />
      </div>

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-4xl px-6 sm:px-10 py-12 sm:py-20 space-y-6">
        {/* HUD Indicator Badge */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/90 border border-emerald-500/40 text-emerald-400 font-mono text-xs shadow-[0_0_15px_rgba(16,185,129,0.2)]"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
          </span>
          <span className="font-semibold tracking-wider">TAIWAN SELECT 2026–2028 FLAGSHIP</span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-300">半導體與頂級工藝紀元</span>
        </motion.div>

        {/* Headlines */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="space-y-3"
        >
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white mb-2 tracking-tight">
            台灣好物・世界看見
          </h1>
          <p className="text-zinc-400 text-sm sm:text-base font-mono uppercase tracking-widest">
            Taiwanese excellence, seen by the world. <span className="text-zinc-600 font-mono ml-2">VER 2028.1.0</span>
          </p>
        </motion.div>

        {/* Feature Tickers */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="flex flex-wrap items-center gap-3 text-xs font-mono text-zinc-300 pt-1"
        >
          <div className="flex items-center gap-1.5 bg-zinc-900/90 px-3 py-1 rounded-sm border border-zinc-800">
            <Cpu className="w-3.5 h-3.5 text-[#00FF00]" />
            <span>TSMC 3nm 晶片夥伴</span>
          </div>
          <div className="flex items-center gap-1.5 bg-zinc-900/90 px-3 py-1 rounded-sm border border-zinc-800">
            <ShieldCheck className="w-3.5 h-3.5 text-[#E60012]" />
            <span>100% 台灣製造認證</span>
          </div>
          <div className="flex items-center gap-1.5 bg-zinc-900/90 px-3 py-1 rounded-sm border border-zinc-800">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>全台 24hr 極速到府</span>
          </div>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-wrap items-center gap-4 pt-4"
        >
          <button
            onClick={onExploreClick}
            className="px-6 py-2.5 bg-[#00FF00] text-black font-bold text-xs uppercase tracking-widest hover:brightness-110 transition-all cursor-pointer font-mono flex items-center gap-2 shadow-[0_0_15px_rgba(0,255,0,0.3)]"
          >
            <span>立即探索</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onShopClick('smart-tech')}
            className="px-6 py-2.5 border border-zinc-700 text-white font-bold text-xs uppercase tracking-widest hover:bg-zinc-800 transition-colors cursor-pointer font-mono flex items-center gap-2"
          >
            <ShoppingCart className="w-3.5 h-3.5 text-[#00FF00]" />
            <span>品牌旗艦</span>
          </button>
        </motion.div>
      </div>

      {/* Visual Graphical Data Grid Lines */}
      <div className="absolute right-6 bottom-6 hidden lg:flex items-center gap-6 font-mono text-[11px] text-slate-500 z-10">
        <div>
          <span className="block text-emerald-400 font-bold text-sm">3.2 Gbps</span>
          <span>DATA THROUGHPUT</span>
        </div>
        <div className="w-px h-8 bg-slate-800" />
        <div>
          <span className="block text-slate-200 font-bold text-sm">99.98%</span>
          <span>MIT CERTIFIED</span>
        </div>
        <div className="w-px h-8 bg-slate-800" />
        <div>
          <span className="block text-red-400 font-bold text-sm">24 HR</span>
          <span>TAIPEI DELIVER</span>
        </div>
      </div>
    </section>
  );
};
