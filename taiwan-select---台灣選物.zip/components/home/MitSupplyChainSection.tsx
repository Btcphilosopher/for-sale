'use client';

import React from 'react';
import { ShieldCheck, Cpu, ArrowRight, CheckCircle2, Factory, Globe2 } from 'lucide-react';
import { MIT_MANUFACTURERS } from '@/data/mitManufacturers';
import { useLanguage } from '@/context/LanguageContext';

export const MitSupplyChainSection: React.FC = () => {
  const { t, getText } = useLanguage();

  const steps = [
    { code: '01', title: t.mitSection.step1, desc: '台北與新竹高科技創新設計中心' },
    { code: '02', title: t.mitSection.step2, desc: '台積電夥伴 3nm 晶片與精密微學程' },
    { code: '03', title: t.mitSection.step3, desc: '100% 台灣在地廠區嚴格品質管驗' },
    { code: '04', title: t.mitSection.step4, desc: '全台 24hr 送達與全球極速冷鏈' },
  ];

  return (
    <section className="bg-slate-950 border border-slate-800 rounded-xl p-6 sm:p-8 my-8 space-y-8 relative overflow-hidden">
      {/* Background glow and subtle grid */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute inset-0 tech-grid-bg opacity-20 pointer-events-none" />

      {/* Header */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-start justify-between gap-4 max-w-full">
        <div className="space-y-2 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#E60012]/15 border border-[#E60012]/40 text-[#E60012] font-mono text-xs font-bold">
            <ShieldCheck className="w-4 h-4" />
            <span>MADE IN TAIWAN 台灣製造供應鏈權威認證</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {t.mitSection.title}
          </h2>
          <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
            {t.mitSection.subtitle}
          </p>
        </div>

        {/* Professional Polish Live Data Badge */}
        <div className="flex items-center gap-3">
          <div className="text-[#00FF00] font-mono text-xs border border-[#00FF00]/40 bg-zinc-900 px-3 py-1 rounded-sm shadow-[0_0_8px_rgba(0,255,0,0.2)]">
            LIVE_DATA
          </div>
        </div>
      </div>

      {/* Industrial Supply Chain Progress Metrics */}
      <div className="relative z-10 bg-[#050505] border border-zinc-800 p-5 rounded-sm space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-400 font-mono">INDUSTRIAL SUPPLY CHAIN METRICS</h3>
            <p className="text-[10px] text-zinc-600 mt-0.5 uppercase font-mono">Network Status: Synchronized</p>
          </div>
          <div className="text-[10px] text-zinc-400 font-mono uppercase italic">Verified by Taiwan Select Engine</div>
        </div>

        <div className="space-y-3 font-mono">
          <div className="flex items-center">
            <div className="w-24 text-[10px] text-zinc-500 uppercase">Design</div>
            <div className="flex-1 h-1.5 bg-zinc-900 relative mx-4 rounded-sm overflow-hidden">
              <div className="absolute inset-0 w-full bg-[#00FF00] shadow-[0_0_8px_#00FF00]" />
            </div>
            <div className="text-[10px] text-[#00FF00] font-mono font-bold">100%</div>
          </div>
          <div className="flex items-center">
            <div className="w-24 text-[10px] text-zinc-500 uppercase">Engineered</div>
            <div className="flex-1 h-1.5 bg-zinc-900 relative mx-4 rounded-sm overflow-hidden">
              <div className="absolute inset-0 w-4/5 bg-[#00FF00]" />
            </div>
            <div className="text-[10px] text-[#00FF00] font-mono font-bold">82%</div>
          </div>
          <div className="flex items-center">
            <div className="w-24 text-[10px] text-zinc-500 uppercase">Shipment</div>
            <div className="flex-1 h-1.5 bg-zinc-900 relative mx-4 rounded-sm overflow-hidden">
              <div className="absolute inset-0 w-1/3 bg-zinc-700" />
            </div>
            <div className="text-[10px] text-zinc-500 font-mono font-bold">34%</div>
          </div>
        </div>

        <div className="border-t border-zinc-900 pt-3 flex items-center justify-between font-mono">
          <div className="flex gap-6">
            <div className="text-left">
              <div className="text-xs font-bold text-white">12.4K</div>
              <div className="text-[8px] text-zinc-600 uppercase">Units Active</div>
            </div>
            <div className="text-left">
              <div className="text-xs font-bold text-[#00FF00]">+0.42%</div>
              <div className="text-[8px] text-zinc-600 uppercase">Yield Rate</div>
            </div>
          </div>
          <div className="text-[10px] text-zinc-500 uppercase">TPE-TSMC Science Protocol 2026</div>
        </div>
      </div>

      {/* Supply Chain Flow Diagrams */}
      <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {steps.map((step, idx) => (
          <div
            key={step.code}
            className="p-4 rounded-lg bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 space-y-2 transition-all relative group"
          >
            <div className="flex items-center justify-between font-mono">
              <span className="text-xs text-emerald-400 font-bold">{step.code}</span>
              <span className="text-[10px] text-slate-500">STAGE {idx + 1}</span>
            </div>
            <h4 className="text-xs sm:text-sm font-bold text-slate-200 group-hover:text-emerald-400 transition-colors">
              {step.title}
            </h4>
            <p className="text-[11px] text-slate-400 leading-normal">{step.desc}</p>
          </div>
        ))}
      </div>

      {/* Manufacturer Partners Grid */}
      <div className="relative z-10 space-y-4 pt-4 border-t border-slate-900">
        <h3 className="text-sm font-bold text-slate-200 font-mono flex items-center gap-2">
          <Factory className="w-4 h-4 text-emerald-400" />
          <span>{t.mitSection.manufacturersTitle}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {MIT_MANUFACTURERS.map(mfg => (
            <div
              key={mfg.id}
              className="p-4 rounded-lg bg-slate-900/50 border border-slate-800/80 hover:bg-slate-900 transition-all flex flex-col justify-between space-y-3"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between font-mono text-[10px]">
                  <span className="text-emerald-400 font-semibold">{mfg.logoText}</span>
                  <span className="text-slate-500">EST. {mfg.yearEstablished}</span>
                </div>
                <h4 className="text-sm font-bold text-slate-100">{getText(mfg.name)}</h4>
                <div className="text-[11px] text-emerald-400/90 font-mono font-medium">
                  {mfg.region}
                </div>
                <p className="text-xs text-slate-400 line-clamp-2">{mfg.specialty}</p>
              </div>

              <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] font-mono text-slate-500">
                <span>CERT_ID:</span>
                <span className="text-slate-300 font-bold">{mfg.certCode}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
