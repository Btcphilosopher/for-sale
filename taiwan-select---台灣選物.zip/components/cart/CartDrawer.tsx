'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, X, Trash2, ArrowRight, Tag, ShieldCheck, Check } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useLanguage } from '@/context/LanguageContext';

interface CartDrawerProps {
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ onProceedToCheckout }) => {
  const {
    cart,
    removeFromCart,
    updateQuantity,
    subtotal,
    discount,
    shippingFee,
    total,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    isCartOpen,
    setIsCartOpen,
  } = useCart();
  const { t, getText } = useLanguage();

  const [couponCode, setCouponCode] = useState('');
  const [couponFeedback, setCouponFeedback] = useState<{ success?: boolean; message?: string }>({});

  const handleApplyCoupon = () => {
    if (!couponCode.trim()) return;
    const res = applyCoupon(couponCode);
    setCouponFeedback(res);
    if (res.success) setCouponCode('');
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50"
          />

          <motion.div
            initial={{ opacity: 0, x: 400 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 400 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-slate-900 border-l border-slate-800 text-slate-100 z-50 flex flex-col shadow-2xl font-sans"
          >
            {/* Header */}
            <div className="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
              <div className="flex items-center gap-2 font-mono text-sm font-bold">
                <ShoppingBag className="w-5 h-5 text-emerald-400" />
                <span>{t.checkout.cartTitle}</span>
                <span className="bg-emerald-500/20 text-emerald-400 text-xs px-2 py-0.5 rounded border border-emerald-500/30">
                  {cart.length} ITEMS
                </span>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cart.length === 0 ? (
                <div className="py-20 text-center space-y-3 font-mono text-slate-400">
                  <ShoppingBag className="w-12 h-12 text-slate-700 mx-auto" />
                  <p className="text-sm">購物車內目前沒有任何選物商品。</p>
                </div>
              ) : (
                cart.map(item => (
                  <div
                    key={item.product.id}
                    className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 flex gap-3 relative group"
                  >
                    <img
                      src={item.product.image}
                      alt=""
                      className="w-16 h-16 object-cover rounded bg-slate-900 border border-slate-800 shrink-0"
                    />

                    <div className="flex-1 min-w-0 space-y-1 font-sans">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-xs font-bold text-slate-200 truncate">
                          {getText(item.product.name)}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-slate-500 hover:text-red-400 p-0.5"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-[11px] font-mono text-slate-400">
                        {item.product.brand}
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <div className="inline-flex items-center bg-slate-900 border border-slate-800 rounded font-mono text-xs">
                          <button
                            onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                            className="px-2 py-0.5 text-slate-400 hover:text-white"
                          >
                            -
                          </button>
                          <span className="px-2 text-emerald-400 font-bold">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                            className="px-2 py-0.5 text-slate-400 hover:text-white"
                          >
                            +
                          </button>
                        </div>

                        <div className="font-mono text-xs font-bold text-emerald-400">
                          NT$ {(item.product.price * item.quantity).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer Summary & Coupon Code */}
            {cart.length > 0 && (
              <div className="p-4 border-t border-slate-800 bg-slate-950 space-y-3 font-mono">
                {/* Coupon input */}
                <div className="space-y-1">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={couponCode}
                      onChange={e => setCouponCode(e.target.value)}
                      placeholder="輸入優惠代碼 (例: TAIWAN2026)"
                      className="flex-1 bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                    <button
                      onClick={handleApplyCoupon}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded border border-slate-700"
                    >
                      套用
                    </button>
                  </div>

                  {appliedCoupon && (
                    <div className="flex items-center justify-between text-xs text-emerald-400 pt-1">
                      <span>已套用: {appliedCoupon.title}</span>
                      <button onClick={removeCoupon} className="text-slate-500 hover:text-red-400">
                        [移除]
                      </button>
                    </div>
                  )}

                  {couponFeedback.message && !appliedCoupon && (
                    <div className={`text-[11px] ${couponFeedback.success ? 'text-emerald-400' : 'text-red-400'}`}>
                      {couponFeedback.message}
                    </div>
                  )}
                </div>

                {/* Totals */}
                <div className="space-y-1.5 text-xs pt-2 border-t border-slate-900">
                  <div className="flex justify-between text-slate-400">
                    <span>{t.checkout.subtotal}:</span>
                    <span>NT$ {subtotal.toLocaleString()}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-red-400">
                      <span>{t.checkout.discount}:</span>
                      <span>- NT$ {discount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-400">
                    <span>{t.checkout.shippingFee}:</span>
                    <span>{shippingFee === 0 ? '免運費 FREE' : `NT$ ${shippingFee}`}</span>
                  </div>
                  <div className="flex justify-between text-base font-bold text-emerald-400 pt-2 border-t border-slate-800">
                    <span>{t.checkout.total}:</span>
                    <span>NT$ {total.toLocaleString()}</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    onProceedToCheckout();
                  }}
                  className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded flex items-center justify-center gap-2 transition-all shadow-[0_0_15px_rgba(16,185,129,0.3)] cursor-pointer text-sm"
                >
                  <span>{t.actions.checkout}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
