'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, ShieldCheck, CreditCard, Truck, ArrowRight, ArrowLeft, PackageCheck } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useLanguage } from '@/context/LanguageContext';

interface CheckoutFlowProps {
  onBackToStore: () => void;
  onAddOrderToHistory: (order: any) => void;
}

export const CheckoutFlow: React.FC<CheckoutFlowProps> = ({ onBackToStore, onAddOrderToHistory }) => {
  const { cart, subtotal, discount, shippingFee, total, clearCart } = useCart();
  const { t, getText } = useLanguage();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form states
  const [shippingInfo, setShippingInfo] = useState({
    recipientName: '陳冠宇 (Kuan-Yu Chen)',
    phone: '0912-345-678',
    city: '台北市',
    district: '信義區',
    address: '信義路五段7號 (Taipei 101 Tower)',
    shippingMethod: '24hr-express',
  });

  const [paymentMethod, setPaymentMethod] = useState<'line-pay' | 'apple-pay' | 'credit-card' | '711'>('line-pay');
  const [createdOrder, setCreatedOrder] = useState<any>(null);

  const handlePlaceOrder = () => {
    const trackingNo = `TW-${Math.floor(100000 + Math.random() * 900000)}`;
    const newOrder = {
      id: `ORD-${Date.now().toString().slice(-6)}`,
      date: new Date().toLocaleDateString('zh-TW'),
      items: cart.map(item => ({
        id: item.product.id,
        productId: item.product.id,
        productName: getText(item.product.name),
        productImage: item.product.image,
        price: item.product.price,
        quantity: item.quantity,
      })),
      totalAmount: total,
      status: 'processing' as const,
      trackingNumber: trackingNo,
      shippingAddress: shippingInfo,
      paymentMethod,
    };

    setCreatedOrder(newOrder);
    onAddOrderToHistory(newOrder);
    clearCart();
    setStep(4);
  };

  return (
    <div className="max-w-4xl mx-auto my-8 space-y-6 font-sans">
      {/* Step Indicator Bar */}
      <div className="p-4 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between font-mono text-xs text-slate-400">
        <div className={`flex items-center gap-2 ${step >= 1 ? 'text-emerald-400 font-bold' : ''}`}>
          <span className="w-5 h-5 rounded-full bg-slate-900 border border-current flex items-center justify-center text-[10px]">
            1
          </span>
          <span>1. 購物車清單</span>
        </div>

        <ArrowRight className="w-4 h-4 text-slate-700" />

        <div className={`flex items-center gap-2 ${step >= 2 ? 'text-emerald-400 font-bold' : ''}`}>
          <span className="w-5 h-5 rounded-full bg-slate-900 border border-current flex items-center justify-center text-[10px]">
            2
          </span>
          <span>2. 配送資訊</span>
        </div>

        <ArrowRight className="w-4 h-4 text-slate-700" />

        <div className={`flex items-center gap-2 ${step >= 3 ? 'text-emerald-400 font-bold' : ''}`}>
          <span className="w-5 h-5 rounded-full bg-slate-900 border border-current flex items-center justify-center text-[10px]">
            3
          </span>
          <span>3. 付款方式</span>
        </div>

        <ArrowRight className="w-4 h-4 text-slate-700" />

        <div className={`flex items-center gap-2 ${step === 4 ? 'text-emerald-400 font-bold' : ''}`}>
          <span className="w-5 h-5 rounded-full bg-slate-900 border border-current flex items-center justify-center text-[10px]">
            4
          </span>
          <span>4. 完成訂單</span>
        </div>
      </div>

      {/* Step 1: Cart Items Summary */}
      {step === 1 && (
        <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-6">
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2 font-mono">
            <span>購物車商品小計</span>
          </h2>

          <div className="space-y-3">
            {cart.map(item => (
              <div
                key={item.product.id}
                className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <img src={item.product.image} alt="" className="w-12 h-12 object-cover rounded" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">{getText(item.product.name)}</h4>
                    <p className="text-[11px] font-mono text-slate-400">
                      NT$ {item.product.price.toLocaleString()} x {item.quantity}
                    </p>
                  </div>
                </div>
                <div className="font-mono text-sm font-bold text-emerald-400">
                  NT$ {(item.product.price * item.quantity).toLocaleString()}
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-800">
            <button
              onClick={onBackToStore}
              className="px-4 py-2 bg-slate-800 text-slate-300 hover:text-white rounded text-xs font-mono"
            >
              繼續選購
            </button>
            <button
              onClick={() => setStep(2)}
              className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-mono rounded text-xs flex items-center gap-2 shadow-[0_0_12px_rgba(16,185,129,0.3)]"
            >
              <span>下一步：填寫配送地址</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Shipping Details */}
      {step === 2 && (
        <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-6">
          <h2 className="text-lg font-bold text-slate-100 font-mono">填寫台灣本島與國際配送資訊</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
            <div className="space-y-1">
              <label className="text-slate-400">收件人姓名 Recipient Name</label>
              <input
                type="text"
                value={shippingInfo.recipientName}
                onChange={e => setShippingInfo({ ...shippingInfo, recipientName: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2.5 text-slate-100"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400">聯絡電話 Mobile Phone</label>
              <input
                type="text"
                value={shippingInfo.phone}
                onChange={e => setShippingInfo({ ...shippingInfo, phone: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2.5 text-slate-100"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400">縣市 / 鄉鎮市區 City & District</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={shippingInfo.city}
                  onChange={e => setShippingInfo({ ...shippingInfo, city: e.target.value })}
                  className="w-1/2 bg-slate-950 border border-slate-700 rounded p-2.5 text-slate-100"
                />
                <input
                  type="text"
                  value={shippingInfo.district}
                  onChange={e => setShippingInfo({ ...shippingInfo, district: e.target.value })}
                  className="w-1/2 bg-slate-950 border border-slate-700 rounded p-2.5 text-slate-100"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400">詳細地址 Detailed Address</label>
              <input
                type="text"
                value={shippingInfo.address}
                onChange={e => setShippingInfo({ ...shippingInfo, address: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2.5 text-slate-100"
              />
            </div>
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-800">
            <button
              onClick={() => setStep(1)}
              className="px-4 py-2 bg-slate-800 text-slate-300 rounded text-xs font-mono"
            >
              上一步
            </button>
            <button
              onClick={() => setStep(3)}
              className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-mono rounded text-xs flex items-center gap-2"
            >
              <span>下一步：選擇付款方式</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Payment Method */}
      {step === 3 && (
        <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-6">
          <h2 className="text-lg font-bold text-slate-100 font-mono">選擇安全數位支付機制</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[
              { id: 'line-pay', title: 'LINE Pay 快速行動支付', desc: '享 5% LINE POINTS 回饋' },
              { id: 'apple-pay', title: 'Apple Pay 快速感應支付', desc: 'iOS 裝置一鍵生物辨識' },
              { id: 'credit-card', title: '信用卡 / 簽帳金融卡', desc: '支援 Visa, Mastercard, JCB' },
              { id: '711', title: '7-11 / 全家 超商取貨付款', desc: '全台 10,000+ 門市快速取貨' },
            ].map(pm => (
              <div
                key={pm.id}
                onClick={() => setPaymentMethod(pm.id as any)}
                className={`p-4 rounded-lg border cursor-pointer transition-all ${
                  paymentMethod === pm.id
                    ? 'bg-emerald-950/40 border-emerald-500 text-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.2)] font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm">{pm.title}</span>
                  {paymentMethod === pm.id && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                </div>
                <p className="text-xs text-slate-400 mt-1 font-mono">{pm.desc}</p>
              </div>
            ))}
          </div>

          <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 text-xs font-mono space-y-1 text-slate-300">
            <div className="flex justify-between">
              <span>小計 Subtotal:</span>
              <span>NT$ {subtotal.toLocaleString()}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-red-400">
                <span>折扣 Discount:</span>
                <span>- NT$ {discount.toLocaleString()}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>運費 Shipping:</span>
              <span>{shippingFee === 0 ? 'FREE 免運' : `NT$ ${shippingFee}`}</span>
            </div>
            <div className="flex justify-between text-base font-bold text-emerald-400 pt-2 border-t border-slate-800">
              <span>應付總金額 Total:</span>
              <span>NT$ {total.toLocaleString()}</span>
            </div>
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-800">
            <button
              onClick={() => setStep(2)}
              className="px-4 py-2 bg-slate-800 text-slate-300 rounded text-xs font-mono"
            >
              上一步
            </button>
            <button
              onClick={handlePlaceOrder}
              className="px-8 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-mono rounded text-sm flex items-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.35)] cursor-pointer"
            >
              <CreditCard className="w-4 h-4" />
              <span>確認下單付款 (DEMO CHECKOUT)</span>
            </button>
          </div>
        </div>
      )}

      {/* Step 4: Order Confirmation */}
      {step === 4 && createdOrder && (
        <div className="p-8 bg-slate-900 border border-emerald-500/50 rounded-xl space-y-6 text-center font-sans shadow-[0_0_30px_rgba(16,185,129,0.15)]">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 mx-auto flex items-center justify-center">
            <CheckCircle2 className="w-10 h-10 animate-bounce" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-black text-slate-100">{t.checkout.orderSuccess}</h2>
            <p className="text-xs text-slate-400 font-mono">
              感謝您支持 TAIWAN SELECT 台灣製造與頂級高科技選物。
            </p>
          </div>

          <div className="max-w-md mx-auto p-4 bg-slate-950 rounded-lg border border-slate-800 text-left font-mono text-xs space-y-2 text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-500">訂單編號 Order ID:</span>
              <span className="font-bold text-slate-100">{createdOrder.id}</span>
            </div>
            <div className="flex justify-between text-emerald-400 font-bold">
              <span>{t.checkout.trackingCode}:</span>
              <span>{createdOrder.trackingNumber}</span>
            </div>
            <div className="flex justify-between">
              <span>付款方式 Payment:</span>
              <span className="uppercase">{createdOrder.paymentMethod}</span>
            </div>
            <div className="flex justify-between border-t border-slate-900 pt-2">
              <span>總金額 Amount Paid:</span>
              <span className="text-emerald-400 font-bold">
                NT$ {createdOrder.totalAmount.toLocaleString()}
              </span>
            </div>
          </div>

          <button
            onClick={onBackToStore}
            className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-mono rounded text-xs"
          >
            返回 TAIWAN SELECT 商城
          </button>
        </div>
      )}
    </div>
  );
};
