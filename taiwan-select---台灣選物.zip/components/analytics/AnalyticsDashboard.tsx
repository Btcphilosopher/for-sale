'use client';

import React, { useState } from 'react';
import { BarChart3, TrendingUp, DollarSign, Package, Users, Activity, Edit3, Save, Plus, ArrowUpRight } from 'lucide-react';
import { Product } from '@/types/ecommerce';
import { useLanguage } from '@/context/LanguageContext';

interface AnalyticsDashboardProps {
  products: Product[];
  onUpdateProductStock: (productId: string, newStock: number) => void;
  onUpdateProductPrice: (productId: string, newPrice: number) => void;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  products,
  onUpdateProductStock,
  onUpdateProductPrice,
}) => {
  const { getText } = useLanguage();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editStock, setEditStock] = useState<number>(0);
  const [editPrice, setEditPrice] = useState<number>(0);

  const metrics = [
    { label: 'GMV 平台總交易額', value: 'NT$ 18,450,000', change: '+14.2%', icon: DollarSign, color: 'text-emerald-400' },
    { label: '淨營業收入 Net Revenue', value: 'NT$ 15,280,000', change: '+12.8%', icon: TrendingUp, color: 'text-cyan-400' },
    { label: '成單數 Orders Fulfilled', value: '1,842 件', change: '+8.5%', icon: Package, color: 'text-amber-400' },
    { label: '轉化率 Conversion Rate', value: '3.92%', change: '+0.4%', icon: Activity, color: 'text-red-400' },
  ];

  const categoryShare = [
    { name: '3C 智慧科技 Smart Tech', share: 45, color: 'bg-emerald-500' },
    { name: '台灣特色 (茶品/陶瓷)', share: 25, color: 'bg-cyan-500' },
    { name: '時尚與精品腕錶', share: 15, color: 'bg-amber-500' },
    { name: '美妝保養與生鮮食品', share: 15, color: 'bg-red-500' },
  ];

  const startEdit = (p: Product) => {
    setEditingId(p.id);
    setEditStock(p.stockCount);
    setEditPrice(p.price);
  };

  const saveEdit = (productId: string) => {
    onUpdateProductStock(productId, editStock);
    onUpdateProductPrice(productId, editPrice);
    setEditingId(null);
  };

  return (
    <div className="space-y-8 my-6 font-sans">
      {/* Top Banner */}
      <div className="p-6 bg-slate-950 border border-amber-500/40 rounded-xl flex items-center justify-between font-mono">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded bg-amber-500/20 text-amber-400 text-xs font-bold border border-amber-500/30">
            <BarChart3 className="w-4 h-4" />
            <span>商家與平台總控營運中心 ADMIN OPERATIONS</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-100">
            TAIWAN SELECT 即時商情與庫存管理系統
          </h2>
        </div>
        <div className="hidden sm:block text-right text-xs text-slate-400">
          <div>系統連線狀態: ONLINE</div>
          <div className="text-emerald-400 font-bold">HSINCHU DATA NODE #TW-01</div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        {metrics.map((m, idx) => {
          const IconComponent = m.icon;
          return (
            <div
              key={idx}
              className="p-5 rounded-lg bg-slate-900 border border-slate-800 space-y-2 relative overflow-hidden"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">{m.label}</span>
                <IconComponent className={`w-4 h-4 ${m.color}`} />
              </div>
              <div className="text-2xl font-black text-slate-100">{m.value}</div>
              <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-bold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>較上月 {m.change}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Category Performance Share */}
      <div className="p-6 bg-slate-950 border border-slate-800 rounded-xl space-y-4 font-mono">
        <h3 className="text-sm font-bold text-slate-200">品類營收貢獻占比 Category GMV Share</h3>
        <div className="space-y-3">
          {categoryShare.map((cat, idx) => (
            <div key={idx} className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span>{cat.name}</span>
                <span className="font-bold">{cat.share}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-900 rounded overflow-hidden">
                <div className={`h-full ${cat.color}`} style={{ width: `${cat.share}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Real-time Inventory & Price Management Table */}
      <div className="p-6 bg-slate-950 border border-slate-800 rounded-xl space-y-4 font-mono">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-200">商品庫存與價格即時管理 Real-time Merchant Inventory</h3>
          <span className="text-xs text-emerald-400">DEMO EDITABLE</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs divide-y divide-slate-800">
            <thead>
              <tr className="text-slate-400 bg-slate-900">
                <th className="p-3">商品編號 ID</th>
                <th className="p-3">品牌與名稱</th>
                <th className="p-3">定價 (NT$)</th>
                <th className="p-3">庫存數量</th>
                <th className="p-3 text-right">管理操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-900">
              {products.map(p => {
                const isEditing = editingId === p.id;
                return (
                  <tr key={p.id} className="hover:bg-slate-900/50">
                    <td className="p-3 text-slate-400">{p.id}</td>
                    <td className="p-3 font-semibold text-slate-100 flex items-center gap-2">
                      <img src={p.image} alt="" className="w-8 h-8 object-cover rounded" />
                      <span className="truncate max-w-xs">{getText(p.name)}</span>
                    </td>
                    <td className="p-3 text-emerald-400 font-bold">
                      {isEditing ? (
                        <input
                          type="number"
                          value={editPrice}
                          onChange={e => setEditPrice(Number(e.target.value))}
                          className="w-24 bg-slate-900 border border-emerald-500 rounded px-2 py-1 text-slate-100"
                        />
                      ) : (
                        `$${p.price.toLocaleString()}`
                      )}
                    </td>
                    <td className="p-3">
                      {isEditing ? (
                        <input
                          type="number"
                          value={editStock}
                          onChange={e => setEditStock(Number(e.target.value))}
                          className="w-20 bg-slate-900 border border-emerald-500 rounded px-2 py-1 text-slate-100"
                        />
                      ) : (
                        <span className={p.stockCount < 20 ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                          {p.stockCount} UNITS
                        </span>
                      )}
                    </td>
                    <td className="p-3 text-right">
                      {isEditing ? (
                        <button
                          onClick={() => saveEdit(p.id)}
                          className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded flex items-center gap-1 ml-auto"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>儲存</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => startEdit(p)}
                          className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded flex items-center gap-1 ml-auto"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>修改</span>
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
