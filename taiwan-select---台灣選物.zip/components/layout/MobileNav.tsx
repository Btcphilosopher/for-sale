'use client';

import React from 'react';
import { Home, Grid, Search, ShoppingBag, User } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { useCart } from '@/context/CartContext';
import { CategoryId } from '@/types/ecommerce';

interface MobileNavProps {
  activeCategory: CategoryId | 'membership' | 'orders' | 'wishlist' | 'analytics';
  onSelectCategory: (cat: CategoryId | 'membership' | 'orders' | 'wishlist' | 'analytics') => void;
  onOpenCart: () => void;
  onOpenAuth: () => void;
  onOpenSearchModal: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeCategory,
  onSelectCategory,
  onOpenCart,
  onOpenAuth,
  onOpenSearchModal,
}) => {
  const { t } = useLanguage();
  const { totalItems } = useCart();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 border-t border-slate-800 backdrop-blur-md lg:hidden flex items-center justify-around h-16 px-2 font-mono text-[10px]">
      <button
        onClick={() => onSelectCategory('all')}
        className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 ${
          activeCategory === 'all' ? 'text-emerald-400 font-bold' : 'text-slate-400'
        }`}
      >
        <Home className="w-5 h-5" />
        <span>{t.nav.home}</span>
      </button>

      <button
        onClick={() => onSelectCategory('smart-tech')}
        className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 ${
          activeCategory === 'smart-tech' ? 'text-emerald-400 font-bold' : 'text-slate-400'
        }`}
      >
        <Grid className="w-5 h-5" />
        <span>分類</span>
      </button>

      <button
        onClick={onOpenSearchModal}
        className="flex flex-col items-center justify-center gap-1 flex-1 py-1 text-slate-400 hover:text-emerald-400"
      >
        <Search className="w-5 h-5" />
        <span>搜尋</span>
      </button>

      <button
        onClick={onOpenCart}
        className="relative flex flex-col items-center justify-center gap-1 flex-1 py-1 text-slate-400 hover:text-emerald-400"
      >
        <ShoppingBag className="w-5 h-5" />
        <span>{t.cart}</span>
        {totalItems > 0 && (
          <span className="absolute top-0 right-3 bg-red-600 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full">
            {totalItems}
          </span>
        )}
      </button>

      <button
        onClick={() => onSelectCategory('membership')}
        className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 ${
          activeCategory === 'membership' ? 'text-emerald-400 font-bold' : 'text-slate-400'
        }`}
      >
        <User className="w-5 h-5" />
        <span>{t.nav.membership}</span>
      </button>
    </nav>
  );
};
