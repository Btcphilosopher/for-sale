'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Search, ShoppingBag, Heart, Bell, User, Cpu, Moon, Sun, ShieldCheck, Sparkles, X } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { useTheme } from '@/context/ThemeContext';
import { useCart } from '@/context/CartContext';
import { useWishlist } from '@/context/WishlistContext';
import { LanguageSelector } from '@/components/ui/LanguageSelector';
import { INITIAL_PRODUCTS } from '@/data/products';

interface HeaderProps {
  onOpenCart: () => void;
  onOpenNotifications?: () => void;
  onOpenAiConcierge: () => void;
  onOpenAuth: () => void;
  onSelectCategory: (catId: any) => void;
  onSearchSubmit?: (query: string) => void;
  onSelectProduct?: (productId: string) => void;
  onOpenSearch?: () => void;
  activeCategory?: string;
  isAdminMode?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCart,
  onOpenNotifications = () => {},
  onOpenAiConcierge,
  onOpenAuth,
  onSelectCategory,
  onSearchSubmit = () => {},
  onSelectProduct = () => {},
  onOpenSearch,
  activeCategory,
  isAdminMode,
}) => {
  const { t, getText } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { totalItems } = useCart();
  const { wishlistIds } = useWishlist();

  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  const popularKeywords = ['TSMC 3nm', '阿里山烏龍茶', 'Mini-LED 4K', '關廟鳳梨酥', 'RTX 5090', '鶯歌青瓷'];

  const searchResults = searchQuery.trim()
    ? INITIAL_PRODUCTS.filter(p => {
        const q = searchQuery.toLowerCase();
        const nameMatch = getText(p.name).toLowerCase().includes(q);
        const brandMatch = p.brand.toLowerCase().includes(q);
        const tagMatch = p.tags.some(t => t.toLowerCase().includes(q));
        const specMatch = p.specs
          ? (p.specs.cpu?.toLowerCase().includes(q) ||
             p.specs.origin?.toLowerCase().includes(q) ||
             p.specs.display?.toLowerCase().includes(q))
          : false;
        return nameMatch || brandMatch || tagMatch || specMatch;
      }).slice(0, 5)
    : [];

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      onSearchSubmit(searchQuery);
      setIsSearchFocused(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 dark:bg-slate-950/95 backdrop-blur-md border-b border-slate-800/80 shadow-lg">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between gap-4">
        {/* LEFT: Branding & Stamp */}
        <div
          onClick={() => onSelectCategory('all')}
          className="flex items-center gap-3 cursor-pointer group select-none shrink-0"
        >
          {/* Taiwanese Red Traditional Stamp Seal */}
          <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-sm bg-red-600/90 hover:bg-red-600 border border-red-400/50 flex flex-col items-center justify-center text-white shadow-[0_0_12px_rgba(217,43,43,0.3)] transition-all transform group-hover:scale-105">
            <span className="font-serif font-black text-xs sm:text-sm tracking-tighter leading-tight">
              台灣
            </span>
            <span className="font-serif font-black text-[9px] sm:text-[10px] tracking-widest leading-none text-red-100">
              選物
            </span>
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-mono font-black text-base sm:text-lg tracking-widest text-slate-100 group-hover:text-emerald-400 transition-colors">
                TAIWAN SELECT
              </span>
              <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-mono px-1.5 py-0.2 rounded border border-emerald-500/30 hidden md:inline-block">
                MIT 2026
              </span>
            </div>
            <span className="text-[10px] sm:text-xs text-slate-400 tracking-wider font-sans font-medium">
              台灣選物・世界視野
            </span>
          </div>
        </div>

        {/* CENTER: Search Bar */}
        <div ref={searchContainerRef} className="flex-1 max-w-2xl relative hidden md:block">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onKeyDown={handleSearchKeyDown}
              placeholder={t.searchPlaceholder}
              className="w-full bg-slate-900/90 dark:bg-slate-900/95 text-slate-100 text-xs sm:text-sm pl-10 pr-24 py-2.5 rounded-md border border-slate-700/80 focus:border-emerald-500/80 focus:ring-1 focus:ring-emerald-500/50 focus:outline-none transition-all placeholder-slate-500 font-sans shadow-inner"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />

            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="p-1 text-slate-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                onClick={() => {
                  onSearchSubmit(searchQuery);
                  setIsSearchFocused(false);
                }}
                className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-mono text-xs font-bold rounded cursor-pointer transition-all shadow-[0_0_8px_rgba(16,185,129,0.3)]"
              >
                {t.searchButton}
              </button>
            </div>
          </div>

          {/* Instant Search Suggestions Dropdown */}
          {isSearchFocused && (
            <div className="absolute top-full left-0 right-0 mt-1.5 bg-slate-900/95 border border-slate-800 rounded-md shadow-2xl overflow-hidden z-50 p-3 space-y-3 font-sans">
              {searchQuery.trim() === '' ? (
                <div>
                  <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-emerald-400" />
                    熱門搜尋關鍵字
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {popularKeywords.map(kw => (
                      <button
                        key={kw}
                        onClick={() => {
                          setSearchQuery(kw);
                          onSearchSubmit(kw);
                          setIsSearchFocused(false);
                        }}
                        className="px-2.5 py-1 bg-slate-800/80 hover:bg-emerald-500/20 border border-slate-700 hover:border-emerald-500/40 text-slate-300 hover:text-emerald-400 text-xs rounded transition-all font-mono"
                      >
                        {kw}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div>
                  <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center justify-between">
                    <span>搜尋結果 ({searchResults.length})</span>
                    <span className="text-[10px] text-emerald-400">按 Enter 看更多</span>
                  </div>

                  {searchResults.length === 0 ? (
                    <div className="py-4 text-center text-xs text-slate-400 font-mono">
                      未找到符合「{searchQuery}」的商品。
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      {searchResults.map(p => (
                        <div
                          key={p.id}
                          onClick={() => {
                            onSelectProduct(p.id);
                            setIsSearchFocused(false);
                          }}
                          className="flex items-center gap-3 p-2 hover:bg-slate-800/80 rounded transition-colors cursor-pointer group"
                        >
                          <img
                            src={p.image}
                            alt={getText(p.name)}
                            className="w-10 h-10 object-cover rounded bg-slate-950"
                          />
                          <div className="flex-1 min-w-0">
                            <h5 className="text-xs text-slate-200 group-hover:text-emerald-400 truncate font-semibold">
                              {getText(p.name)}
                            </h5>
                            <p className="text-[10px] text-slate-400 font-mono">
                              {p.brand} · {p.specs?.origin || 'Taiwan'}
                            </p>
                          </div>
                          <div className="font-mono text-xs text-emerald-400 font-bold">
                            NT$ {p.price.toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* RIGHT: Language, AI, Theme, Notifications, Cart, Account */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Language Selector */}
          <LanguageSelector className="hidden sm:inline-flex" />

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            title="Theme Toggle"
            className="p-2 text-slate-400 hover:text-slate-100 bg-slate-900 border border-slate-800 rounded-md hover:border-slate-700 transition-colors"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-300" />}
          </button>

          {/* AI Concierge Trigger */}
          <button
            onClick={onOpenAiConcierge}
            className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 hover:from-emerald-500/30 hover:to-teal-500/30 border border-emerald-500/40 text-emerald-400 rounded-md font-mono text-xs font-semibold shadow-[0_0_12px_rgba(16,185,129,0.15)] transition-all cursor-pointer"
          >
            <Cpu className="w-3.5 h-3.5 animate-pulse" />
            <span>AI 導覽</span>
          </button>

          {/* Notifications */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 text-slate-400 hover:text-slate-100 bg-slate-900 border border-slate-800 rounded-md hover:border-slate-700 transition-colors"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
          </button>

          {/* Wishlist */}
          <button
            onClick={() => onSelectCategory('wishlist')}
            className="relative p-2 text-slate-400 hover:text-red-400 bg-slate-900 border border-slate-800 rounded-md hover:border-slate-700 transition-colors"
          >
            <Heart className="w-4 h-4" />
            {wishlistIds.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-red-600 text-white font-mono text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold shadow-[0_0_6px_#d92b2b]">
                {wishlistIds.length}
              </span>
            )}
          </button>

          {/* Cart Drawer Trigger */}
          <button
            onClick={onOpenCart}
            className="relative p-2 sm:px-3 sm:py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-md flex items-center gap-2 font-mono text-xs font-bold transition-all shadow-[0_0_12px_rgba(16,185,129,0.3)] cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden sm:inline">{t.cart}</span>
            {totalItems > 0 && (
              <span className="bg-slate-950 text-emerald-400 px-1.5 py-0.2 rounded text-[11px] font-bold">
                {totalItems}
              </span>
            )}
          </button>

          {/* Account Modal Trigger */}
          <button
            onClick={onOpenAuth}
            className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-md text-slate-200 text-xs font-mono font-medium transition-colors"
          >
            <User className="w-4 h-4 text-emerald-400" />
            <span>{t.login}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
