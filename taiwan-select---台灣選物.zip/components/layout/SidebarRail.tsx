'use client';

import React from 'react';
import {
  Home,
  Flame,
  Award,
  Cpu,
  Smartphone,
  Sparkles,
  ShoppingBag,
  UtensilsCrossed,
  Layers,
  Store,
  Tag,
  UserCheck,
  PackageCheck,
  Heart,
  Coins,
  ShieldCheck,
  BarChart3,
  HelpCircle,
  Headphones,
} from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { CategoryId } from '@/types/ecommerce';

interface SidebarRailProps {
  activeCategory: CategoryId | 'membership' | 'orders' | 'wishlist' | 'analytics';
  onSelectCategory: (cat: CategoryId | 'membership' | 'orders' | 'wishlist' | 'analytics') => void;
  isAdminMode: boolean;
  onToggleAdminMode: () => void;
  onOpenCustomerSupport: () => void;
}

export const SidebarRail: React.FC<SidebarRailProps> = ({
  activeCategory,
  onSelectCategory,
  isAdminMode,
  onToggleAdminMode,
  onOpenCustomerSupport,
}) => {
  const { t } = useLanguage();

  const mainNavItems = [
    { id: 'all' as const, label: t.nav.home, icon: Home },
    { id: 'trending' as const, label: t.nav.trending, icon: Flame },
    { id: 'taiwan-select' as const, label: t.nav.taiwanSelect, icon: Award, highlight: true },
    { id: 'smart-tech' as const, label: t.nav.smartTech, icon: Cpu },
    { id: 'consumer-electronics' as const, label: t.nav.consumerElectronics, icon: Smartphone },
    { id: 'beauty' as const, label: t.nav.beauty, icon: Sparkles },
    { id: 'fashion' as const, label: t.nav.fashion, icon: ShoppingBag },
    { id: 'food' as const, label: t.nav.food, icon: UtensilsCrossed },
    { id: 'home-living' as const, label: t.nav.homeLiving, icon: Layers },
    { id: 'brand-stores' as const, label: t.nav.brandStores, icon: Store },
    { id: 'offers' as const, label: t.nav.offers, icon: Tag },
  ];

  const userNavItems = [
    { id: 'membership' as const, label: t.nav.membership, icon: UserCheck },
    { id: 'orders' as const, label: t.nav.orders, icon: PackageCheck },
    { id: 'wishlist' as const, label: t.nav.wishlistNav, icon: Heart },
    { id: 'analytics' as const, label: t.nav.analytics, icon: BarChart3, isAdmin: true },
  ];

  return (
    <aside className="w-56 bg-[#050505] border-r border-zinc-800 text-zinc-300 flex flex-col justify-between hidden lg:flex shrink-0 select-none font-sans sticky top-20 h-[calc(100vh-5rem)] overflow-y-auto no-scrollbar">
      <div className="flex-1 flex flex-col">
        {/* Rail Top Branding */}
        <div className="p-5 border-b border-zinc-800 bg-[#050505]">
          <div className="text-[10px] tracking-[0.2em] text-zinc-500 uppercase mb-1 font-semibold font-mono">
            TAIWAN SELECT
          </div>
          <div className="text-base font-bold text-white tracking-wider">台灣選物</div>
        </div>

        {/* Main Categories */}
        <div className="p-2 space-y-1 overflow-y-auto flex-1">
          <div className="px-3 pt-3 pb-1 text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-semibold flex items-center justify-between">
            <span>CORE NAV</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#00FF00] shadow-[0_0_8px_#00FF00]" />
          </div>

          {mainNavItems.map(item => {
            const Icon = item.icon;
            const isActive = activeCategory === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectCategory(item.id)}
                className={`w-full flex items-center space-x-3 px-3 py-2 text-xs transition-colors cursor-pointer group ${
                  isActive
                    ? 'bg-zinc-900 border-l-2 border-[#00FF00] text-white font-semibold'
                    : 'text-zinc-500 hover:text-white hover:bg-zinc-900/50'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full transition-colors ${isActive ? 'bg-[#00FF00] shadow-[0_0_6px_#00FF00]' : 'bg-zinc-700'}`} />
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#00FF00]' : item.highlight ? 'text-[#E60012]' : 'text-zinc-500 group-hover:text-zinc-300'}`} />
                <span className="flex-1 text-left truncate">{item.label}</span>
                {item.highlight && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#E60012] shadow-[0_0_6px_#E60012]" />
                )}
              </button>
            );
          })}

          {/* Account Section Divider */}
          <div className="pt-4 pb-1 px-3 text-[10px] uppercase tracking-widest text-zinc-600 font-bold font-mono">
            ACCOUNT & MGMT
          </div>

          {userNavItems.map(item => {
            const Icon = item.icon;
            const isActive = activeCategory === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectCategory(item.id)}
                className={`w-full flex items-center space-x-3 px-3 py-2 text-xs transition-colors cursor-pointer group ${
                  isActive
                    ? 'bg-zinc-900 border-l-2 border-[#00FF00] text-white font-semibold'
                    : 'text-zinc-500 hover:text-white hover:bg-zinc-900/50'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-[#00FF00]' : 'bg-zinc-700'}`} />
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#00FF00]' : item.isAdmin ? 'text-amber-400' : 'text-zinc-500 group-hover:text-zinc-300'}`} />
                <span className="flex-1 text-left truncate">{item.label}</span>
                {item.isAdmin && (
                  <span className="text-[9px] font-mono px-1 py-0.2 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-sm">
                    ADMIN
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* 24hr Customer Support Trigger */}
        <div className="p-3 border-t border-zinc-800 bg-[#050505]">
          <button
            onClick={onOpenCustomerSupport}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs text-zinc-300 hover:text-white transition-colors cursor-pointer font-mono"
          >
            <Headphones className="w-3.5 h-3.5 text-[#00FF00]" />
            <span>24H 客服支援</span>
          </button>
        </div>

        {/* System Status Panel from Design Theme */}
        <div className="p-3 border-t border-zinc-800 bg-[#050505]">
          <div className="bg-zinc-900 rounded-sm p-2.5 border border-zinc-800">
            <div className="text-[9px] text-zinc-500 mb-1 font-mono uppercase tracking-widest">
              ENGINEERING STATUS
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[#00FF00] font-mono uppercase tracking-tighter font-semibold">
                Sys. Optimal
              </span>
              <div className="w-2 h-2 rounded-full bg-[#00FF00] shadow-[0_0_8px_#00FF00]" />
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};
