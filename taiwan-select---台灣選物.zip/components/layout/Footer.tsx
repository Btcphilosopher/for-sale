'use client';

import React from 'react';
import { ShieldCheck, Truck, CreditCard, Headphones, QrCode } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

export const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 font-sans text-xs pt-12 pb-24 lg:pb-12">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 space-y-12">
        {/* Top Feature Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 sm:p-6 bg-slate-900/80 border border-slate-800 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-slate-200">{t.serviceHighlights.fastDeliveryTitle}</div>
              <div className="text-[11px] text-slate-400">{t.serviceHighlights.fastDeliverySub}</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-slate-200">{t.serviceHighlights.warrantyTitle}</div>
              <div className="text-[11px] text-slate-400">{t.serviceHighlights.warrantySub}</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-slate-200">{t.serviceHighlights.paymentTitle}</div>
              <div className="text-[11px] text-slate-400">{t.serviceHighlights.paymentSub}</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-slate-200">{t.serviceHighlights.rewardsTitle}</div>
              <div className="text-[11px] text-slate-400">{t.serviceHighlights.rewardsSub}</div>
            </div>
          </div>
        </div>

        {/* Multi-column Footer links */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-red-600 rounded-sm flex items-center justify-center text-white font-serif font-bold text-xs">
                選
              </div>
              <span className="font-mono font-bold text-slate-100 text-base tracking-wider">
                TAIWAN SELECT
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed text-xs max-w-sm">
              融合台灣高科技半導體產業底蘊與頂級人文工藝美學，為全球消費者締造極致品質的智慧選物平台。
            </p>
            <div className="font-mono text-[11px] text-emerald-400 border border-emerald-500/30 bg-emerald-500/10 inline-block px-2.5 py-1 rounded">
              SYSTEM INFRASTRUCTURE: TAIPEI & HSINCHU SCIENCE PARK
            </div>
          </div>

          <div className="space-y-2 font-mono">
            <h4 className="text-slate-200 font-bold text-xs">智慧科技 Smart Tech</h4>
            <ul className="space-y-1.5 text-slate-400 text-[11px]">
              <li className="hover:text-emerald-400 cursor-pointer">3C 旗艦筆電</li>
              <li className="hover:text-emerald-400 cursor-pointer">TSMC 晶片產品</li>
              <li className="hover:text-emerald-400 cursor-pointer">Mini-LED 顯示器</li>
              <li className="hover:text-emerald-400 cursor-pointer">聲學降噪耳機</li>
            </ul>
          </div>

          <div className="space-y-2 font-mono">
            <h4 className="text-slate-200 font-bold text-xs">台灣在地工藝 MIT</h4>
            <ul className="space-y-1.5 text-slate-400 text-[11px]">
              <li className="hover:text-emerald-400 cursor-pointer">阿里山極品高山茶</li>
              <li className="hover:text-emerald-400 cursor-pointer">關廟金鑽鳳梨酥</li>
              <li className="hover:text-emerald-400 cursor-pointer">鶯歌金絲青瓷壺</li>
              <li className="hover:text-emerald-400 cursor-pointer">台南蝴蝶蘭生技</li>
            </ul>
          </div>

          <div className="space-y-2 font-mono">
            <h4 className="text-slate-200 font-bold text-xs">客戶服務 Care</h4>
            <ul className="space-y-1.5 text-slate-400 text-[11px]">
              <li className="hover:text-emerald-400 cursor-pointer">訂單與物流追蹤</li>
              <li className="hover:text-emerald-400 cursor-pointer">15天無鑑賞期說明</li>
              <li className="hover:text-emerald-400 cursor-pointer">尊榮矽谷會員權益</li>
              <li className="hover:text-emerald-400 cursor-pointer">AI 導覽專員諮詢</li>
            </ul>
          </div>
        </div>

        {/* Bottom Status & Copyright Line from Professional Polish Design Theme */}
        <div className="pt-6 border-t border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-4 font-mono text-[10px] text-zinc-500 uppercase">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <div className="w-1.5 h-1.5 bg-[#00FF00] rounded-full animate-pulse shadow-[0_0_8px_#00FF00]"></div>
              <span className="text-zinc-400 uppercase tracking-widest font-bold">Connected to TPE-01 Node</span>
            </div>
            <div className="text-zinc-600 hidden sm:block">Secure Protocol TLS 1.4</div>
          </div>
          <div className="flex items-center space-x-4">
            <span className="hover:text-zinc-300 cursor-pointer">Privacy</span>
            <span className="text-zinc-700">/</span>
            <span className="hover:text-zinc-300 cursor-pointer">Compliance</span>
            <span className="text-zinc-700">/</span>
            <span className="text-zinc-400">&copy; 2028 TAIWAN SELECT ECOSYSTEM</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
