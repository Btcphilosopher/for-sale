'use client';

import React from 'react';
import { Heart, ShoppingCart, SlidersHorizontal, Star, ShieldCheck, Check } from 'lucide-react';
import { Product } from '@/types/ecommerce';
import { useLanguage } from '@/context/LanguageContext';
import { useWishlist } from '@/context/WishlistContext';
import { useCart } from '@/context/CartContext';
import { InventoryBar } from '@/components/ui/InventoryBar';
import { TechBadge } from '@/components/ui/TechBadge';

interface ProductCardProps {
  product: Product;
  onSelect: (productId: string) => void;
  isCompared?: boolean;
  onToggleCompare?: (productId: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelect,
  isCompared = false,
  onToggleCompare,
}) => {
  const { t, getText } = useLanguage();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { addToCart } = useCart();

  const isFav = isInWishlist(product.id);

  return (
    <div className="group relative bg-[#0a0a0b] border border-zinc-800 hover:border-zinc-700 rounded-sm overflow-hidden transition-all duration-300 flex flex-col justify-between shadow-md font-sans">
      {/* Top Media Container */}
      <div className="relative aspect-4/3 w-full bg-[#050505] overflow-hidden cursor-pointer" onClick={() => onSelect(product.id)}>
        <img
          src={product.image}
          alt={getText(product.name)}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
        />

        {/* Product ID & Category Label watermark */}
        <div className="absolute bottom-2 right-2 text-2xl font-black text-zinc-800 group-hover:text-[#00FF00] transition-colors font-mono select-none">
          {product.category === 'smart-tech' ? '3C' : product.category === 'taiwan-select' ? 'TW' : 'MIT'}
        </div>

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1.5 z-10">
          {product.isMIT && (
            <TechBadge label="MIT 台灣製造" variant="red" />
          )}
          {product.isNew && (
            <TechBadge label="NEW 2026" variant="green" pulse />
          )}
          {product.discountPercentage && (
            <span className="bg-[#E60012] text-white font-mono text-[10px] font-bold px-1.5 py-0.5 rounded-sm shadow-[0_0_8px_#E60012]">
              -{product.discountPercentage}%
            </span>
          )}
        </div>

        {/* Top Right Action Buttons */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 z-10">
          <button
            onClick={e => {
              e.stopPropagation();
              toggleWishlist(product.id);
            }}
            className={`p-1.5 rounded-sm backdrop-blur-md transition-colors cursor-pointer ${
              isFav
                ? 'bg-[#E60012] text-white shadow-[0_0_8px_#E60012]'
                : 'bg-zinc-950/80 text-zinc-400 hover:text-white hover:bg-zinc-900 border border-zinc-800'
            }`}
          >
            <Heart className="w-3.5 h-3.5 fill-current" />
          </button>

          {onToggleCompare && (
            <button
              onClick={e => {
                e.stopPropagation();
                onToggleCompare(product.id);
              }}
              title="Compare Specs"
              className={`p-1.5 rounded-sm backdrop-blur-md font-mono text-[10px] transition-colors cursor-pointer ${
                isCompared
                  ? 'bg-[#00FF00] text-black font-bold shadow-[0_0_8px_#00FF00]'
                  : 'bg-zinc-950/80 text-zinc-400 hover:text-[#00FF00] hover:bg-zinc-900 border border-zinc-800'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
        <div className="space-y-2">
          {/* Product ID & Brand */}
          <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500 uppercase">
            <span>ID: {product.id.toUpperCase()}</span>
            <span className="flex items-center gap-1 text-amber-400">
              <Star className="w-3 h-3 fill-amber-400" />
              <span>{product.rating.toFixed(1)}</span>
            </span>
          </div>

          {/* Title */}
          <h3
            onClick={() => onSelect(product.id)}
            className="text-xs sm:text-sm font-bold text-zinc-100 uppercase tracking-wider group-hover:text-[#00FF00] transition-colors line-clamp-2 cursor-pointer leading-snug"
          >
            {getText(product.name)}
          </h3>

          {/* Specifications Matrix */}
          {product.specs && (
            <div className="grid grid-cols-2 gap-1.5 pt-1 font-mono text-[10px] text-zinc-400 bg-zinc-950 p-2 rounded-sm border border-zinc-800">
              {product.specs.cpu && (
                <div className="truncate">
                  <span className="text-zinc-600">CPU:</span>{' '}
                  <span className="text-[#00FF00] font-medium">{product.specs.cpu.split(' ')[0]}</span>
                </div>
              )}
              {product.specs.memory && (
                <div className="truncate">
                  <span className="text-zinc-600">RAM:</span>{' '}
                  <span className="text-zinc-300 font-medium">{product.specs.memory.split(' ')[0]} {product.specs.memory.split(' ')[1]}</span>
                </div>
              )}
              {product.specs.storage && (
                <div className="truncate">
                  <span className="text-zinc-600">SSD:</span>{' '}
                  <span className="text-zinc-300 font-medium">{product.specs.storage.split(' ')[0]} {product.specs.storage.split(' ')[1]}</span>
                </div>
              )}
              {product.specs.origin && (
                <div className="truncate">
                  <span className="text-zinc-600">ORIGIN:</span>{' '}
                  <span className="text-zinc-300 font-medium">{product.specs.origin}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Pricing & Stock Bar */}
        <div className="space-y-3 pt-2 border-t border-zinc-800">
          <InventoryBar stockCount={product.stockCount} showDemoLabel={false} />

          <div className="flex items-center justify-between">
            <div>
              <div className="font-mono text-base sm:text-lg font-bold text-white tracking-tight">
                NT$ {product.price.toLocaleString()}
              </div>
              {product.originalPrice && (
                <div className="font-mono text-[10px] text-zinc-600 line-through">
                  NT$ {product.originalPrice.toLocaleString()}
                </div>
              )}
            </div>

            <button
              onClick={() => addToCart(product)}
              className="w-8 h-8 border border-zinc-800 flex items-center justify-center hover:bg-[#00FF00] hover:text-black hover:border-[#00FF00] transition-colors cursor-pointer text-zinc-400 group/btn"
              title={t.actions.addToCart}
            >
              <span className="text-base font-bold font-mono group-hover/btn:text-black">+</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
