'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Heart, ShoppingBag, ShieldCheck, Truck, Cpu, Check, SlidersHorizontal, Share2 } from 'lucide-react';
import { Product } from '@/types/ecommerce';
import { useLanguage } from '@/context/LanguageContext';
import { useWishlist } from '@/context/WishlistContext';
import { useCart } from '@/context/CartContext';
import { InventoryBar } from '@/components/ui/InventoryBar';
import { TechBadge } from '@/components/ui/TechBadge';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onToggleCompare?: (productId: string) => void;
  isCompared?: boolean;
  onBuyNowCheckout: (product: Product, quantity: number) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onToggleCompare,
  isCompared = false,
  onBuyNowCheckout,
}) => {
  const { t, getText } = useLanguage();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { addToCart } = useCart();

  const [activeImgIndex, setActiveImgIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  const isFav = isInWishlist(product.id);
  const gallery = product.gallery && product.gallery.length > 0 ? product.gallery : [product.image];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden z-10 my-8 font-sans max-h-[90vh] flex flex-col"
        >
          {/* Header Bar */}
          <div className="p-4 border-b border-slate-800 bg-slate-950/90 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2 font-mono text-xs">
              <TechBadge label="MIT 台灣製造旗艦" variant="red" />
              <span className="text-slate-400">/</span>
              <span className="text-slate-300 font-semibold">{product.brand}</span>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column: Photography & Gallery */}
            <div className="space-y-4">
              <div className="relative aspect-4/3 rounded-lg overflow-hidden bg-slate-950 border border-slate-800">
                <img
                  src={gallery[activeImgIndex]}
                  alt={getText(product.name)}
                  className="w-full h-full object-cover"
                />
              </div>

              {gallery.length > 1 && (
                <div className="flex gap-2">
                  {gallery.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImgIndex(idx)}
                      className={`w-16 h-16 rounded overflow-hidden border transition-all cursor-pointer ${
                        activeImgIndex === idx
                          ? 'border-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)] scale-105'
                          : 'border-slate-800 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              <div className="p-4 rounded-lg bg-slate-950/80 border border-slate-800 space-y-2 text-xs font-mono text-slate-300">
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>品質保證與服務聲明</span>
                </div>
                <div className="flex justify-between border-t border-slate-800/80 pt-2 text-slate-400">
                  <span>配送：{product.deliveryEstimate}</span>
                  <span>保固：{product.warrantyText}</span>
                </div>
              </div>
            </div>

            {/* Right Column: Specifications & Purchasing */}
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="text-xs font-mono text-emerald-400 tracking-wider">
                  {product.brand} · {product.specs?.origin || 'MADE IN TAIWAN'}
                </div>
                <h1 className="text-xl sm:text-2xl font-bold text-slate-100 leading-snug">
                  {getText(product.name)}
                </h1>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {getText(product.description)}
                </p>
              </div>

              {/* Price & Member Price */}
              <div className="p-4 rounded-lg bg-slate-950 border border-slate-800/90 flex items-center justify-between font-mono">
                <div>
                  <div className="text-[10px] text-slate-400 uppercase">定價 Price</div>
                  <div className="text-2xl font-bold text-emerald-400">
                    NT$ {product.price.toLocaleString()}
                  </div>
                  {product.originalPrice && (
                    <div className="text-xs text-slate-500 line-through">
                      NT$ {product.originalPrice.toLocaleString()}
                    </div>
                  )}
                </div>

                {product.memberPrice && (
                  <div className="text-right bg-emerald-950/60 p-2.5 rounded border border-emerald-500/30">
                    <div className="text-[10px] text-emerald-400 font-bold">
                      尊榮會員特惠 Member Price
                    </div>
                    <div className="text-lg font-bold text-slate-100">
                      NT$ {product.memberPrice.toLocaleString()}
                    </div>
                  </div>
                )}
              </div>

              {/* Live Inventory Status Bar */}
              <InventoryBar stockCount={product.stockCount} />

              {/* Engineering Specs Matrix */}
              {product.specs && (
                <div className="space-y-2">
                  <h4 className="text-xs font-mono font-bold text-slate-200 flex items-center gap-1.5">
                    <Cpu className="w-4 h-4 text-emerald-400" />
                    <span>技術規格參數 Specification Matrix</span>
                  </h4>

                  <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950 p-3 rounded border border-slate-800/80">
                    {product.specs.cpu && (
                      <div>
                        <span className="text-slate-500 block text-[10px]">CPU 處理器</span>
                        <span className="text-slate-200">{product.specs.cpu}</span>
                      </div>
                    )}
                    {product.specs.memory && (
                      <div>
                        <span className="text-slate-500 block text-[10px]">MEMORY 記憶體</span>
                        <span className="text-slate-200">{product.specs.memory}</span>
                      </div>
                    )}
                    {product.specs.storage && (
                      <div>
                        <span className="text-slate-500 block text-[10px]">STORAGE 儲存</span>
                        <span className="text-slate-200">{product.specs.storage}</span>
                      </div>
                    )}
                    {product.specs.power && (
                      <div>
                        <span className="text-slate-500 block text-[10px]">POWER 功耗</span>
                        <span className="text-slate-200">{product.specs.power}</span>
                      </div>
                    )}
                    {product.specs.display && (
                      <div className="col-span-2">
                        <span className="text-slate-500 block text-[10px]">DISPLAY 顯示</span>
                        <span className="text-slate-200">{product.specs.display}</span>
                      </div>
                    )}
                    {product.specs.certId && (
                      <div className="col-span-2 pt-1 border-t border-slate-900 text-[10px] text-emerald-400">
                        MIT 防偽追蹤碼: {product.specs.certId}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Quantity Selector & Purchase CTA Actions */}
              <div className="space-y-3 pt-4 border-t border-slate-800">
                <div className="flex items-center gap-4">
                  <span className="text-xs font-mono text-slate-400">數量 Quantity:</span>
                  <div className="inline-flex items-center bg-slate-950 border border-slate-800 rounded font-mono text-xs">
                    <button
                      onClick={() => setQuantity(q => Math.max(1, q - 1))}
                      className="px-3 py-1.5 text-slate-400 hover:text-white"
                    >
                      -
                    </button>
                    <span className="px-3 font-bold text-slate-100">{quantity}</span>
                    <button
                      onClick={() => setQuantity(q => q + 1)}
                      className="px-3 py-1.5 text-slate-400 hover:text-white"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      addToCart(product, quantity);
                      onClose();
                    }}
                    className="py-3 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-100 font-mono text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <ShoppingBag className="w-4 h-4 text-emerald-400" />
                    <span>{t.actions.addToCart}</span>
                  </button>

                  <button
                    onClick={() => {
                      onBuyNowCheckout(product, quantity);
                    }}
                    className="py-3 rounded bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-mono text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-[0_0_15px_rgba(16,185,129,0.3)] cursor-pointer"
                  >
                    <span>{t.actions.buyNow}</span>
                  </button>
                </div>

                <div className="flex items-center justify-between text-xs font-mono text-slate-400 pt-2">
                  <button
                    onClick={() => toggleWishlist(product.id)}
                    className="flex items-center gap-1.5 hover:text-red-400 transition-colors cursor-pointer"
                  >
                    <Heart className={`w-4 h-4 ${isFav ? 'text-red-500 fill-current' : ''}`} />
                    <span>{isFav ? '已加入收藏' : t.actions.saveWishlist}</span>
                  </button>

                  {onToggleCompare && (
                    <button
                      onClick={() => onToggleCompare(product.id)}
                      className="flex items-center gap-1.5 hover:text-emerald-400 transition-colors cursor-pointer"
                    >
                      <SlidersHorizontal className="w-4 h-4" />
                      <span>{isCompared ? '已加入比對' : t.actions.compareSpecs}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
