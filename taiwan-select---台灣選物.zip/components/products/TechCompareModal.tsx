'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Cpu, Check, Trash2 } from 'lucide-react';
import { Product } from '@/types/ecommerce';
import { useLanguage } from '@/context/LanguageContext';
import { useCart } from '@/context/CartContext';

interface TechCompareModalProps {
  comparedProducts: Product[];
  onClose: () => void;
  onRemoveFromCompare: (productId: string) => void;
  onClearCompare: () => void;
}

export const TechCompareModal: React.FC<TechCompareModalProps> = ({
  comparedProducts,
  onClose,
  onRemoveFromCompare,
  onClearCompare,
}) => {
  const { t, getText } = useLanguage();
  const { addToCart } = useCart();

  if (comparedProducts.length === 0) return null;

  const rowLabels = [
    { key: 'price', label: '價格 Price' },
    { key: 'brand', label: '品牌 Brand' },
    { key: 'origin', label: '產地與製造 (MIT)' },
    { key: 'cpu', label: 'Performance 效能/處理器' },
    { key: 'memory', label: 'Memory 記憶體' },
    { key: 'storage', label: 'Storage 儲存空間' },
    { key: 'power', label: 'Power 功耗/電源' },
    { key: 'display', label: 'Display 顯示器' },
    { key: 'warranty', label: 'Warranty 保固期' },
    { key: 'stockCount', label: 'Availability 庫存狀態' },
  ];

  const getSpecValue = (p: Product, key: string) => {
    if (key === 'price') return `NT$ ${p.price.toLocaleString()}`;
    if (key === 'brand') return p.brand;
    if (key === 'origin') return p.specs?.origin || (p.isMIT ? '台灣製造 Made in Taiwan' : '國際精選');
    if (key === 'stockCount') return `${p.stockCount} UNITS (${p.inStock ? '庫存充足' : '低庫存'})`;
    if (!p.specs) return 'N/A';
    return (p.specs as any)[key] || 'N/A';
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto font-sans">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-6xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden z-10 my-8 flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-emerald-400 animate-pulse" />
              <h3 className="text-base font-bold text-slate-100 font-mono">
                {t.sections.techComparisonTitle} ({comparedProducts.length}/4)
              </h3>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={onClearCompare}
                className="text-xs font-mono text-slate-400 hover:text-red-400 flex items-center gap-1 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>清空比較表</span>
              </button>
              <button
                onClick={onClose}
                className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Table Content */}
          <div className="flex-1 overflow-auto p-4 sm:p-6">
            <table className="w-full text-left font-mono text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="p-3 w-40 text-slate-400 font-semibold bg-slate-950/60 sticky left-0 z-20">
                    產品與指標
                  </th>
                  {comparedProducts.map(p => (
                    <th key={p.id} className="p-3 min-w-[200px] bg-slate-950/40 align-top">
                      <div className="space-y-2 relative">
                        <button
                          onClick={() => onRemoveFromCompare(p.id)}
                          className="absolute -top-1 -right-1 p-1 text-slate-500 hover:text-red-400"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                        <img src={p.image} alt="" className="w-16 h-16 object-cover rounded border border-slate-800" />
                        <div className="font-bold text-slate-100 line-clamp-2">{getText(p.name)}</div>
                        <button
                          onClick={() => addToCart(p)}
                          className="w-full py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded text-[11px] transition-colors"
                        >
                          加入購物車
                        </button>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {rowLabels.map(row => (
                  <tr key={row.key} className="hover:bg-slate-950/40">
                    <td className="p-3 font-semibold text-slate-300 bg-slate-950/80 sticky left-0 z-10 border-r border-slate-800">
                      {row.label}
                    </td>
                    {comparedProducts.map(p => {
                      const val = getSpecValue(p, row.key);
                      return (
                        <td key={p.id} className="p-3 text-slate-200">
                          {row.key === 'price' ? (
                            <span className="text-emerald-400 font-bold text-sm">{val}</span>
                          ) : (
                            val
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
