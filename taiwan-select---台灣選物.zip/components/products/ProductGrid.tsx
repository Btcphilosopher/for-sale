'use client';

import React, { useState, useMemo } from 'react';
import { SlidersHorizontal, ArrowUpDown, Filter, ShieldCheck, Cpu } from 'lucide-react';
import { Product, CategoryId } from '@/types/ecommerce';
import { ProductCard } from './ProductCard';
import { useLanguage } from '@/context/LanguageContext';

interface ProductGridProps {
  products: Product[];
  selectedCategory: CategoryId | 'membership' | 'orders' | 'wishlist' | 'analytics';
  onSelectCategory: (cat: CategoryId) => void;
  onSelectProduct: (productId: string) => void;
  comparedIds: string[];
  onToggleCompare: (productId: string) => void;
  onOpenCompareModal: () => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  selectedCategory,
  onSelectCategory,
  onSelectProduct,
  comparedIds,
  onToggleCompare,
  onOpenCompareModal,
}) => {
  const { t } = useLanguage();

  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [mitOnly, setMitOnly] = useState<boolean>(false);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      // Category check
      if (selectedCategory !== 'all' && selectedCategory !== 'trending' && selectedCategory !== 'offers') {
        if (p.category !== selectedCategory) return false;
      }
      if (selectedCategory === 'trending' && !p.isHot && !p.isFeatured) return false;
      if (selectedCategory === 'offers' && !p.discountPercentage) return false;
      if (mitOnly && !p.isMIT) return false;
      if (inStockOnly && !p.inStock) return false;
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // default featured
    });
  }, [products, selectedCategory, mitOnly, inStockOnly, sortBy]);

  return (
    <div className="space-y-6 my-6 font-sans">
      {/* Top Filter Controls Bar */}
      <div className="p-4 bg-slate-950 border border-slate-800 rounded-lg flex flex-wrap items-center justify-between gap-4">
        {/* Left Toggles */}
        <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
          <button
            onClick={() => setMitOnly(prev => !prev)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded border transition-all cursor-pointer ${
              mitOnly
                ? 'bg-red-950/80 text-red-400 border-red-500/50 shadow-[0_0_10px_rgba(239,68,68,0.2)] font-bold'
                : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>MIT 台灣製造特輯</span>
          </button>

          <button
            onClick={() => setInStockOnly(prev => !prev)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded border transition-all cursor-pointer ${
              inStockOnly
                ? 'bg-emerald-950/80 text-emerald-400 border-emerald-500/50 shadow-[0_0_10px_rgba(16,185,129,0.2)] font-bold'
                : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>現貨速發</span>
          </button>

          {comparedIds.length > 0 && (
            <button
              onClick={onOpenCompareModal}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded shadow-[0_0_12px_rgba(16,185,129,0.3)] cursor-pointer"
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>產品比較矩陣 ({comparedIds.length})</span>
            </button>
          )}
        </div>

        {/* Right Sort Selector */}
        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
          <span>{t.actions.sort}:</span>
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as any)}
            className="bg-slate-900 text-slate-200 border border-slate-700 rounded px-2.5 py-1.5 focus:outline-none focus:border-emerald-500"
          >
            <option value="featured">精選推薦 Featured</option>
            <option value="price-asc">價格：由低至高 Price Low-High</option>
            <option value="price-desc">價格：由高至低 Price High-Low</option>
            <option value="rating">評價最高 Highest Rated</option>
          </select>
        </div>
      </div>

      {/* Product Cards Grid */}
      {filteredProducts.length === 0 ? (
        <div className="py-16 text-center bg-slate-950 border border-slate-800 rounded-lg space-y-3 font-mono">
          <Filter className="w-8 h-8 text-slate-600 mx-auto" />
          <p className="text-sm text-slate-400">尚無符合此條件的台灣選物商品。</p>
          <button
            onClick={() => {
              setMitOnly(false);
              setInStockOnly(false);
              onSelectCategory('all');
            }}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-emerald-400 rounded text-xs"
          >
            {t.actions.clearFilter}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
          {filteredProducts.map(p => (
            <ProductCard
              key={p.id}
              product={p}
              onSelect={onSelectProduct}
              isCompared={comparedIds.includes(p.id)}
              onToggleCompare={onToggleCompare}
            />
          ))}
        </div>
      )}
    </div>
  );
};
