'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, Sparkles, ArrowRight } from 'lucide-react';
import { Product } from '@/types/ecommerce';
import { useLanguage } from '@/context/LanguageContext';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (productId: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  products,
  onSelectProduct,
}) => {
  const { t, getText } = useLanguage();
  const [query, setQuery] = useState('');

  const searchResults = query.trim()
    ? products.filter(
        p =>
          getText(p.name).toLowerCase().includes(query.toLowerCase()) ||
          p.brand.toLowerCase().includes(query.toLowerCase()) ||
          p.category.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 font-sans">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden z-10 text-slate-100 font-mono"
          >
            {/* Search Input Bar */}
            <div className="p-4 border-b border-slate-800 flex items-center gap-3 bg-slate-950">
              <Search className="w-5 h-5 text-emerald-400" />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="搜尋 3C 筆電, TSMC 晶片, 阿里山茶, 美妝..."
                className="flex-1 bg-transparent text-sm text-slate-100 placeholder-slate-500 focus:outline-none"
              />
              <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Suggestions or Results */}
            <div className="p-4 max-h-96 overflow-y-auto space-y-3 text-xs">
              {!query.trim() ? (
                <div className="space-y-3 text-slate-400">
                  <div className="text-[11px] font-bold text-slate-500 uppercase">熱門關鍵字 Trending Keywords</div>
                  <div className="flex flex-wrap gap-2">
                    {['TSMC 3nm', '阿里山金萱茶', 'Mini-LED 顯示器', '關廟鳳梨酥', '鶯歌陶藝', '蘭花精萃'].map(kw => (
                      <button
                        key={kw}
                        onClick={() => setQuery(kw)}
                        className="px-2.5 py-1 bg-slate-950 border border-slate-800 hover:border-emerald-500/50 rounded text-slate-300 hover:text-emerald-400 transition-all"
                      >
                        {kw}
                      </button>
                    ))}
                  </div>
                </div>
              ) : searchResults.length === 0 ? (
                <div className="py-8 text-center text-slate-500">
                  找不到符合 &quot;{query}&quot; 的商品
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="text-[11px] font-bold text-slate-500 uppercase">
                    搜尋結果 ({searchResults.length})
                  </div>
                  {searchResults.map(p => (
                    <div
                      key={p.id}
                      onClick={() => {
                        onClose();
                        onSelectProduct(p.id);
                      }}
                      className="p-2.5 rounded bg-slate-950/80 border border-slate-800 hover:border-emerald-500/50 flex items-center justify-between cursor-pointer transition-all group"
                    >
                      <div className="flex items-center gap-3">
                        <img src={p.image} alt="" className="w-10 h-10 object-cover rounded" />
                        <div>
                          <div className="font-bold text-slate-100 group-hover:text-emerald-400 transition-colors">
                            {getText(p.name)}
                          </div>
                          <div className="text-[10px] text-slate-400">{p.brand} · {p.category}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-emerald-400 font-bold">NT$ {p.price.toLocaleString()}</span>
                        <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
