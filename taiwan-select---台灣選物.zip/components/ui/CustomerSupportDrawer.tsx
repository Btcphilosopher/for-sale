'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Headphones, X, Send, Bot, User, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

interface CustomerSupportDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CustomerSupportDrawer: React.FC<CustomerSupportDrawerProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  const [messages, setMessages] = useState([
    { sender: 'support', text: '您好！歡迎使用 TAIWAN SELECT 24hr 客服中心，請問有什麼我可以協助您的？' },
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg = input.trim();
    setMessages(prev => [...prev, { sender: 'user', text: userMsg }]);
    setInput('');

    setTimeout(() => {
      let reply = '感謝您的訊息！我們的客服工程專員正在為您查詢，您也可以點擊選單查詢物流與全台配送進度。';
      if (userMsg.includes('物流') || userMsg.includes('運送') || userMsg.includes('到貨')) {
        reply = '全台主要城市（台北、新竹、台中、台南、高雄）均支援 24hr 極速專車到府配送服務。您可以至訂單查詢中輸入物流追蹤碼！';
      } else if (userMsg.includes('MIT') || userMsg.includes('台灣製造') || userMsg.includes('品質')) {
        reply = 'TAIWAN SELECT 上架之 MIT 商品皆經過經濟部工業局與本平台最高標準驗證，並賦予專屬防偽追蹤序號！';
      }
      setMessages(prev => [...prev, { sender: 'support', text: reply }]);
    }, 800);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50"
          />

          <motion.div
            initial={{ opacity: 0, x: 400 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 400 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-slate-900 border-l border-slate-800 text-slate-100 z-50 flex flex-col shadow-2xl font-sans"
          >
            {/* Header */}
            <div className="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
              <div className="flex items-center gap-2 font-mono text-sm font-bold">
                <Headphones className="w-5 h-5 text-emerald-400" />
                <span>24hr 客服中心 Customer Service</span>
              </div>
              <button onClick={onClose} className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 font-mono text-xs">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex gap-2.5 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {m.sender === 'support' && (
                    <div className="w-7 h-7 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                      <Headphones className="w-4 h-4" />
                    </div>
                  )}
                  <div
                    className={`p-3 rounded-lg max-w-[80%] leading-relaxed ${
                      m.sender === 'user'
                        ? 'bg-emerald-500 text-slate-950 font-bold'
                        : 'bg-slate-950 border border-slate-800 text-slate-200'
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
            </div>

            {/* Input Bar */}
            <div className="p-4 border-t border-slate-800 bg-slate-950 flex gap-2">
              <input
                type="text"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSend()}
                placeholder="輸入您想諮詢的問題..."
                className="flex-1 bg-slate-900 border border-slate-700 rounded px-3 py-2 text-xs font-mono text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={handleSend}
                className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded flex items-center justify-center cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
