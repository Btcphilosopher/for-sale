'use client';

import React from 'react';

interface TechBadgeProps {
  label: string;
  variant?: 'green' | 'red' | 'blue' | 'graphite';
  pulse?: boolean;
  className?: string;
}

export const TechBadge: React.FC<TechBadgeProps> = ({
  label,
  variant = 'green',
  pulse = false,
  className = '',
}) => {
  const variantStyles = {
    green: 'bg-emerald-950/80 text-emerald-400 border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.15)]',
    red: 'bg-red-950/80 text-red-400 border-red-500/40 shadow-[0_0_10px_rgba(239,68,68,0.15)]',
    blue: 'bg-cyan-950/80 text-cyan-400 border-cyan-500/40 shadow-[0_0_10px_rgba(6,182,212,0.15)]',
    graphite: 'bg-slate-800/80 text-slate-300 border-slate-700/60',
  };

  const dotColors = {
    green: 'bg-emerald-400 shadow-[0_0_6px_#10b981]',
    red: 'bg-red-400 shadow-[0_0_6px_#ef4444]',
    blue: 'bg-cyan-400 shadow-[0_0_6px_#06b6d4]',
    graphite: 'bg-slate-400',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2 py-0.5 border rounded-sm font-mono text-[10px] sm:text-xs font-medium tracking-wide uppercase ${variantStyles[variant]} ${className}`}
    >
      {pulse && (
        <span className="relative flex h-1.5 w-1.5">
          <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${dotColors[variant]}`}></span>
          <span className={`relative inline-flex rounded-full h-1.5 w-1.5 ${dotColors[variant]}`}></span>
        </span>
      )}
      {label}
    </span>
  );
};
