'use client';

import React from 'react';
import { useLanguage } from '@/context/LanguageContext';

interface InventoryBarProps {
  stockCount: number;
  maxStock?: number;
  showDemoLabel?: boolean;
  className?: string;
}

export const InventoryBar: React.FC<InventoryBarProps> = ({
  stockCount,
  maxStock = 150,
  showDemoLabel = true,
  className = '',
}) => {
  const { t } = useLanguage();
  const percentage = Math.min(100, Math.max(5, Math.round((stockCount / maxStock) * 100)));

  const isLow = stockCount <= 20;

  return (
    <div className={`space-y-1.5 font-mono text-xs ${className}`}>
      <div className="flex items-center justify-between text-[11px] tracking-wider text-slate-400 dark:text-slate-400">
        <span className="flex items-center gap-1.5 font-semibold">
          <span className={`inline-block w-2 h-2 rounded-full ${isLow ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400 shadow-[0_0_8px_#10b981]'}`} />
          {isLow ? t.specs.lowStock : t.specs.inStock}
        </span>
        <span className="text-emerald-400 dark:text-emerald-400 font-bold">
          {stockCount} UNITS
        </span>
      </div>

      <div className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-sm overflow-hidden p-0.5 border border-slate-300 dark:border-slate-700/60 flex items-center">
        <div
          className={`h-full rounded-xs transition-all duration-500 ${
            isLow
              ? 'bg-gradient-to-r from-amber-500 to-red-500'
              : 'bg-gradient-to-r from-emerald-500 to-teal-400 shadow-[0_0_10px_rgba(16,185,129,0.5)]'
          }`}
          style={{ width: `${percentage}%` }}
        />
      </div>

      {showDemoLabel && (
        <div className="flex items-center justify-between text-[9px] text-slate-500 dark:text-slate-500 tracking-tight">
          <span>SYS_STATUS: LIVE_INVENTORY</span>
          <span className="bg-slate-800 text-emerald-400/90 px-1 py-0.2 rounded border border-slate-700/50">
            DEMO DATA
          </span>
        </div>
      )}
    </div>
  );
};
