'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, X, ShieldCheck, Zap, Package, Sparkles } from 'lucide-react';

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const NOTIFICATIONS = [
  {
    id: 'n1',
    title: '雙11 科技選物節即刻啟動',
    time: '10 分鐘前',
    type: 'promo',
    desc: '全館台灣製造精品限時回饋高達 20%，結帳輸入 TAIWAN2026 再折 $500！',
    icon: Zap,
  },
  {
    id: 'n2',
    title: '出貨通知：訂單 TW-889102',
    time: '2 小時前',
    type: 'system',
    desc: '您的 Silicon-X Pro 16 筆記型電腦已由新竹園區快遞出貨，預計明日送達。',
    icon: Package,
  },
  {
    id: 'n3',
    title: '尊榮矽谷會員點數入帳',
    time: '1 天前',
    type: 'reward',
    desc: '感謝支持台灣在地工藝！已獲得紅利點數 1,280 點。',
    icon: Sparkles,
  },
  {
    id: 'n4',
    title: 'Made in Taiwan 品質認證升級',
    time: '3 天前',
    type: 'info',
    desc: '所有平台商品履歷皆通過科技區塊鏈防偽驗證，安心購買。',
    icon: ShieldCheck,
  },
];

export const NotificationPanel: React.FC<NotificationPanelProps> = ({ isOpen, onClose }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50"
          />
          <motion.div
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 300 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-sm bg-slate-900 border-l border-slate-800 text-slate-100 z-50 flex flex-col shadow-2xl"
          >
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
              <div className="flex items-center gap-2 font-mono text-sm tracking-wide">
                <Bell className="w-4 h-4 text-emerald-400 animate-pulse" />
                <span className="font-bold text-slate-100">通知與系統消息</span>
                <span className="bg-emerald-500/20 text-emerald-400 text-xs px-1.5 py-0.5 rounded border border-emerald-500/40">
                  4 NEW
                </span>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {NOTIFICATIONS.map(item => {
                const IconComponent = item.icon;
                return (
                  <div
                    key={item.id}
                    className="p-3.5 bg-slate-950/60 border border-slate-800/80 hover:border-emerald-500/40 rounded-md transition-all group"
                  >
                    <div className="flex items-start gap-3">
                      <div className="p-2 rounded bg-slate-900 border border-slate-700/60 text-emerald-400 group-hover:border-emerald-500/50">
                        <IconComponent className="w-4 h-4" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-semibold text-slate-200 group-hover:text-emerald-400 transition-colors">
                            {item.title}
                          </h4>
                          <span className="text-[10px] font-mono text-slate-500">{item.time}</span>
                        </div>
                        <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3 border-t border-slate-800 bg-slate-950/80 text-center font-mono text-xs text-slate-400">
              TAIWAN SELECT REAL-TIME ALERT SYSTEM v2.8
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
