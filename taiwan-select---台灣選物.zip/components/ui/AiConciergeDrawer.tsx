'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, X, Send, Sparkles, Loader2, Cpu, ExternalLink } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

import { Product } from '@/types/ecommerce';

interface AiConciergeDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProductQuery?: (query: string) => void;
  products?: Product[];
  onSelectProduct?: (productId: string) => void;
}

interface Message {
  sender: 'ai' | 'user';
  text: string;
  time: string;
}

export const AiConciergeDrawer: React.FC<AiConciergeDrawerProps> = ({
  isOpen,
  onClose,
  onSelectProductQuery,
}) => {
  const { language } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'ai',
      text: '您好！我是 TAIWAN SELECT 智慧選物 AI 導覽員。請問您想尋找半導體級高科技商品、阿里山頂級茶款，或是台灣極致工藝禮品呢？',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const presetQuestions = [
    '推薦高科技與台灣製造伴手禮',
    'Silicon-X Pro 16 AI 筆電有何特色？',
    '阿里山高山茶適合搭配什麼點心？',
    '台灣製造 (MIT) 品質驗證流程？',
  ];

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim() || isLoading) return;

    const userMsg: Message = {
      sender: 'user',
      text: query,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: query, language }),
      });
      const data = await res.json();

      const aiMsg: Message = {
        sender: 'ai',
        text: data.text || '【AI 導覽員】系統目前正升級中，歡迎參考台灣特色選物專區！',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch {
      setMessages(prev => [
        ...prev,
        {
          sender: 'ai',
          text: '【AI 導覽員】即時傳送訊息時發生網路波動。已為您整理頂級 3C 與阿里山茶品專區！',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50"
          />
          <motion.div
            initial={{ opacity: 0, x: 400 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 400 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-slate-900 border-l border-slate-800 text-slate-100 z-50 flex flex-col shadow-2xl"
          >
            {/* Top Bar */}
            <div className="p-4 border-b border-slate-800 bg-slate-950/90 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  <Cpu className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                    TAIWAN SELECT AI 智慧導覽
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  </h3>
                  <p className="text-[10px] font-mono text-slate-400">
                    POWERED BY GEMINI AI · MIT CONCIERGE
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Presets */}
            <div className="px-4 py-2.5 bg-slate-950/40 border-b border-slate-800 flex gap-1.5 overflow-x-auto no-scrollbar text-xs">
              {presetQuestions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(q)}
                  className="whitespace-nowrap px-2.5 py-1 rounded bg-slate-800/80 hover:bg-emerald-500/20 border border-slate-700 hover:border-emerald-500/40 text-slate-300 hover:text-emerald-400 font-mono text-[11px] transition-all cursor-pointer"
                >
                  {q}
                </button>
              ))}
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 font-sans text-xs">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg p-3 space-y-1 ${
                      m.sender === 'user'
                        ? 'bg-emerald-600 text-white rounded-br-none'
                        : 'bg-slate-950/90 border border-slate-800 text-slate-200 rounded-bl-none shadow-md'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-1 mb-1 text-[10px] opacity-75 font-mono">
                      <span>{m.sender === 'user' ? 'YOU' : 'AI CONCIERGE'}</span>
                      <span>{m.time}</span>
                    </div>
                    <div className="whitespace-pre-wrap leading-relaxed">{m.text}</div>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-slate-950/90 border border-slate-800 rounded-lg p-3 text-emerald-400 flex items-center gap-2 font-mono text-xs">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    AI 導覽員正分析台灣選物與技術資料庫...
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-3 border-t border-slate-800 bg-slate-950/90 flex gap-2">
              <input
                type="text"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSend()}
                placeholder="詢問商品規格、產地、茶款與選物建議..."
                className="flex-1 bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-sans"
              />
              <button
                onClick={() => handleSend()}
                disabled={isLoading || !input.trim()}
                className="px-3.5 py-2 rounded-md bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold flex items-center justify-center disabled:opacity-50 transition-colors cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
