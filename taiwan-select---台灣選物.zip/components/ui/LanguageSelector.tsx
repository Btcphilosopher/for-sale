'use client';

import React from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { Language } from '@/types/ecommerce';

export const LanguageSelector: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { language, setLanguage } = useLanguage();

  const options: { code: Language; label: string }[] = [
    { code: 'zh-TW', label: '繁中' },
    { code: 'en', label: 'English' },
    { code: 'nan', label: '台語' },
  ];

  return (
    <div className={`inline-flex items-center gap-1.5 bg-slate-900/80 dark:bg-slate-950/90 border border-slate-700/50 rounded-md p-1 text-xs font-mono tracking-wider ${className}`}>
      {options.map((opt, idx) => {
        const isActive = language === opt.code;
        return (
          <React.Fragment key={opt.code}>
            {idx > 0 && <span className="text-slate-600 select-none">|</span>}
            <button
              onClick={() => setLanguage(opt.code)}
              className={`px-2 py-0.5 rounded transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.2)] font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {opt.label}
            </button>
          </React.Fragment>
        );
      })}
    </div>
  );
};
