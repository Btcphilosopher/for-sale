'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '@/types/ecommerce';
import { TRANSLATIONS } from '@/data/translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof TRANSLATIONS['zh-TW'];
  getText: (textObj: Record<string, string> | string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window === 'undefined') return 'zh-TW';
    const saved = localStorage.getItem('taiwan_select_lang') as Language;
    return saved && (saved === 'zh-TW' || saved === 'en' || saved === 'nan') ? saved : 'zh-TW';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('taiwan_select_lang', lang);
    }
  };

  const t = TRANSLATIONS[language] || TRANSLATIONS['zh-TW'];

  const getText = (textObj: Record<string, string> | string): string => {
    if (typeof textObj === 'string') return textObj;
    if (!textObj) return '';
    return textObj[language] || textObj['zh-TW'] || textObj['en'] || Object.values(textObj)[0] || '';
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, getText }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
