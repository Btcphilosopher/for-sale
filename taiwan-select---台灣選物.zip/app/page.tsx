'use client';

import React, { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { SidebarRail } from '@/components/layout/SidebarRail';
import { MobileNav } from '@/components/layout/MobileNav';
import { Footer } from '@/components/layout/Footer';
import { HeroSection } from '@/components/home/HeroSection';
import { CategoryGrid } from '@/components/home/CategoryGrid';
import { PromoBanners } from '@/components/home/PromoBanners';
import { MitSupplyChainSection } from '@/components/home/MitSupplyChainSection';
import { ProductGrid } from '@/components/products/ProductGrid';
import { ProductDetailModal } from '@/components/products/ProductDetailModal';
import { TechCompareModal } from '@/components/products/TechCompareModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { CheckoutFlow } from '@/components/cart/CheckoutFlow';
import { MembershipView } from '@/components/membership/MembershipView';
import { AnalyticsDashboard } from '@/components/analytics/AnalyticsDashboard';
import { AiConciergeDrawer } from '@/components/ui/AiConciergeDrawer';
import { AuthModal } from '@/components/ui/AuthModal';
import { SearchModal } from '@/components/ui/SearchModal';
import { CustomerSupportDrawer } from '@/components/ui/CustomerSupportDrawer';
import { INITIAL_PRODUCTS } from '@/data/products';
import { Product, CategoryId } from '@/types/ecommerce';
import { useCart } from '@/context/CartContext';

export default function Home() {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [activeCategory, setActiveCategory] = useState<CategoryId | 'membership' | 'orders' | 'wishlist' | 'analytics'>('all');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [comparedIds, setComparedIds] = useState<string[]>([]);
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);
  
  // Drawers and Modal States
  const [isAiConciergeOpen, setIsAiConciergeOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [isCheckoutActive, setIsCheckoutActive] = useState(false);

  // Orders State
  const [orders, setOrders] = useState<any[]>([
    {
      id: 'ORD-849201',
      date: '2026-08-15',
      items: [
        {
          id: 'p1',
          productId: 'p1',
          productName: 'ASUS ROG Zephyrus G16 (2026 TSMC 3nm Edition)',
          price: 78900,
          quantity: 1,
        },
      ],
      totalAmount: 78900,
      status: 'shipped',
      trackingNumber: 'TW-884920',
      paymentMethod: 'line-pay',
    },
  ]);

  const { setIsCartOpen, addToCart } = useCart();

  // Handlers
  const handleToggleCompare = (productId: string) => {
    setComparedIds(prev => {
      if (prev.includes(productId)) {
        return prev.filter(id => id !== productId);
      }
      if (prev.length >= 4) {
        alert('最多只能同時比較 4 項商品規格。');
        return prev;
      }
      return [...prev, productId];
    });
  };

  const handleUpdateStock = (productId: string, newStock: number) => {
    setProducts(prev =>
      prev.map(p => (p.id === productId ? { ...p, stockCount: newStock, inStock: newStock > 0 } : p))
    );
  };

  const handleUpdatePrice = (productId: string, newPrice: number) => {
    setProducts(prev =>
      prev.map(p => (p.id === productId ? { ...p, price: newPrice } : p))
    );
  };

  const handleAddOrderToHistory = (order: any) => {
    setOrders(prev => [order, ...prev]);
  };

  const selectedProduct = products.find(p => p.id === selectedProductId) || null;
  const comparedProducts = products.filter(p => comparedIds.includes(p.id));

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Global Header */}
      <Header
        onOpenAiConcierge={() => setIsAiConciergeOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onSelectCategory={cat => {
          setIsCheckoutActive(false);
          setActiveCategory(cat);
        }}
        activeCategory={activeCategory}
        isAdminMode={isAdminMode}
      />

      {/* Main Layout Body: Left Sidebar + Center Workspace */}
      <div className="flex-1 flex max-w-[1800px] w-full mx-auto px-2 sm:px-4 lg:px-6 gap-6">
        {/* Persistent Left Navigation Rail (Desktop) */}
        <SidebarRail
          activeCategory={activeCategory}
          onSelectCategory={cat => {
            setIsCheckoutActive(false);
            setActiveCategory(cat);
          }}
          isAdminMode={isAdminMode}
          onToggleAdminMode={() => setIsAdminMode(!isAdminMode)}
          onOpenCustomerSupport={() => setIsSupportOpen(true)}
        />

        {/* Center Main Stage Content Area */}
        <main className="flex-1 min-w-0 pb-20 lg:pb-12">
          {isCheckoutActive ? (
            <CheckoutFlow
              onBackToStore={() => setIsCheckoutActive(false)}
              onAddOrderToHistory={handleAddOrderToHistory}
            />
          ) : activeCategory === 'membership' || activeCategory === 'orders' || activeCategory === 'wishlist' ? (
            <MembershipView
              orders={orders}
              allProducts={products}
              onSelectProduct={id => setSelectedProductId(id)}
            />
          ) : activeCategory === 'analytics' ? (
            <AnalyticsDashboard
              products={products}
              onUpdateProductStock={handleUpdateStock}
              onUpdateProductPrice={handleUpdatePrice}
            />
          ) : (
            <>
              {/* Hero Section */}
              <HeroSection
                onExploreClick={() => setActiveCategory('smart-tech')}
                onShopClick={cat => setActiveCategory(cat)}
              />

              {/* Promotional Banners */}
              <PromoBanners onSelectCategory={cat => setActiveCategory(cat)} />

              {/* Category Selection Grid */}
              <CategoryGrid onSelectCategory={cat => setActiveCategory(cat)} />

              {/* Made in Taiwan Supply Chain Section */}
              <MitSupplyChainSection />

              {/* Primary Product Marketplace Grid */}
              <div className="mt-8">
                <ProductGrid
                  products={products}
                  selectedCategory={activeCategory}
                  onSelectCategory={cat => setActiveCategory(cat)}
                  onSelectProduct={id => setSelectedProductId(id)}
                  comparedIds={comparedIds}
                  onToggleCompare={handleToggleCompare}
                  onOpenCompareModal={() => setIsCompareModalOpen(true)}
                />
              </div>
            </>
          )}
        </main>
      </div>

      {/* Footer */}
      <Footer />

      {/* Mobile Bottom Bar */}
      <MobileNav
        activeCategory={activeCategory}
        onSelectCategory={cat => {
          setIsCheckoutActive(false);
          setActiveCategory(cat);
        }}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenSearchModal={() => setIsSearchOpen(true)}
      />

      {/* Modals & Drawers */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProductId(null)}
        onToggleCompare={handleToggleCompare}
        isCompared={selectedProduct ? comparedIds.includes(selectedProduct.id) : false}
        onBuyNowCheckout={(product, quantity) => {
          addToCart(product, quantity);
          setSelectedProductId(null);
          setIsCheckoutActive(true);
        }}
      />

      {isCompareModalOpen && (
        <TechCompareModal
          comparedProducts={comparedProducts}
          onClose={() => setIsCompareModalOpen(false)}
          onRemoveFromCompare={id => setComparedIds(prev => prev.filter(p => p !== id))}
          onClearCompare={() => setComparedIds([])}
        />
      )}

      <CartDrawer onProceedToCheckout={() => setIsCheckoutActive(true)} />

      <AiConciergeDrawer
        isOpen={isAiConciergeOpen}
        onClose={() => setIsAiConciergeOpen(false)}
        products={products}
        onSelectProduct={id => setSelectedProductId(id)}
      />

      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        products={products}
        onSelectProduct={id => setSelectedProductId(id)}
      />

      <CustomerSupportDrawer isOpen={isSupportOpen} onClose={() => setIsSupportOpen(false)} />
    </div>
  );
}
