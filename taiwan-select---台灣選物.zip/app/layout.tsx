import type { Metadata } from 'next';
import './globals.css';
import { Providers } from '@/components/Providers';

export const metadata: Metadata = {
  title: 'TAIWAN SELECT — 台灣選物・世界視野',
  description: 'Next-Generation Taiwanese Ecommerce & Semiconductor-Era Industrial Technology Commerce Ecosystem',
  openGraph: {
    title: 'TAIWAN SELECT — 台灣選物・世界視野',
    description: 'Next-Generation Taiwanese Ecommerce Platform',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-TW" className="dark" style={{ colorScheme: 'dark' }}>
      <body className="bg-slate-950 text-slate-100 antialiased" suppressHydrationWarning>
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}
