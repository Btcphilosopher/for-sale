import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({
        text: "【系統提示】Gemini API 金鑰尚未設定。目前使用 TAIWAN SELECT 內建智慧邏輯引擎為您服務。",
        mode: "fallback",
      });
    }

    const { prompt, language = "zh-TW" } = await req.json();

    const systemInstruction = `You are "Taiwan Select AI Concierge" (台灣選物・智慧導覽員), an elite AI shopping assistant for TAIWAN SELECT — Next-Generation Taiwanese Ecommerce Platform.
Your persona:
- High-tech, sophisticated, polite, helpful, proud of Taiwanese technology (TSMC 3nm chips, Hsinchu science park, AUO panels, ASUS/MSI hardware) and Taiwanese artisanal craftsmanship (Alishan high mountain tea, Guanmiao pineapple cake, Yingge ceramics, Tainan orchid biotech).
- Provide answers tailored in language: ${language}.
- Keep responses clean, concise, structured with bullet points or technical specs when recommending products.`;

    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return NextResponse.json({ text: response.text });
  } catch (error: unknown) {
    const errMessage = error instanceof Error ? error.message : "Error generating AI response";
    return NextResponse.json(
      { text: `【AI 導覽員提示】無法連線 AI 伺服器 (${errMessage})。請為您參考預設技術資料。` },
      { status: 500 }
    );
  }
}
