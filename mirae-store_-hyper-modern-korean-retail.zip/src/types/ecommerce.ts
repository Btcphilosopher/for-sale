export interface Product {
  id: string;
  name: string;
  nameEn: string;
  brand: string;
  category: string; // e.g., 'fashion', 'beauty', 'tech', etc.
  categoryKr: string;
  subcategory?: string;
  price: number;
  originalPrice: number;
  discountRate: number; // e.g. 20 for 20%
  rating: number; // e.g. 4.9
  reviewCount: number;
  isNew?: boolean;
  isBest?: boolean;
  isTrending?: boolean;
  ranking?: number; // 1, 2, 3...
  rankingChange?: 'up' | 'down' | 'same' | 'new';
  rankingAmount?: number;
  image: string;
  galleryImages: string[];
  description: string;
  features: string[];
  options?: {
    name: string;
    values: string[];
  }[];
  specs?: Record<string, string>;
  stockStatus: 'in_stock' | 'low_stock' | 'out_of_stock';
  deliveryInfo: string;
  salesCount: number;
  tags?: string[];
}

export interface Category {
  id: string;
  name: string;
  nameEn: string;
  iconName: string;
  subcategories: string[];
}

export interface CartItem {
  id: string; // unique cart item id
  product: Product;
  quantity: number;
  selectedOptions?: Record<string, string>;
}

export interface Coupon {
  id: string;
  code: string;
  name: string;
  discountType: 'amount' | 'rate';
  discountValue: number; // 10000 or 15 (%)
  minSpend: number;
  expiryDate: string;
  isClaimed: boolean;
  description: string;
}

export interface OrderRecipient {
  name: string;
  phone: string;
  zipcode: string;
  address: string;
  addressDetail: string;
  deliveryMemo: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  date: string;
  items: CartItem[];
  subtotalAmount: number;
  discountAmount: number;
  shippingFee: number;
  totalAmount: number;
  paymentMethod: string;
  recipient: OrderRecipient;
  status: '결제완료' | '배송준비중' | '배송중' | '배송완료';
  trackingNumber?: string;
}

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  tier: 'VIP FUTURE' | 'BLACK' | 'SILVER' | 'WELCOME';
  points: number;
  claimedCouponIds: string[];
}

export interface Review {
  id: string;
  productId: string;
  userName: string;
  userTier: string;
  rating: number;
  date: string;
  content: string;
  optionsSelected?: string;
  helpfulCount: number;
  verifiedPurchase: boolean;
  images?: string[];
}
