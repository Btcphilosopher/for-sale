import React from 'react';
import { ECommerceProvider, useECommerce } from './context/ECommerceContext';
import { ToastNotification } from './components/ToastNotification';
import { TopUtilityBar } from './components/TopUtilityBar';
import { MainHeader } from './components/MainHeader';
import { MegaMenuModal } from './components/MegaMenuModal';
import { CategoryNavigation } from './components/CategoryNavigation';
import { HeroCarousel } from './components/HeroCarousel';
import { CategoryStrip } from './components/CategoryStrip';
import { TodaysDiscovery } from './components/TodaysDiscovery';
import { CouponBanner } from './components/CouponBanner';
import { TrendingProducts } from './components/TrendingProducts';
import { SearchOverlay } from './components/SearchOverlay';
import { FloatingRail } from './components/FloatingRail';
import { RecentlyViewedDrawer } from './components/RecentlyViewedDrawer';
import { ProductDetail } from './components/ProductDetail';
import { CartView } from './components/CartView';
import { CheckoutView } from './components/CheckoutView';
import { OrderCompleteView } from './components/OrderCompleteView';
import { MyPageView } from './components/MyPageView';
import { CategoryView } from './components/CategoryView';
import { MobileBottomNav } from './components/MobileBottomNav';
import { Footer } from './components/Footer';

const MainAppContent: React.FC = () => {
  const { currentView } = useECommerce();

  return (
    <div className="min-h-screen flex flex-col bg-[#09090b] text-zinc-100 font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* Toast Notifications */}
      <ToastNotification />

      {/* Modals & Overlays */}
      <MegaMenuModal />
      <SearchOverlay />
      <RecentlyViewedDrawer />

      {/* Top Header Utilities */}
      <TopUtilityBar />
      <MainHeader />
      <CategoryNavigation />

      {/* Dynamic View Content */}
      <main className="flex-1">
        {currentView === 'home' && (
          <div className="space-y-6">
            <HeroCarousel />
            <CategoryStrip />
            <TodaysDiscovery />
            <CouponBanner />
            <TrendingProducts />
          </div>
        )}

        {currentView === 'product_detail' && <ProductDetail />}
        {(currentView === 'category' || currentView === 'search_results') && <CategoryView />}
        {currentView === 'cart' && <CartView />}
        {currentView === 'checkout' && <CheckoutView />}
        {currentView === 'order_complete' && <OrderCompleteView />}
        {currentView === 'mypage' && <MyPageView />}
      </main>

      {/* Floating Utilities Rail */}
      <FloatingRail />

      {/* Mobile Navigation */}
      <MobileBottomNav />

      {/* Footer */}
      <Footer />

    </div>
  );
};

export default function App() {
  return (
    <ECommerceProvider>
      <MainAppContent />
    </ECommerceProvider>
  );
}
