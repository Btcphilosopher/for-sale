import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, Coupon, Order, UserProfile } from '../types/ecommerce';
import { PRODUCTS, INITIAL_COUPONS } from '../data/mockData';

export type ViewType = 
  | 'home' 
  | 'product_detail' 
  | 'category' 
  | 'cart' 
  | 'checkout' 
  | 'order_complete' 
  | 'mypage' 
  | 'search_results';

export interface Toast {
  id: string;
  message: string;
  type?: 'success' | 'info' | 'warning';
}

interface ECommerceContextType {
  // Navigation
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  selectedProductId: string | null;
  openProductDetail: (productId: string) => void;
  selectedCategoryId: string | null;
  setSelectedCategoryId: (catId: string | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  performSearch: (query: string) => void;

  // UI Modals / Drawers
  isMegaMenuOpen: boolean;
  setIsMegaMenuOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isRecentlyViewedOpen: boolean;
  setIsRecentlyViewedOpen: (open: boolean) => void;

  // Products Data
  products: Product[];
  filteredProducts: Product[];

  // Cart State
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, selectedOptions?: Record<string, string>) => void;
  removeFromCart: (cartItemId: string) => void;
  updateCartQuantity: (cartItemId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotalCount: number;
  cartSubtotalPrice: number;
  
  // Wishlist State
  wishlistIds: string[];
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;

  // Recently Viewed State
  recentlyViewedIds: string[];
  addRecentlyViewed: (productId: string) => void;
  clearRecentlyViewed: () => void;

  // Coupons
  coupons: Coupon[];
  claimCoupon: (couponId: string) => void;
  activeCoupon: Coupon | null;
  setActiveCoupon: (coupon: Coupon | null) => void;

  // User Profile
  userProfile: UserProfile;
  
  // Orders
  orders: Order[];
  createOrder: (orderData: Omit<Order, 'id' | 'orderNumber' | 'date' | 'status'>) => Order;
  lastCompletedOrder: Order | null;

  // Toasts
  toasts: Toast[];
  addToast: (message: string, type?: 'success' | 'info' | 'warning') => void;
  removeToast: (id: string) => void;
}

const ECommerceContext = createContext<ECommerceContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY_CART = 'mirae_store_cart_v1';
const LOCAL_STORAGE_KEY_WISHLIST = 'mirae_store_wishlist_v1';
const LOCAL_STORAGE_KEY_RECENT = 'mirae_store_recent_v1';
const LOCAL_STORAGE_KEY_COUPONS = 'mirae_store_coupons_v1';
const LOCAL_STORAGE_KEY_ORDERS = 'mirae_store_orders_v1';

export const ECommerceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isRecentlyViewedOpen, setIsRecentlyViewedOpen] = useState(false);

  const [products] = useState<Product[]>(PRODUCTS);
  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_COUPONS);
      return saved ? JSON.parse(saved) : INITIAL_COUPONS;
    } catch {
      return INITIAL_COUPONS;
    }
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_CART);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_WISHLIST);
      return saved ? JSON.parse(saved) : ['prod-001', 'prod-004'];
    } catch {
      return ['prod-001', 'prod-004'];
    }
  });

  const [recentlyViewedIds, setRecentlyViewedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_RECENT);
      return saved ? JSON.parse(saved) : ['prod-001', 'prod-002', 'prod-003'];
    } catch {
      return ['prod-001', 'prod-002', 'prod-003'];
    }
  });

  const [activeCoupon, setActiveCoupon] = useState<Coupon | null>(null);

  const [userProfile] = useState<UserProfile>({
    name: '김미래',
    email: 'mirae.kim@miraestore.kr',
    phone: '010-8888-2026',
    tier: 'VIP FUTURE',
    points: 15200,
    claimedCouponIds: ['coup-001'],
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_ORDERS);
      if (saved) return JSON.parse(saved);
      // Sample default order for MyPage display
      return [
        {
          id: 'ord-sample-1',
          orderNumber: 'M20260828-8841',
          date: '2026.08.26',
          items: [
            {
              id: 'item-1',
              product: PRODUCTS[0],
              quantity: 1,
              selectedOptions: { '스트랩 컬러': '티타늄 실버', '케이스 사이즈': '45mm' },
            },
          ],
          subtotalAmount: 248000,
          discountAmount: 10000,
          shippingFee: 0,
          totalAmount: 238000,
          paymentMethod: '카카오페이',
          recipient: {
            name: '김미래',
            phone: '010-8888-2026',
            zipcode: '06132',
            address: '서울특별시 강남구 테헤란로 152 (역삼동)',
            addressDetail: '강남파이낸스센터 18층',
            deliveryMemo: '부재 시 문 앞에 놓아주세요.',
          },
          status: '배송중',
          trackingNumber: 'KR-9482710492',
        },
      ];
    } catch {
      return [];
    }
  });

  const [lastCompletedOrder, setLastCompletedOrder] = useState<Order | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Sync state to local storage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_CART, JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_WISHLIST, JSON.stringify(wishlistIds));
    } catch (e) {
      console.error(e);
    }
  }, [wishlistIds]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_RECENT, JSON.stringify(recentlyViewedIds));
    } catch (e) {
      console.error(e);
    }
  }, [recentlyViewedIds]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_COUPONS, JSON.stringify(coupons));
    } catch (e) {
      console.error(e);
    }
  }, [coupons]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_ORDERS, JSON.stringify(orders));
    } catch (e) {
      console.error(e);
    }
  }, [orders]);

  const addToast = (message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 5);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 3200);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const openProductDetail = (productId: string) => {
    setSelectedProductId(productId);
    addRecentlyViewed(productId);
    setCurrentView('product_detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const performSearch = (query: string) => {
    setSearchQuery(query);
    setIsSearchOpen(false);
    setCurrentView('search_results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const addToCart = (product: Product, quantity = 1, selectedOptions: Record<string, string> = {}) => {
    setCart((prevCart) => {
      const optionKey = JSON.stringify(selectedOptions);
      const existingIndex = prevCart.findIndex(
        (item) => item.product.id === product.id && JSON.stringify(item.selectedOptions) === optionKey
      );

      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += quantity;
        return updated;
      } else {
        const newCartItem: CartItem = {
          id: `${product.id}-${Date.now()}`,
          product,
          quantity,
          selectedOptions,
        };
        return [...prevCart, newCartItem];
      }
    });
    addToast(`${product.name}이(가) 장바구니에 추가되었습니다.`);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== cartItemId));
    addToast('선택한 상품을 장바구니에서 삭제하였습니다.', 'info');
  };

  const updateCartQuantity = (cartItemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.id === cartItemId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    setWishlistIds((prev) => {
      const exists = prev.includes(productId);
      const targetProd = products.find((p) => p.id === productId);
      if (exists) {
        addToast(`${targetProd?.name || '상품'}을(를) 찜 목록에서 제외했습니다.`, 'info');
        return prev.filter((id) => id !== productId);
      } else {
        addToast(`${targetProd?.name || '상품'}을(를) 찜 목록에 담았습니다. ♡`);
        return [productId, ...prev];
      }
    });
  };

  const isWishlisted = (productId: string) => wishlistIds.includes(productId);

  const addRecentlyViewed = (productId: string) => {
    setRecentlyViewedIds((prev) => {
      const filtered = prev.filter((id) => id !== productId);
      return [productId, ...filtered].slice(0, 15);
    });
  };

  const clearRecentlyViewed = () => {
    setRecentlyViewedIds([]);
    addToast('최근 본 상품 기록을 삭제하였습니다.', 'info');
  };

  const claimCoupon = (couponId: string) => {
    setCoupons((prev) =>
      prev.map((c) => (c.id === couponId ? { ...c, isClaimed: true } : c))
    );
    const coup = coupons.find((c) => c.id === couponId);
    if (coup) {
      addToast(`쿠폰 [${coup.name}]이(가) 정상적으로 발급되었습니다!`);
    }
  };

  const cartTotalCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const cartSubtotalPrice = cart.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  const filteredProducts = products.filter((product) => {
    if (selectedCategoryId) {
      if (product.category !== selectedCategoryId) return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchName = product.name.toLowerCase().includes(q);
      const matchBrand = product.brand.toLowerCase().includes(q);
      const matchCat = product.categoryKr.toLowerCase().includes(q);
      const matchTag = product.tags?.some((t) => t.toLowerCase().includes(q));
      if (!matchName && !matchBrand && !matchCat && !matchTag) return false;
    }
    return true;
  });

  const createOrder = (orderData: Omit<Order, 'id' | 'orderNumber' | 'date' | 'status'>): Order => {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now()}`,
      orderNumber: `M${dateStr}-${randomSuffix}`,
      date: new Date().toLocaleDateString('ko-KR'),
      status: '결제완료',
      trackingNumber: `KR-${Math.floor(1000000000 + Math.random() * 9000000000)}`,
    };

    setOrders((prev) => [newOrder, ...prev]);
    setLastCompletedOrder(newOrder);
    clearCart();
    setActiveCoupon(null);
    setCurrentView('order_complete');
    addToast('주문 및 결제가 성공적으로 completed 처리되었습니다!');
    return newOrder;
  };

  return (
    <ECommerceContext.Provider
      value={{
        currentView,
        setCurrentView,
        selectedProductId,
        openProductDetail,
        selectedCategoryId,
        setSelectedCategoryId,
        searchQuery,
        setSearchQuery,
        performSearch,
        isMegaMenuOpen,
        setIsMegaMenuOpen,
        isSearchOpen,
        setIsSearchOpen,
        isRecentlyViewedOpen,
        setIsRecentlyViewedOpen,
        products,
        filteredProducts,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartTotalCount,
        cartSubtotalPrice,
        wishlistIds,
        toggleWishlist,
        isWishlisted,
        recentlyViewedIds,
        addRecentlyViewed,
        clearRecentlyViewed,
        coupons,
        claimCoupon,
        activeCoupon,
        setActiveCoupon,
        userProfile,
        orders,
        createOrder,
        lastCompletedOrder,
        toasts,
        addToast,
        removeToast,
      }}
    >
      {children}
    </ECommerceContext.Provider>
  );
};

export const useECommerce = () => {
  const context = useContext(ECommerceContext);
  if (!context) {
    throw new Error('useECommerce must be used within an ECommerceProvider');
  }
  return context;
};
