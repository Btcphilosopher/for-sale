import React, { useState } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { SAMPLE_REVIEWS } from '../data/mockData';
import {
  Star,
  Heart,
  ShoppingBag,
  Truck,
  ShieldCheck,
  RotateCcw,
  Share2,
  ChevronRight,
  Check,
  MessageSquare,
  ThumbsUp,
  Plus,
  Minus,
} from 'lucide-react';

export const ProductDetail: React.FC = () => {
  const {
    selectedProductId,
    products,
    addToCart,
    toggleWishlist,
    isWishlisted,
    setCurrentView,
    addToast,
  } = useECommerce();

  const product = products.find((p) => p.id === selectedProductId) || products[0];
  const wishlisted = isWishlisted(product.id);

  const [activeImage, setActiveImage] = useState<string>(product.image);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    if (product.options) {
      product.options.forEach((opt) => {
        initial[opt.name] = opt.values[0];
      });
    }
    return initial;
  });

  const [quantity, setQuantity] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<'info' | 'reviews' | 'qna' | 'shipping'>('info');
  const [newReviewText, setNewReviewText] = useState('');
  const [reviewsList, setReviewsList] = useState(SAMPLE_REVIEWS);

  const handleOptionChange = (optionName: string, val: string) => {
    setSelectedOptions((prev) => ({ ...prev, [optionName]: val }));
  };

  const handleAddToCart = () => {
    addToCart(product, quantity, selectedOptions);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity, selectedOptions);
    setCurrentView('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewText.trim()) return;

    const newRev = {
      id: `rev-${Date.now()}`,
      productId: product.id,
      userName: '김미래 (나)',
      userTier: 'VIP FUTURE',
      rating: 5,
      date: new Date().toLocaleDateString('ko-KR'),
      content: newReviewText,
      optionsSelected: Object.entries(selectedOptions).map(([k, v]) => `${k}: ${v}`).join(' / '),
      helpfulCount: 0,
      verifiedPurchase: true,
    };

    setReviewsList((prev) => [newRev, ...prev]);
    setNewReviewText('');
    addToast('리뷰가 등록되었습니다. 포인트 500P가 적립되었습니다!');
  };

  const formatPrice = (p: number) => p.toLocaleString('ko-KR') + '원';

  return (
    <div className="w-full max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-12 animate-in fade-in duration-300">
      
      {/* Breadcrumb Navigation */}
      <div className="flex items-center gap-2 text-xs text-zinc-400 font-mono">
        <button onClick={() => setCurrentView('home')} className="hover:text-white">홈</button>
        <ChevronRight className="w-3 h-3" />
        <button onClick={() => setCurrentView('category')} className="hover:text-white">{product.categoryKr}</button>
        <ChevronRight className="w-3 h-3" />
        <span className="text-zinc-200 font-semibold truncate max-w-xs">{product.name}</span>
      </div>

      {/* Product Top Detail Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
        
        {/* Left: Gallery (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="relative aspect-square w-full rounded-3xl overflow-hidden bg-zinc-950 border border-zinc-800 shadow-2xl group">
            <img
              src={activeImage}
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            {product.discountRate > 0 && (
              <span className="absolute top-4 left-4 px-3 py-1 rounded-xl bg-rose-600 text-white font-mono font-extrabold text-sm shadow-lg">
                {product.discountRate}% OFF
              </span>
            )}
          </div>

          {/* Gallery Thumbnails */}
          <div className="flex items-center gap-3 overflow-x-auto no-scrollbar">
            {product.galleryImages.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActiveImage(img)}
                className={`w-20 h-20 rounded-2xl overflow-hidden border-2 transition-all shrink-0 bg-zinc-950 ${
                  activeImage === img ? 'border-indigo-500 scale-105 shadow-lg' : 'border-zinc-800 opacity-60 hover:opacity-100'
                }`}
              >
                <img src={img} alt="갤러리" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Right: Purchase Specs (5 Cols) */}
        <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
          <div>
            
            {/* Brand & Rating Header */}
            <div className="flex items-center justify-between text-xs font-mono mb-2">
              <span className="text-indigo-400 font-bold tracking-widest uppercase">{product.brand}</span>
              <div className="flex items-center gap-1.5 text-zinc-300">
                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span className="font-bold">{product.rating}</span>
                <span className="text-zinc-500">({product.reviewCount}개 리뷰)</span>
              </div>
            </div>

            {/* Product Title */}
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-snug">
              {product.name}
            </h1>

            {/* Price Box */}
            <div className="mt-4 p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 space-y-1">
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-black text-white font-mono">
                  {formatPrice(product.price)}
                </span>
                {product.discountRate > 0 && (
                  <span className="text-base text-zinc-500 line-through font-mono">
                    {formatPrice(product.originalPrice)}
                  </span>
                )}
              </div>
              <p className="text-xs text-indigo-400 font-medium">
                VIP 미래 회원가: <span className="font-bold">{formatPrice(Math.round(product.price * 0.95))}</span> (추가 5% 자동적립)
              </p>
            </div>

            {/* Shipping & Delivery Badge */}
            <div className="mt-4 p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800 space-y-2 text-xs text-zinc-300">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>배송 정보: <strong className="text-emerald-400">{product.deliveryInfo}</strong></span>
              </div>
              <div className="flex items-center gap-2 text-zinc-400">
                <ShieldCheck className="w-4 h-4 text-purple-400 shrink-0" />
                <span>미래상점 100% 정품 보장 & 2년 무상 A/S</span>
              </div>
            </div>

            {/* Options Selection */}
            {product.options && product.options.length > 0 && (
              <div className="mt-6 space-y-4">
                {product.options.map((option) => (
                  <div key={option.name} className="space-y-2">
                    <label className="text-xs font-bold text-zinc-300 font-mono block">
                      {option.name} 선택
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {option.values.map((val) => {
                        const isSelected = selectedOptions[option.name] === val;
                        return (
                          <button
                            key={val}
                            onClick={() => handleOptionChange(option.name, val)}
                            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all border ${
                              isSelected
                                ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/20'
                                : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                            }`}
                          >
                            {val}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Quantity Selector */}
            <div className="mt-6 space-y-2">
              <label className="text-xs font-bold text-zinc-300 font-mono block">수량</label>
              <div className="flex items-center gap-3">
                <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-xl p-1">
                  <button
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-12 text-center text-sm font-bold font-mono text-white">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity((q) => q + 1)}
                    className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <span className="text-xs text-zinc-400">
                  총 금액: <strong className="text-white text-base font-mono">{formatPrice(product.price * quantity)}</strong>
                </span>
              </div>
            </div>

          </div>

          {/* Action Buttons */}
          <div className="pt-6 space-y-3 border-t border-zinc-800">
            <div className="grid grid-cols-12 gap-3">
              <button
                onClick={() => toggleWishlist(product.id)}
                className={`col-span-2 p-3.5 rounded-2xl border flex items-center justify-center transition-all ${
                  wishlisted
                    ? 'bg-rose-500/20 border-rose-500 text-rose-500'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                }`}
                title="찜하기"
              >
                <Heart className={`w-5 h-5 ${wishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
              </button>

              <button
                onClick={handleAddToCart}
                className="col-span-5 py-3.5 rounded-2xl bg-zinc-900 border border-zinc-700 hover:border-indigo-500 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-lg"
              >
                <ShoppingBag className="w-4 h-4 text-indigo-400" />
                <span>장바구니</span>
              </button>

              <button
                onClick={handleBuyNow}
                className="col-span-5 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm transition-all shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-1"
              >
                <span>바로 구매</span>
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* Tabs Section: 상품정보 / 리뷰 / 상품문의 / 배송교환 */}
      <div className="pt-8">
        
        {/* Tabs Bar */}
        <div className="flex border-b border-zinc-800 font-bold text-sm">
          <button
            onClick={() => setActiveTab('info')}
            className={`pb-4 px-6 border-b-2 transition-all ${
              activeTab === 'info'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            상품정보
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`pb-4 px-6 border-b-2 transition-all ${
              activeTab === 'reviews'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            리뷰 ({reviewsList.length})
          </button>
          <button
            onClick={() => setActiveTab('qna')}
            className={`pb-4 px-6 border-b-2 transition-all ${
              activeTab === 'qna'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            상품문의 (2)
          </button>
          <button
            onClick={() => setActiveTab('shipping')}
            className={`pb-4 px-6 border-b-2 transition-all ${
              activeTab === 'shipping'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            배송/교환/반품
          </button>
        </div>

        {/* Tab Content Panels */}
        <div className="py-8">
          
          {/* 상품정보 */}
          {activeTab === 'info' && (
            <div className="space-y-8 max-w-4xl">
              <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4">
                <h3 className="text-lg font-bold text-white">상품 핵심 포인트</h3>
                <p className="text-zinc-300 leading-relaxed text-sm">{product.description}</p>
                <ul className="space-y-2 text-xs text-zinc-300">
                  {product.features.map((feat, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-indigo-400" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Specs Table */}
              {product.specs && (
                <div className="space-y-3">
                  <h3 className="text-base font-bold text-white font-mono">제품 상세 스펙</h3>
                  <div className="border border-zinc-800 rounded-2xl overflow-hidden text-xs">
                    {Object.entries(product.specs).map(([key, val], idx) => (
                      <div
                        key={key}
                        className={`grid grid-cols-3 p-3.5 ${
                          idx % 2 === 0 ? 'bg-zinc-900/80' : 'bg-zinc-950'
                        } border-b border-zinc-800/60 last:border-0`}
                      >
                        <span className="font-bold text-zinc-400">{key}</span>
                        <span className="col-span-2 text-zinc-200">{val}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 리뷰 */}
          {activeTab === 'reviews' && (
            <div className="space-y-8 max-w-4xl">
              
              {/* Write Review Input */}
              <form onSubmit={handleAddReview} className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-3">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-indigo-400" />
                  <span>구매 후기 작성하기</span>
                </h4>
                <textarea
                  value={newReviewText}
                  onChange={(e) => setNewReviewText(e.target.value)}
                  placeholder="실제 사용 후기를 작성해 주세요. 작성 시 500P 적립금을 드립니다."
                  rows={3}
                  className="w-full p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-500 transition-colors"
                >
                  리뷰 등록 (500P 적립)
                </button>
              </form>

              {/* Review List */}
              <div className="space-y-4">
                {reviewsList.map((rev) => (
                  <div key={rev.id} className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{rev.userName}</span>
                        <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px] font-mono">
                          {rev.userTier}
                        </span>
                      </div>
                      <span className="text-zinc-500 font-mono">{rev.date}</span>
                    </div>

                    <div className="flex items-center gap-1 text-amber-400">
                      {Array.from({ length: rev.rating }).map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                      ))}
                    </div>

                    {rev.optionsSelected && (
                      <p className="text-[11px] text-zinc-500 font-mono">선택옵션: {rev.optionsSelected}</p>
                    )}

                    <p className="text-xs text-zinc-200 leading-relaxed pt-1">{rev.content}</p>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* Q&A */}
          {activeTab === 'qna' && (
            <div className="p-8 rounded-2xl bg-zinc-900/60 border border-zinc-800 max-w-4xl text-xs space-y-4">
              <h3 className="text-base font-bold text-white">상품 Q&A 문의</h3>
              <p className="text-zinc-400">배송, 사이즈, 스펙 등 궁금한 점을 문의해주시면 미래상점 전담 매니저가 신속하게 답변해드립니다.</p>
              <button onClick={() => addToast('1:1 문의하기 창이 열렸습니다.', 'info')} className="px-4 py-2 bg-indigo-600 text-white rounded-xl font-bold">
                문의하기 작성
              </button>
            </div>
          )}

          {/* 배송/교환 */}
          {activeTab === 'shipping' && (
            <div className="p-8 rounded-2xl bg-zinc-900/60 border border-zinc-800 max-w-4xl text-xs text-zinc-300 space-y-4">
              <h3 className="text-base font-bold text-white">배송 / 교환 / 반품 안내</h3>
              <ul className="space-y-2 list-disc list-inside text-zinc-400">
                <li>배송기간: 결제 완료 후 1~2일 이내 수령 (서울/수도권 당일 및 내일 도착 보장)</li>
                <li>배송비: 50,000원 이상 구매 시 무료배송</li>
                <li>교환/반품 기간: 상품 수령 후 7일 이내 신청 가능</li>
              </ul>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
