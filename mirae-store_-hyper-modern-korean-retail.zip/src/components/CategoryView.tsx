import React, { useState } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { CATEGORIES } from '../data/mockData';
import { ProductCard } from './ProductCard';
import { Filter, SlidersHorizontal, Grid } from 'lucide-react';

export const CategoryView: React.FC = () => {
  const {
    selectedCategoryId,
    setSelectedCategoryId,
    filteredProducts,
    searchQuery,
  } = useECommerce();

  const [sortBy, setSortBy] = useState<'recommended' | 'newest' | 'price_asc' | 'price_desc' | 'rating'>('recommended');

  const activeCategory = CATEGORIES.find((c) => c.id === selectedCategoryId);

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'newest') return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
    if (sortBy === 'price_asc') return a.price - b.price;
    if (sortBy === 'price_desc') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    return (b.salesCount || 0) - (a.salesCount || 0);
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-6 animate-in fade-in duration-300">
      
      {/* Category Header */}
      <div className="p-6 md:p-8 rounded-3xl bg-zinc-900/80 border border-zinc-800 space-y-2">
        <h1 className="text-2xl md:text-3xl font-black text-white font-mono tracking-tight">
          {searchQuery ? `"${searchQuery}" 검색 결과` : activeCategory ? activeCategory.name : '전체 상품'}
        </h1>
        <p className="text-xs text-zinc-400 font-mono uppercase">
          {activeCategory ? activeCategory.nameEn : 'ALL PRODUCTS'} ({sortedProducts.length} ITEMS)
        </p>

        {/* Subcategories Filter Chips */}
        {activeCategory && activeCategory.subcategories && (
          <div className="flex flex-wrap gap-2 pt-4 border-t border-zinc-800/80">
            {activeCategory.subcategories.map((sub, i) => (
              <span
                key={i}
                className="px-3 py-1 rounded-full bg-zinc-950 border border-zinc-800 text-xs text-zinc-300 font-medium hover:border-indigo-500/40 cursor-pointer"
              >
                {sub}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Filter & Sort Control Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-zinc-800/80 text-xs font-semibold text-zinc-400">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-indigo-400" />
          <span>총 {sortedProducts.length}개의 상품</span>
        </div>

        {/* Sort Select */}
        <div className="flex items-center gap-2">
          <span className="hidden sm:inline">정렬:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs focus:outline-none focus:border-indigo-500"
          >
            <option value="recommended">추천순 (인기)</option>
            <option value="newest">신상품순</option>
            <option value="price_asc">낮은 가격순</option>
            <option value="price_desc">높은 가격순</option>
            <option value="rating">평점 높은순</option>
          </select>
        </div>
      </div>

      {/* Products Grid */}
      {sortedProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {sortedProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-24 space-y-3 bg-zinc-900/30 rounded-3xl border border-zinc-800">
          <Grid className="w-12 h-12 mx-auto text-zinc-600 stroke-1" />
          <p className="text-base font-bold text-white">조건에 부합하는 상품이 없습니다.</p>
          <p className="text-xs text-zinc-400">다른 검색어를 입력하시거나 카테고리를 변경해 보세요.</p>
          <button
            onClick={() => setSelectedCategoryId(null)}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-bold text-xs"
          >
            전체 상품 보기
          </button>
        </div>
      )}

    </div>
  );
};
