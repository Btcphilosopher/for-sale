import React, { useState, useEffect } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { Menu, Search, ShoppingBag, User, Heart } from 'lucide-react';

export const MainHeader: React.FC = () => {
  const {
    setCurrentView,
    setSelectedCategoryId,
    setSearchQuery,
    searchQuery,
    setIsMegaMenuOpen,
    setIsSearchOpen,
    cartTotalCount,
    wishlistIds,
  } = useECommerce();

  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleBrandClick = () => {
    setSelectedCategoryId(null);
    setSearchQuery('');
    setCurrentView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavClick = (navType: string) => {
    if (navType === '베스트') {
      setSelectedCategoryId(null);
      setSearchQuery('베스트');
      setCurrentView('search_results');
    } else if (navType === '신상품') {
      setSelectedCategoryId(null);
      setSearchQuery('신상');
      setCurrentView('search_results');
    } else if (navType === '랭킹') {
      setSelectedCategoryId(null);
      setSearchQuery('랭킹');
      setCurrentView('search_results');
    } else {
      setSelectedCategoryId(null);
      setSearchQuery(navType);
      setCurrentView('search_results');
    }
  };

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 border-b ${
        isScrolled
          ? 'bg-zinc-950/90 backdrop-blur-md border-zinc-800 shadow-2xl py-3'
          : 'bg-zinc-950/70 backdrop-blur-sm border-zinc-900 py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-between gap-4 md:gap-8">
        
        {/* Left Area: Hamburger + Brand */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setIsMegaMenuOpen(true)}
            className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:border-zinc-700 transition-all group"
            aria-label="전체 카테고리 메뉴"
          >
            <Menu className="w-5 h-5 group-hover:scale-110 transition-transform" />
          </button>

          {/* Logo */}
          <button
            onClick={handleBrandClick}
            className="flex flex-col items-start text-left focus:outline-none group"
          >
            <div className="flex items-center gap-1.5">
              <span className="text-xl md:text-2xl font-black tracking-tight text-white font-mono bg-gradient-to-r from-white via-zinc-200 to-indigo-400 bg-clip-text text-transparent">
                미래상점
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
            </div>
            <span className="text-[10px] tracking-widest text-zinc-500 font-semibold font-mono uppercase group-hover:text-indigo-400 transition-colors">
              MIRAE STORE
            </span>
          </button>
        </div>

        {/* Center Area: Search Bar */}
        <div className="flex-1 max-w-xl mx-2 hidden sm:block">
          <div
            onClick={() => setIsSearchOpen(true)}
            className="relative cursor-pointer group"
          >
            <input
              type="text"
              readOnly
              value={searchQuery}
              placeholder="찾고 싶은 상품을 검색해보세요"
              className="w-full bg-zinc-900/90 hover:bg-zinc-900 border border-zinc-800 group-hover:border-indigo-500/50 rounded-2xl py-2.5 pl-4 pr-12 text-sm text-zinc-100 placeholder-zinc-500 cursor-pointer focus:outline-none transition-all shadow-inner"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-xl bg-indigo-600/90 text-white group-hover:bg-indigo-500 transition-colors">
              <Search className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* Right Area: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-semibold text-zinc-300">
          <button
            onClick={() => handleNavClick('베스트')}
            className="hover:text-indigo-400 transition-colors relative py-1 hover:after:content-[''] hover:after:absolute hover:after:bottom-0 hover:after:left-0 hover:after:w-full hover:after:h-0.5 hover:after:bg-indigo-500"
          >
            베스트
          </button>
          <button
            onClick={() => handleNavClick('신상품')}
            className="hover:text-indigo-400 transition-colors relative py-1 hover:after:content-[''] hover:after:absolute hover:after:bottom-0 hover:after:left-0 hover:after:w-full hover:after:h-0.5 hover:after:bg-indigo-500"
          >
            신상품
          </button>
          <button
            onClick={() => handleNavClick('랭킹')}
            className="hover:text-indigo-400 transition-colors relative py-1 hover:after:content-[''] hover:after:absolute hover:after:bottom-0 hover:after:left-0 hover:after:w-full hover:after:h-0.5 hover:after:bg-indigo-500"
          >
            랭킹
          </button>
          <button
            onClick={() => handleNavClick('브랜드')}
            className="hover:text-indigo-400 transition-colors relative py-1 hover:after:content-[''] hover:after:absolute hover:after:bottom-0 hover:after:left-0 hover:after:w-full hover:after:h-0.5 hover:after:bg-indigo-500"
          >
            브랜드
          </button>
          <button
            onClick={() => handleNavClick('기획전')}
            className="hover:text-indigo-400 transition-colors relative py-1 hover:after:content-[''] hover:after:absolute hover:after:bottom-0 hover:after:left-0 hover:after:w-full hover:after:h-0.5 hover:after:bg-indigo-500"
          >
            기획전
          </button>
        </nav>

        {/* Mobile quick action buttons */}
        <div className="flex sm:hidden items-center gap-2">
          <button
            onClick={() => setIsSearchOpen(true)}
            className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300"
          >
            <Search className="w-5 h-5" />
          </button>
          <button
            onClick={() => setCurrentView('cart')}
            className="relative p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300"
          >
            <ShoppingBag className="w-5 h-5 text-indigo-400" />
            {cartTotalCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-indigo-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {cartTotalCount}
              </span>
            )}
          </button>
        </div>

      </div>
    </header>
  );
};
