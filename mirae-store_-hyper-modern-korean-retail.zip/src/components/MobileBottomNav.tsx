import React from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { Home, Grid, Search, Heart, User, ShoppingBag } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    setIsMegaMenuOpen,
    setIsSearchOpen,
    setSelectedCategoryId,
    setSearchQuery,
    wishlistIds,
  } = useECommerce();

  const handleHome = () => {
    setSelectedCategoryId(null);
    setSearchQuery('');
    setCurrentView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-zinc-950/95 border-t border-zinc-800/80 backdrop-blur-lg px-4 py-2">
      <div className="grid grid-cols-5 text-center text-[10px] font-semibold text-zinc-400">
        
        {/* 홈 */}
        <button
          onClick={handleHome}
          className={`flex flex-col items-center gap-1 py-1 transition-colors ${
            currentView === 'home' ? 'text-indigo-400' : 'hover:text-white'
          }`}
        >
          <Home className="w-5 h-5" />
          <span>홈</span>
        </button>

        {/* 카테고리 */}
        <button
          onClick={() => setIsMegaMenuOpen(true)}
          className="flex flex-col items-center gap-1 py-1 hover:text-white transition-colors"
        >
          <Grid className="w-5 h-5" />
          <span>카테고리</span>
        </button>

        {/* 검색 */}
        <button
          onClick={() => setIsSearchOpen(true)}
          className="flex flex-col items-center gap-1 py-1 hover:text-white transition-colors"
        >
          <Search className="w-5 h-5" />
          <span>검색</span>
        </button>

        {/* 찜 */}
        <button
          onClick={() => {
            setCurrentView('mypage');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="relative flex flex-col items-center gap-1 py-1 hover:text-white transition-colors"
        >
          <Heart className="w-5 h-5" />
          {wishlistIds.length > 0 && (
            <span className="absolute top-0 right-4 bg-rose-500 text-white text-[9px] font-bold rounded-full w-3.5 h-3.5 flex items-center justify-center">
              {wishlistIds.length}
            </span>
          )}
          <span>찜</span>
        </button>

        {/* 마이 */}
        <button
          onClick={() => {
            setCurrentView('mypage');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center gap-1 py-1 transition-colors ${
            currentView === 'mypage' ? 'text-indigo-400' : 'hover:text-white'
          }`}
        >
          <User className="w-5 h-5" />
          <span>마이</span>
        </button>

      </div>
    </div>
  );
};
