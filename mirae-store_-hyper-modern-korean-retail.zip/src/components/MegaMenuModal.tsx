import React, { useState } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { CATEGORIES } from '../data/mockData';
import {
  X,
  Shirt,
  Sparkles,
  Smartphone,
  Home,
  Utensils,
  Activity,
  Car,
  BookOpen,
  Smile,
  HeartHandshake,
  ChevronRight,
  Grid,
} from 'lucide-react';

export const MegaMenuModal: React.FC = () => {
  const { isMegaMenuOpen, setIsMegaMenuOpen, setSelectedCategoryId, setCurrentView } = useECommerce();
  const [activeTabId, setActiveTabId] = useState<string>(CATEGORIES[0].id);

  if (!isMegaMenuOpen) return null;

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Shirt': return <Shirt className="w-5 h-5" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5" />;
      case 'Smartphone': return <Smartphone className="w-5 h-5" />;
      case 'Home': return <Home className="w-5 h-5" />;
      case 'Utensils': return <Utensils className="w-5 h-5" />;
      case 'Activity': return <Activity className="w-5 h-5" />;
      case 'Car': return <Car className="w-5 h-5" />;
      case 'BookOpen': return <BookOpen className="w-5 h-5" />;
      case 'Smile': return <Smile className="w-5 h-5" />;
      case 'HeartHandshake': return <HeartHandshake className="w-5 h-5" />;
      default: return <Grid className="w-5 h-5" />;
    }
  };

  const handleCategorySelect = (catId: string) => {
    setSelectedCategoryId(catId);
    setIsMegaMenuOpen(false);
    setCurrentView('category');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeCatObj = CATEGORIES.find((c) => c.id === activeTabId) || CATEGORIES[0];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/80 backdrop-blur-md animate-in fade-in duration-200 pt-16 md:pt-20 px-4">
      <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl w-full max-w-5xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800/80 bg-zinc-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Grid className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">전체 카테고리</h2>
              <p className="text-xs text-zinc-400 font-mono uppercase">ALL CATEGORIES</p>
            </div>
          </div>
          <button
            onClick={() => setIsMegaMenuOpen(false)}
            className="p-2 rounded-xl bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Grid */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          
          {/* Category List Sidebar (Left 5 Cols) */}
          <div className="md:col-span-5 border-r border-zinc-800/80 overflow-y-auto p-3 space-y-1 bg-zinc-950">
            {CATEGORIES.map((cat) => {
              const isActive = cat.id === activeTabId;
              return (
                <button
                  key={cat.id}
                  onMouseEnter={() => setActiveTabId(cat.id)}
                  onClick={() => handleCategorySelect(cat.id)}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl text-left transition-all ${
                    isActive
                      ? 'bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-600/20'
                      : 'text-zinc-300 hover:bg-zinc-900 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={isActive ? 'text-white' : 'text-zinc-400'}>
                      {renderIcon(cat.iconName)}
                    </span>
                    <div>
                      <span className="text-sm block">{cat.name}</span>
                      <span className={`text-[10px] font-mono tracking-wider ${isActive ? 'text-indigo-200' : 'text-zinc-500'}`}>
                        {cat.nameEn}
                      </span>
                    </div>
                  </div>
                  <ChevronRight className={`w-4 h-4 ${isActive ? 'text-white' : 'text-zinc-600'}`} />
                </button>
              );
            })}
          </div>

          {/* Subcategories & Quick Feature (Right 7 Cols) */}
          <div className="md:col-span-7 p-6 overflow-y-auto bg-zinc-900/40 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-zinc-800/80">
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400">
                    {renderIcon(activeCatObj.iconName)}
                  </span>
                  <div>
                    <h3 className="text-base font-bold text-white">{activeCatObj.name}</h3>
                    <p className="text-xs text-indigo-400 font-mono uppercase">{activeCatObj.nameEn}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleCategorySelect(activeCatObj.id)}
                  className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                >
                  카테고리 전체보기 →
                </button>
              </div>

              {/* Subcategories Grid */}
              <div className="grid grid-cols-2 gap-3">
                {activeCatObj.subcategories.map((sub, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleCategorySelect(activeCatObj.id)}
                    className="p-3 rounded-xl bg-zinc-900 border border-zinc-800/80 text-left text-sm text-zinc-300 hover:text-white hover:border-indigo-500/40 hover:bg-zinc-850 transition-all flex items-center justify-between group"
                  >
                    <span>{sub}</span>
                    <ChevronRight className="w-3.5 h-3.5 text-zinc-600 group-hover:text-indigo-400 transition-colors" />
                  </button>
                ))}
              </div>
            </div>

            {/* Bottom Promo */}
            <div className="mt-8 p-4 rounded-2xl bg-gradient-to-r from-indigo-900/40 to-purple-900/40 border border-indigo-500/30 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-indigo-300">SPECIAL CAMPAIGN</p>
                <p className="text-sm font-bold text-white">2026 하이퍼 카테고리 핫딜 30%</p>
              </div>
              <button
                onClick={() => handleCategorySelect(activeCatObj.id)}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 text-xs font-bold text-white hover:bg-indigo-500 transition-colors"
              >
                쇼핑하기
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
