import React from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { CheckCircle2, Truck, Package, ArrowRight, Home, Receipt } from 'lucide-react';

export const OrderCompleteView: React.FC = () => {
  const { lastCompletedOrder, setCurrentView } = useECommerce();

  if (!lastCompletedOrder) {
    return (
      <div className="w-full max-w-xl mx-auto py-20 text-center space-y-4">
        <p className="text-zinc-400">주문 내역이 없습니다.</p>
        <button
          onClick={() => setCurrentView('home')}
          className="px-6 py-2.5 rounded-xl bg-indigo-600 text-white font-bold text-xs"
        >
          홈으로 가기
        </button>
      </div>
    );
  }

  const formatPrice = (p: number) => p.toLocaleString('ko-KR') + '원';

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-12 space-y-8 animate-in fade-in duration-300">
      
      {/* Top Banner */}
      <div className="text-center space-y-3">
        <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 mx-auto flex items-center justify-center">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white font-mono">
          주문이 정상 접수되었습니다!
        </h1>
        <p className="text-xs text-zinc-400">
          주문번호 <strong className="text-indigo-400 font-mono">{lastCompletedOrder.orderNumber}</strong>
        </p>
      </div>

      {/* Order Details Card */}
      <div className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 space-y-4 text-xs">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3 font-mono">
          <span className="font-bold text-white">결제 상세 요약</span>
          <span className="text-zinc-400">{lastCompletedOrder.date}</span>
        </div>

        <div className="space-y-3">
          {lastCompletedOrder.items.map((item) => (
            <div key={item.id} className="flex items-center gap-3">
              <img
                src={item.product.image}
                alt={item.product.name}
                className="w-12 h-12 rounded-xl object-cover shrink-0 bg-zinc-950"
              />
              <div className="flex-1 min-w-0">
                <p className="font-bold text-white truncate">{item.product.name}</p>
                <p className="text-[10px] text-zinc-400 font-mono">수량 {item.quantity}개</p>
              </div>
              <span className="font-mono font-bold text-white">
                {formatPrice(item.product.price * item.quantity)}
              </span>
            </div>
          ))}
        </div>

        <div className="pt-4 border-t border-zinc-800 space-y-2">
          <div className="flex justify-between text-zinc-400">
            <span>배송지</span>
            <span className="text-white text-right font-medium max-w-xs">
              {lastCompletedOrder.recipient.address} {lastCompletedOrder.recipient.addressDetail}
            </span>
          </div>
          <div className="flex justify-between text-zinc-400">
            <span>받는분</span>
            <span className="text-white font-medium">{lastCompletedOrder.recipient.name} ({lastCompletedOrder.recipient.phone})</span>
          </div>
          <div className="flex justify-between text-zinc-400">
            <span>결제 수단</span>
            <span className="text-white font-medium">{lastCompletedOrder.paymentMethod}</span>
          </div>
          <div className="pt-3 border-t border-zinc-800 flex justify-between text-sm font-bold text-white">
            <span>총 결제금액</span>
            <span className="text-indigo-400 font-mono text-base">{formatPrice(lastCompletedOrder.totalAmount)}</span>
          </div>
        </div>
      </div>

      {/* Navigation Actions */}
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={() => setCurrentView('mypage')}
          className="flex-1 py-3.5 rounded-2xl bg-zinc-900 border border-zinc-700 hover:border-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all"
        >
          <Receipt className="w-4 h-4 text-indigo-400" />
          <span>주문내역 조회하기</span>
        </button>

        <button
          onClick={() => setCurrentView('home')}
          className="flex-1 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg"
        >
          <Home className="w-4 h-4" />
          <span>쇼핑 계속하기</span>
        </button>
      </div>

    </div>
  );
};
