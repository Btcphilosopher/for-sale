import React from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { CATEGORIES } from '../data/mockData';
import {
  Shirt,
  Sparkles,
  Smartphone,
  Home,
  Utensils,
  Activity,
  Car,
  BookOpen,
  Smile,
  HeartHandshake,
  Grid,
} from 'lucide-react';

export const CategoryNavigation: React.FC = () => {
  const { selectedCategoryId, setSelectedCategoryId, setCurrentView } = useECommerce();

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Shirt': return <Shirt className="w-4 h-4" />;
      case 'Sparkles': return <Sparkles className="w-4 h-4" />;
      case 'Smartphone': return <Smartphone className="w-4 h-4" />;
      case 'Home': return <Home className="w-4 h-4" />;
      case 'Utensils': return <Utensils className="w-4 h-4" />;
      case 'Activity': return <Activity className="w-4 h-4" />;
      case 'Car': return <Car className="w-4 h-4" />;
      case 'BookOpen': return <BookOpen className="w-4 h-4" />;
      case 'Smile': return <Smile className="w-4 h-4" />;
      case 'HeartHandshake': return <HeartHandshake className="w-4 h-4" />;
      default: return <Grid className="w-4 h-4" />;
    }
  };

  const handleSelect = (id: string | null) => {
    setSelectedCategoryId(id);
    if (id) {
      setCurrentView('category');
    } else {
      setCurrentView('home');
    }
  };

  return (
    <div className="bg-zinc-950/80 border-b border-zinc-900 overflow-x-auto no-scrollbar py-2.5 px-4 md:px-8">
      <div className="max-w-7xl mx-auto flex items-center gap-2 min-w-max">
        
        {/* Entire Category Pill */}
        <button
          onClick={() => handleSelect(null)}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
            selectedCategoryId === null
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'bg-zinc-900/90 border border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:text-white'
          }`}
        >
          <Grid className="w-3.5 h-3.5" />
          <span>전체</span>
        </button>

        {/* 10 Categories */}
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategoryId === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => handleSelect(cat.id)}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
                isSelected
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'bg-zinc-900/90 border border-zinc-800/80 text-zinc-300 hover:border-indigo-500/40 hover:text-white'
              }`}
            >
              <span className={isSelected ? 'text-white' : 'text-zinc-400'}>
                {renderIcon(cat.iconName)}
              </span>
              <span>{cat.name}</span>
            </button>
          );
        })}

      </div>
    </div>
  );
};
