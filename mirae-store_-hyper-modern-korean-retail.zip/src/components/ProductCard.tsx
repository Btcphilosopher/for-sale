import React from 'react';
import { Product } from '../types/ecommerce';
import { useECommerce } from '../context/ECommerceContext';
import { Heart, ShoppingBag, Star } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  showRanking?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, showRanking = false }) => {
  const { openProductDetail, toggleWishlist, isWishlisted, addToCart } = useECommerce();
  const wishlisted = isWishlisted(product.id);

  const formatPrice = (price: number) => {
    return price.toLocaleString('ko-KR') + '원';
  };

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  return (
    <div
      onClick={() => openProductDetail(product.id)}
      className="group relative bg-zinc-900/80 border border-zinc-800/80 hover:border-indigo-500/40 rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-indigo-500/10 flex flex-col justify-between"
    >
      {/* Top Image Container */}
      <div className="relative w-full aspect-square bg-zinc-950 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
          loading="lazy"
        />

        {/* Gradient Overlay on Hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent opacity-0 group-hover:opacity-60 transition-opacity duration-300" />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {showRanking && product.ranking && (
            <span className="w-7 h-7 rounded-lg bg-indigo-600 text-white font-mono font-black text-sm flex items-center justify-center shadow-lg">
              {product.ranking}
            </span>
          )}
          {product.isNew && (
            <span className="px-2.5 py-0.5 rounded-md bg-cyan-500/90 text-zinc-950 font-mono font-extrabold text-[10px] tracking-wider uppercase shadow-md">
              NEW
            </span>
          )}
          {product.discountRate > 0 && (
            <span className="px-2.5 py-0.5 rounded-md bg-rose-600 text-white font-bold text-[11px] shadow-md">
              {product.discountRate}% OFF
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={handleWishlistToggle}
          className={`absolute top-3 right-3 p-2 rounded-full border backdrop-blur-md transition-all z-10 ${
            wishlisted
              ? 'bg-rose-500/20 border-rose-500 text-rose-500 opacity-100'
              : 'bg-zinc-900/60 border-white/10 text-zinc-300 hover:text-white opacity-80 sm:opacity-0 group-hover:opacity-100'
          }`}
          aria-label="찜하기"
        >
          <Heart className={`w-4 h-4 ${wishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
        </button>

        {/* Quick Add Button on Hover */}
        <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0 z-10">
          <button
            onClick={handleQuickAdd}
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-2 transition-colors"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>장바구니 담기</span>
          </button>
        </div>
      </div>

      {/* Card Info Area */}
      <div className="p-4 flex-1 flex flex-col justify-between gap-2">
        <div>
          <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400 mb-1">
            <span className="font-semibold text-indigo-400">{product.brand}</span>
            {product.rating > 0 && (
              <span className="flex items-center gap-1 text-zinc-400">
                <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                {product.rating} ({product.reviewCount})
              </span>
            )}
          </div>

          <h3 className="text-sm font-bold text-zinc-100 line-clamp-2 leading-snug group-hover:text-indigo-300 transition-colors">
            {product.name}
          </h3>
        </div>

        {/* Price Area */}
        <div className="pt-2 border-t border-zinc-800/60 flex items-baseline justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-base font-black text-white font-mono">
              {formatPrice(product.price)}
            </span>
            {product.discountRate > 0 && (
              <span className="text-xs text-zinc-500 line-through font-mono">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>

          {product.deliveryInfo && (
            <span className="text-[10px] text-emerald-400 font-medium bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded">
              무료배송
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
