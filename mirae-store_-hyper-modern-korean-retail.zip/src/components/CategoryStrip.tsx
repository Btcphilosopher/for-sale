import React from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { CATEGORIES } from '../data/mockData';
import {
  Shirt,
  Sparkles,
  Smartphone,
  Home,
  Utensils,
  Activity,
  Car,
  BookOpen,
  Smile,
  HeartHandshake,
  Grid,
} from 'lucide-react';

export const CategoryStrip: React.FC = () => {
  const { setSelectedCategoryId, setCurrentView, setIsMegaMenuOpen } = useECommerce();

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Shirt': return <Shirt className="w-5 h-5 text-indigo-400" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-purple-400" />;
      case 'Smartphone': return <Smartphone className="w-5 h-5 text-cyan-400" />;
      case 'Home': return <Home className="w-5 h-5 text-amber-400" />;
      case 'Utensils': return <Utensils className="w-5 h-5 text-emerald-400" />;
      case 'Activity': return <Activity className="w-5 h-5 text-rose-400" />;
      case 'Car': return <Car className="w-5 h-5 text-blue-400" />;
      case 'BookOpen': return <BookOpen className="w-5 h-5 text-orange-400" />;
      case 'Smile': return <Smile className="w-5 h-5 text-yellow-400" />;
      case 'HeartHandshake': return <HeartHandshake className="w-5 h-5 text-pink-400" />;
      default: return <Grid className="w-5 h-5 text-indigo-400" />;
    }
  };

  const handleSelectCategory = (id: string) => {
    setSelectedCategoryId(id);
    setCurrentView('category');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section className="w-full max-w-7xl mx-auto px-4 md:px-8 py-4">
      <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-2">
        
        {/* 10 Categories */}
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => handleSelectCategory(cat.id)}
            className="flex-shrink-0 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-zinc-900/90 border border-zinc-800/80 hover:border-indigo-500/50 hover:bg-zinc-850 hover:scale-105 transition-all group shadow-md"
          >
            <div className="p-2 rounded-xl bg-zinc-950 border border-zinc-800 group-hover:border-indigo-500/40 transition-colors">
              {renderIcon(cat.iconName)}
            </div>
            <div className="text-left">
              <span className="text-xs font-bold text-zinc-200 group-hover:text-white block whitespace-nowrap">
                {cat.name}
              </span>
              <span className="text-[10px] text-zinc-500 font-mono tracking-wider block uppercase">
                {cat.nameEn}
              </span>
            </div>
          </button>
        ))}

        {/* Final Category: 전체보기 */}
        <button
          onClick={() => setIsMegaMenuOpen(true)}
          className="flex-shrink-0 flex items-center gap-2.5 px-5 py-3 rounded-2xl bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/40 hover:border-indigo-400 hover:scale-105 transition-all text-white shadow-lg"
        >
          <div className="p-2 rounded-xl bg-indigo-600 text-white">
            <Grid className="w-5 h-5" />
          </div>
          <div className="text-left">
            <span className="text-xs font-extrabold text-white block whitespace-nowrap">
              전체보기
            </span>
            <span className="text-[10px] text-indigo-300 font-mono block">
              VIEW ALL
            </span>
          </div>
        </button>

      </div>
    </section>
  );
};
