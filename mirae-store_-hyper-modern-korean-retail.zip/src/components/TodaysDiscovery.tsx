import React, { useState, useEffect } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { ProductCard } from './ProductCard';
import { Sparkles, Clock, ArrowRight } from 'lucide-react';

export const TodaysDiscovery: React.FC = () => {
  const { products, setCurrentView, setSearchQuery } = useECommerce();

  // Countdown timer: 09 hours 45 mins 21 secs
  const [timeLeft, setTimeLeft] = useState({ hours: 9, minutes: 45, seconds: 21 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          return { hours: 23, minutes: 59, seconds: 59 };
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTwoDigits = (num: number) => String(num).padStart(2, '0');

  // Filter 4 featured items for Today's Discovery
  const discoveryProducts = products.filter((p) => p.tags?.includes('오늘의발견')).slice(0, 4);

  const handleMore = () => {
    setSearchQuery('오늘의발견');
    setCurrentView('search_results');
  };

  return (
    <section className="w-full max-w-7xl mx-auto px-4 md:px-8 py-8">
      
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-800/80">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h2 className="text-xl md:text-2xl font-black tracking-tight text-white font-mono">
              오늘의 발견
            </h2>
            <span className="text-xs font-mono tracking-widest text-indigo-400 font-bold uppercase ml-1">
              TODAY'S DISCOVERY
            </span>
          </div>
          <p className="text-xs text-zinc-400">
            24시간 한정 타임딜, 미래상점이 큐레이션한 차세대 시그니처 픽
          </p>
        </div>

        {/* Live Countdown Badge */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-indigo-950/80 border border-indigo-500/30 text-indigo-200 text-xs font-mono font-bold shadow-lg">
            <Clock className="w-4 h-4 text-indigo-400 animate-pulse" />
            <span>남은 시간</span>
            <span className="bg-indigo-600 text-white px-2 py-0.5 rounded-lg text-sm">
              {formatTwoDigits(timeLeft.hours)}:{formatTwoDigits(timeLeft.minutes)}:{formatTwoDigits(timeLeft.seconds)}
            </span>
          </div>

          <button
            onClick={handleMore}
            className="text-xs text-zinc-400 hover:text-white font-semibold flex items-center gap-1 transition-colors"
          >
            <span>더보기</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Product Grid (4 items) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {discoveryProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

    </section>
  );
};
