import React, { useState } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { ShoppingBag, Trash2, Plus, Minus, ArrowRight, Ticket, ShieldCheck, Heart } from 'lucide-react';

export const CartView: React.FC = () => {
  const {
    cart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    coupons,
    activeCoupon,
    setActiveCoupon,
    setCurrentView,
    toggleWishlist,
    addToast,
  } = useECommerce();

  const [selectedItemIds, setSelectedItemIds] = useState<string[]>(() => cart.map((i) => i.id));

  const toggleSelectItem = (id: string) => {
    setSelectedItemIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedItemIds.length === cart.length) {
      setSelectedItemIds([]);
    } else {
      setSelectedItemIds(cart.map((i) => i.id));
    }
  };

  const selectedCartItems = cart.filter((item) => selectedItemIds.includes(item.id));

  const subtotal = selectedCartItems.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  let discountAmount = 0;
  if (activeCoupon) {
    if (activeCoupon.discountType === 'amount') {
      discountAmount = activeCoupon.discountValue;
    } else {
      discountAmount = Math.round((subtotal * activeCoupon.discountValue) / 100);
    }
  }

  const shippingFee = subtotal >= 50000 || subtotal === 0 ? 0 : 3000;
  const totalAmount = Math.max(0, subtotal - discountAmount + shippingFee);

  const formatPrice = (p: number) => p.toLocaleString('ko-KR') + '원';

  const handleCheckout = () => {
    if (selectedCartItems.length === 0) {
      addToast('주문할 상품을 선택해주세요.', 'warning');
      return;
    }
    setCurrentView('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const claimedCoupons = coupons.filter((c) => c.isClaimed);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      
      {/* Page Title */}
      <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight font-mono">장바구니</h1>
            <p className="text-xs text-zinc-400 font-mono uppercase">SHOPPING CART ({cart.length})</p>
          </div>
        </div>

        {cart.length > 0 && (
          <button
            onClick={clearCart}
            className="text-xs text-zinc-500 hover:text-rose-400 flex items-center gap-1 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>장바구니 비우기</span>
          </button>
        )}
      </div>

      {cart.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Cart Items List (8 Cols) */}
          <div className="lg:col-span-8 space-y-4">
            
            {/* Table Control Header */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 text-xs font-semibold text-zinc-300">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectedItemIds.length === cart.length && cart.length > 0}
                  onChange={toggleSelectAll}
                  className="w-4 h-4 rounded accent-indigo-600"
                />
                <span>전체선택 ({selectedItemIds.length}/{cart.length})</span>
              </label>

              <span>상품 정보</span>
            </div>

            {/* Items */}
            {cart.map((item) => {
              const isChecked = selectedItemIds.includes(item.id);
              return (
                <div
                  key={item.id}
                  className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                    isChecked
                      ? 'bg-zinc-900/90 border-indigo-500/40'
                      : 'bg-zinc-900/40 border-zinc-800 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => toggleSelectItem(item.id)}
                      className="w-4 h-4 rounded accent-indigo-600 shrink-0"
                    />

                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-20 h-20 rounded-xl object-cover shrink-0 bg-zinc-950 border border-zinc-800"
                    />

                    <div className="min-w-0 space-y-1">
                      <span className="text-[10px] text-indigo-400 font-mono block">
                        {item.product.brand}
                      </span>
                      <h3 className="text-sm font-bold text-white truncate">{item.product.name}</h3>

                      {item.selectedOptions && Object.keys(item.selectedOptions).length > 0 && (
                        <p className="text-[11px] text-zinc-400 font-mono">
                          옵션: {Object.entries(item.selectedOptions).map(([k, v]) => `${k}: ${v}`).join(', ')}
                        </p>
                      )}

                      <p className="text-xs font-extrabold text-white font-mono">
                        {formatPrice(item.product.price)}
                      </p>
                    </div>
                  </div>

                  {/* Quantity & Actions */}
                  <div className="flex items-center justify-between sm:justify-end gap-4 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-0 border-zinc-800">
                    <div className="flex items-center bg-zinc-950 border border-zinc-800 rounded-xl p-1">
                      <button
                        onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                        className="p-1 text-zinc-400 hover:text-white"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-8 text-center text-xs font-bold font-mono text-white">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                        className="p-1 text-zinc-400 hover:text-white"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="text-right font-mono font-bold text-sm text-white min-w-20">
                      {formatPrice(item.product.price * item.quantity)}
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => toggleWishlist(item.product.id)}
                        className="p-2 text-zinc-500 hover:text-rose-400 transition-colors"
                        title="찜하기"
                      >
                        <Heart className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="p-2 text-zinc-500 hover:text-rose-400 transition-colors"
                        title="삭제"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                </div>
              );
            })}

          </div>

          {/* Cart Summary & Coupon Section (4 Cols) */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Coupon Selector Card */}
            <div className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-white font-mono">
                <Ticket className="w-4 h-4 text-indigo-400" />
                <span>할인 쿠폰 적용</span>
              </div>

              {claimedCoupons.length > 0 ? (
                <select
                  value={activeCoupon?.id || ''}
                  onChange={(e) => {
                    const found = claimedCoupons.find((c) => c.id === e.target.value) || null;
                    setActiveCoupon(found);
                  }}
                  className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="">적용 안함</option>
                  {claimedCoupons.map((c) => (
                    <option key={c.id} value={c.id}>
                      [{c.code}] {c.name} ({c.discountValue}{c.discountType === 'rate' ? '%' : '원'} 할인)
                    </option>
                  ))}
                </select>
              ) : (
                <p className="text-xs text-zinc-500">
                  보유한 쿠폰이 없습니다. 홈 화면에서 신규 회원 웰컴 쿠폰을 받아보세요!
                </p>
              )}
            </div>

            {/* Price Calculation Box */}
            <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-4">
              <h3 className="text-sm font-bold text-white font-mono border-b border-zinc-800 pb-3">
                결제 예정 금액
              </h3>

              <div className="space-y-2.5 text-xs">
                <div className="flex items-center justify-between text-zinc-300">
                  <span>총 상품금액</span>
                  <span className="font-mono">{formatPrice(subtotal)}</span>
                </div>

                <div className="flex items-center justify-between text-zinc-300">
                  <span>쿠폰 할인금액</span>
                  <span className="font-mono text-rose-400">
                    -{formatPrice(discountAmount)}
                  </span>
                </div>

                <div className="flex items-center justify-between text-zinc-300">
                  <span>배송비</span>
                  <span className="font-mono">
                    {shippingFee === 0 ? '0원 (무료)' : formatPrice(shippingFee)}
                  </span>
                </div>

                <div className="pt-3 border-t border-zinc-800 flex items-baseline justify-between text-base font-extrabold text-white">
                  <span>총 결제금액</span>
                  <span className="text-xl text-indigo-400 font-mono">{formatPrice(totalAmount)}</span>
                </div>
              </div>

              <button
                onClick={handleCheckout}
                className="w-full py-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all"
              >
                <span>주문하기 ({selectedCartItems.length}건)</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="pt-2 text-[11px] text-zinc-500 text-center flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                <span>안심 스마트 결제 시스템</span>
              </div>
            </div>

          </div>

        </div>
      ) : (
        <div className="text-center py-20 bg-zinc-900/40 border border-zinc-800 rounded-3xl space-y-4">
          <ShoppingBag className="w-12 h-12 mx-auto text-zinc-600 stroke-1" />
          <h2 className="text-lg font-bold text-white">장바구니에 담긴 상품이 없습니다</h2>
          <p className="text-xs text-zinc-400">미래상점의 미래지향적 시그니처 아이템들을 둘러보세요.</p>
          <button
            onClick={() => setCurrentView('home')}
            className="px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition-colors"
          >
            지금 쇼핑하러 가기 →
          </button>
        </div>
      )}

    </div>
  );
};
