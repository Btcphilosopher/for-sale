import React, { useState, useEffect } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { User, Eye, Package, ArrowUp } from 'lucide-react';

export const FloatingRail: React.FC = () => {
  const {
    setCurrentView,
    setIsRecentlyViewedOpen,
    recentlyViewedIds,
    orders,
  } = useECommerce();

  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed right-6 bottom-24 md:bottom-12 z-40 hidden md:flex flex-col gap-3 items-end">
      
      {/* Utility Rail Panel */}
      <div className="bg-zinc-950/90 border border-zinc-800 rounded-2xl p-2 shadow-2xl backdrop-blur-md flex flex-col gap-2">
        
        {/* 마이페이지 */}
        <button
          onClick={() => {
            setCurrentView('mypage');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="relative p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:border-indigo-500/50 hover:bg-zinc-850 transition-all group"
          title="마이페이지"
        >
          <User className="w-5 h-5 text-indigo-400 group-hover:scale-110 transition-transform" />
          <span className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-2.5 py-1 rounded-lg bg-zinc-900 text-white text-xs font-semibold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity border border-zinc-800 pointer-events-none shadow-xl">
            마이페이지
          </span>
        </button>

        {/* 최근 본 상품 */}
        <button
          onClick={() => setIsRecentlyViewedOpen(true)}
          className="relative p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:border-indigo-500/50 hover:bg-zinc-850 transition-all group"
          title="최근 본 상품"
        >
          <Eye className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform" />
          {recentlyViewedIds.length > 0 && (
            <span className="absolute -top-1 -right-1 bg-cyan-500 text-zinc-950 text-[10px] font-black rounded-full w-4 h-4 flex items-center justify-center">
              {recentlyViewedIds.length}
            </span>
          )}
          <span className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-2.5 py-1 rounded-lg bg-zinc-900 text-white text-xs font-semibold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity border border-zinc-800 pointer-events-none shadow-xl">
            최근 본 상품 ({recentlyViewedIds.length})
          </span>
        </button>

        {/* 주문내역 */}
        <button
          onClick={() => {
            setCurrentView('mypage');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="relative p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:border-indigo-500/50 hover:bg-zinc-850 transition-all group"
          title="주문내역"
        >
          <Package className="w-5 h-5 text-purple-400 group-hover:scale-110 transition-transform" />
          {orders.length > 0 && (
            <span className="absolute -top-1 -right-1 bg-purple-500 text-white text-[10px] font-black rounded-full w-4 h-4 flex items-center justify-center">
              {orders.length}
            </span>
          )}
          <span className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-2.5 py-1 rounded-lg bg-zinc-900 text-white text-xs font-semibold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity border border-zinc-800 pointer-events-none shadow-xl">
            주문내역
          </span>
        </button>

      </div>

      {/* Back to Top Floating Button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="p-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-xl shadow-indigo-600/30 hover:scale-110 transition-all border border-indigo-400/30"
          title="맨 위로 이동"
          aria-label="맨 위로 이동"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}

    </div>
  );
};
