import React, { useState, useEffect, useRef } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { HERO_SLIDES } from '../data/mockData';
import { ChevronLeft, ChevronRight, Play, Pause, Sparkles, ArrowRight } from 'lucide-react';

export const HeroCarousel: React.FC = () => {
  const { setCurrentView, setSearchQuery, setSelectedCategoryId } = useECommerce();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const slide = HERO_SLIDES[currentIndex];

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % HERO_SLIDES.length);
      }, 5500);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? HERO_SLIDES.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const handleCTA = () => {
    setSelectedCategoryId('fashion');
    setCurrentView('category');
  };

  return (
    <section className="relative w-full max-w-7xl mx-auto px-4 md:px-8 pt-4 pb-6">
      <div className="relative h-[480px] sm:h-[540px] md:h-[600px] w-full rounded-3xl overflow-hidden border border-zinc-800/80 shadow-2xl bg-zinc-950 group">
        
        {/* Slide Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center transition-all duration-1000 ease-out transform scale-105"
          style={{ backgroundImage: `url(${slide.image})` }}
        >
          {/* Dark Overlay Gradient */}
          <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-zinc-950/40" />
        </div>

        {/* Content Box */}
        <div className="relative z-10 h-full flex flex-col justify-between p-8 md:p-14 max-w-2xl">
          
          {/* Top Badge */}
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-[11px] font-mono tracking-widest uppercase font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 backdrop-blur-md flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-indigo-400" />
              {slide.badge}
            </span>
            <span className="text-xs text-zinc-400 font-mono hidden sm:inline">
              [{slide.tag}]
            </span>
          </div>

          {/* Main Typography */}
          <div className="space-y-3 my-auto">
            <p className="text-indigo-400 font-medium text-sm md:text-base tracking-wide">
              {slide.subheadline}
            </p>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-white font-mono leading-none drop-shadow-md">
              {slide.headline}
            </h1>
            <p className="text-zinc-300 text-base md:text-lg font-normal pt-1">
              {slide.campaign}
            </p>

            {/* Primary CTA */}
            <div className="pt-4 flex items-center gap-4">
              <button
                onClick={handleCTA}
                className="px-7 py-3.5 rounded-2xl bg-white text-zinc-950 hover:bg-indigo-400 hover:text-white font-bold text-sm transition-all shadow-xl flex items-center gap-2 group/btn"
              >
                <span>{slide.ctaText}</span>
                <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          {/* Bottom Pagination & Play/Pause Controls */}
          <div className="flex items-center justify-between pt-4 border-t border-white/10">
            <div className="flex items-center gap-2">
              {HERO_SLIDES.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === currentIndex
                      ? 'w-8 bg-indigo-400'
                      : 'w-2 bg-zinc-600 hover:bg-zinc-400'
                  }`}
                  aria-label={`슬라이드 ${idx + 1}`}
                />
              ))}
            </div>

            <div className="flex items-center gap-2 text-xs font-mono text-zinc-400 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10">
              <span>{String(currentIndex + 1).padStart(2, '0')}</span>
              <span>/</span>
              <span>{String(HERO_SLIDES.length).padStart(2, '0')}</span>
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-1 hover:text-white transition-colors ml-1"
                aria-label={isPlaying ? '일시정지' : '재생'}
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

        </div>

        {/* Carousel Prev / Next Arrow Buttons */}
        <div className="absolute right-6 bottom-8 z-10 hidden sm:flex items-center gap-2">
          <button
            onClick={handlePrev}
            className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-700/80 text-white hover:bg-indigo-600 hover:border-indigo-500 transition-all shadow-lg backdrop-blur-md"
            aria-label="이전 슬라이드"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={handleNext}
            className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-700/80 text-white hover:bg-indigo-600 hover:border-indigo-500 transition-all shadow-lg backdrop-blur-md"
            aria-label="다음 슬라이드"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

      </div>
    </section>
  );
};
