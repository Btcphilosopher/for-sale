import React from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { Flame, TrendingUp, ShoppingBag, ArrowUpRight } from 'lucide-react';

export const TrendingProducts: React.FC = () => {
  const { products, openProductDetail, addToCart } = useECommerce();

  // Sort products by salesCount or ranking
  const trendingList = [...products]
    .sort((a, b) => (a.ranking || 99) - (b.ranking || 99))
    .slice(0, 6);

  const formatPrice = (p: number) => p.toLocaleString('ko-KR') + '원';

  return (
    <section className="w-full max-w-7xl mx-auto px-4 md:px-8 py-8">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-zinc-800/80">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Flame className="w-5 h-5 text-rose-500 animate-pulse" />
            <h2 className="text-xl md:text-2xl font-black tracking-tight text-white font-mono">
              실시간 인기 상품
            </h2>
            <span className="text-xs font-mono tracking-widest text-indigo-400 font-bold uppercase ml-1">
              TRENDING NOW
            </span>
          </div>
          <p className="text-xs text-zinc-400">
            지금 서울에서 가장 많은 사랑을 받고 있는 랭킹 Top Items
          </p>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-xs text-zinc-400 font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>실시간 집계 중 (10분 주기 업데이트)</span>
        </div>
      </div>

      {/* Trending Horizontal List / Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {trendingList.map((product, idx) => {
          const rankNum = idx + 1;
          return (
            <div
              key={product.id}
              onClick={() => openProductDetail(product.id)}
              className="group p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 hover:border-indigo-500/40 hover:bg-zinc-850 transition-all cursor-pointer flex items-center gap-4 relative overflow-hidden shadow-lg"
            >
              {/* Ranking Number Badge */}
              <div className="flex flex-col items-center justify-center min-w-10">
                <span className={`text-2xl font-black font-mono ${
                  rankNum === 1 ? 'text-amber-400 text-3xl' : rankNum === 2 ? 'text-zinc-300' : rankNum === 3 ? 'text-amber-600' : 'text-zinc-500'
                }`}>
                  {rankNum}
                </span>

                {/* Trend Change Indicator */}
                <div className="flex items-center gap-0.5 text-[10px] font-mono font-bold mt-0.5">
                  {product.rankingChange === 'up' && (
                    <span className="text-rose-400 flex items-center">
                      ▲{product.rankingAmount || 1}
                    </span>
                  )}
                  {product.rankingChange === 'new' && (
                    <span className="text-cyan-400">NEW</span>
                  )}
                  {(!product.rankingChange || product.rankingChange === 'same') && (
                    <span className="text-zinc-500">-</span>
                  )}
                </div>
              </div>

              {/* Thumbnail */}
              <div className="w-20 h-20 rounded-xl overflow-hidden bg-zinc-950 shrink-0 border border-zinc-800 relative">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  loading="lazy"
                />
              </div>

              {/* Product Info */}
              <div className="flex-1 min-w-0 space-y-1">
                <span className="text-[10px] text-indigo-400 font-mono block">
                  {product.brand}
                </span>
                <h3 className="text-sm font-bold text-white truncate group-hover:text-indigo-300 transition-colors">
                  {product.name}
                </h3>

                <div className="flex items-baseline gap-2">
                  <span className="text-sm font-extrabold text-white font-mono">
                    {formatPrice(product.price)}
                  </span>
                  {product.discountRate > 0 && (
                    <span className="text-xs font-bold text-rose-500">
                      {product.discountRate}%
                    </span>
                  )}
                </div>
              </div>

              {/* Quick Add Button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  addToCart(product, 1);
                }}
                className="p-2.5 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white hover:bg-indigo-600 transition-all opacity-80 sm:opacity-0 group-hover:opacity-100"
                title="장바구니 담기"
              >
                <ShoppingBag className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>

    </section>
  );
};
