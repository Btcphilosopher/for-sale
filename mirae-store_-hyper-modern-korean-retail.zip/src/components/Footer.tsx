import React from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { Shield, Sparkles, Lock, Headphones, Globe } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setCurrentView, setSelectedCategoryId, setSearchQuery } = useECommerce();

  const handleCategoryLink = (catId: string) => {
    setSelectedCategoryId(catId);
    setCurrentView('category');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-zinc-950 border-t border-zinc-900 text-zinc-400 text-xs py-12 px-4 md:px-8 mt-20 mb-16 md:mb-0">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Top Badges Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pb-8 border-b border-zinc-900">
          <div className="flex items-center gap-3 p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800/80">
            <Headphones className="w-5 h-5 text-indigo-400 shrink-0" />
            <div>
              <p className="font-bold text-white text-sm">1588-2026</p>
              <p className="text-[10px] text-zinc-500">24/7 AI 하이퍼 고객센터</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800/80">
            <Shield className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <p className="font-bold text-white text-sm">100% 정품 보장</p>
              <p className="text-[10px] text-zinc-500">공식 브랜드 직접 입점</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800/80">
            <Lock className="w-5 h-5 text-purple-400 shrink-0" />
            <div>
              <p className="font-bold text-white text-sm">보안결제 ISO27001</p>
              <p className="text-[10px] text-zinc-500">암호화 금융 거래</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800/80">
            <Globe className="w-5 h-5 text-cyan-400 shrink-0" />
            <div>
              <p className="font-bold text-white text-sm">SEOUL & GLOBAL</p>
              <p className="text-[10px] text-zinc-500">글로벌 프리미엄 딜리버리</p>
            </div>
          </div>
        </div>

        {/* Footer Navigation Columns */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 text-xs">
          
          {/* Brand Info */}
          <div className="col-span-2 space-y-3">
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-black text-white font-mono tracking-tight">미래상점</span>
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
              <span className="text-xs font-mono tracking-widest text-zinc-500 uppercase">MIRAE STORE</span>
            </div>
            <p className="text-zinc-400 leading-relaxed max-w-sm">
              서울의 디지털 디자인 감성과 하이퍼모던 기술을 결합한 차세대 한국형 이커머스 플랫폼입니다.
            </p>
            <p className="text-[11px] font-mono text-zinc-500">
              © 2026 MIRAE STORE Co., Ltd. All Rights Reserved.
            </p>
          </div>

          {/* Category Links */}
          <div className="space-y-2">
            <h4 className="font-bold text-white font-mono uppercase text-[11px]">CATEGORIES</h4>
            <ul className="space-y-1.5 text-zinc-400">
              <li><button onClick={() => handleCategoryLink('fashion')} className="hover:text-white">패션의류</button></li>
              <li><button onClick={() => handleCategoryLink('beauty')} className="hover:text-white">뷰티</button></li>
              <li><button onClick={() => handleCategoryLink('tech')} className="hover:text-white">디지털/가전</button></li>
              <li><button onClick={() => handleCategoryLink('lifestyle')} className="hover:text-white">라이프</button></li>
              <li><button onClick={() => handleCategoryLink('food')} className="hover:text-white">식품</button></li>
            </ul>
          </div>

          {/* Customer Support Links */}
          <div className="space-y-2">
            <h4 className="font-bold text-white font-mono uppercase text-[11px]">CUSTOMER</h4>
            <ul className="space-y-1.5 text-zinc-400">
              <li><a href="#" className="hover:text-white">공지사항</a></li>
              <li><a href="#" className="hover:text-white">자주 묻는 질문 (FAQ)</a></li>
              <li><a href="#" className="hover:text-white">1:1 문의</a></li>
              <li><a href="#" className="hover:text-white">배송 조회</a></li>
              <li><a href="#" className="hover:text-white">멤버십 혜택 안내</a></li>
            </ul>
          </div>

          {/* Legal Links */}
          <div className="space-y-2">
            <h4 className="font-bold text-white font-mono uppercase text-[11px]">LEGAL</h4>
            <ul className="space-y-1.5 text-zinc-400">
              <li><a href="#" className="hover:text-white font-bold text-zinc-200">개인정보처리방침</a></li>
              <li><a href="#" className="hover:text-white">이용약관</a></li>
              <li><a href="#" className="hover:text-white">전자금융거래약관</a></li>
              <li><a href="#" className="hover:text-white">사업자정보확인</a></li>
              <li><a href="#" className="hover:text-white">ESG 경영 리포트</a></li>
            </ul>
          </div>

        </div>

        {/* Legal Corporate Info Disclaimer */}
        <div className="pt-8 border-t border-zinc-900 text-[11px] text-zinc-500 leading-relaxed space-y-1 font-mono">
          <p>(주)미래상점 코리아 | 대표이사: 김미래 | 사업자등록번호: 2026-88-02026 | 통신판매업신고: 2026-서울강남-0123호</p>
          <p>주소: 서울특별시 강남구 테헤란로 152 강남파이낸스센터 18층 | 개인정보보호책임자: 박네오 (privacy@miraestore.kr)</p>
          <p>미래상점은 통신판매중개자로서 통신판매의 당사자가 아니며, 상품의 주문, 배송 및 환불 등과 관련한 의무와 책임은 각 입점 판매자에게 있습니다.</p>
        </div>

      </div>
    </footer>
  );
};
