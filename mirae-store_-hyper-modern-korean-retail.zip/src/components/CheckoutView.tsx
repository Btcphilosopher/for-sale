import React, { useState } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { CreditCard, Truck, ShieldCheck, CheckCircle2, Ticket, MapPin, User, Phone } from 'lucide-react';

export const CheckoutView: React.FC = () => {
  const {
    cart,
    userProfile,
    activeCoupon,
    coupons,
    setActiveCoupon,
    createOrder,
    setCurrentView,
    addToast,
  } = useECommerce();

  const [recipient, setRecipient] = useState({
    name: userProfile.name,
    phone: userProfile.phone,
    zipcode: '06132',
    address: '서울특별시 강남구 테헤란로 152 (역삼동)',
    addressDetail: '강남파이낸스센터 18층',
    deliveryMemo: '부재 시 문 앞에 놓아주세요.',
  });

  const [paymentMethod, setPaymentMethod] = useState<'카카오페이' | '네이버페이' | '토스페이' | '신용카드' | '삼성페이'>('카카오페이');
  const [pointsToUse, setPointsToUse] = useState<number>(0);

  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  let couponDiscount = 0;
  if (activeCoupon) {
    if (activeCoupon.discountType === 'amount') {
      couponDiscount = activeCoupon.discountValue;
    } else {
      couponDiscount = Math.round((subtotal * activeCoupon.discountValue) / 100);
    }
  }

  const shippingFee = subtotal >= 50000 || subtotal === 0 ? 0 : 3000;
  const totalAmount = Math.max(0, subtotal - couponDiscount - pointsToUse + shippingFee);

  const formatPrice = (p: number) => p.toLocaleString('ko-KR') + '원';

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) {
      addToast('주문할 상품이 없습니다.', 'warning');
      return;
    }
    if (!recipient.name || !recipient.phone || !recipient.address) {
      addToast('배송지 정보를 모두 입력해주세요.', 'warning');
      return;
    }

    createOrder({
      items: cart,
      subtotalAmount: subtotal,
      discountAmount: couponDiscount + pointsToUse,
      shippingFee,
      totalAmount,
      paymentMethod,
      recipient,
    });
  };

  const handleUseAllPoints = () => {
    const maxPoints = Math.min(userProfile.points, subtotal - couponDiscount);
    setPointsToUse(maxPoints);
    addToast(`적립금 ${maxPoints.toLocaleString()}P가 적용되었습니다.`);
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 md:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="border-b border-zinc-800 pb-4">
        <h1 className="text-2xl font-black text-white font-mono tracking-tight">주문 / 결제</h1>
        <p className="text-xs text-zinc-400 font-mono">ORDER & CHECKOUT</p>
      </div>

      <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Form Area (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* 배송지 정보 */}
          <div className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2 text-sm font-bold text-white font-mono">
                <MapPin className="w-4 h-4 text-indigo-400" />
                <span>배송지 정보</span>
              </div>
              <button
                type="button"
                onClick={() => addToast('기본 배송지로 자동 설정되었습니다.', 'info')}
                className="text-xs text-indigo-400 hover:text-indigo-300"
              >
                기본배송지 불러오기
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-zinc-400 block mb-1">받는 사람</label>
                  <input
                    type="text"
                    required
                    value={recipient.name}
                    onChange={(e) => setRecipient({ ...recipient, name: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-zinc-400 block mb-1">연락처</label>
                  <input
                    type="text"
                    required
                    value={recipient.phone}
                    onChange={(e) => setRecipient({ ...recipient, phone: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-zinc-400 block mb-1">우편번호 & 주소</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    readOnly
                    value={recipient.zipcode}
                    className="w-28 p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => addToast('우편번호 검색 시뮬레이션: 서울시 강남구 테헤란로 152', 'info')}
                    className="px-4 py-2.5 rounded-xl bg-zinc-800 text-zinc-200 hover:text-white text-xs font-bold"
                  >
                    주소 검색
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={recipient.address}
                  onChange={(e) => setRecipient({ ...recipient, address: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white mb-2"
                />
                <input
                  type="text"
                  value={recipient.addressDetail}
                  onChange={(e) => setRecipient({ ...recipient, addressDetail: e.target.value })}
                  placeholder="상세주소 입력"
                  className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white"
                />
              </div>

              <div>
                <label className="text-zinc-400 block mb-1">배송 요청사항</label>
                <select
                  value={recipient.deliveryMemo}
                  onChange={(e) => setRecipient({ ...recipient, deliveryMemo: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white"
                >
                  <option value="부재 시 문 앞에 놓아주세요.">부재 시 문 앞에 놓아주세요.</option>
                  <option value="배송 전 연락해 주세요.">배송 전 연락해 주세요.</option>
                  <option value="경비실에 맡겨 주세요.">경비실에 맡겨 주세요.</option>
                  <option value="택배함에 넣어 주세요.">택배함에 넣어 주세요.</option>
                </select>
              </div>
            </div>
          </div>

          {/* 포인트 / 적립금 사용 */}
          <div className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <span className="text-sm font-bold text-white font-mono">적립금 사용</span>
              <span className="text-xs text-indigo-400 font-mono">
                보유 적립금: {userProfile.points.toLocaleString()}P
              </span>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="number"
                max={userProfile.points}
                value={pointsToUse || ''}
                onChange={(e) => setPointsToUse(Number(e.target.value))}
                placeholder="0"
                className="flex-1 p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-white font-mono text-sm"
              />
              <button
                type="button"
                onClick={handleUseAllPoints}
                className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs text-white font-bold"
              >
                전액 사용
              </button>
            </div>
          </div>

          {/* 결제 수단 선택 */}
          <div className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 space-y-4">
            <div className="text-sm font-bold text-white font-mono border-b border-zinc-800 pb-3">
              결제 방법
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                { id: '카카오페이', label: '카카오페이', color: 'bg-yellow-400 text-zinc-950' },
                { id: '네이버페이', label: '네이버페이', color: 'bg-emerald-500 text-white' },
                { id: '토스페이', label: '토스페이', color: 'bg-blue-500 text-white' },
                { id: '삼성페이', label: '삼성페이', color: 'bg-indigo-600 text-white' },
                { id: '신용카드', label: '신용카드', color: 'bg-zinc-800 text-white' },
              ].map((pm) => {
                const isSelected = paymentMethod === pm.id;
                return (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => setPaymentMethod(pm.id as any)}
                    className={`p-3.5 rounded-2xl border text-xs font-bold transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-400 shadow-lg shadow-indigo-600/30'
                        : 'bg-zinc-950 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <span>{pm.label}</span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-white" />}
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right Summary Area (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Order Items Summary */}
          <div className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 space-y-4">
            <h3 className="text-sm font-bold text-white font-mono border-b border-zinc-800 pb-3">
              주문 상품 정보 ({cart.length})
            </h3>

            <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
              {cart.map((item) => (
                <div key={item.id} className="flex items-center gap-3 text-xs">
                  <img src={item.product.image} alt={item.product.name} className="w-12 h-12 rounded-xl object-cover shrink-0 bg-zinc-950" />
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-white truncate">{item.product.name}</p>
                    <p className="text-[10px] text-zinc-400 font-mono">수량 {item.quantity}개</p>
                  </div>
                  <span className="font-mono font-bold text-white">
                    {formatPrice(item.product.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>

            {/* Price Calculations */}
            <div className="pt-4 border-t border-zinc-800 space-y-2 text-xs">
              <div className="flex justify-between text-zinc-400">
                <span>상품금액</span>
                <span className="font-mono text-white">{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>할인금액</span>
                <span className="font-mono text-rose-400">-{formatPrice(couponDiscount + pointsToUse)}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>배송비</span>
                <span className="font-mono text-white">{shippingFee === 0 ? '0원' : formatPrice(shippingFee)}</span>
              </div>
              <div className="pt-3 border-t border-zinc-800 flex justify-between items-baseline text-base font-bold text-white">
                <span>최종 결제금액</span>
                <span className="text-xl text-indigo-400 font-mono font-black">{formatPrice(totalAmount)}</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition-all"
            >
              {formatPrice(totalAmount)} 결제하기
            </button>

            <p className="text-[10px] text-zinc-500 text-center">
              위 주문 내용을 확인하였으며 결제 진행에 동의합니다.
            </p>
          </div>

        </div>

      </form>

    </div>
  );
};
