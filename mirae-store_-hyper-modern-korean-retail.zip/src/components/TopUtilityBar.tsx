import React from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { Heart, ShoppingBag, Sparkles } from 'lucide-react';

export const TopUtilityBar: React.FC = () => {
  const {
    cartTotalCount,
    wishlistIds,
    setCurrentView,
    setSelectedCategoryId,
    setSearchQuery,
    addToast,
  } = useECommerce();

  const handleDownloadApp = () => {
    addToast('미래상점 앱 다운로드 링크가 SMS로 발송되었습니다.', 'info');
  };

  const handleGoHome = () => {
    setSelectedCategoryId(null);
    setSearchQuery('');
    setCurrentView('home');
  };

  return (
    <div className="bg-zinc-950 border-b border-zinc-800/80 text-xs text-zinc-400 py-1.5 px-4 md:px-8">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Left Utilities */}
        <div className="hidden md:flex items-center gap-4">
          <button
            onClick={handleDownloadApp}
            className="hover:text-zinc-200 transition-colors flex items-center gap-1"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
            앱 다운로드
          </button>
          <span className="text-zinc-800">|</span>
          <button
            onClick={() => addToast('고객센터 1588-2026 (평일 09:00 - 18:00)', 'info')}
            className="hover:text-zinc-200 transition-colors"
          >
            고객센터
          </button>
          <span className="text-zinc-800">|</span>
          <button
            onClick={() => addToast('공지: 2026 써머 하이퍼 페스타 오픈 안내', 'info')}
            className="hover:text-zinc-200 transition-colors"
          >
            공지사항
          </button>
        </div>

        {/* Center Banner */}
        <div
          onClick={handleGoHome}
          className="cursor-pointer mx-auto md:mx-0 flex items-center gap-1.5 font-medium text-zinc-300 hover:text-indigo-300 transition-colors"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-spin-slow" />
          <span>지금 가입하면 10% 할인 쿠폰 + 무료배송 혜택</span>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('mypage')}
            className="hover:text-zinc-100 transition-colors"
          >
            로그인
          </button>
          <span className="text-zinc-800">|</span>
          <button
            onClick={() => setCurrentView('mypage')}
            className="hover:text-zinc-100 transition-colors"
          >
            회원가입
          </button>
          <span className="text-zinc-800">|</span>
          
          {/* Wishlist */}
          <button
            onClick={() => setCurrentView('mypage')}
            className="relative hover:text-zinc-100 transition-colors flex items-center gap-1"
            title="찜한 상품"
          >
            <Heart className="w-3.5 h-3.5 text-zinc-300 hover:text-rose-400" />
            {wishlistIds.length > 0 && (
              <span className="bg-rose-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {wishlistIds.length}
              </span>
            )}
          </button>

          {/* Cart Counter */}
          <button
            onClick={() => setCurrentView('cart')}
            className="relative hover:text-zinc-100 transition-colors flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded-full"
            title="장바구니"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-zinc-200 font-semibold">{cartTotalCount}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
