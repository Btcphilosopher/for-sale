import React from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { X, Eye, Trash2, ShoppingBag } from 'lucide-react';

export const RecentlyViewedDrawer: React.FC = () => {
  const {
    isRecentlyViewedOpen,
    setIsRecentlyViewedOpen,
    recentlyViewedIds,
    products,
    openProductDetail,
    clearRecentlyViewed,
    addToCart,
  } = useECommerce();

  if (!isRecentlyViewedOpen) return null;

  const recentProducts = recentlyViewedIds
    .map((id) => products.find((p) => p.id === id))
    .filter((p): p is typeof products[0] => p !== undefined);

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-zinc-950 border-l border-zinc-800 h-full flex flex-col shadow-2xl">
        
        {/* Drawer Header */}
        <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Eye className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">최근 본 상품</h3>
              <p className="text-xs text-zinc-400 font-mono">RECENTLY VIEWED ({recentProducts.length})</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {recentProducts.length > 0 && (
              <button
                onClick={clearRecentlyViewed}
                className="p-2 text-zinc-500 hover:text-rose-400 transition-colors"
                title="기록 전체 삭제"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => setIsRecentlyViewedOpen(false)}
              className="p-2 text-zinc-400 hover:text-white rounded-xl bg-zinc-900 hover:bg-zinc-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {recentProducts.length > 0 ? (
            recentProducts.map((product) => (
              <div
                key={product.id}
                onClick={() => {
                  setIsRecentlyViewedOpen(false);
                  openProductDetail(product.id);
                }}
                className="group p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 hover:border-indigo-500/40 hover:bg-zinc-850 cursor-pointer flex items-center gap-3 transition-all"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-16 h-16 rounded-xl object-cover shrink-0 bg-zinc-950"
                />
                <div className="flex-1 min-w-0 space-y-0.5">
                  <span className="text-[10px] text-indigo-400 font-mono block">
                    {product.brand}
                  </span>
                  <h4 className="text-xs font-bold text-white truncate group-hover:text-indigo-300 transition-colors">
                    {product.name}
                  </h4>
                  <p className="text-xs font-extrabold text-white font-mono">
                    {product.price.toLocaleString('ko-KR')}원
                  </p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    addToCart(product, 1);
                  }}
                  className="p-2 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white hover:bg-indigo-600 transition-colors"
                  title="장바구니 담기"
                >
                  <ShoppingBag className="w-4 h-4" />
                </button>
              </div>
            ))
          ) : (
            <div className="text-center py-20 text-zinc-500 space-y-3">
              <Eye className="w-10 h-10 mx-auto text-zinc-700 stroke-1" />
              <p className="text-sm">최근 본 상품이 없습니다.</p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
