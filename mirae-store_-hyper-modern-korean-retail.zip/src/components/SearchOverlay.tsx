import React, { useState, useEffect } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { TRENDING_SEARCH_KEYWORDS, CATEGORIES } from '../data/mockData';
import { Search, X, Clock, Flame, Tag, Trash2, ArrowRight } from 'lucide-react';

const RECENT_SEARCHES_KEY = 'mirae_recent_searches_v1';

export const SearchOverlay: React.FC = () => {
  const {
    isSearchOpen,
    setIsSearchOpen,
    performSearch,
    products,
    openProductDetail,
    setSelectedCategoryId,
    setCurrentView,
  } = useECommerce();

  const [inputVal, setInputVal] = useState('');
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(RECENT_SEARCHES_KEY);
      return saved ? JSON.parse(saved) : ['스마트워치', '노이즈 캔슬링', '보이드 향수'];
    } catch {
      return ['스마트워치', '노이즈 캔슬링', '보이드 향수'];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(recentSearches));
    } catch (e) {
      console.error(e);
    }
  }, [recentSearches]);

  if (!isSearchOpen) return null;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputVal.trim()) {
      addRecentSearch(inputVal.trim());
      performSearch(inputVal.trim());
    }
  };

  const handleKeywordClick = (keyword: string) => {
    addRecentSearch(keyword);
    performSearch(keyword);
  };

  const addRecentSearch = (kw: string) => {
    setRecentSearches((prev) => {
      const filtered = prev.filter((item) => item !== kw);
      return [kw, ...filtered].slice(0, 10);
    });
  };

  const removeRecentSearch = (kw: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setRecentSearches((prev) => prev.filter((item) => item !== kw));
  };

  const clearAllRecent = () => {
    setRecentSearches([]);
  };

  const handleCategoryClick = (catId: string) => {
    setSelectedCategoryId(catId);
    setIsSearchOpen(false);
    setCurrentView('category');
  };

  // Predictive search suggestions
  const liveSuggestions = inputVal.trim()
    ? products.filter((p) =>
        p.name.toLowerCase().includes(inputVal.toLowerCase()) ||
        p.brand.toLowerCase().includes(inputVal.toLowerCase()) ||
        p.categoryKr.toLowerCase().includes(inputVal.toLowerCase())
      ).slice(0, 5)
    : [];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/85 backdrop-blur-md pt-12 md:pt-20 px-4 animate-in fade-in duration-200">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl">
        
        {/* Search Input Box */}
        <form onSubmit={handleSearchSubmit} className="relative p-4 md:p-6 border-b border-zinc-800 bg-zinc-900/60">
          <div className="relative flex items-center">
            <Search className="absolute left-4 w-5 h-5 text-indigo-400" />
            <input
              type="text"
              autoFocus
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="검색어를 입력하세요 (예: 스마트워치, 이어폰, 향수)"
              className="w-full bg-zinc-900 border border-zinc-700/80 focus:border-indigo-500 rounded-2xl py-3.5 pl-12 pr-12 text-base text-white placeholder-zinc-500 focus:outline-none transition-all font-mono"
            />
            {inputVal && (
              <button
                type="button"
                onClick={() => setInputVal('')}
                className="absolute right-12 text-zinc-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={() => setIsSearchOpen(false)}
              className="absolute right-3 text-zinc-400 hover:text-white p-1.5 rounded-xl hover:bg-zinc-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </form>

        {/* Predictive Suggestions while typing */}
        {inputVal.trim().length > 0 ? (
          <div className="p-6 max-h-[60vh] overflow-y-auto space-y-3">
            <p className="text-xs font-mono text-zinc-400 uppercase tracking-wider mb-2">
              실시간 연관 상품 ({liveSuggestions.length})
            </p>
            {liveSuggestions.length > 0 ? (
              liveSuggestions.map((prod) => (
                <div
                  key={prod.id}
                  onClick={() => {
                    setIsSearchOpen(false);
                    openProductDetail(prod.id);
                  }}
                  className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800 hover:border-indigo-500/50 hover:bg-zinc-850 cursor-pointer flex items-center gap-4 transition-all"
                >
                  <img src={prod.image} alt={prod.name} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                  <div className="flex-1 min-w-0">
                    <span className="text-[10px] text-indigo-400 font-mono block">{prod.brand}</span>
                    <h4 className="text-sm font-bold text-white truncate">{prod.name}</h4>
                  </div>
                  <span className="text-sm font-extrabold text-indigo-300 font-mono">
                    {prod.price.toLocaleString('ko-KR')}원
                  </span>
                </div>
              ))
            ) : (
              <p className="text-sm text-zinc-500 text-center py-8">
                일치하는 연관 상품이 없습니다. 엔터를 눌러 전체 검색 결과를 확인하세요.
              </p>
            )}
          </div>
        ) : (
          /* Default State: Recent, Popular, Categories */
          <div className="p-6 max-h-[65vh] overflow-y-auto space-y-6">
            
            {/* 최근 검색어 */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-zinc-300 font-mono">
                  <Clock className="w-3.5 h-3.5 text-indigo-400" />
                  <span>최근 검색어</span>
                </div>
                {recentSearches.length > 0 && (
                  <button
                    onClick={clearAllRecent}
                    className="text-[11px] text-zinc-500 hover:text-zinc-300 flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>전체 삭제</span>
                  </button>
                )}
              </div>

              {recentSearches.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {recentSearches.map((kw, i) => (
                    <div
                      key={i}
                      onClick={() => handleKeywordClick(kw)}
                      className="px-3.5 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 hover:text-white hover:border-indigo-500/50 cursor-pointer flex items-center gap-2 transition-all"
                    >
                      <span>{kw}</span>
                      <button
                        onClick={(e) => removeRecentSearch(kw, e)}
                        className="text-zinc-500 hover:text-rose-400"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-zinc-500">최근 검색한 내역이 없습니다.</p>
              )}
            </div>

            {/* 인기 검색어 */}
            <div>
              <div className="flex items-center gap-1.5 text-xs font-bold text-zinc-300 font-mono mb-3">
                <Flame className="w-3.5 h-3.5 text-rose-500" />
                <span>인기 검색어</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {TRENDING_SEARCH_KEYWORDS.map((kw, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleKeywordClick(kw)}
                    className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800 hover:border-indigo-500/40 text-left text-xs text-zinc-300 hover:text-white flex items-center gap-2 transition-all"
                  >
                    <span className="font-mono font-bold text-indigo-400 w-4 text-center">
                      {idx + 1}
                    </span>
                    <span className="truncate">{kw}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 추천 카테고리 */}
            <div>
              <div className="flex items-center gap-1.5 text-xs font-bold text-zinc-300 font-mono mb-3">
                <Tag className="w-3.5 h-3.5 text-cyan-400" />
                <span>추천 카테고리</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.slice(0, 6).map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => handleCategoryClick(cat.id)}
                    className="px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-cyan-500/40 text-xs text-zinc-300 hover:text-cyan-300 flex items-center gap-1.5 transition-all"
                  >
                    <span>{cat.name}</span>
                    <ArrowRight className="w-3 h-3 text-zinc-500" />
                  </button>
                ))}
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
