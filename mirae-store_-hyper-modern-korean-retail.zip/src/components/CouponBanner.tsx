import React from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { Sparkles, CheckCircle2, Ticket, ArrowDown } from 'lucide-react';

export const CouponBanner: React.FC = () => {
  const { coupons, claimCoupon } = useECommerce();

  const welcomeCoupon = coupons.find((c) => c.code === 'WELCOME10K') || coupons[0];

  const handleClaim = () => {
    if (welcomeCoupon) {
      claimCoupon(welcomeCoupon.id);
    }
  };

  return (
    <section className="w-full max-w-7xl mx-auto px-4 md:px-8 py-6">
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-indigo-950 via-zinc-950 to-purple-950 border border-indigo-500/30 p-8 md:p-12 shadow-2xl group">
        
        {/* Background Decorative Glow */}
        <div className="absolute -top-24 -left-24 w-72 h-72 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
          
          {/* Left Text */}
          <div className="space-y-3 text-center md:text-left max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-mono uppercase font-bold">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>NEW MEMBER EXCLUSIVE BENIFITS</span>
            </div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight font-mono">
              신규 회원 혜택
            </h2>

            <p className="text-zinc-300 text-base md:text-lg">
              지금 가입 및 첫 로그인 시 <span className="text-indigo-400 font-extrabold font-mono">최대 10,000원 할인 쿠폰</span> + 무료배송 자동 적용
            </p>

            <p className="text-xs text-zinc-500">
              * 50,000원 이상 결제 시 사용 가능 / 발급 후 30일간 유효
            </p>
          </div>

          {/* Right Coupon Visual & Claim Button */}
          <div className="flex flex-col sm:flex-row items-center gap-4 bg-zinc-900/80 border border-zinc-800 p-4 rounded-2xl backdrop-blur-md">
            <div className="flex items-center gap-4 px-2">
              <div className="p-3.5 rounded-2xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                <Ticket className="w-8 h-8" />
              </div>
              <div className="text-left">
                <span className="text-xs text-zinc-400 font-mono block">COUPON CODE</span>
                <span className="text-xl font-extrabold text-white font-mono block">
                  10,000 KRW
                </span>
                <span className="text-[11px] text-indigo-300 font-mono">WELCOME10K</span>
              </div>
            </div>

            <button
              onClick={handleClaim}
              disabled={welcomeCoupon?.isClaimed}
              className={`px-6 py-3.5 rounded-xl font-bold text-sm transition-all shadow-xl flex items-center gap-2 ${
                welcomeCoupon?.isClaimed
                  ? 'bg-zinc-800 text-zinc-400 cursor-not-allowed border border-zinc-700'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30 hover:scale-105'
              }`}
            >
              {welcomeCoupon?.isClaimed ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>발급 완료</span>
                </>
              ) : (
                <>
                  <span>쿠폰 받기</span>
                  <ArrowDown className="w-4 h-4 animate-bounce" />
                </>
              )}
            </button>
          </div>

        </div>
      </div>
    </section>
  );
};
