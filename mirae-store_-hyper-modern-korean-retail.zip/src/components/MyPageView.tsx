import React, { useState } from 'react';
import { useECommerce } from '../context/ECommerceContext';
import { ProductCard } from './ProductCard';
import { User, Package, Heart, Ticket, Eye, Sparkles, Truck, ChevronRight } from 'lucide-react';

export const MyPageView: React.FC = () => {
  const {
    userProfile,
    orders,
    wishlistIds,
    recentlyViewedIds,
    products,
    coupons,
    claimCoupon,
    setCurrentView,
  } = useECommerce();

  const [activeTab, setActiveTab] = useState<'orders' | 'wishlist' | 'recent' | 'coupons'>('orders');

  const wishlistedProducts = wishlistIds
    .map((id) => products.find((p) => p.id === id))
    .filter((p): p is typeof products[0] => p !== undefined);

  const recentProducts = recentlyViewedIds
    .map((id) => products.find((p) => p.id === id))
    .filter((p): p is typeof products[0] => p !== undefined);

  const formatPrice = (p: number) => p.toLocaleString('ko-KR') + '원';

  return (
    <div className="w-full max-w-7xl mx-auto px-4 md:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      
      {/* Profile Dashboard Banner */}
      <div className="p-6 md:p-8 rounded-3xl bg-gradient-to-r from-zinc-900 via-zinc-950 to-indigo-950/60 border border-zinc-800 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 text-indigo-400 flex items-center justify-center font-mono font-bold text-xl shrink-0">
            {userProfile.name[0]}
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-xl font-black text-white font-mono">{userProfile.name}님</h1>
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-mono font-bold border border-indigo-500/30">
                {userProfile.tier}
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-mono">{userProfile.email}</p>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-4 w-full md:w-auto pt-4 md:pt-0 border-t md:border-t-0 border-zinc-800">
          <div className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800 text-center min-w-28">
            <span className="text-[10px] text-zinc-400 font-mono block">적립 포인트</span>
            <span className="text-sm font-extrabold text-indigo-400 font-mono block">
              {userProfile.points.toLocaleString()}P
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800 text-center min-w-28">
            <span className="text-[10px] text-zinc-400 font-mono block">보유 쿠폰</span>
            <span className="text-sm font-extrabold text-purple-400 font-mono block">
              {coupons.filter((c) => c.isClaimed).length}장
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800 text-center min-w-28">
            <span className="text-[10px] text-zinc-400 font-mono block">찜한 상품</span>
            <span className="text-sm font-extrabold text-rose-400 font-mono block">
              {wishlistIds.length}개
            </span>
          </div>
        </div>

      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-zinc-800 font-bold text-sm">
        <button
          onClick={() => setActiveTab('orders')}
          className={`pb-4 px-6 border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'orders'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>주문내역/배송조회 ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('wishlist')}
          className={`pb-4 px-6 border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'wishlist'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>찜한 상품 ({wishlistIds.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('recent')}
          className={`pb-4 px-6 border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'recent'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Eye className="w-4 h-4" />
          <span>최근 본 상품 ({recentlyViewedIds.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('coupons')}
          className={`pb-4 px-6 border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'coupons'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Ticket className="w-4 h-4" />
          <span>쿠폰함 ({coupons.length})</span>
        </button>
      </div>

      {/* Tab Panels */}
      <div>
        
        {/* 주문내역 */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            {orders.length > 0 ? (
              orders.map((order) => (
                <div key={order.id} className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800 pb-3 text-xs">
                    <div>
                      <span className="text-zinc-400 font-mono mr-3">주문일자: {order.date}</span>
                      <span className="font-bold text-white font-mono">주문번호: {order.orderNumber}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 font-bold text-xs border border-indigo-500/30">
                        {order.status}
                      </span>
                      {order.trackingNumber && (
                        <span className="text-zinc-400 font-mono">운송장: {order.trackingNumber}</span>
                      )}
                    </div>
                  </div>

                  <div className="space-y-3">
                    {order.items.map((item) => (
                      <div key={item.id} className="flex items-center gap-4 text-xs">
                        <img src={item.product.image} alt={item.product.name} className="w-14 h-14 rounded-xl object-cover shrink-0 bg-zinc-950" />
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-white truncate">{item.product.name}</p>
                          <p className="text-[11px] text-zinc-400 font-mono">
                            수량 {item.quantity}개 / {formatPrice(item.product.price)}
                          </p>
                        </div>
                        <span className="font-mono font-bold text-white">
                          {formatPrice(item.product.price * item.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs">
                    <span className="text-zinc-400">결제수단: {order.paymentMethod}</span>
                    <span className="text-sm font-bold text-white">
                      총 결제금액 <strong className="text-indigo-400 font-mono text-base">{formatPrice(order.totalAmount)}</strong>
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-20 text-zinc-500">주문 내역이 없습니다.</div>
            )}
          </div>
        )}

        {/* 찜한 상품 Grid */}
        {activeTab === 'wishlist' && (
          <div>
            {wishlistedProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {wishlistedProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 text-zinc-500">찜한 상품이 없습니다.</div>
            )}
          </div>
        )}

        {/* 최근 본 상품 Grid */}
        {activeTab === 'recent' && (
          <div>
            {recentProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {recentProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 text-zinc-500">최근 본 상품이 없습니다.</div>
            )}
          </div>
        )}

        {/* 쿠폰함 */}
        {activeTab === 'coupons' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {coupons.map((c) => (
              <div key={c.id} className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] text-indigo-400 font-mono font-bold block">{c.code}</span>
                  <h4 className="text-sm font-bold text-white">{c.name}</h4>
                  <p className="text-xs text-zinc-400">{c.description}</p>
                  <p className="text-[10px] text-zinc-500 font-mono">유효기간: ~ {c.expiryDate}</p>
                </div>

                <button
                  onClick={() => claimCoupon(c.id)}
                  disabled={c.isClaimed}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                    c.isClaimed
                      ? 'bg-zinc-800 text-zinc-500 cursor-default'
                      : 'bg-indigo-600 text-white hover:bg-indigo-500'
                  }`}
                >
                  {c.isClaimed ? '보유중' : '쿠폰 받기'}
                </button>
              </div>
            ))}
          </div>
        )}

      </div>

    </div>
  );
};
