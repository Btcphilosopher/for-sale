export type Language = 'ar' | 'en';

export type Currency = 'SAR' | 'AED' | 'QAR' | 'KWD' | 'BHD' | 'OMR';

export interface Country {
  code: string;
  name_ar: string;
  name_en: string;
  flag: string;
  currency: Currency;
  currencySymbol_ar: string;
  currencySymbol_en: string;
  exchangeRateToSAR: number; // SAR as base 1.0
  vatRate: number; // e.g. 0.15 for 15%
  deliveryDays: string;
  phonePrefix: string;
  cities: string[];
}

export interface ProductVariant {
  id: string;
  name_ar: string;
  name_en: string;
  type: 'color' | 'size' | 'volume';
  value: string;
  inStock: boolean;
}

export interface ProductReview {
  id: string;
  author: string;
  city: string;
  rating: number;
  date: string;
  title_ar: string;
  title_en: string;
  comment_ar: string;
  comment_en: string;
  verified: boolean;
}

export interface Product {
  id: string;
  brand: string;
  name_ar: string;
  name_en: string;
  description_ar: string;
  description_en: string;
  details_ar: string[];
  details_en: string[];
  category: string; // e.g., 'fashion', 'perfumes', 'watches', 'handbags', 'electronics', 'home'
  subcategory_ar: string;
  subcategory_en: string;
  priceSAR: number; // Base price in SAR
  originalPriceSAR?: number;
  discountPercentage?: number;
  images: string[];
  videoUrl?: string;
  rating: number;
  reviewCount: number;
  stock: number;
  isNewArrival?: boolean;
  isBestSeller?: boolean;
  isExclusive?: boolean;
  expressDelivery: boolean;
  tags: string[];
  variants?: ProductVariant[];
  reviews?: ProductReview[];
}

export interface Category {
  id: string;
  name_ar: string;
  name_en: string;
  subtitle_ar: string;
  subtitle_en: string;
  iconName: string;
  image: string;
  popularSearchTerms: string[];
  subcategories: {
    id: string;
    name_ar: string;
    name_en: string;
    items?: { id: string; name_ar: string; name_en: string }[];
  }[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
  selectedVolume?: string;
}

export interface OrderItem {
  productId: string;
  name_ar: string;
  name_en: string;
  priceSAR: number;
  quantity: number;
  image: string;
  variantInfo?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  date: string;
  status: 'confirmed' | 'processing' | 'shipped' | 'delivered';
  status_ar: string;
  status_en: string;
  items: OrderItem[];
  totalSAR: number;
  shippingSAR: number;
  vatSAR: number;
  discountSAR: number;
  paymentMethod: string;
  shippingAddress: {
    name: string;
    city: string;
    district: string;
    street: string;
    phone: string;
    country: string;
  };
  trackingNumber: string;
  estimatedDelivery: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  country: string;
  city: string;
  rewardPoints: number;
  membershipTier: 'Silver' | 'Gold' | 'VIP Platinum';
  membershipTier_ar: string;
  savedAddresses: {
    id: string;
    title_ar: string;
    title_en: string;
    name: string;
    city: string;
    address: string;
    phone: string;
    isDefault: boolean;
  }[];
  paymentMethods: {
    id: string;
    type: 'visa' | 'mastercard' | 'mada' | 'applepay';
    lastFour: string;
    expiry: string;
    isDefault: boolean;
  }[];
  coupons: {
    code: string;
    discount_ar: string;
    discount_en: string;
    minSpendSAR: number;
    expiryDate: string;
  }[];
}

export type ActivePage = 
  | 'home' 
  | 'product-detail' 
  | 'category' 
  | 'cart' 
  | 'checkout' 
  | 'account' 
  | 'search-results' 
  | 'wishlist'
  | 'track-order'
  | 'help-center';
