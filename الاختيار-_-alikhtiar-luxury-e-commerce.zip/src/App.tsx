import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { HeroCarousel } from './components/HeroCarousel';
import { CategoryGrid } from './components/CategoryGrid';
import { ProductGrid } from './components/ProductGrid';
import { PromotionBanner } from './components/PromotionBanner';
import { ServicePanel } from './components/ServicePanel';
import { ProductDetailPage } from './components/ProductDetailPage';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CategoryPage } from './components/CategoryPage';
import { CheckoutPage } from './components/CheckoutPage';
import { AccountDashboard } from './components/AccountDashboard';
import { HelpCenterPage } from './components/HelpCenterPage';
import { CartDrawer } from './components/CartDrawer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { Footer } from './components/Footer';
import { Sparkles, X } from 'lucide-react';

const MainContent: React.FC = () => {
  const { activePage, toast, hideToast } = useApp();
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-[#FBF9F5] text-[#121110] selection:bg-[#C5A059] selection:text-white">
      
      {/* Toast Notification Alert */}
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-[#231F1D] text-white px-5 py-3 rounded-2xl border border-[#C5A059] shadow-2xl flex items-center gap-3 animate-fadeIn">
          <Sparkles className="w-4 h-4 text-[#DFBF7A]" />
          <div className="text-xs">
            <span className="font-bold text-[#DFBF7A] block">{toast.title}</span>
            <span className="text-gray-300">{toast.message}</span>
          </div>
          <button onClick={hideToast} className="text-gray-400 hover:text-white ms-2">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Primary Header */}
      <Header onOpenCart={() => setIsCartDrawerOpen(true)} />

      {/* Dynamic Page Views */}
      <main className="flex-1">
        {activePage === 'home' && (
          <>
            <HeroCarousel />
            <CategoryGrid />
            <ProductGrid />
            <PromotionBanner />
            <ServicePanel />
          </>
        )}

        {activePage === 'category' && <CategoryPage />}
        {activePage === 'product-detail' && <ProductDetailPage />}
        {activePage === 'wishlist' && <AccountDashboard />}
        {activePage === 'cart' && <CheckoutPage />}
        {activePage === 'checkout' && <CheckoutPage />}
        {activePage === 'account' && <AccountDashboard />}
        {activePage === 'help-center' && <HelpCenterPage />}
        {activePage === 'track-order' && <HelpCenterPage />}
      </main>

      {/* Primary Footer */}
      <Footer />

      {/* Mobile Sticky Bottom Navigation */}
      <MobileBottomNav onOpenCart={() => setIsCartDrawerOpen(true)} />

      {/* Global Drawers & Modals */}
      <CartDrawer isOpen={isCartDrawerOpen} onClose={() => setIsCartDrawerOpen(false)} />
      <ProductDetailModal />

    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}

export default App;
