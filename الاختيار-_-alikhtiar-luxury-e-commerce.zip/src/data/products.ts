import { Product } from '../types';

export const PRODUCTS: Product[] = [
  {
    id: 'p-1',
    brand: 'ROYAL HOROLOGY',
    name_ar: 'ساعة كلاسيك فاخرة',
    name_en: 'Classic Luxury Timepiece',
    description_ar: 'ساعة يد كلاسيكية مصنوعة من الفولاذ المقاوم للصدأ ومطلية بالذهب الوردي 18 قيراط مع حزام جلد طبيعي فاخر وآلية حركة سويسرية أوتوماتيكية دقيقة.',
    description_en: 'A classic wrist watch crafted with 18k rose gold plating, genuine Italian leather strap, and precision Swiss automatic movement.',
    details_ar: [
      'آلية الحركة: أوتوماتيكية سويسرية',
      'قطر الهيكل: 41 مم',
      'حزام: جلد طبيعي فاخر بلون بني داكن',
      'مقاومة الماء: حتى 50 متراً',
      'الضمان: 5 سنوات ضمان دولي'
    ],
    details_en: [
      'Movement: Swiss Automatic',
      'Case Diameter: 41mm',
      'Strap: Genuine Dark Brown Italian Leather',
      'Water Resistance: 50m / 5 ATM',
      'Warranty: 5-Year International Warranty'
    ],
    category: 'watches',
    subcategory_ar: 'ساعات كلاسيكية',
    subcategory_en: 'Classic Watches',
    priceSAR: 1250,
    originalPriceSAR: 2000,
    discountPercentage: 37,
    images: [
      'https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?q=80&w=800&auto=format&fit=crop'
    ],
    rating: 4.9,
    reviewCount: 128,
    stock: 14,
    isBestSeller: true,
    expressDelivery: true,
    tags: ['ساعة', 'ساعات', 'ذهب', 'جلد', 'سويسرية', 'watch', 'luxury', 'timepiece'],
    variants: [
      { id: 'v1', name_ar: 'بني ذهبي', name_en: 'Brown Gold', type: 'color', value: '#A37C42', inStock: true },
      { id: 'v2', name_ar: 'أسود فضي', name_en: 'Black Silver', type: 'color', value: '#121110', inStock: true },
    ],
    reviews: [
      {
        id: 'r1',
        author: 'فيصل العتيبي',
        city: 'الرياض',
        rating: 5,
        date: '14 أغسطس 2026',
        title_ar: 'جودة استثنائية وسرعة توصيل',
        title_en: 'Exceptional Quality & Fast Delivery',
        comment_ar: 'الساعة أكثر جمالاً في الواقع! التغليف فاخر والتوصيل للرياض استغرق 24 ساعة فقط.',
        comment_en: 'The watch looks even better in person! Packaging was super premium and delivered to Riyadh in under 24 hours.',
        verified: true
      },
      {
        id: 'r2',
        author: 'سارة آل مكتوم',
        city: 'دبي',
        rating: 5,
        date: '02 أغسطس 2026',
        title_ar: 'هدية راقية جداً',
        title_en: 'Extremely refined gift',
        comment_ar: 'اشتريتها كهدية تخرج، الدقة والتشطيب النهائي يعكسان مستوى الفخامة الحقيقية.',
        comment_en: 'Bought it as a graduation gift. The craftsmanship reflects genuine luxury.',
        verified: true
      }
    ]
  },
  {
    id: 'p-2',
    brand: 'ATELIER DE L’OUD',
    name_ar: 'عطر عود فاخر',
    name_en: 'Royal Oud Extrait de Parfum',
    description_ar: 'نفحات ملكية من العود المروكي المعتق والورد الجوري والمسك الأبيض والعنبر الدافئ. عطر ذو ثبات عالي وفوحان آسر يلائم المناسبات الفاخرة.',
    description_en: 'A royal blend of aged Moroki Oud, Damask Rose, white musk, and amber. Long-lasting luxury projection crafted for grand occasions.',
    details_ar: [
      'الحجم: 100 مل',
      'التركيز: اكستري دي بارفان (ثبات أكثر من 24 ساعة)',
      'المكونات العليا: ورد جوري، زعفران إيراني',
      'المكونات الوسطى: عود مروكي معتق، عنبر دافئ',
      'قاعدة العطر: مسك أبيض، صندل هندي'
    ],
    details_en: [
      'Volume: 100 ml',
      'Concentration: Extrait de Parfum (24+ Hours Longevity)',
      'Top Notes: Damask Rose, Iranian Saffron',
      'Heart Notes: Aged Moroki Oud, Warm Amber',
      'Base Notes: White Musk, Indian Sandalwood'
    ],
    category: 'perfumes',
    subcategory_ar: 'العود والبخور الملكي',
    subcategory_en: 'Royal Oud & Incense',
    priceSAR: 580,
    originalPriceSAR: 920,
    discountPercentage: 37,
    images: [
      'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1547887537-6158d64c35b3?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1523293182086-7651a899d37f?q=80&w=800&auto=format&fit=crop'
    ],
    rating: 5.0,
    reviewCount: 310,
    stock: 28,
    isBestSeller: true,
    isExclusive: true,
    expressDelivery: true,
    tags: ['عطر', 'عطور', 'عود', 'مسك', 'بخور', 'perfume', 'oud', 'fragrance'],
    variants: [
      { id: 'v10', name_ar: '100 مل', name_en: '100 ml', type: 'volume', value: '100ml', inStock: true },
      { id: 'v11', name_ar: '50 مل', name_en: '50 ml', type: 'volume', value: '50ml', inStock: true },
    ],
    reviews: [
      {
        id: 'r3',
        author: 'خالد المنصوري',
        city: 'أبوظبي',
        rating: 5,
        date: '20 أغسطس 2026',
        title_ar: 'ثبات وفوحان لا يوصف',
        title_en: 'Unmatched Longevity & Projection',
        comment_ar: 'من أفضل عطور العود التي جربتها، ثباته يبقى في الملابس لأيام متواصلة.',
        comment_en: 'One of the best Oud fragrances I have used. Lasts on clothes for days.',
        verified: true
      }
    ]
  },
  {
    id: 'p-3',
    brand: 'MAISON D’ELITE',
    name_ar: 'حقيبة جلد فاخرة',
    name_en: 'Elegance Leather Handbag',
    description_ar: 'حقيبة يد نسائية مصنوعة يدويًا من أفضل أنواع الجلد الطبيعي الناعم مع إبزيم معدني بني اللون منقوش بالشعار وتفاصيل متقنة.',
    description_en: 'Handcrafted luxury women’s tote bag made from premium full-grain Italian leather featuring golden engraved hardware.',
    details_ar: [
      'الخامة: جلد طبيعي 100% عالي الجودة',
      'البطانة: شامواه حريري دافئ',
      'الأبعاد: 32 سم × 24 سم × 14 سم',
      'الألوان المتوفرة: بيج رملي، أسود ملكي، جملي',
      'حزام كتف قابل للإزالة والضبط'
    ],
    details_en: [
      'Material: 100% Premium Full-Grain Italian Leather',
      'Lining: Silk Suede Interior',
      'Dimensions: 32cm x 24cm x 14cm',
      'Available Colors: Sand Beige, Royal Black, Camel',
      'Includes Detachable Shoulder Strap'
    ],
    category: 'handbags',
    subcategory_ar: 'حقائب اليد الجلدية',
    subcategory_en: 'Leather Handbags',
    priceSAR: 1890,
    originalPriceSAR: 2850,
    discountPercentage: 34,
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=800&auto=format&fit=crop'
    ],
    rating: 4.8,
    reviewCount: 94,
    stock: 8,
    isBestSeller: true,
    expressDelivery: true,
    tags: ['حقيبة', 'حقائب', 'جلد', 'شنطة', 'موضة', 'handbag', 'bag', 'leather'],
    variants: [
      { id: 'v20', name_ar: 'بيج رملي', name_en: 'Sand Beige', type: 'color', value: '#EAE0D0', inStock: true },
      { id: 'v21', name_ar: 'أسود ملكي', name_en: 'Royal Black', type: 'color', value: '#121110', inStock: true },
    ]
  },
  {
    id: 'p-4',
    brand: 'SOLARIS LUXE',
    name_ar: 'نظارة شمسية فاخرة',
    name_en: 'Aviator Gold Sunglasses',
    description_ar: 'نظارات شمسية بتصميم أفياتور فاخر مع إطار مذهب خفيف الوزن وعدسات متدرجة تحمي من الأشعة فوق البنفسجية 100% بنقاء استثنائي.',
    description_en: 'Luxury aviator sunglasses with a lightweight gold-plated titanium frame and UV400 polarized gradient lenses.',
    details_ar: [
      'الإطار: تيتانيوم مطلي بالذهب 24 قيراط',
      'العدسات: مستقطبة ذات حماية UV400',
      'الوزن: 22 غرام شديدة الخفة',
      'الملحقات: حافظة جلدية فاخرة ومنديل تنظيف حريري'
    ],
    details_en: [
      'Frame: 24k Gold-Plated Titanium',
      'Lenses: Polarized UV400 Gradient',
      'Weight: 22g Ultra Lightweight',
      'Includes: Luxury Leather Case & Silk Cloth'
    ],
    category: 'sunglasses',
    subcategory_ar: 'نظارات شمسية',
    subcategory_en: 'Sunglasses',
    priceSAR: 620,
    originalPriceSAR: 950,
    discountPercentage: 35,
    images: [
      'https://images.unsplash.com/photo-1511499767150-a48a237f0083?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1572635196237-14b3f281503f?q=80&w=800&auto=format&fit=crop'
    ],
    rating: 4.7,
    reviewCount: 76,
    stock: 19,
    isNewArrival: true,
    expressDelivery: true,
    tags: ['نظارة', 'نظارات', 'شمسية', 'ذهب', 'sunglasses', 'eyewear'],
  },
  {
    id: 'p-5',
    brand: 'ALIKHTIAR ATELIER',
    name_ar: 'عباية حرير مطرزة بالخيوط الذهبية',
    name_en: 'Embroidered Silk Abaya',
    description_ar: 'عباية حصرية مصنوعة من الحرير الكريب الياباني الفاخر مع تطريز يدوي دقيق بالخيوط الذهبية المستوحاة من الهندسة المعمارية للخليج.',
    description_en: 'Exclusive luxury abaya crafted from Japanese silk crepe with hand-stitched gold thread embroidery inspired by Gulf architecture.',
    details_ar: [
      'القماش: حرير كريب ياباني 100%',
      'التطريز: خيوط ذهبية ناعمة يدويّة',
      'الملحقات: طقم مع شيلة حريرية مطابقة',
      'المقاسات المتوفرة: 52، 54، 56، 58، 60'
    ],
    details_en: [
      'Fabric: 100% Japanese Silk Crepe',
      'Embroidery: Fine Hand-Stitched Gold Thread',
      'Includes: Matching Silk Shayla / Scarf',
      'Available Sizes: 52, 54, 56, 58, 60'
    ],
    category: 'fashion',
    subcategory_ar: 'عبايات فاخرة',
    subcategory_en: 'Luxury Abayas',
    priceSAR: 2450,
    originalPriceSAR: 3200,
    discountPercentage: 23,
    images: [
      'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=800&auto=format&fit=crop'
    ],
    rating: 5.0,
    reviewCount: 42,
    stock: 5,
    isExclusive: true,
    expressDelivery: true,
    tags: ['عباية', 'عبايات', 'حرير', 'موضة', 'مطرزة', 'abaya', 'fashion', 'silk'],
    variants: [
      { id: 's54', name_ar: 'مقاس 54', name_en: 'Size 54', type: 'size', value: '54', inStock: true },
      { id: 's56', name_ar: 'مقاس 56', name_en: 'Size 56', type: 'size', value: '56', inStock: true },
      { id: 's58', name_ar: 'مقاس 58', name_en: 'Size 58', type: 'size', value: '58', inStock: true },
    ]
  },
  {
    id: 'p-6',
    brand: 'AURA SOUND',
    name_ar: 'سماعات رأس لاسلكية فاخرة',
    name_en: 'Wireless Noise-Canceling Headphones',
    description_ar: 'سماعات رأس عازلة للضوضاء بتقنية إلغاء الضوضاء الفائقة وتصميم من الألومنيوم وجلد الماعز الناعم وصوت ثلاثي الأبعاد عالي الدقة.',
    description_en: 'Premium active noise-canceling headphones crafted with brushed aluminum, leather earcups, and spatial 3D studio audio.',
    details_ar: [
      'عزل الضوضاء: تقنية ANC للتكيف مع المحيط',
      'عمر البطارية: يصل إلى 38 ساعة متواصلة',
      'الشحن: شحن سريع (10 دقائق تعطي 5 ساعات)',
      'التوصيل: بلوتوث 5.3 فائق السرعة'
    ],
    details_en: [
      'Noise Cancellation: Adaptive ANC',
      'Battery Life: Up to 38 hours playback',
      'Fast Charge: 10 mins charge = 5 hours playback',
      'Connectivity: Ultra-fast Bluetooth 5.3'
    ],
    category: 'electronics',
    subcategory_ar: 'سماعات وصوتيات فاخرة',
    subcategory_en: 'High-End Audio',
    priceSAR: 1490,
    originalPriceSAR: 1890,
    discountPercentage: 21,
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?q=80&w=800&auto=format&fit=crop'
    ],
    rating: 4.9,
    reviewCount: 168,
    stock: 22,
    isNewArrival: true,
    expressDelivery: true,
    tags: ['سماعات', 'إلكترونيات', 'صوتيات', 'تقنية', 'headphones', 'audio', 'tech']
  },
  {
    id: 'p-7',
    brand: 'DIAMOND PRIVÉ',
    name_ar: 'خاتم ذهب أبيض مرصع بالألماس',
    name_en: '18K White Gold Diamond Solitaire Ring',
    description_ar: 'خاتم من الذهب الأبيض عيار 18 يتوسطه حجر ألماس طبيعي قطع برليانت بنقاء VVS1 ووزن 1.2 قيراط مع شهادة معتمدة.',
    description_en: '18k white gold solitaire ring featuring a 1.2 carat VVS1 clarity brilliant-cut natural diamond with GIA certificate.',
    details_ar: [
      'المعدن: ذهب أبيض عيار 18 قيراط',
      'الألماس: 1.2 قيراط نقاء VVS1 لون F',
      'الشهادة: شهادة معتمدة دولياً من GIA',
      'الضمان: ضمان مدى الحياة والتنظيف المجاني'
    ],
    details_en: [
      'Metal: 18k White Gold',
      'Diamond: 1.2 Carats, VVS1 Clarity, Color F',
      'Certification: GIA Certified',
      'Warranty: Lifetime Guarantee & Complimentary Cleaning'
    ],
    category: 'jewelry',
    subcategory_ar: 'قلائد وأقراط',
    subcategory_en: 'Fine Jewelry',
    priceSAR: 8900,
    originalPriceSAR: 11500,
    discountPercentage: 22,
    images: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=800&auto=format&fit=crop'
    ],
    rating: 5.0,
    reviewCount: 38,
    stock: 3,
    isExclusive: true,
    expressDelivery: true,
    tags: ['خاتم', 'ماس', 'مجوهرات', 'ذهب', 'ألماس', 'ring', 'diamond', 'jewelry']
  },
  {
    id: 'p-8',
    brand: 'BOKHOOR TECH',
    name_ar: 'مبخرة إلكترونية ذكية مطليّة بالذهب',
    name_en: 'Luxury Smart Electric Incense Burner',
    description_ar: 'مبخرة ذكية تعمل بالشحن السريع مع نظام تحكم بدرجة الحرارة لنشر عبق العود والبخور دون احتراق وبأعلى درجات الأمان.',
    description_en: 'Smart portable electric bukhoor incense burner with gold trim, precision heat control, and USB-C fast charge.',
    details_ar: [
      'التقنية: تسخين سيراميكي ذكي',
      'البطارية: 3000 مل أمبير تكفي 25 استخدام',
      'الملحقات: ملعقة عود، ملقط، حقيبة مخملية، كابل شحن',
      'اللون: أسود غير لامع مع لمسات ذهبية'
    ],
    details_en: [
      'Technology: Smart Ceramic Heating Element',
      'Battery: 3000mAh for up to 25 sessions',
      'Includes: Oud Spoon, Tweezers, Velvet Pouch, USB-C Cable',
      'Color: Matte Black with Brushed Gold Accents'
    ],
    category: 'home',
    subcategory_ar: 'ديكورات ومبخرات',
    subcategory_en: 'Decor & Electric Incense',
    priceSAR: 340,
    originalPriceSAR: 490,
    discountPercentage: 30,
    images: [
      'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1507652313519-d4e9174996dd?q=80&w=800&auto=format&fit=crop'
    ],
    rating: 4.8,
    reviewCount: 215,
    stock: 45,
    isBestSeller: true,
    expressDelivery: true,
    tags: ['مبخرة', 'بخور', 'منزل', 'عود', 'تقنية', 'incense', 'home', 'burner']
  }
];
