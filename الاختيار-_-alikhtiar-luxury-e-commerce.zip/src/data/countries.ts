import { Country } from '../types';

export const GULF_COUNTRIES: Country[] = [
  {
    code: 'SA',
    name_ar: 'المملكة العربية السعودية',
    name_en: 'Saudi Arabia',
    flag: '🇸🇦',
    currency: 'SAR',
    currencySymbol_ar: 'ر.س',
    currencySymbol_en: 'SAR',
    exchangeRateToSAR: 1.0,
    vatRate: 0.15,
    deliveryDays: '1–2 يوم عمل',
    phonePrefix: '+966',
    cities: ['الرياض', 'جدة', 'الدمام', 'الخبر', 'مكة المكرمة', 'المدينة المنورة']
  },
  {
    code: 'AE',
    name_ar: 'الإمارات العربية المتحدة',
    name_en: 'United Arab Emirates',
    flag: '🇦🇪',
    currency: 'AED',
    currencySymbol_ar: 'د.إ',
    currencySymbol_en: 'AED',
    exchangeRateToSAR: 0.98,
    vatRate: 0.05,
    deliveryDays: '1–2 يوم عمل (توصيل نفس اليوم في دبي)',
    phonePrefix: '+971',
    cities: ['دبي', 'أبوظبي', 'الشارقة', 'العين', 'عجمان']
  },
  {
    code: 'QA',
    name_ar: 'دولة قطر',
    name_en: 'Qatar',
    flag: '🇶🇦',
    currency: 'QAR',
    currencySymbol_ar: 'ر.ق',
    currencySymbol_en: 'QAR',
    exchangeRateToSAR: 0.97,
    vatRate: 0.0,
    deliveryDays: '2–3 أيام عمل',
    phonePrefix: '+974',
    cities: ['الدوحة', 'الريان', 'الوكرة', 'اللؤلؤة']
  },
  {
    code: 'KW',
    name_ar: 'دولة الكويت',
    name_en: 'Kuwait',
    flag: '🇰🇼',
    currency: 'KWD',
    currencySymbol_ar: 'د.ك',
    currencySymbol_en: 'KWD',
    exchangeRateToSAR: 0.082,
    vatRate: 0.0,
    deliveryDays: '2–3 أيام عمل',
    phonePrefix: '+965',
    cities: ['مدينة الكويت', 'حولي', 'السالمية', 'الأحمدي']
  },
  {
    code: 'BH',
    name_ar: 'مملكة البحرين',
    name_en: 'Bahrain',
    flag: '🇧🇭',
    currency: 'BHD',
    currencySymbol_ar: 'د.ب',
    currencySymbol_en: 'BHD',
    exchangeRateToSAR: 0.10,
    vatRate: 0.10,
    deliveryDays: '2–3 أيام عمل',
    phonePrefix: '+973',
    cities: ['المنامة', 'المحرق', 'الرفاع']
  },
  {
    code: 'OM',
    name_ar: 'سلطنة عمان',
    name_en: 'Oman',
    flag: '🇴🇲',
    currency: 'OMR',
    currencySymbol_ar: 'ر.ع',
    currencySymbol_en: 'OMR',
    exchangeRateToSAR: 0.102,
    vatRate: 0.05,
    deliveryDays: '3–4 أيام عمل',
    phonePrefix: '+968',
    cities: ['مسقط', 'صلالة', 'صحار']
  }
];

export function formatPrice(priceInSAR: number, targetCountry: Country, isArabic: boolean): string {
  const converted = priceInSAR * targetCountry.exchangeRateToSAR;
  // Format with proper digits
  const formattedNumber = new Intl.NumberFormat(isArabic ? 'ar-SA' : 'en-US', {
    maximumFractionDigits: targetCountry.currency === 'KWD' || targetCountry.currency === 'BHD' || targetCountry.currency === 'OMR' ? 3 : 0,
    minimumFractionDigits: targetCountry.currency === 'KWD' || targetCountry.currency === 'BHD' || targetCountry.currency === 'OMR' ? 3 : 0,
  }).format(converted);

  const symbol = isArabic ? targetCountry.currencySymbol_ar : targetCountry.currencySymbol_en;
  return isArabic ? `${formattedNumber} ${symbol}` : `${symbol} ${formattedNumber}`;
}
