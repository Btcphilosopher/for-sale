import { Category } from '../types';

export const CATEGORIES: Category[] = [
  {
    id: 'fashion',
    name_ar: 'الأزياء',
    name_en: 'Fashion',
    subtitle_ar: 'عبايات، فساتين وموضة عصرية',
    subtitle_en: 'Abayas, Couture & Contemporary',
    iconName: 'Shirt',
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=600&auto=format&fit=crop',
    popularSearchTerms: ['عبايات', 'فساتين', 'قمصان', 'موضة دبي'],
    subcategories: [
      {
        id: 'abayas',
        name_ar: 'العبايات والجلابيات',
        name_en: 'Abayas & Kaftans',
        items: [
          { id: 'luxury-abayas', name_ar: 'عبايات فاخرة', name_en: 'Luxury Abayas' },
          { id: 'silk-kaftans', name_ar: 'قفاطين حريرية', name_en: 'Silk Kaftans' },
          { id: 'casual-abayas', name_ar: 'عبايات يومية', name_en: 'Casual Abayas' },
        ]
      },
      {
        id: 'dresses',
        name_ar: 'الفساتين والسهار',
        name_en: 'Dresses & Couture',
        items: [
          { id: 'evening-wear', name_ar: 'ملابس السهرة', name_en: 'Evening Wear' },
          { id: 'silk-dresses', name_ar: 'فساتين حرير', name_en: 'Silk Dresses' },
        ]
      },
      {
        id: 'designers',
        name_ar: 'المصممون الاقليميون',
        name_en: 'Regional Designers',
        items: [
          { id: 'brand-01', name_ar: 'علامة الاختيار 01', name_en: 'ALIKHTIAR Atelier' },
          { id: 'brand-02', name_ar: 'علامة الرياض هـوت كوتور', name_en: 'Riyadh Haute' },
          { id: 'brand-03', name_ar: 'دار دبي للموضة', name_en: 'Dubai Fashion House' },
        ]
      }
    ]
  },
  {
    id: 'perfumes',
    name_ar: 'العطور',
    name_en: 'Perfumes & Oud',
    subtitle_ar: 'عود، بخور وعطور عالمية',
    subtitle_en: 'Royal Oud & High Perfumery',
    iconName: 'Sparkles',
    image: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=600&auto=format&fit=crop',
    popularSearchTerms: ['عود', 'مسك', 'بخاخ فاخر', 'دهن عود الملكي'],
    subcategories: [
      {
        id: 'oud',
        name_ar: 'العود والبخور الملكي',
        name_en: 'Royal Oud & Incense',
        items: [
          { id: 'dehn-oud', name_ar: 'دهن عود معتق', name_en: 'Aged Dehn Al Oud' },
          { id: 'bukhoor', name_ar: 'بخور مروكي فاخر', name_en: 'Moroki Bukhoor' },
        ]
      },
      {
        id: 'niche-fragrance',
        name_ar: 'عطور النيش العالمية',
        name_en: 'Niche Fragrances',
        items: [
          { id: 'amber', name_ar: 'عطور العنبر والمسك', name_en: 'Amber & Musk' },
          { id: 'french-perfumes', name_ar: 'عطور فرنسية حصرية', name_en: 'Exclusive French Perfumes' },
        ]
      }
    ]
  },
  {
    id: 'watches',
    name_ar: 'الساعات',
    name_en: 'Timepieces',
    subtitle_ar: 'ساعات سويسرية ومجوهرات الوقت',
    subtitle_en: 'Swiss Chronographs & High Jewelry',
    iconName: 'Watch',
    image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=600&auto=format&fit=crop',
    popularSearchTerms: ['ساعة كلاسيك', 'ساعة كرونوغراف', 'ساعات سويسرية', 'ساعة ذهب'],
    subcategories: [
      {
        id: 'swiss-watches',
        name_ar: 'الساعات السويسرية',
        name_en: 'Swiss Watches',
        items: [
          { id: 'classic-watches', name_ar: 'ساعات كلاسيكية', name_en: 'Classic Watches' },
          { id: 'chronograph', name_ar: 'ساعات رياضية فاخرة', name_en: 'Luxury Sport Watches' },
        ]
      }
    ]
  },
  {
    id: 'handbags',
    name_ar: 'الحقائب',
    name_en: 'Handbags & Leather',
    subtitle_ar: 'جلد طبيعي وحقائب كلاسيكية',
    subtitle_en: 'Crafted Leather & Modern Icons',
    iconName: 'ShoppingBag',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=600&auto=format&fit=crop',
    popularSearchTerms: ['حقيبة جلد', 'شنطة سهرة', 'محفظة جلدية'],
    subcategories: [
      {
        id: 'totes',
        name_ar: 'حقائب اليد الجلدية',
        name_en: 'Leather Tote Bags',
        items: [
          { id: 'exclusive-tote', name_ar: 'حقائب سفر واستخدام يومي', name_en: 'Everyday Luxury Totes' },
        ]
      }
    ]
  },
  {
    id: 'jewelry',
    name_ar: 'المجوهرات',
    name_en: 'Jewelry',
    subtitle_ar: 'ألمس الذهب والماس والذهب الوردي',
    subtitle_en: 'Fine Gold, Diamonds & Gemstones',
    iconName: 'Gem',
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=600&auto=format&fit=crop',
    popularSearchTerms: ['مجوهرات ذهب', 'خاتم ماس', 'قلادة فخمة'],
    subcategories: [
      {
        id: 'necklaces',
        name_ar: 'قلائد وأقراط',
        name_en: 'Necklaces & Earrings',
        items: [
          { id: 'diamond-rings', name_ar: 'خواتم ألماسيّة', name_en: 'Diamond Rings' },
        ]
      }
    ]
  },
  {
    id: 'electronics',
    name_ar: 'الإلكترونيات',
    name_en: 'Electronics & Tech',
    subtitle_ar: 'تقنيات فائقة وسماعات فاخرة',
    subtitle_en: 'Hypermodern Audio & Mobile Tech',
    iconName: 'Headphones',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=600&auto=format&fit=crop',
    popularSearchTerms: ['سماعات', 'هواتف ذكية', 'أجهزة منزلية تقنية'],
    subcategories: [
      {
        id: 'audio',
        name_ar: 'سماعات وصوتيات فاخرة',
        name_en: 'High-End Audio',
        items: [
          { id: 'noise-cancelling', name_ar: 'سماعات عازلة للصوت', name_en: 'Noise Cancelling Headphones' },
        ]
      }
    ]
  },
  {
    id: 'home',
    name_ar: 'المنزل',
    name_en: 'Home & Living',
    subtitle_ar: 'ديكور خليجي حديث ومبخرات إلكترونية',
    subtitle_en: 'Gulf Interior Accents & Modern Incense Burners',
    iconName: 'Home',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=600&auto=format&fit=crop',
    popularSearchTerms: ['مبخرة إلكترونية', 'ديكور فاخر', 'شموع معطرة'],
    subcategories: [
      {
        id: 'decor',
        name_ar: 'ديكورات ومبخرات',
        name_en: 'Decor & Electric Incense',
        items: [
          { id: 'incense-burners', name_ar: 'مبخرة ذكية', name_en: 'Smart Incense Burners' },
        ]
      }
    ]
  },
  {
    id: 'sunglasses',
    name_ar: 'النظارات',
    name_en: 'Eyewear',
    subtitle_ar: 'نظارات شمسية فاخرة',
    subtitle_en: 'Designer Sunglasses & Frames',
    iconName: 'Glasses',
    image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?q=80&w=600&auto=format&fit=crop',
    popularSearchTerms: ['نظارة شمسية', 'إطار كلاسيكي'],
    subcategories: [
      {
        id: 'sunglasses-sub',
        name_ar: 'نظارات شمسية',
        name_en: 'Sunglasses',
        items: []
      }
    ]
  }
];
