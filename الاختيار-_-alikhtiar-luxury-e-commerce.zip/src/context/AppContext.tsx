import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Language, 
  Country, 
  Product, 
  CartItem, 
  Order, 
  UserProfile, 
  ActivePage 
} from '../types';
import { GULF_COUNTRIES } from '../data/countries';
import { PRODUCTS } from '../data/products';
import { ar } from '../locales/ar';
import { en } from '../locales/en';

interface Toast {
  id: string;
  title: string;
  message: string;
  type?: 'success' | 'info';
}

interface AppContextType {
  language: Language;
  direction: 'rtl' | 'ltr';
  t: typeof ar;
  country: Country;
  activePage: ActivePage;
  selectedProductId: string | null;
  selectedCategory: string | null;
  searchQuery: string;
  quickViewProduct: Product | null;
  cart: CartItem[];
  wishlist: string[];
  recentlyViewed: string[];
  appliedCoupon: string | null;
  orders: Order[];
  user: UserProfile;
  toasts: Toast[];

  // Handlers
  setLanguage: (lang: Language) => void;
  setCountry: (countryCode: string) => void;
  navigateTo: (page: ActivePage, extra?: { productId?: string; categoryId?: string; query?: string }) => void;
  openQuickView: (product: Product) => void;
  closeQuickView: () => void;
  setSearchQuery: (query: string) => void;
  
  // Cart Actions
  addToCart: (product: Product, quantity?: number, variant?: { color?: string; size?: string; volume?: string }) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  
  // Wishlist Actions
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Coupon Actions
  applyCouponCode: (code: string) => boolean;
  
  // Order Placement
  createOrder: (shippingAddress: Order['shippingAddress'], paymentMethod: string) => Order;

  // Toast
  showToast: (title: string, message: string) => void;
}

const INITIAL_USER: UserProfile = {
  id: 'usr-882',
  name: 'الأمير فيصل عبد العزيز',
  email: 'faisal.abdulaziz@alikhtiar.sa',
  phone: '+966 50 889 1234',
  country: 'المملكة العربية السعودية',
  city: 'الرياض',
  rewardPoints: 1450,
  membershipTier: 'VIP Platinum',
  membershipTier_ar: 'عضوية VIP ذهبية',
  savedAddresses: [
    {
      id: 'addr-1',
      title_ar: 'منزل الرياض (الصحافة)',
      title_en: 'Riyadh Residence (Al-Sahafa)',
      name: 'فيصل عبد العزيز',
      city: 'الرياض',
      address: 'حي الصحافة، شارع العليا، فيلا 42',
      phone: '+966 50 889 1234',
      isDefault: true,
    },
    {
      id: 'addr-2',
      title_ar: 'مكتب دبي (برج خليفة)',
      title_en: 'Dubai Office (Downtown)',
      name: 'Faisal Abdulaziz',
      city: 'دبي',
      address: 'Downtown Dubai, Boulevard Plaza Tower 1, Suite 1802',
      phone: '+971 50 112 4455',
      isDefault: false,
    }
  ],
  paymentMethods: [
    {
      id: 'pm-1',
      type: 'applepay',
      lastFour: '8812',
      expiry: '09/28',
      isDefault: true,
    },
    {
      id: 'pm-2',
      type: 'mada',
      lastFour: '4509',
      expiry: '12/27',
      isDefault: false,
    }
  ],
  coupons: [
    {
      code: 'ALIKHTIAR10',
      discount_ar: 'خصم 10% للأعضاء الجدد',
      discount_en: '10% New Member Discount',
      minSpendSAR: 300,
      expiryDate: '2026-12-31',
    },
    {
      code: 'GULF2026',
      discount_ar: 'خصم 15% على العطور والساعات',
      discount_en: '15% Off Perfumes & Timepieces',
      minSpendSAR: 500,
      expiryDate: '2026-10-15',
    }
  ]
};

const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-9011',
    orderNumber: 'ALK-2026-88219',
    date: '26 أغسطس 2026',
    status: 'shipped',
    status_ar: 'تم الشحن (في الطريق للرياض)',
    status_en: 'Shipped (In Transit to Riyadh)',
    items: [
      {
        productId: 'p-1',
        name_ar: 'ساعة كلاسيك فاخرة',
        name_en: 'Classic Luxury Timepiece',
        priceSAR: 1250,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=600&auto=format&fit=crop',
        variantInfo: 'بني ذهبي'
      },
      {
        productId: 'p-2',
        name_ar: 'عطر عود فاخر',
        name_en: 'Royal Oud Extrait de Parfum',
        priceSAR: 580,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=600&auto=format&fit=crop',
        variantInfo: '100 مل'
      }
    ],
    totalSAR: 1830,
    shippingSAR: 0,
    vatSAR: 238.7,
    discountSAR: 0,
    paymentMethod: 'Apple Pay',
    shippingAddress: {
      name: 'فيصل عبد العزيز',
      city: 'الرياض',
      district: 'حي الصحافة',
      street: 'شارع العليا، فيلا 42',
      phone: '+966 50 889 1234',
      country: 'المملكة العربية السعودية'
    },
    trackingNumber: 'SMSA-8829104992',
    estimatedDelivery: 'غداً، 29 أغسطس 2026'
  }
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('ar');
  const [country, setCountryState] = useState<Country>(GULF_COUNTRIES[0]); // SA
  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);

  // Persistence in LocalStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('alikhtiar_cart');
      return saved ? JSON.parse(saved) : [
        { product: PRODUCTS[0], quantity: 1, selectedColor: 'بني ذهبي' }
      ];
    } catch {
      return [{ product: PRODUCTS[0], quantity: 1 }];
    }
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('alikhtiar_wishlist');
      return saved ? JSON.parse(saved) : ['p-2', 'p-5'];
    } catch {
      return ['p-2', 'p-5'];
    }
  });

  const [recentlyViewed, setRecentlyViewed] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('alikhtiar_recent');
      return saved ? JSON.parse(saved) : ['p-1', 'p-2', 'p-3'];
    } catch {
      return ['p-1', 'p-2', 'p-3'];
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('alikhtiar_orders');
      return saved ? JSON.parse(saved) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  const [user] = useState<UserProfile>(INITIAL_USER);

  useEffect(() => {
    localStorage.setItem('alikhtiar_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('alikhtiar_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('alikhtiar_recent', JSON.stringify(recentlyViewed));
  }, [recentlyViewed]);

  useEffect(() => {
    localStorage.setItem('alikhtiar_orders', JSON.stringify(orders));
  }, [orders]);

  // Sync document attribute dir="rtl" or "ltr" and lang="ar" or "en"
  useEffect(() => {
    const dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.setAttribute('dir', dir);
    document.documentElement.setAttribute('lang', language);
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const setCountry = (code: string) => {
    const found = GULF_COUNTRIES.find(c => c.code === code);
    if (found) {
      setCountryState(found);
      showToast(
        language === 'ar' ? 'تم تغيير الدولة' : 'Country Updated',
        language === 'ar' ? `التوصيل إلى ${found.name_ar} (العملة: ${found.currencySymbol_ar})` : `Delivering to ${found.name_en} (${found.currency})`
      );
    }
  };

  const showToast = (title: string, message: string, type: 'success' | 'info' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3500);
  };

  const navigateTo = (page: ActivePage, extra?: { productId?: string; categoryId?: string; query?: string }) => {
    setActivePage(page);
    if (extra?.productId) {
      setSelectedProductId(extra.productId);
      // add to recently viewed
      setRecentlyViewed(prev => Array.from(new Set([extra.productId!, ...prev])));
    }
    if (extra?.categoryId) {
      setSelectedCategory(extra.categoryId);
    }
    if (extra?.query !== undefined) {
      setSearchQuery(extra.query);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openQuickView = (product: Product) => {
    setQuickViewProduct(product);
  };

  const closeQuickView = () => {
    setQuickViewProduct(null);
  };

  const addToCart = (
    product: Product, 
    quantity = 1, 
    variant?: { color?: string; size?: string; volume?: string }
  ) => {
    setCart(prev => {
      const existingIndex = prev.findIndex(item => item.product.id === product.id);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += quantity;
        return updated;
      }
      return [
        ...prev, 
        { 
          product, 
          quantity, 
          selectedColor: variant?.color,
          selectedSize: variant?.size,
          selectedVolume: variant?.volume 
        }
      ];
    });

    showToast(
      language === 'ar' ? 'تمت الإضافة للسلة' : 'Added to Cart',
      language === 'ar' ? `${product.name_ar} تمت إضافته إلى سلة التسوق الخاصة بك.` : `${product.name_en} has been added to your shopping cart.`
    );
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item => item.product.id === productId ? { ...item, quantity } : item));
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    const product = PRODUCTS.find(p => p.id === productId);
    setWishlist(prev => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast(
          language === 'ar' ? 'تمت الإزالة من المفضلة' : 'Removed from Wishlist',
          language === 'ar' ? `تمت إزالة المنتج من قائمتك المفضلة.` : `Item removed from your wishlist.`
        );
        return prev.filter(id => id !== productId);
      } else {
        showToast(
          language === 'ar' ? 'أضيف للمفضلة' : 'Added to Wishlist',
          language === 'ar' ? `${product?.name_ar || 'المنتج'} في قائمة رغباتك الآن.` : `${product?.name_en || 'Item'} added to your luxury wishlist.`
        );
        return [...prev, productId];
      }
    });
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  const applyCouponCode = (code: string): boolean => {
    const normalized = code.trim().toUpperCase();
    if (normalized === 'ALIKHTIAR10' || normalized === 'GULF2026') {
      setAppliedCoupon(normalized);
      showToast(
        language === 'ar' ? 'تم قبول القسيمة!' : 'Coupon Applied!',
        language === 'ar' ? 'حصلت على خصم 10% على إجمالي الطلب.' : 'You received 10% discount on your order total.'
      );
      return true;
    }
    showToast(
      language === 'ar' ? 'رمز غير صالح' : 'Invalid Coupon',
      language === 'ar' ? 'تأكد من كتابة الرمز ALIKHTIAR10 بشكل صحيح' : 'Please check coupon code syntax.'
    );
    return false;
  };

  const createOrder = (shippingAddress: Order['shippingAddress'], paymentMethod: string): Order => {
    const subtotalSAR = cart.reduce((acc, item) => acc + item.product.priceSAR * item.quantity, 0);
    const discountSAR = appliedCoupon ? subtotalSAR * 0.10 : 0;
    const vatSAR = (subtotalSAR - discountSAR) * country.vatRate;
    const totalSAR = subtotalSAR - discountSAR + vatSAR;

    const newOrder: Order = {
      id: `ord-${Math.floor(Math.random() * 90000 + 10000)}`,
      orderNumber: `ALK-2026-${Math.floor(Math.random() * 8999 + 1000)}`,
      date: new Date().toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' }),
      status: 'confirmed',
      status_ar: 'تم التأكيد (قيد التجهيز الفاخر)',
      status_en: 'Confirmed (In Preparation)',
      items: cart.map(item => ({
        productId: item.product.id,
        name_ar: item.product.name_ar,
        name_en: item.product.name_en,
        priceSAR: item.product.priceSAR,
        quantity: item.quantity,
        image: item.product.images[0],
        variantInfo: item.selectedColor || item.selectedSize || item.selectedVolume
      })),
      totalSAR,
      shippingSAR: 0,
      vatSAR,
      discountSAR,
      paymentMethod,
      shippingAddress,
      trackingNumber: `SMSA-${Math.floor(Math.random() * 8999999 + 1000000)}`,
      estimatedDelivery: country.deliveryDays
    };

    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    setAppliedCoupon(null);
    return newOrder;
  };

  const t = language === 'ar' ? ar : en;
  const direction = language === 'ar' ? 'rtl' : 'ltr';

  return (
    <AppContext.Provider
      value={{
        language,
        direction,
        t,
        country,
        activePage,
        selectedProductId,
        selectedCategory,
        searchQuery,
        quickViewProduct,
        cart,
        wishlist,
        recentlyViewed,
        appliedCoupon,
        orders,
        user,
        toasts,
        setLanguage,
        setCountry,
        navigateTo,
        openQuickView,
        closeQuickView,
        setSearchQuery,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        toggleWishlist,
        isInWishlist,
        applyCouponCode,
        createOrder,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
