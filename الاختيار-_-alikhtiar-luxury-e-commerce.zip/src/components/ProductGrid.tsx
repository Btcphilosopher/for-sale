import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS } from '../data/products';
import { ProductCard } from './ProductCard';
import { Sparkles, Filter, SlidersHorizontal } from 'lucide-react';

export const ProductGrid: React.FC = () => {
  const { language } = useApp();
  const [activeTab, setActiveTab] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('popular');

  const tabs = [
    { id: 'all', label_ar: 'الكل', label_en: 'All Items' },
    { id: 'bestSellers', label_ar: 'الأكثر مبيعاً', label_en: 'Best Sellers' },
    { id: 'newArrivals', label_ar: 'وصل حديثاً', label_en: 'New Arrivals' },
    { id: 'exclusiveOud', label_ar: 'العود الخاص', label_en: 'Exclusive Oud' },
    { id: 'swissWatches', label_ar: 'ساعات سويسرية', label_en: 'Swiss Watches' },
    { id: 'fineLeather', label_ar: 'جلد فاخر', label_en: 'Fine Leather' },
  ];

  const filteredProducts = useMemo(() => {
    let list = [...PRODUCTS];

    if (activeTab === 'bestSellers') {
      list = list.filter(p => p.isBestSeller);
    } else if (activeTab === 'newArrivals') {
      list = list.filter(p => p.isNewArrival);
    } else if (activeTab === 'exclusiveOud') {
      list = list.filter(p => p.category === 'perfumes' || p.tags.includes('عود'));
    } else if (activeTab === 'swissWatches') {
      list = list.filter(p => p.category === 'watches');
    } else if (activeTab === 'fineLeather') {
      list = list.filter(p => p.category === 'handbags');
    }

    if (sortBy === 'price-low') {
      list.sort((a, b) => a.priceSAR - b.priceSAR);
    } else if (sortBy === 'price-high') {
      list.sort((a, b) => b.priceSAR - a.priceSAR);
    } else if (sortBy === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    }

    return list;
  }, [activeTab, sortBy]);

  return (
    <section className="py-14 bg-[#F5F2ED]">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 border-b border-[#D1C9BC] pb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-6 h-[1px] bg-[#A89060]"></div>
              <span className="text-[10px] font-bold text-[#A89060] uppercase tracking-widest block">
                {language === 'ar' ? 'اختيارات النخبة' : 'Elite Selections'}
              </span>
            </div>
            <h2 className="font-serif text-2xl sm:text-4xl font-bold text-[#1A1A1A]">
              {language === 'ar' ? 'منتجات مختارة لك' : 'Curated For You'}
            </h2>
          </div>

          {/* Sort Control */}
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold text-[#7D7463] flex items-center gap-1">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#A89060]" />
              {language === 'ar' ? 'ترتيب حسب:' : 'Sort By:'}
            </span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-white border border-[#D1C9BC] text-[#1A1A1A] text-xs font-bold py-2 px-3 outline-none focus:border-[#A89060] cursor-pointer"
            >
              <option value="popular">{language === 'ar' ? 'الأكثر شعبية' : 'Most Popular'}</option>
              <option value="price-low">{language === 'ar' ? 'السعر: من الأقل للأعلى' : 'Price: Low to High'}</option>
              <option value="price-high">{language === 'ar' ? 'السعر: من الأعلى للأقل' : 'Price: High to Low'}</option>
              <option value="rating">{language === 'ar' ? 'الأعلى تقييماً' : 'Highest Rated'}</option>
            </select>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-4 mb-8">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-5 py-2 text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#1A1A1A] text-white border border-[#A89060]'
                    : 'bg-white text-[#1A1A1A] border border-[#D1C9BC] hover:border-[#A89060]'
                }`}
              >
                {language === 'ar' ? tab.label_ar : tab.label_en}
              </button>
            );
          })}
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

      </div>
    </section>
  );
};
