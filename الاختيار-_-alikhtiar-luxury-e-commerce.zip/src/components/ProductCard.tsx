import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';
import { formatPrice } from '../data/countries';
import { Heart, Eye, ShoppingBag, Star, Truck, Check } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { 
    language, 
    country, 
    navigateTo, 
    openQuickView, 
    addToCart, 
    toggleWishlist, 
    isInWishlist 
  } = useApp();

  const [isHovered, setIsHovered] = useState(false);
  const isWishlisted = isInWishlist(product.id);

  const primaryImage = product.images[0];
  const secondaryImage = product.images[1] || product.images[0];

  return (
    <div 
      className="group bg-white border border-[#E8E1D5] hover:border-[#A89060] transition-all duration-300 flex flex-col overflow-hidden relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Top Image Container with Badges & Wishlist */}
      <div 
        className="relative aspect-square w-full bg-[#EAE3D8]/50 overflow-hidden cursor-pointer"
        onClick={() => navigateTo('product-detail', { productId: product.id })}
      >
        {/* Main Product Image with hover zoom */}
        <img
          src={isHovered ? secondaryImage : primaryImage}
          alt={language === 'ar' ? product.name_ar : product.name_en}
          className="w-full h-full object-cover object-center transition-all duration-500 ease-out group-hover:scale-105"
          loading="lazy"
        />

        {/* Top Badges (Discount % & Exclusive) */}
        <div className="absolute top-3 right-3 left-3 flex items-center justify-between pointer-events-none z-10">
          <div className="flex flex-col gap-1 items-start">
            {product.discountPercentage && (
              <span className="bg-[#1A1A1A] text-white text-[10px] font-bold px-2 py-0.5 dir-ltr">
                -{product.discountPercentage}%
              </span>
            )}
            {product.isExclusive && (
              <span className="bg-[#A89060] text-white text-[9px] font-bold px-2 py-0.5 uppercase tracking-wider">
                {language === 'ar' ? 'حصري' : 'Exclusive'}
              </span>
            )}
          </div>

          {/* Wishlist Heart Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleWishlist(product.id);
            }}
            className={`pointer-events-auto p-2 backdrop-blur-md transition-all cursor-pointer ${
              isWishlisted 
                ? 'bg-[#A89060] text-white' 
                : 'bg-white/90 text-[#1A1A1A] hover:bg-white hover:text-[#A89060]'
            }`}
            title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Floating Quick Action Overlay Buttons */}
        <div className="absolute bottom-3 inset-x-3 flex items-center gap-2 transition-all duration-300 transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 z-10">
          <button
            onClick={(e) => {
              e.stopPropagation();
              openQuickView(product);
            }}
            className="flex-1 flex items-center justify-center gap-1.5 bg-white text-[#1A1A1A] text-xs font-bold py-2 px-2 border border-[#D1C9BC] shadow-sm hover:border-[#A89060] transition-colors cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5 text-[#A89060]" />
            <span>{language === 'ar' ? 'نظرة سريعة' : 'Quick View'}</span>
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product);
            }}
            className="flex-1 flex items-center justify-center gap-1.5 bg-[#1A1A1A] hover:bg-[#A89060] text-white text-xs font-bold py-2 px-2 shadow-sm transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'إضافة للسلة' : 'Add to Cart'}</span>
          </button>
        </div>
      </div>

      {/* Card Details Body */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-2 bg-white">
        
        <div>
          {/* Brand Name */}
          <div className="flex items-center justify-between text-[10px] mb-1">
            <span className="font-bold text-[#A89060] uppercase tracking-tighter">
              {product.brand}
            </span>
            {product.expressDelivery && (
              <span className="flex items-center gap-1 text-[9px] text-[#7D7463] font-semibold bg-[#EAE3D8]/60 px-1.5 py-0.5">
                <Truck className="w-3 h-3 text-[#A89060]" />
                <span>{language === 'ar' ? 'توصيل سريع' : 'Express'}</span>
              </span>
            )}
          </div>

          {/* Product Name */}
          <h3 
            onClick={() => navigateTo('product-detail', { productId: product.id })}
            className="text-sm font-medium text-[#1A1A1A] hover:text-[#A89060] transition-colors cursor-pointer line-clamp-2 leading-snug"
          >
            {language === 'ar' ? product.name_ar : product.name_en}
          </h3>
        </div>

        {/* Rating Stars */}
        <div className="flex items-center gap-1 text-xs">
          <div className="flex items-center text-[#A89060]">
            <Star className="w-3.5 h-3.5 fill-current" />
            <span className="font-bold text-[#1A1A1A] ms-1 text-xs">{product.rating}</span>
          </div>
          <span className="text-[#7D7463] text-[10px]">
            ({product.reviewCount})
          </span>
        </div>

        {/* Price & Original Price */}
        <div className="pt-2 border-t border-[#E8E1D5] flex items-baseline justify-between">
          <div className="flex items-baseline gap-2">
            <span className="font-bold text-sm text-[#1A1A1A]">
              {formatPrice(product.priceSAR, country, language === 'ar')}
            </span>
            {product.originalPriceSAR && (
              <span className="text-[10px] text-[#7D7463] line-through">
                {formatPrice(product.originalPriceSAR, country, language === 'ar')}
              </span>
            )}
          </div>

          <span className="text-[9px] text-[#7D7463]">
            {language === 'ar' ? 'شامل الضريبة' : 'VAT Incl.'}
          </span>
        </div>

      </div>
    </div>
  );
};
