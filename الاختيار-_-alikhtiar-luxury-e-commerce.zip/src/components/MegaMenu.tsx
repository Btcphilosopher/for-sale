import React from 'react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/categories';
import { Sparkles, ArrowLeft, ArrowRight } from 'lucide-react';

interface MegaMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MegaMenu: React.FC<MegaMenuProps> = ({ isOpen, onClose }) => {
  const { language, navigateTo } = useApp();

  if (!isOpen) return null;

  const ArrowIcon = language === 'ar' ? ArrowLeft : ArrowRight;

  return (
    <div 
      className="absolute top-full right-0 left-0 z-40 bg-[#FBF9F5] border-b border-[#C5A059]/30 shadow-2xl animate-fadeIn transition-all"
      onMouseLeave={onClose}
    >
      <div className="max-w-7xl mx-auto p-6 md:p-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Main Category Columns */}
          {CATEGORIES.slice(0, 3).map((cat) => (
            <div key={cat.id} className="space-y-4">
              <div 
                onClick={() => {
                  navigateTo('category', { categoryId: cat.id });
                  onClose();
                }}
                className="flex items-center gap-2 text-[#C5A059] font-bold text-base cursor-pointer hover:underline border-b border-[#EAE0D0] pb-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>{language === 'ar' ? cat.name_ar : cat.name_en}</span>
              </div>

              <div className="space-y-4">
                {cat.subcategories.map((sub) => (
                  <div key={sub.id} className="space-y-2">
                    <h5 className="text-xs font-bold text-[#121110] uppercase tracking-wider">
                      {language === 'ar' ? sub.name_ar : sub.name_en}
                    </h5>
                    <ul className="space-y-1.5 text-xs text-gray-600">
                      {sub.items?.map((item) => (
                        <li key={item.id}>
                          <button
                            onClick={() => {
                              navigateTo('category', { categoryId: cat.id });
                              onClose();
                            }}
                            className="hover:text-[#C5A059] transition-colors hover:translate-x-1 cursor-pointer"
                          >
                            {language === 'ar' ? item.name_ar : item.name_en}
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Luxury Editorial Feature Box */}
          <div className="bg-[#231F1D] text-white rounded-2xl p-6 flex flex-col justify-between relative overflow-hidden group">
            <img 
              src="https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=600&auto=format&fit=crop"
              alt="Editorial"
              className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:scale-105 transition-transform duration-700"
            />
            <div className="relative z-10 space-y-2">
              <span className="text-[10px] font-bold text-[#DFBF7A] tracking-widest uppercase bg-black/40 px-2.5 py-1 rounded-full backdrop-blur-sm border border-[#C5A059]/40 inline-block">
                {language === 'ar' ? 'تشكيلة حصرية 2026' : 'Exclusive 2026'}
              </span>
              <h4 className="font-arabic-heading text-xl font-bold text-white leading-tight">
                {language === 'ar' ? 'مجموعة العود الملكي والساعات' : 'Royal Oud & High Horology'}
              </h4>
              <p className="text-xs text-gray-300">
                {language === 'ar' ? 'تصاميم فاخرة ومصممة خصيصاً لأصحاب الذوق المتميز' : 'Curated masterworks for the refined connoisseur'}
              </p>
            </div>

            <button
              onClick={() => {
                navigateTo('category', { categoryId: 'perfumes' });
                onClose();
              }}
              className="relative z-10 mt-6 inline-flex items-center gap-2 text-xs font-bold text-[#DFBF7A] hover:text-white transition-colors cursor-pointer"
            >
              <span>{language === 'ar' ? 'تصفح التشكيلة الكاملة' : 'Browse Full Collection'}</span>
              <ArrowIcon className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
