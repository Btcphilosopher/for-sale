import React from 'react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/categories';
import { 
  Shirt, 
  Sparkles, 
  Watch, 
  ShoppingBag, 
  Gem, 
  Headphones, 
  Home, 
  Glasses, 
  LayoutGrid,
  Footprints,
  Baby,
  Trophy,
  Car
} from 'lucide-react';

const ICON_MAP: Record<string, React.ElementType> = {
  Shirt,
  Sparkles,
  Watch,
  ShoppingBag,
  Gem,
  Headphones,
  Home,
  Glasses,
  Footprints,
  Baby,
  Trophy,
  Car
};

export const CategoryGrid: React.FC = () => {
  const { language, navigateTo } = useApp();

  return (
    <section className="py-12 bg-[#F5F2ED] border-b border-[#D1C9BC]">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Header Title */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-6 h-[1px] bg-[#A89060]"></div>
              <span className="text-[10px] font-bold text-[#A89060] uppercase tracking-widest block">
                {language === 'ar' ? 'تشكيلات فاخرة' : 'Curated Categories'}
              </span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#1A1A1A]">
              {language === 'ar' ? 'تصفح حسب القسم' : 'Explore By Category'}
            </h2>
          </div>
          <button 
            onClick={() => navigateTo('category', { categoryId: 'fashion' })}
            className="text-xs font-bold text-[#A89060] hover:underline flex items-center gap-1 cursor-pointer"
          >
            {language === 'ar' ? 'عرض جميع الأقسام' : 'View All Categories'}
          </button>
        </div>

        {/* Horizontal Category Cards Bar */}
        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-4 pt-1">
          {/* All Categories Button */}
          <button
            onClick={() => navigateTo('category', { categoryId: 'fashion' })}
            className="flex-shrink-0 flex flex-col items-center justify-center w-28 h-28 p-3 bg-[#1A1A1A] text-white border border-[#A89060] hover:bg-[#A89060] transition-all duration-300 group cursor-pointer"
          >
            <div className="w-9 h-9 bg-[#A89060] group-hover:bg-white text-white group-hover:text-[#1A1A1A] flex items-center justify-center mb-2 transition-colors">
              <LayoutGrid className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold truncate">
              {language === 'ar' ? 'الأقسام' : 'All Categories'}
            </span>
          </button>

          {CATEGORIES.map((cat) => {
            const IconComponent = ICON_MAP[cat.iconName] || Sparkles;
            return (
              <button
                key={cat.id}
                onClick={() => navigateTo('category', { categoryId: cat.id })}
                className="flex-shrink-0 flex flex-col items-center justify-center w-28 h-28 p-3 bg-white border border-[#D1C9BC] hover:border-[#A89060] text-[#1A1A1A] transition-all duration-300 group cursor-pointer"
              >
                <div className="w-9 h-9 bg-[#EAE3D8] group-hover:bg-[#A89060] group-hover:text-white flex items-center justify-center text-[#7D7463] mb-2 transition-colors">
                  <IconComponent className="w-4 h-4" />
                </div>
                <span className="text-xs font-medium text-[#1A1A1A] group-hover:text-[#A89060] truncate transition-colors">
                  {language === 'ar' ? cat.name_ar : cat.name_en}
                </span>
                <span className="text-[9px] text-[#7D7463] truncate mt-0.5">
                  {language === 'ar' ? cat.subtitle_ar.split('،')[0] : cat.subtitle_en.split('&')[0]}
                </span>
              </button>
            );
          })}
        </div>

        {/* Featured Editorial Category Banners Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          
          {/* Card 1: Men's Fashion & Timepieces */}
          <div 
            onClick={() => navigateTo('category', { categoryId: 'watches' })}
            className="relative h-64 overflow-hidden group cursor-pointer border border-[#D1C9BC]"
          >
            <img 
              src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=800&auto=format&fit=crop" 
              alt="Men Fashion"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A]/90 via-[#1A1A1A]/30 to-transparent" />
            <div className="absolute bottom-6 right-6 left-6 text-white space-y-1">
              <span className="text-[10px] font-bold text-[#A89060] uppercase tracking-widest">
                {language === 'ar' ? 'تشكيلة رجالية فاخرة' : 'Luxe Men Collection'}
              </span>
              <h3 className="font-serif text-xl font-bold text-white">
                {language === 'ar' ? 'مجموعة الرجال والساعات' : 'Men & Fine Horology'}
              </h3>
              <p className="text-xs text-[#EAE3D8]">
                {language === 'ar' ? 'ساعات سويسرية وجلديات كلاسيكية' : 'Swiss chronographs & leather accessories'}
              </p>
            </div>
          </div>

          {/* Card 2: Women's Couture & Abayas */}
          <div 
            onClick={() => navigateTo('category', { categoryId: 'fashion' })}
            className="relative h-64 overflow-hidden group cursor-pointer border border-[#D1C9BC]"
          >
            <img 
              src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=800&auto=format&fit=crop" 
              alt="Women Couture"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A]/90 via-[#1A1A1A]/30 to-transparent" />
            <div className="absolute bottom-6 right-6 left-6 text-white space-y-1">
              <span className="text-[10px] font-bold text-[#A89060] uppercase tracking-widest">
                {language === 'ar' ? 'تألقي كل يوم' : 'Daily Elegance'}
              </span>
              <h3 className="font-serif text-xl font-bold text-white">
                {language === 'ar' ? 'مجموعة النساء والعبايات' : 'Women’s High Fashion & Abayas'}
              </h3>
              <p className="text-xs text-[#EAE3D8]">
                {language === 'ar' ? 'حرير، تطريز ذهبي وتصاميم حصرية' : 'Pure silk crepe & gold embroidery'}
              </p>
            </div>
          </div>

          {/* Card 3: Royal Fragrance & Oud */}
          <div 
            onClick={() => navigateTo('category', { categoryId: 'perfumes' })}
            className="relative h-64 overflow-hidden group cursor-pointer border border-[#D1C9BC]"
          >
            <img 
              src="https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=800&auto=format&fit=crop" 
              alt="Fragrance"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A]/90 via-[#1A1A1A]/30 to-transparent" />
            <div className="absolute bottom-6 right-6 left-6 text-white space-y-1">
              <span className="text-[10px] font-bold text-[#A89060] uppercase tracking-widest">
                {language === 'ar' ? 'عطور النيش الحصرية' : 'Niche Fragrance World'}
              </span>
              <h3 className="font-serif text-xl font-bold text-white">
                {language === 'ar' ? 'العود والبخور الملكي' : 'Royal Oud & Incense'}
              </h3>
              <p className="text-xs text-[#EAE3D8]">
                {language === 'ar' ? 'دهن عود معتق ونفحات نادرة' : 'Aged Dehn Al Oud & Amber Extrait'}
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
