import React, { useState, useEffect, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { ChevronLeft, ChevronRight, Sparkles, Pause, Play } from 'lucide-react';

interface CampaignSlide {
  id: string;
  badge_ar: string;
  badge_en: string;
  subheading_ar: string;
  subheading_en: string;
  title_ar: string;
  title_en: string;
  description_ar: string;
  description_en: string;
  cta_ar: string;
  cta_en: string;
  image: string;
  categoryLink: string;
}

const CAMPAIGNS: CampaignSlide[] = [
  {
    id: 'camp-1',
    badge_ar: 'تشكيلة موسم 2026 الحصرية',
    badge_en: 'Exclusive 2026 Season',
    subheading_ar: 'أسلوبك. تميزك. اختيارك.',
    subheading_en: 'Your Style. Your Choice.',
    title_ar: 'تسوق أحدث المجموعات لعام 2026',
    title_en: 'Discover the latest collections',
    description_ar: 'تشكيلة حصرية من أفضل العلامات العالمية والمحلية المنتقاة بعناية للذوق الخليجي الرفيع.',
    description_en: 'Curated from the world\'s finest global and regional brands for modern Gulf living.',
    cta_ar: 'تسوق الآن',
    cta_en: 'Shop Now',
    image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1600&auto=format&fit=crop',
    categoryLink: 'fashion'
  },
  {
    id: 'camp-2',
    badge_ar: 'مملكة العود والنادرة',
    badge_en: 'Kingdom of Rare Oud',
    subheading_ar: 'عبق الأصالة والفخامة.',
    subheading_en: 'The Scent of Pure Heritage.',
    title_ar: 'عطور العود والمسك الملكي',
    title_en: 'Royal Oud & High Perfumery',
    description_ar: 'خلطات استثنائية من دهن العود المعتق والبخور المروكي من دور العطور الحصرية.',
    description_en: 'Masterfully blended aged Oud and rare rose extraits from exclusive perfume houses.',
    cta_ar: 'استكشف العطور',
    cta_en: 'Explore Perfumes',
    image: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=1600&auto=format&fit=crop',
    categoryLink: 'perfumes'
  },
  {
    id: 'camp-3',
    badge_ar: 'ساعات سويسرية فاخرة',
    badge_en: 'Swiss Luxury Timepieces',
    subheading_ar: 'دقة التصميم. خلود الوقت.',
    subheading_en: 'Precision Craft. Timeless Horizon.',
    title_ar: 'تشكيلة الساعات الملكية',
    title_en: 'The Royal Horology Edition',
    description_ar: 'ساعات كرونوغراف كلاسيكية وذهب مرصع بالألماس من أعرق المصنعين السويسريين.',
    description_en: 'Hand-assembled Swiss automatic chronographs encased in 18k rose gold and titanium.',
    cta_ar: 'تسوق الساعات',
    cta_en: 'Discover Timepieces',
    image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1600&auto=format&fit=crop',
    categoryLink: 'watches'
  },
  {
    id: 'camp-4',
    badge_ar: 'جلديات إيطالية مطرزة',
    badge_en: 'Crafted Italian Leather',
    subheading_ar: 'إنقاطة لا تعترف بالزمن.',
    subheading_en: 'Refinement Beyond Boundaries.',
    title_ar: 'الحقائب والجلديات الفاخرة',
    title_en: 'Haute Leather Handbags',
    description_ar: 'تصاميم جلد طبيعي 100% منفذة يدوياً بأيدي أمهر الحرفيين في أوروبا والخليج.',
    description_en: 'Full-grain Italian leather totes and evening clutches tailored with gold hardware.',
    cta_ar: 'تصفح الحقائب',
    cta_en: 'Browse Handbags',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1600&auto=format&fit=crop',
    categoryLink: 'handbags'
  }
];

export const HeroCarousel: React.FC = () => {
  const { language, navigateTo } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % CAMPAIGNS.length);
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + CAMPAIGNS.length) % CAMPAIGNS.length);
  }, []);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, [isPlaying, nextSlide]);

  const slide = CAMPAIGNS[currentIndex];

  // In RTL, "Next" arrow visually points Left, and "Prev" points Right.
  const isRtl = language === 'ar';
  const LeftIcon = isRtl ? ChevronRight : ChevronLeft;
  const RightIcon = isRtl ? ChevronLeft : ChevronRight;

  return (
    <div 
      className="relative w-full bg-[#1A1A1A] overflow-hidden group border-b border-[#D1C9BC]"
      onMouseEnter={() => setIsPlaying(false)}
      onMouseLeave={() => setIsPlaying(true)}
    >
      {/* Background Image Container with Immersive Overlay */}
      <div className="relative h-[480px] sm:h-[540px] md:h-[580px] w-full">
        {CAMPAIGNS.map((c, index) => {
          const isActive = index === currentIndex;
          return (
            <div
              key={c.id}
              className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                isActive ? 'opacity-100 z-10' : 'opacity-0 z-0'
              }`}
            >
              <img
                src={c.image}
                alt={language === 'ar' ? c.title_ar : c.title_en}
                className="w-full h-full object-cover object-center scale-105 animate-subtleZoom opacity-70"
              />
              {/* Immersive Theme Gradient Overlays */}
              <div className="absolute inset-0 bg-gradient-to-r from-[#1A1A1A]/95 via-[#1A1A1A]/60 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A] via-transparent to-[#1A1A1A]/40" />
            </div>
          );
        })}

        {/* Hero Content Overlay */}
        <div className="relative z-20 max-w-7xl mx-auto h-full px-8 sm:px-16 flex items-center">
          <div className="max-w-xl text-white space-y-5 animate-fadeIn">
            
            {/* Badge & Decorative Hairline */}
            <div className="flex items-center gap-3">
              <div className="w-8 h-[1px] bg-[#A89060]"></div>
              <span className="text-[#A89060] text-xs font-bold tracking-widest uppercase">
                {language === 'ar' ? slide.badge_ar : slide.badge_en}
              </span>
            </div>

            {/* Subheading */}
            <p className="font-serif font-light text-base sm:text-xl text-[#EAE3D8]">
              {language === 'ar' ? slide.subheading_ar : slide.subheading_en}
            </p>

            {/* Main Title */}
            <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl text-white leading-[1.1]">
              {language === 'ar' ? slide.title_ar : slide.title_en}
            </h1>

            {/* Description */}
            <p className="text-[#EAE3D8]/80 text-xs sm:text-sm leading-relaxed max-w-md">
              {language === 'ar' ? slide.description_ar : slide.description_en}
            </p>

            {/* CTA Button */}
            <div className="pt-2">
              <button
                onClick={() => navigateTo('category', { categoryId: slide.categoryLink })}
                className="inline-flex items-center gap-3 bg-[#1A1A1A] text-white px-10 py-4 text-xs font-bold tracking-widest border border-[#A89060] hover:bg-[#A89060] transition-colors cursor-pointer"
              >
                <span>{language === 'ar' ? slide.cta_ar : slide.cta_en}</span>
                <RightIcon className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Counter and Navigation Controls */}
        <div className="absolute bottom-8 right-8 sm:right-16 z-30 flex items-center gap-4 text-white">
          <button
            onClick={prevSlide}
            className="w-10 h-10 border border-[#EAE3D8]/40 rounded-full flex items-center justify-center cursor-pointer hover:border-[#A89060] hover:bg-[#A89060] transition-all"
            aria-label="Previous Slide"
          >
            <LeftIcon className="w-4 h-4" />
          </button>
          
          <div className="text-xs font-bold font-mono tracking-widest text-white">
            0{currentIndex + 1} <span className="text-[#7D7463] font-light mx-1">/</span> 0{CAMPAIGNS.length}
          </div>

          <button
            onClick={nextSlide}
            className="w-10 h-10 bg-[#1A1A1A] border border-[#A89060] text-white rounded-full flex items-center justify-center cursor-pointer hover:bg-[#A89060] transition-all"
            aria-label="Next Slide"
          >
            <RightIcon className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="ms-2 text-[#EAE3D8]/60 hover:text-white transition-colors p-1"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </div>
  );
};
