import React from 'react';
import { useApp } from '../context/AppContext';
import { GULF_COUNTRIES } from '../data/countries';
import { X, Check, MapPin } from 'lucide-react';

interface CountrySelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CountrySelectorModal: React.FC<CountrySelectorModalProps> = ({ isOpen, onClose }) => {
  const { country, setCountry, language } = useApp();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-[#FBF9F5] rounded-2xl border border-[#C5A059]/40 w-full max-w-md shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#EAE0D0] bg-[#F4EFE6]">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-[#C5A059]" />
            <h3 className="font-bold text-lg text-[#121110]">
              {language === 'ar' ? 'اختر دولة التوصيل والعملة' : 'Select Delivery Country & Currency'}
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-black hover:bg-black/5 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of Gulf Countries */}
        <div className="p-4 space-y-2 max-h-[60vh] overflow-y-auto">
          {GULF_COUNTRIES.map((c) => {
            const isSelected = country.code === c.code;
            return (
              <button
                key={c.code}
                onClick={() => {
                  setCountry(c.code);
                  onClose();
                }}
                className={`w-full flex items-center justify-between p-4 rounded-xl border text-start transition-all cursor-pointer ${
                  isSelected 
                    ? 'border-[#C5A059] bg-[#EAE0D0]/40 shadow-sm ring-1 ring-[#C5A059]'
                    : 'border-[#EAE0D0] bg-white hover:border-[#C5A059]/50 hover:bg-[#F4EFE6]/50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl" role="img" aria-label={c.name_en}>
                    {c.flag}
                  </span>
                  <div>
                    <h4 className="font-bold text-[#121110] text-sm">
                      {language === 'ar' ? c.name_ar : c.name_en}
                    </h4>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {language === 'ar' ? `التوصيل: ${c.deliveryDays}` : `Delivery: ${c.deliveryDays}`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="px-2.5 py-1 bg-[#231F1D] text-[#DFBF7A] text-xs font-semibold rounded-md dir-ltr">
                    {language === 'ar' ? c.currencySymbol_ar : c.currencySymbol_en}
                  </span>
                  {isSelected && (
                    <div className="w-6 h-6 rounded-full bg-[#C5A059] text-white flex items-center justify-center">
                      <Check className="w-4 h-4" />
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#F4EFE6] border-t border-[#EAE0D0] text-center text-xs text-gray-600">
          {language === 'ar' 
            ? 'تتغير الأسعار والضرائب ومواعيد التوصيل تلقائياً حسب الدولة المختارة.'
            : 'Prices, VAT rates, and delivery estimates adapt automatically to your selection.'}
        </div>
      </div>
    </div>
  );
};
