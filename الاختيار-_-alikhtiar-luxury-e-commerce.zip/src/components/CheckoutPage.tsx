import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatPrice } from '../data/countries';
import { Order } from '../types';
import { 
  CheckCircle2, 
  MapPin, 
  Truck, 
  CreditCard, 
  ShieldCheck, 
  ArrowLeft, 
  ArrowRight,
  Smartphone,
  Lock,
  Copy,
  ChevronRight
} from 'lucide-react';

export const CheckoutPage: React.FC = () => {
  const { 
    cart, 
    language, 
    country, 
    user, 
    appliedCoupon, 
    createOrder, 
    navigateTo, 
    showToast 
  } = useApp();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form states
  const [fullName, setFullName] = useState(user.name);
  const [phone, setPhone] = useState('508891234');
  const [email, setEmail] = useState(user.email);
  const [city, setCity] = useState(country.cities[0] || 'الرياض');
  const [district, setDistrict] = useState('حي الصحافة');
  const [street, setStreet] = useState('شارع العليا الرئيسي، فيلا 42');
  
  const [deliveryOption, setDeliveryOption] = useState<'express' | 'standard'>('express');
  const [paymentMethod, setPaymentMethod] = useState<string>('applepay');

  // Completed Order storage
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  const subtotalSAR = cart.reduce((acc, item) => acc + item.product.priceSAR * item.quantity, 0);
  const discountSAR = appliedCoupon ? subtotalSAR * 0.10 : 0;
  const vatSAR = (subtotalSAR - discountSAR) * country.vatRate;
  const totalSAR = subtotalSAR - discountSAR + vatSAR;

  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const handlePlaceOrder = () => {
    const shippingAddress = {
      name: fullName,
      city,
      district,
      street,
      phone: `${country.phonePrefix} ${phone}`,
      country: isAr ? country.name_ar : country.name_en
    };

    const newOrd = createOrder(shippingAddress, paymentMethod);
    setCompletedOrder(newOrd);
    setStep(4);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (cart.length === 0 && step !== 4) {
    return (
      <div className="py-20 text-center bg-[#FBF9F5]">
        <h3 className="font-bold text-xl text-[#121110] mb-2">
          {isAr ? 'سلة التسوق فارغة' : 'Your Shopping Cart is Empty'}
        </h3>
        <button
          onClick={() => navigateTo('home')}
          className="mt-4 bg-[#C5A059] text-white px-6 py-2.5 rounded-full font-bold text-xs"
        >
          {isAr ? 'العودة للرئيسية' : 'Return to Home'}
        </button>
      </div>
    );
  }

  return (
    <div className="py-10 bg-[#FBF9F5]">
      <div className="max-w-6xl mx-auto px-4">
        
        {/* Step Progress Bar */}
        <div className="mb-10 bg-white rounded-2xl p-4 border border-[#EAE0D0] shadow-sm">
          <div className="flex items-center justify-between max-w-2xl mx-auto text-xs font-bold">
            
            <div className={`flex items-center gap-2 ${step >= 1 ? 'text-[#C5A059]' : 'text-gray-400'}`}>
              <div className={`w-7 h-7 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-[#C5A059] text-white' : 'bg-gray-200'}`}>
                1
              </div>
              <span className="hidden sm:inline">{isAr ? 'العنوان' : 'Address'}</span>
            </div>

            <div className={`h-0.5 flex-1 mx-2 ${step >= 2 ? 'bg-[#C5A059]' : 'bg-gray-200'}`} />

            <div className={`flex items-center gap-2 ${step >= 2 ? 'text-[#C5A059]' : 'text-gray-400'}`}>
              <div className={`w-7 h-7 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-[#C5A059] text-white' : 'bg-gray-200'}`}>
                2
              </div>
              <span className="hidden sm:inline">{isAr ? 'الشحن' : 'Delivery'}</span>
            </div>

            <div className={`h-0.5 flex-1 mx-2 ${step >= 3 ? 'bg-[#C5A059]' : 'bg-gray-200'}`} />

            <div className={`flex items-center gap-2 ${step >= 3 ? 'text-[#C5A059]' : 'text-gray-400'}`}>
              <div className={`w-7 h-7 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-[#C5A059] text-white' : 'bg-gray-200'}`}>
                3
              </div>
              <span className="hidden sm:inline">{isAr ? 'الدفع' : 'Payment'}</span>
            </div>

            <div className={`h-0.5 flex-1 mx-2 ${step >= 4 ? 'bg-[#C5A059]' : 'bg-gray-200'}`} />

            <div className={`flex items-center gap-2 ${step === 4 ? 'text-[#C5A059]' : 'text-gray-400'}`}>
              <div className={`w-7 h-7 rounded-full flex items-center justify-center ${step === 4 ? 'bg-[#C5A059] text-white' : 'bg-gray-200'}`}>
                4
              </div>
              <span className="hidden sm:inline">{isAr ? 'التأكيد' : 'Confirmation'}</span>
            </div>

          </div>
        </div>

        {/* ORDER CONFIRMATION VIEW (STEP 4) */}
        {step === 4 && completedOrder && (
          <div className="bg-white rounded-3xl p-8 sm:p-12 border border-[#C5A059]/40 shadow-2xl text-center max-w-3xl mx-auto space-y-6 animate-fadeIn">
            <div className="w-20 h-20 rounded-full bg-[#0F382C] text-[#DFBF7A] mx-auto flex items-center justify-center border-2 border-[#C5A059]">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <span className="text-xs font-bold text-[#C5A059] uppercase tracking-widest">
                {isAr ? 'تمت عملية الشراء بنجاح' : 'Payment Successful'}
              </span>
              <h2 className="font-arabic-heading text-3xl font-extrabold text-[#121110]">
                {isAr ? 'شكراً لتسوقك من الاختيار' : 'Thank you for shopping with ALIKHTIAR'}
              </h2>
              <p className="text-xs text-gray-500 max-w-md mx-auto">
                {isAr
                  ? `تم إرسال تفاصيل الفاتورة الإلكترونية وتتبع الشحنة إلى بريدك ${completedOrder.shippingAddress.name}.`
                  : `Confirmation and receipt sent to ${completedOrder.shippingAddress.name}.`}
              </p>
            </div>

            {/* Order Cards Meta */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-start text-xs bg-[#F4EFE6] p-6 rounded-2xl border border-[#EAE0D0]">
              <div>
                <span className="text-gray-400 block">{isAr ? 'رقم الطلب:' : 'Order Number:'}</span>
                <span className="font-mono font-bold text-sm text-[#121110]">{completedOrder.orderNumber}</span>
              </div>
              <div>
                <span className="text-gray-400 block">{isAr ? 'رقم تتبع الشحنة:' : 'Tracking Code:'}</span>
                <span className="font-mono font-bold text-sm text-[#C5A059]">{completedOrder.trackingNumber}</span>
              </div>
              <div>
                <span className="text-gray-400 block">{isAr ? 'عنوان التوصيل:' : 'Delivery Address:'}</span>
                <span className="font-bold text-[#121110]">
                  {completedOrder.shippingAddress.city}، {completedOrder.shippingAddress.district}
                </span>
              </div>
              <div>
                <span className="text-gray-400 block">{isAr ? 'الموعد المتوقع للتوصيل:' : 'Estimated Delivery:'}</span>
                <span className="font-bold text-emerald-700">{completedOrder.estimatedDelivery}</span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <button
                onClick={() => navigateTo('account')}
                className="w-full sm:w-auto bg-[#231F1D] text-[#DFBF7A] px-8 py-3.5 rounded-full font-bold text-xs border border-[#C5A059] shadow-lg cursor-pointer"
              >
                {isAr ? 'تتبع الطلب في حسابي' : 'Track Order in My Account'}
              </button>
              <button
                onClick={() => navigateTo('home')}
                className="w-full sm:w-auto bg-[#C5A059] text-white px-8 py-3.5 rounded-full font-bold text-xs shadow-lg cursor-pointer"
              >
                {isAr ? 'متابعة التسوق' : 'Continue Shopping'}
              </button>
            </div>
          </div>
        )}

        {/* MULTI-STEP FORM (STEPS 1, 2, 3) */}
        {step < 4 && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Main Form Box (2 Cols) */}
            <div className="lg:col-span-2 space-y-8">
              
              {/* STEP 1: SHIPPING ADDRESS */}
              {step === 1 && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE0D0] shadow-sm space-y-6">
                  <div className="flex items-center gap-2 text-[#C5A059] font-bold text-lg border-b border-[#F4EFE6] pb-4">
                    <MapPin className="w-5 h-5" />
                    <h3>{isAr ? '1. عنوان التوصيل الفاخر' : '1. Delivery Address'}</h3>
                  </div>

                  {/* Saved Address Quick Select */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-700 block">
                      {isAr ? 'اختر من العناوين المحفوظة:' : 'Select Saved Address:'}
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {user.savedAddresses.map((addr) => (
                        <button
                          key={addr.id}
                          type="button"
                          onClick={() => {
                            setFullName(addr.name);
                            setCity(addr.city);
                            setDistrict(isAr ? 'حي الصحافة' : 'Downtown');
                            setStreet(addr.address);
                          }}
                          className="p-3 rounded-xl border border-[#C5A059]/40 bg-[#F4EFE6]/50 hover:bg-[#F4EFE6] text-start text-xs font-bold transition-all"
                        >
                          <span className="text-[#C5A059] block mb-0.5">
                            {isAr ? addr.title_ar : addr.title_en}
                          </span>
                          <span className="text-[#121110] block">{addr.address}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Input Fields */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="font-bold text-gray-700 block mb-1">
                        {isAr ? 'الاسم الكامل' : 'Full Name'}
                      </label>
                      <input
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full p-3 bg-[#F4EFE6]/50 border border-[#EAE0D0] focus:border-[#C5A059] rounded-xl outline-none"
                      />
                    </div>

                    <div>
                      <label className="font-bold text-gray-700 block mb-1">
                        {isAr ? 'رقم الجوال (بدون رمز الدولة)' : 'Mobile Number'}
                      </label>
                      <div className="flex dir-ltr">
                        <span className="bg-[#231F1D] text-[#DFBF7A] px-3 flex items-center rounded-l-xl font-mono text-xs border border-[#231F1D]">
                          {country.phonePrefix}
                        </span>
                        <input
                          type="text"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="w-full p-3 bg-[#F4EFE6]/50 border border-[#EAE0D0] focus:border-[#C5A059] rounded-r-xl outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="font-bold text-gray-700 block mb-1">
                        {isAr ? 'المدينة' : 'City'}
                      </label>
                      <select
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full p-3 bg-[#F4EFE6]/50 border border-[#EAE0D0] focus:border-[#C5A059] rounded-xl outline-none"
                      >
                        {country.cities.map((c, i) => (
                          <option key={i} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="font-bold text-gray-700 block mb-1">
                        {isAr ? 'الحي / المنطقة' : 'District'}
                      </label>
                      <input
                        type="text"
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        className="w-full p-3 bg-[#F4EFE6]/50 border border-[#EAE0D0] focus:border-[#C5A059] rounded-xl outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="font-bold text-gray-700 block mb-1">
                        {isAr ? 'تفاصيل اسم الشارع والبناء والفيلا' : 'Street & Villa Details'}
                      </label>
                      <input
                        type="text"
                        value={street}
                        onChange={(e) => setStreet(e.target.value)}
                        className="w-full p-3 bg-[#F4EFE6]/50 border border-[#EAE0D0] focus:border-[#C5A059] rounded-xl outline-none"
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => setStep(2)}
                    className="w-full flex items-center justify-center gap-2 bg-[#C5A059] text-white py-3.5 rounded-xl font-bold text-xs shadow-lg hover:bg-[#A37C42] cursor-pointer"
                  >
                    <span>{isAr ? 'الانتقال إلى خيارات الشحن' : 'Proceed to Delivery Options'}</span>
                    <ArrowIcon className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* STEP 2: SHIPPING OPTIONS */}
              {step === 2 && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE0D0] shadow-sm space-y-6">
                  <div className="flex items-center gap-2 text-[#C5A059] font-bold text-lg border-b border-[#F4EFE6] pb-4">
                    <Truck className="w-5 h-5" />
                    <h3>{isAr ? '2. خيارات التوصيل الفاخر' : '2. Delivery Options'}</h3>
                  </div>

                  <div className="space-y-3">
                    <button
                      onClick={() => setDeliveryOption('express')}
                      className={`w-full p-4 rounded-2xl border flex items-center justify-between text-start transition-all cursor-pointer ${
                        deliveryOption === 'express'
                          ? 'border-[#C5A059] bg-[#F4EFE6] ring-1 ring-[#C5A059]'
                          : 'border-[#EAE0D0] bg-white'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-[#231F1D] text-[#DFBF7A] flex items-center justify-center">
                          <Truck className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-xs text-[#121110]">
                            {isAr ? 'التوصيل الفاخر الممتاز (خلال 24 ساعة)' : 'VIP Express Luxury Delivery (Within 24h)'}
                          </h4>
                          <p className="text-[11px] text-gray-500">
                            {isAr ? 'توصيل عبر سيارات خاصة مجهزة بعناية فائقة' : 'White-glove courier with climate protection'}
                          </p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-emerald-700">{isAr ? 'مجاني' : 'FREE'}</span>
                    </button>

                    <button
                      onClick={() => setDeliveryOption('standard')}
                      className={`w-full p-4 rounded-2xl border flex items-center justify-between text-start transition-all cursor-pointer ${
                        deliveryOption === 'standard'
                          ? 'border-[#C5A059] bg-[#F4EFE6] ring-1 ring-[#C5A059]'
                          : 'border-[#EAE0D0] bg-white'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gray-100 text-gray-700 flex items-center justify-center">
                          <Truck className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-xs text-[#121110]">
                            {isAr ? 'التوصيل القياسي (خلال 1-2 يوم عمل)' : 'Standard Delivery (1-2 Days)'}
                          </h4>
                          <p className="text-[11px] text-gray-500">
                            {isAr ? `توصيل قياسي لدولة ${country.name_ar}` : `Standard shipping across ${country.name_en}`}
                          </p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-emerald-700">{isAr ? 'مجاني' : 'FREE'}</span>
                    </button>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => setStep(1)}
                      className="px-6 py-3 border border-gray-300 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-50"
                    >
                      {isAr ? 'الرجوع' : 'Back'}
                    </button>
                    <button
                      onClick={() => setStep(3)}
                      className="flex-1 flex items-center justify-center gap-2 bg-[#C5A059] text-white py-3.5 rounded-xl font-bold text-xs shadow-lg hover:bg-[#A37C42] cursor-pointer"
                    >
                      <span>{isAr ? 'الانتقال إلى طرق الدفع' : 'Proceed to Payment Options'}</span>
                      <ArrowIcon className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: PAYMENT METHOD */}
              {step === 3 && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE0D0] shadow-sm space-y-6">
                  <div className="flex items-center gap-2 text-[#C5A059] font-bold text-lg border-b border-[#F4EFE6] pb-4">
                    <CreditCard className="w-5 h-5" />
                    <h3>{isAr ? '3. اختر طريقة الدفع المشفرة' : '3. Payment Method'}</h3>
                  </div>

                  {/* Payment Methods Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    {[
                      { id: 'applepay', name: 'Apple Pay', desc: isAr ? 'دفع سريع بلمسة واحدة' : 'One-touch checkout', badge: 'Popular' },
                      { id: 'mada', name: 'بطاقة مدى mada', desc: isAr ? 'الدفع المباشر للخليج' : 'Saudi & Gulf Debit', badge: 'Recommended' },
                      { id: 'card', name: 'Visa / Mastercard / AMEX', desc: isAr ? 'بطاقة ائتمان تشفير 256-bit' : 'Encrypted Credit Card' },
                      { id: 'stcpay', name: 'stc pay', desc: isAr ? 'محفظة stc الرقمية' : 'Digital Wallet' },
                      { id: 'tamara', name: 'تمارا Tamara (4 دفعات)', desc: isAr ? 'قسمها على 4 بدون فوائد' : 'Split in 4 interest-free' },
                      { id: 'tabby', name: 'تابي Tabby (4 دفعات)', desc: isAr ? 'قسم فاتورتك على 4 أشهر' : 'Split into 4 monthly payments' },
                      { id: 'cod', name: isAr ? 'الدفع عند الاستلام' : 'Cash on Delivery', desc: isAr ? 'دفع نقدي عند وصول الشحنة' : 'Pay upon arrival' },
                    ].map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => setPaymentMethod(m.id)}
                        className={`p-4 rounded-2xl border text-start transition-all cursor-pointer ${
                          paymentMethod === m.id
                            ? 'border-[#C5A059] bg-[#231F1D] text-white ring-2 ring-[#C5A059]/40 shadow-lg'
                            : 'border-[#EAE0D0] bg-white text-[#121110] hover:border-[#C5A059]'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-sm">{m.name}</span>
                          {m.badge && (
                            <span className="text-[10px] bg-[#C5A059] text-white px-2 py-0.5 rounded font-extrabold">
                              {m.badge}
                            </span>
                          )}
                        </div>
                        <span className={`text-[11px] ${paymentMethod === m.id ? 'text-gray-300' : 'text-gray-500'}`}>
                          {m.desc}
                        </span>
                      </button>
                    ))}
                  </div>

                  {/* Simulated Card Form if Card selected */}
                  {paymentMethod === 'card' && (
                    <div className="p-4 bg-[#F4EFE6] rounded-2xl border border-[#C5A059]/40 space-y-3 text-xs">
                      <div className="flex items-center justify-between text-gray-700 font-bold">
                        <span>{isAr ? 'تفاصيل البطاقة' : 'Card Details'}</span>
                        <Lock className="w-3.5 h-3.5 text-[#C5A059]" />
                      </div>
                      <input
                        type="text"
                        placeholder="4111 2222 3333 4444"
                        className="w-full p-2.5 bg-white border border-gray-300 rounded-xl outline-none dir-ltr font-mono"
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          placeholder="MM/YY"
                          className="p-2.5 bg-white border border-gray-300 rounded-xl outline-none dir-ltr text-center font-mono"
                        />
                        <input
                          type="text"
                          placeholder="CVC"
                          className="p-2.5 bg-white border border-gray-300 rounded-xl outline-none dir-ltr text-center font-mono"
                        />
                      </div>
                    </div>
                  )}

                  <div className="flex gap-3 pt-2">
                    <button
                      onClick={() => setStep(2)}
                      className="px-6 py-3 border border-gray-300 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-50"
                    >
                      {isAr ? 'الرجوع' : 'Back'}
                    </button>
                    <button
                      onClick={handlePlaceOrder}
                      className="flex-1 flex items-center justify-center gap-2 bg-[#C5A059] hover:bg-[#A37C42] text-white py-4 rounded-xl font-extrabold text-sm shadow-xl transition-all cursor-pointer hover:scale-[1.01]"
                    >
                      <Lock className="w-4 h-4" />
                      <span>{isAr ? `تأكيد ودفع ${formatPrice(totalSAR, country, isAr)}` : `Confirm & Pay ${formatPrice(totalSAR, country, isAr)}`}</span>
                    </button>
                  </div>

                </div>
              )}

            </div>

            {/* Sidebar Summary Box (1 Col) */}
            <div className="space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-[#EAE0D0] shadow-sm space-y-4">
                <h4 className="font-arabic-heading font-bold text-base text-[#121110] border-b border-[#F4EFE6] pb-3">
                  {isAr ? 'ملخص الطلب' : 'Order Summary'}
                </h4>

                {/* Items Mini List */}
                <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                  {cart.map((item) => (
                    <div key={item.product.id} className="flex gap-3 text-xs">
                      <img
                        src={item.product.images[0]}
                        alt="item"
                        className="w-12 h-12 object-cover rounded-lg bg-gray-100 flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h5 className="font-bold text-[#121110] truncate">
                          {isAr ? item.product.name_ar : item.product.name_en}
                        </h5>
                        <span className="text-gray-400 block">{item.quantity} x {formatPrice(item.product.priceSAR, country, isAr)}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="space-y-2 text-xs border-t border-[#F4EFE6] pt-3">
                  <div className="flex justify-between text-gray-600">
                    <span>{isAr ? 'المجموع الفرعي' : 'Subtotal'}</span>
                    <span className="font-bold text-[#121110]">{formatPrice(subtotalSAR, country, isAr)}</span>
                  </div>
                  {appliedCoupon && (
                    <div className="flex justify-between text-emerald-700 font-bold">
                      <span>{isAr ? 'الخصم المطبق' : 'Discount'}</span>
                      <span>-{formatPrice(discountSAR, country, isAr)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-gray-600">
                    <span>{isAr ? 'الشحن' : 'Shipping'}</span>
                    <span className="text-emerald-700 font-bold">{isAr ? 'مجاني' : 'FREE'}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>{isAr ? 'الضريبة' : 'VAT'}</span>
                    <span>{formatPrice(vatSAR, country, isAr)}</span>
                  </div>
                  <div className="flex justify-between text-base font-black text-[#121110] pt-2 border-t border-dashed border-[#EAE0D0]">
                    <span>{isAr ? 'الإجمالي' : 'Total'}</span>
                    <span className="text-[#C5A059] font-arabic-heading">{formatPrice(totalSAR, country, isAr)}</span>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-1.5 text-[11px] text-gray-500 pt-2 border-t border-[#F4EFE6]">
                  <ShieldCheck className="w-4 h-4 text-[#C5A059]" />
                  <span>{isAr ? 'دفع مشفر 256-bit آمن 100%' : '100% Encrypted SSL Checkout'}</span>
                </div>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
