import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS } from '../data/products';
import { Search, X, TrendingUp, Sparkles, ArrowLeft, ArrowRight } from 'lucide-react';
import { formatPrice } from '../data/countries';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

const POPULAR_SEARCHES_AR = ['عطور', 'ساعات', 'حقائب', 'أحذية', 'عبايات', 'مجوهرات', 'هواتف', 'سماعات'];
const POPULAR_SEARCHES_EN = ['perfumes', 'watches', 'handbags', 'shoes', 'abayas', 'jewelry', 'phones', 'headphones'];

export const SearchOverlay: React.FC<SearchOverlayProps> = ({ isOpen, onClose }) => {
  const { language, country, navigateTo, openQuickView, searchQuery, setSearchQuery } = useApp();
  const [localQuery, setLocalQuery] = useState(searchQuery || '');

  // Normalize Arabic text helper
  const normalizeText = (str: string) => {
    return str
      .toLowerCase()
      .replace(/[أإآ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .trim();
  };

  const filteredProducts = useMemo(() => {
    if (!localQuery.trim()) return [];
    const q = normalizeText(localQuery);

    return PRODUCTS.filter(p => {
      const nameAr = normalizeText(p.name_ar);
      const nameEn = p.name_en.toLowerCase();
      const brand = p.brand.toLowerCase();
      const category = p.category.toLowerCase();
      const descAr = normalizeText(p.description_ar);
      const descEn = p.description_en.toLowerCase();
      const tags = p.tags.map(t => normalizeText(t)).join(' ');

      return (
        nameAr.includes(q) ||
        nameEn.includes(q) ||
        brand.includes(q) ||
        category.includes(q) ||
        descAr.includes(q) ||
        descEn.includes(q) ||
        tags.includes(q)
      );
    });
  }, [localQuery]);

  if (!isOpen) return null;

  const popularSearches = language === 'ar' ? POPULAR_SEARCHES_AR : POPULAR_SEARCHES_EN;
  const ArrowIcon = language === 'ar' ? ArrowLeft : ArrowRight;

  const handleSelectQuery = (term: string) => {
    setLocalQuery(term);
    setSearchQuery(term);
    navigateTo('search-results', { query: term });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md animate-fadeIn flex flex-col justify-start">
      <div className="bg-[#FBF9F5] border-b border-[#C5A059]/30 shadow-2xl p-4 md:p-8">
        <div className="max-w-5xl mx-auto">
          {/* Top Bar with Input & Close */}
          <div className="flex items-center justify-between mb-6">
            <span className="text-xs font-semibold text-[#C5A059] uppercase tracking-widest flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              {language === 'ar' ? 'البحث الذكي الفاخر' : 'Smart Luxury Search'}
            </span>
            <button
              onClick={onClose}
              className="p-2 text-gray-500 hover:text-black rounded-full hover:bg-black/5 transition-colors cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Large Search Input */}
          <div className="relative mb-6">
            <Search className={`absolute top-1/2 -translate-y-1/2 ${language === 'ar' ? 'right-4' : 'left-4'} w-7 h-7 text-[#C5A059]`} />
            <input
              type="text"
              value={localQuery}
              onChange={(e) => setLocalQuery(e.target.value)}
              placeholder={language === 'ar' ? 'ماذا تبحث اليوم؟ (مثل: عطر عود، ساعة فاخرة، حقيبة...)' : 'What are you looking for today? (e.g. Oud perfume, luxury watch...)'}
              autoFocus
              className={`w-full py-4 ${language === 'ar' ? 'pr-14 pl-12' : 'pl-14 pr-12'} bg-white border-2 border-[#C5A059]/40 focus:border-[#C5A059] rounded-2xl text-lg md:text-xl text-[#121110] outline-none shadow-lg transition-all placeholder:text-gray-400`}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && localQuery.trim()) {
                  setSearchQuery(localQuery);
                  navigateTo('search-results', { query: localQuery });
                  onClose();
                }
              }}
            />
            {localQuery && (
              <button
                onClick={() => setLocalQuery('')}
                className={`absolute top-1/2 -translate-y-1/2 ${language === 'ar' ? 'left-4' : 'right-4'} text-gray-400 hover:text-black`}
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Popular Search Tags */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3 text-xs font-bold text-gray-600 uppercase tracking-wider">
              <TrendingUp className="w-4 h-4 text-[#C5A059]" />
              {language === 'ar' ? 'عمليات البحث الشائعة' : 'Popular Searches'}
            </div>
            <div className="flex flex-wrap gap-2">
              {popularSearches.map((term, i) => (
                <button
                  key={i}
                  onClick={() => handleSelectQuery(term)}
                  className="px-4 py-2 bg-[#F4EFE6] hover:bg-[#C5A059] hover:text-white text-[#121110] text-sm rounded-full border border-[#EAE0D0] transition-all cursor-pointer"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>

          {/* Instant Search Results Preview */}
          {localQuery.trim() && (
            <div className="mt-6 border-t border-[#EAE0D0] pt-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-bold text-[#121110] text-base">
                  {language === 'ar'
                    ? `النتائج المتاحة (${filteredProducts.length})`
                    : `Matching Results (${filteredProducts.length})`}
                </h4>
                {filteredProducts.length > 0 && (
                  <button
                    onClick={() => {
                      setSearchQuery(localQuery);
                      navigateTo('search-results', { query: localQuery });
                      onClose();
                    }}
                    className="text-xs font-bold text-[#C5A059] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    {language === 'ar' ? 'عرض كافة النتائج' : 'View All Results'}
                    <ArrowIcon className="w-4 h-4" />
                  </button>
                )}
              </div>

              {filteredProducts.length === 0 ? (
                <div className="py-8 text-center bg-white rounded-xl border border-dashed border-gray-300">
                  <p className="text-gray-500 text-sm">
                    {language === 'ar'
                      ? `لم نتمكن من العثور على نتائج مطابقة لـ "${localQuery}"`
                      : `No products matching your search for "${localQuery}"`}
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    {language === 'ar' ? 'جرب البحث عن كلمات أخرى مثل: عطر، ساعات، عبايات' : 'Try terms like perfume, watches, abayas'}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 max-h-[50vh] overflow-y-auto pr-1">
                  {filteredProducts.slice(0, 4).map(product => (
                    <div
                      key={product.id}
                      onClick={() => {
                        navigateTo('product-detail', { productId: product.id });
                        onClose();
                      }}
                      className="group flex gap-3 p-3 bg-white rounded-xl border border-[#EAE0D0] hover:border-[#C5A059] hover:shadow-md transition-all cursor-pointer"
                    >
                      <img
                        src={product.images[0]}
                        alt={language === 'ar' ? product.name_ar : product.name_en}
                        className="w-16 h-16 object-cover rounded-lg bg-gray-100 flex-shrink-0 group-hover:scale-105 transition-transform"
                      />
                      <div className="flex flex-col justify-center min-w-0">
                        <span className="text-[10px] text-[#C5A059] font-semibold uppercase tracking-wider">
                          {product.brand}
                        </span>
                        <h5 className="text-xs font-bold text-[#121110] truncate mt-0.5">
                          {language === 'ar' ? product.name_ar : product.name_en}
                        </h5>
                        <div className="text-xs font-extrabold text-[#C5A059] mt-1">
                          {formatPrice(product.priceSAR, country, language === 'ar')}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {/* Click outside backdrop to close */}
      <div className="flex-1" onClick={onClose} />
    </div>
  );
};
