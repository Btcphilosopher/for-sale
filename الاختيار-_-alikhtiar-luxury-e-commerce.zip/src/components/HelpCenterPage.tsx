import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { HelpCircle, Truck, RotateCcw, ShieldCheck, PhoneCall, Mail, Search, ChevronDown } from 'lucide-react';

export const HelpCenterPage: React.FC = () => {
  const { language, country } = useApp();
  const [trackCode, setTrackCode] = useState('');
  const [trackingResult, setTrackingResult] = useState<string | null>(null);

  const isAr = language === 'ar';

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackCode) return;
    setTrackingResult(
      isAr 
        ? `الشحنة رقم ${trackCode}: قيد التوصيل الفاخر إلى ${country.name_ar} (الموعد المتوقع: ${country.deliveryDays}).`
        : `Shipment #${trackCode}: En route via VIP express to ${country.name_en} (${country.deliveryDays}).`
    );
  };

  const faqs = [
    {
      q_ar: 'كم تستغرق مدة التوصيل داخل دول الخليج؟',
      q_en: 'How long does delivery take across the GCC?',
      a_ar: `التوصيل في ${country.name_ar} يستغرق ${country.deliveryDays}. نوفر خدمة الشحن الفاخر السريع بالسيارات المكيفة الحافظة للمنتجات.`,
      a_en: `Delivery to ${country.name_en} takes ${country.deliveryDays}. We use climate-controlled VIP couriers.`
    },
    {
      q_ar: 'كيف يمكنني طلب إرجاع أو استبدال منتج؟',
      q_en: 'How do I request a return or exchange?',
      a_ar: 'يمكنك طلب الإرجاع مجاناً خلال 14 يوماً من استلام الطلب عن طريق التواصل مع خدمة العملاء أو من خلال صفحة حسابي.',
      a_en: 'Returns are complimentary within 14 days of receipt via client care or your account portal.'
    },
    {
      q_ar: 'هل جميع عطور وساعات الاختيار أصيلة 100%؟',
      q_en: 'Are all Oud perfumes and Swiss watches 100% authentic?',
      a_ar: 'نعم، جميع المنتجات أصلية 100% ومستوردة مباشرة من دور الموضة والعطور العالمية المعتمدة مع شهادة أصالة.',
      a_en: 'Yes, 100% genuine guaranteed with certificates of origin and warranty.'
    }
  ];

  return (
    <div className="py-12 bg-[#FBF9F5]">
      <div className="max-w-5xl mx-auto px-4 space-y-12">
        
        {/* Track Shipment Search Box */}
        <div className="bg-[#231F1D] text-white rounded-3xl p-8 sm:p-12 border border-[#C5A059]/40 shadow-2xl text-center space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-[#C5A059] text-white mx-auto flex items-center justify-center">
            <Truck className="w-8 h-8" />
          </div>
          <h1 className="font-arabic-heading text-3xl font-extrabold">
            {isAr ? 'تتبع شحنتك المباشرة' : 'Track Your Live Shipment'}
          </h1>
          <p className="text-xs text-gray-300 max-w-md mx-auto">
            {isAr ? 'أدخل رقم التتبع المكون من 10 أرقام (مثال: ALK-982410)' : 'Enter your tracking code (e.g. ALK-982410)'}
          </p>

          <form onSubmit={handleTrack} className="flex flex-col sm:flex-row items-center max-w-lg mx-auto gap-3">
            <input
              type="text"
              value={trackCode}
              onChange={(e) => setTrackCode(e.target.value)}
              placeholder="ALK-XXXXXXXX"
              className="w-full p-3.5 bg-black/60 border border-[#C5A059]/40 rounded-xl text-xs font-mono text-center sm:text-start text-white outline-none focus:border-[#C5A059]"
            />
            <button
              type="submit"
              className="w-full sm:w-auto bg-[#C5A059] hover:bg-[#A37C42] text-white font-bold text-xs px-8 py-3.5 rounded-xl shadow cursor-pointer whitespace-nowrap"
            >
              {isAr ? 'تتبع الآن' : 'Track Status'}
            </button>
          </form>

          {trackingResult && (
            <div className="p-4 bg-[#C5A059]/20 border border-[#C5A059] rounded-xl text-xs font-bold text-[#DFBF7A] max-w-lg mx-auto">
              {trackingResult}
            </div>
          )}
        </div>

        {/* FAQ Section */}
        <div className="bg-white rounded-3xl p-8 border border-[#EAE0D0] shadow-sm space-y-6">
          <h2 className="font-arabic-heading font-extrabold text-2xl text-[#121110]">
            {isAr ? 'الأسئلة الشائعة' : 'Frequently Asked Questions'}
          </h2>

          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <div key={idx} className="p-5 bg-[#F4EFE6]/50 rounded-2xl border border-[#EAE0D0] space-y-2">
                <h4 className="font-bold text-sm text-[#121110]">
                  {isAr ? faq.q_ar : faq.q_en}
                </h4>
                <p className="text-xs text-gray-600 leading-relaxed">
                  {isAr ? faq.a_ar : faq.a_en}
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
