import React from 'react';
import { useApp } from '../context/AppContext';
import { Gift, Sparkles, ShieldCheck, ArrowLeft, ArrowRight } from 'lucide-react';

export const PromotionBanner: React.FC = () => {
  const { language, navigateTo, applyCouponCode } = useApp();

  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <section className="py-12 bg-[#F5F2ED]">
      <div className="max-w-7xl mx-auto px-6">
        
        <div className="relative bg-[#1A1A1A] border border-[#D1C9BC] text-white p-8 sm:p-12">
          
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
            
            {/* Text Content */}
            <div className="space-y-4 max-w-xl text-center md:text-start">
              
              <div className="inline-flex items-center gap-2 bg-[#A89060]/20 text-[#A89060] px-3 py-1 border border-[#A89060]/40 text-xs font-bold uppercase tracking-widest">
                <Sparkles className="w-4 h-4" />
                <span>{isAr ? 'عضوية نادي الاختيار' : 'ALIKHTIAR Privilege Club'}</span>
              </div>

              <h2 className="font-serif text-3xl sm:text-5xl font-bold text-white leading-tight">
                {isAr ? 'خصم 10% للأعضاء' : 'Exclusive Member Benefits'}
              </h2>

              <p className="font-serif text-lg sm:text-xl text-[#A89060]">
                {isAr ? 'انضم إلى نادي الاختيار واحصل على مزايا حصرية' : '10% off your first order + Complimentary Express Delivery'}
              </p>

              <p className="text-xs sm:text-sm text-[#EAE3D8]/80 leading-relaxed">
                {isAr 
                  ? 'انضم اليوم إلى ناد الاختيار واستمتع بدعوات خاصة لأسابيع الموضة، وإمكانية الوصول المبكر للمجموعات الحصرية والمعاينات الخاصة.'
                  : 'Join today for priority allocations, invitations to private trunk shows, and instant welcome rewards.'}
              </p>

              {/* Action & Code */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-4 justify-center md:justify-start">
                <button
                  onClick={() => {
                    applyCouponCode('ALIKHTIAR10');
                    navigateTo('account');
                  }}
                  className="inline-flex items-center gap-3 bg-[#A89060] hover:bg-white hover:text-[#1A1A1A] text-white font-bold px-8 py-3.5 text-xs tracking-widest transition-colors cursor-pointer"
                >
                  <Gift className="w-4 h-4" />
                  <span>{isAr ? 'انضم مجاناً' : 'Join Free'}</span>
                  <ArrowIcon className="w-4 h-4" />
                </button>

                <span className="text-xs font-mono font-bold text-[#A89060] bg-black/40 px-4 py-2 border border-[#A89060]/30">
                  {isAr ? 'كود التخفيض: ALIKHTIAR10' : 'Promo Code: ALIKHTIAR10'}
                </span>
              </div>

            </div>

            {/* Visual Card */}
            <div className="relative flex-shrink-0 w-72 h-72 sm:w-80 sm:h-80 flex items-center justify-center">
              <div className="absolute inset-0 bg-[#A89060]/20 blur-2xl" />
              <img
                src="https://images.unsplash.com/photo-1549465220-1a8b9238cd48?q=80&w=800&auto=format&fit=crop"
                alt="Luxury Gift Packaging"
                className="relative z-10 w-full h-full object-cover border border-[#A89060]"
              />
              <div className="absolute -bottom-4 -right-4 bg-[#1A1A1A] text-[#A89060] p-3 border border-[#A89060] z-20 flex items-center gap-2 text-xs font-bold">
                <ShieldCheck className="w-4 h-4 text-[#A89060]" />
                <span>{isAr ? 'ضمان الفخامة الأصيلة' : 'Guaranteed Pure Luxury'}</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
