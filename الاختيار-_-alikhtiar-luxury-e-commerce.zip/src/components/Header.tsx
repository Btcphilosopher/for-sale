import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { BrandLogo } from './BrandLogo';
import { LanguageSwitcher } from './LanguageSwitcher';
import { MegaMenu } from './MegaMenu';
import { SearchOverlay } from './SearchOverlay';
import { CountrySelectorModal } from './CountrySelectorModal';
import { 
  Search, 
  Heart, 
  ShoppingBag, 
  User, 
  MapPin, 
  HelpCircle, 
  Truck, 
  ChevronDown,
  Menu,
  X,
  Sparkles
} from 'lucide-react';
import { formatPrice } from '../data/countries';

export const Header: React.FC<{ onOpenCart: () => void }> = ({ onOpenCart }) => {
  const { 
    language, 
    direction, 
    t, 
    country, 
    cart, 
    wishlist, 
    activePage, 
    navigateTo, 
    searchQuery,
    setSearchQuery
  } = useApp();

  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCountryModalOpen, setIsCountryModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const totalCartItems = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotalSAR = cart.reduce((acc, item) => acc + item.product.priceSAR * item.quantity, 0);

  const mainNavLinks = [
    { id: 'home', label_ar: t.nav.home, label_en: 'Home', action: () => navigateTo('home') },
    { id: 'women', label_ar: t.nav.women, label_en: 'Women', action: () => navigateTo('category', { categoryId: 'fashion' }) },
    { id: 'men', label_ar: t.nav.men, label_en: 'Men', action: () => navigateTo('category', { categoryId: 'watches' }) },
    { id: 'beauty', label_ar: t.nav.beauty, label_en: 'Beauty', action: () => navigateTo('category', { categoryId: 'perfumes' }) },
    { id: 'kids', label_ar: t.nav.kids, label_en: 'Kids', action: () => navigateTo('category', { categoryId: 'fashion' }) },
    { id: 'homeLiving', label_ar: t.nav.homeLiving, label_en: 'Home', action: () => navigateTo('category', { categoryId: 'home' }) },
    { id: 'electronics', label_ar: t.nav.electronics, label_en: 'Electronics', action: () => navigateTo('category', { categoryId: 'electronics' }) },
    { id: 'offers', label_ar: t.nav.offers, label_en: 'Offers', action: () => navigateTo('category', { categoryId: 'fashion' }) },
    { id: 'brands', label_ar: t.nav.brands, label_en: 'Brands', action: () => navigateTo('category', { categoryId: 'perfumes' }) },
  ];

  return (
    <header className="sticky top-0 z-30 bg-[#F5F2ED] border-b border-[#D1C9BC]">
      
      {/* 1. UTILITY BAR (Top Light Warm Bar) */}
      <div className="bg-[#F5F2ED] border-b border-[#E8E1D5] py-2 px-6 text-[10px] uppercase tracking-widest text-[#7D7463]">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          
          {/* Announcement text */}
          <div className="flex items-center gap-3 overflow-hidden text-ellipsis whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-[#A89060] animate-pulse" />
            <span className="font-bold text-[#1A1A1A]">
              {t.utilityBar.announcement}
            </span>
          </div>

          {/* Right Utility Controls */}
          <div className="hidden md:flex items-center gap-5 font-bold text-[#1A1A1A]">
            
            {/* Country & Currency Switcher Button */}
            <button
              onClick={() => setIsCountryModalOpen(true)}
              className="flex items-center gap-1.5 hover:text-[#A89060] transition-colors cursor-pointer text-[#1A1A1A]"
            >
              <span className="text-xs">{country.flag}</span>
              <span>{language === 'ar' ? country.name_ar : country.name_en}</span>
              <span className="text-[#A89060] font-mono font-semibold">({country.currency})</span>
              <ChevronDown className="w-3 h-3 text-[#7D7463]" />
            </button>

            <span className="opacity-40">|</span>

            {/* Help Center */}
            <button
              onClick={() => navigateTo('help-center')}
              className="flex items-center gap-1 text-[#7D7463] hover:text-[#1A1A1A] transition-colors cursor-pointer"
            >
              <HelpCircle className="w-3 h-3 text-[#A89060]" />
              <span>{t.utilityBar.helpCenter}</span>
            </button>

            {/* Track Order */}
            <button
              onClick={() => navigateTo('track-order')}
              className="flex items-center gap-1 text-[#7D7463] hover:text-[#1A1A1A] transition-colors cursor-pointer"
            >
              <Truck className="w-3 h-3 text-[#A89060]" />
              <span>{t.utilityBar.trackOrder}</span>
            </button>

            <span className="opacity-40">|</span>

            {/* Language Switcher */}
            <LanguageSwitcher />

            <span className="opacity-40">|</span>

            {/* Account Link */}
            <button
              onClick={() => navigateTo('account')}
              className="flex items-center gap-1.5 text-[#1A1A1A] hover:text-[#A89060] transition-colors cursor-pointer"
            >
              <User className="w-3.5 h-3.5 text-[#A89060]" />
              <span>{t.utilityBar.myAccount}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. MAIN HEADER BAR (Brand Logo + Search + Wishlist/Cart) */}
      <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between gap-6">
        
        {/* Brand Wordmark */}
        <BrandLogo variant="dark" size="md" />

        {/* Large Intelligent Search Bar */}
        <div className="hidden lg:flex flex-1 max-w-md relative">
          <button
            onClick={() => setIsSearchOpen(true)}
            className="w-full flex items-center justify-between bg-white/50 border border-[#D1C9BC] hover:border-[#A89060] px-4 py-2 rounded-full text-start transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-3 text-[#7D7463] text-xs">
              <Search className="w-4 h-4 text-[#7D7463] group-hover:text-[#A89060] transition-colors" />
              <span className="truncate">
                {searchQuery || t.nav.searchPlaceholder}
              </span>
            </div>
            <span className="text-[10px] font-bold bg-[#EAE3D8] text-[#7D7463] px-2 py-0.5 rounded-full">
              ⌘K
            </span>
          </button>
        </div>

        {/* Header Actions (Search Mobile, Wishlist, Cart) */}
        <div className="flex items-center gap-5">
          
          {/* Mobile Search Button */}
          <button
            onClick={() => setIsSearchOpen(true)}
            className="lg:hidden p-2 text-[#1A1A1A] hover:text-[#A89060] rounded-full hover:bg-black/5 transition-colors cursor-pointer"
            aria-label="Search"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Wishlist Button */}
          <button
            onClick={() => navigateTo('wishlist')}
            className="flex flex-col items-center cursor-pointer group text-[#1A1A1A]"
            aria-label="Wishlist"
          >
            <div className="relative">
              <Heart className="w-5 h-5 text-[#1A1A1A] group-hover:text-[#A89060] transition-colors" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-2 bg-[#A89060] text-white text-[8px] font-bold px-1.5 py-0.2 rounded-full">
                  {wishlist.length}
                </span>
              )}
            </div>
            <span className="text-[9px] mt-1 text-[#7D7463]">{t.nav.wishlist}</span>
          </button>

          {/* Cart Drawer Trigger */}
          <button
            onClick={onOpenCart}
            className="flex flex-col items-center cursor-pointer group text-[#1A1A1A]"
            aria-label="Cart"
          >
            <div className="relative">
              <ShoppingBag className="w-5 h-5 text-[#1A1A1A] group-hover:text-[#A89060] transition-colors" />
              <span className="absolute -top-1 -right-2 bg-[#A89060] text-white text-[8px] font-bold px-1.5 py-0.2 rounded-full">
                {totalCartItems}
              </span>
            </div>
            <span className="text-[9px] mt-1 text-[#7D7463]">{t.nav.cart}</span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-[#1A1A1A] hover:text-[#A89060] cursor-pointer"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* 3. MAIN NAVIGATION BAR */}
      <div className="relative border-t border-[#E8E1D5] bg-[#F5F2ED] hidden md:block">
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          
          {/* Mega-Menu Trigger Button ("تصفح الأقسام") */}
          <div className="relative">
            <button
              onClick={() => setIsMegaMenuOpen(!isMegaMenuOpen)}
              className="flex items-center gap-2 bg-[#1A1A1A] text-white px-4 py-2 text-xs font-bold tracking-wide hover:bg-[#A89060] transition-colors cursor-pointer"
            >
              <Menu className="w-3.5 h-3.5 text-[#A89060]" />
              <span>{t.nav.browseCategories}</span>
              <ChevronDown className={`w-3 h-3 text-white/70 transition-transform duration-300 ${isMegaMenuOpen ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Main Links */}
          <nav className="flex items-center gap-6 py-3 text-[13px] font-medium text-[#1A1A1A]">
            {mainNavLinks.map((link) => {
              const isActive = activePage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={link.action}
                  className={`transition-all cursor-pointer whitespace-nowrap pb-1 border-b-2 ${
                    isActive
                      ? 'border-[#A89060] font-bold text-[#1A1A1A]'
                      : 'border-transparent text-[#1A1A1A] hover:text-[#A89060]'
                  }`}
                >
                  {language === 'ar' ? link.label_ar : link.label_en}
                </button>
              );
            })}
          </nav>

          {/* Special Offer Tag */}
          <div className="hidden lg:flex items-center gap-1.5 text-xs font-bold text-[#A89060]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'خصم 10% كود: ALIKHTIAR10' : '10% OFF Code: ALIKHTIAR10'}</span>
          </div>
        </div>

        {/* Mega Menu Dropdown */}
        <MegaMenu isOpen={isMegaMenuOpen} onClose={() => setIsMegaMenuOpen(false)} />
      </div>

      {/* Mobile Collapsible Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-[#EAE0D0] bg-[#FBF9F5] p-4 space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between pb-3 border-b border-[#EAE0D0]">
            <button 
              onClick={() => setIsCountryModalOpen(true)}
              className="flex items-center gap-2 text-xs font-bold text-[#121110]"
            >
              <span>{country.flag}</span>
              <span>{language === 'ar' ? country.name_ar : country.name_en}</span>
              <span className="text-[#C5A059]">({country.currency})</span>
            </button>
            <LanguageSwitcher />
          </div>

          <div className="grid grid-cols-2 gap-2">
            {mainNavLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  link.action();
                  setIsMobileMenuOpen(false);
                }}
                className="p-2.5 text-xs font-bold text-[#121110] bg-white border border-[#EAE0D0] rounded-xl text-start hover:border-[#C5A059]"
              >
                {language === 'ar' ? link.label_ar : link.label_en}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Modals & Overlays */}
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <CountrySelectorModal isOpen={isCountryModalOpen} onClose={() => setIsCountryModalOpen(false)} />
    </header>
  );
};
