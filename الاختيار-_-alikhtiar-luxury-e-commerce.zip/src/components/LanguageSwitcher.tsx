import React from 'react';
import { useApp } from '../context/AppContext';
import { Globe } from 'lucide-react';

export const LanguageSwitcher: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { language, setLanguage } = useApp();

  return (
    <div className={`inline-flex items-center gap-1.5 text-xs font-medium ${className}`}>
      <Globe className="w-3.5 h-3.5 text-[#C5A059]" aria-hidden="true" />
      <div className="flex items-center gap-1 bg-[#231F1D]/80 hover:bg-[#231F1D] text-white px-2.5 py-1 rounded-full border border-[#C5A059]/30 transition-colors">
        <button
          onClick={() => setLanguage('ar')}
          className={`px-1.5 py-0.5 rounded transition-all cursor-pointer ${
            language === 'ar'
              ? 'text-[#DFBF7A] font-bold underline underline-offset-4 decoration-[#C5A059]'
              : 'text-gray-300 hover:text-white'
          }`}
          title="تغيير اللغة إلى العربية"
        >
          العربية
        </button>
        <span className="text-[#C5A059]/60">|</span>
        <button
          onClick={() => setLanguage('en')}
          className={`px-1.5 py-0.5 rounded transition-all cursor-pointer ${
            language === 'en'
              ? 'text-[#DFBF7A] font-bold underline underline-offset-4 decoration-[#C5A059]'
              : 'text-gray-300 hover:text-white'
          }`}
          title="Switch language to English"
        >
          English
        </button>
      </div>
    </div>
  );
};
