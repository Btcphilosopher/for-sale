import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatPrice } from '../data/countries';
import { X, Trash2, ShoppingBag, ArrowLeft, ArrowRight, Tag, Check, Sparkles } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose }) => {
  const { 
    cart, 
    language, 
    country, 
    updateCartQuantity, 
    removeFromCart, 
    navigateTo, 
    appliedCoupon, 
    applyCouponCode 
  } = useApp();

  const [couponInput, setCouponInput] = useState('');

  if (!isOpen) return null;

  const subtotalSAR = cart.reduce((acc, item) => acc + item.product.priceSAR * item.quantity, 0);
  const discountSAR = appliedCoupon ? subtotalSAR * 0.10 : 0;
  const vatSAR = (subtotalSAR - discountSAR) * country.vatRate;
  const totalSAR = subtotalSAR - discountSAR + vatSAR;

  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div 
        className={`absolute inset-y-0 ${isAr ? 'left-0' : 'right-0'} max-w-full flex pl-0 md:pl-10`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-screen max-w-md bg-[#FBF9F5] border-x border-[#C5A059]/30 shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 bg-[#231F1D] text-white flex items-center justify-between border-b border-[#C5A059]/40">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#DFBF7A]" />
              <h3 className="font-arabic-heading font-bold text-lg text-white">
                {isAr ? 'سلة التسوق الفاخرة' : 'Luxury Shopping Cart'}
              </h3>
              <span className="text-xs font-bold bg-[#C5A059] text-white px-2 py-0.5 rounded-full">
                {cart.reduce((acc, item) => acc + item.quantity, 0)}
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-gray-400 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-12">
                <div className="w-16 h-16 rounded-full bg-[#F4EFE6] text-[#C5A059] flex items-center justify-center">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-lg text-[#121110]">
                  {isAr ? 'سلة التسوق فارغة' : 'Your cart is empty'}
                </h4>
                <p className="text-xs text-gray-500 max-w-xs">
                  {isAr ? 'استكشف تشكيلاتنا الفاخرة وأضف منتجاتك المفضلة.' : 'Explore our collections and save your favorite pieces.'}
                </p>
                <button
                  onClick={() => {
                    onClose();
                    navigateTo('home');
                  }}
                  className="bg-[#C5A059] text-white font-bold text-xs px-6 py-3 rounded-full shadow hover:bg-[#A37C42] transition-colors cursor-pointer"
                >
                  {isAr ? 'استكشف المنتجات' : 'Explore Catalog'}
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div 
                  key={item.product.id}
                  className="flex gap-4 p-4 bg-white rounded-2xl border border-[#EAE0D0] shadow-sm relative group"
                >
                  <img
                    src={item.product.images[0]}
                    alt={isAr ? item.product.name_ar : item.product.name_en}
                    className="w-20 h-20 object-cover rounded-xl bg-gray-100 flex-shrink-0"
                  />

                  <div className="flex-1 flex flex-col justify-between min-w-0">
                    <div>
                      <span className="text-[10px] font-serif-luxury font-bold text-[#C5A059] uppercase tracking-wider block">
                        {item.product.brand}
                      </span>
                      <h5 className="font-bold text-xs text-[#121110] truncate mt-0.5">
                        {isAr ? item.product.name_ar : item.product.name_en}
                      </h5>
                      {item.selectedColor && (
                        <span className="text-[10px] text-gray-500 block">
                          {isAr ? `الخيار: ${item.selectedColor}` : `Variant: ${item.selectedColor}`}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <div className="flex items-center border border-[#EAE0D0] rounded-lg bg-[#F4EFE6] overflow-hidden text-xs">
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                          className="px-2 py-0.5 font-bold text-gray-600 hover:bg-black/5"
                        >
                          -
                        </button>
                        <span className="px-2.5 py-0.5 font-bold text-[#121110]">{item.quantity}</span>
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                          className="px-2 py-0.5 font-bold text-gray-600 hover:bg-black/5"
                        >
                          +
                        </button>
                      </div>

                      <span className="font-arabic-heading font-extrabold text-sm text-[#121110]">
                        {formatPrice(item.product.priceSAR * item.quantity, country, isAr)}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="text-gray-400 hover:text-red-600 transition-colors p-1"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Footer Calculations & Checkout Trigger */}
          {cart.length > 0 && (
            <div className="p-6 bg-white border-t border-[#EAE0D0] space-y-4 shadow-xl">
              
              {/* Promo Code Input */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Tag className={`absolute top-1/2 -translate-y-1/2 ${isAr ? 'right-3' : 'left-3'} w-4 h-4 text-[#C5A059]`} />
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    placeholder={isAr ? 'رمز التخفيض (مثال: ALIKHTIAR10)' : 'Promo code (e.g. ALIKHTIAR10)'}
                    className={`w-full py-2 ${isAr ? 'pr-9 pl-3' : 'pl-9 pr-3'} bg-[#F4EFE6] border border-[#C5A059]/40 rounded-xl text-xs outline-none focus:border-[#C5A059] text-[#121110]`}
                  />
                </div>
                <button
                  onClick={() => {
                    if (couponInput) applyCouponCode(couponInput);
                  }}
                  className="bg-[#231F1D] hover:bg-[#121110] text-[#DFBF7A] text-xs font-bold px-4 py-2 rounded-xl transition-colors cursor-pointer"
                >
                  {isAr ? 'تطبيق' : 'Apply'}
                </button>
              </div>

              {appliedCoupon && (
                <div className="flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 p-2 rounded-lg font-semibold">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isAr ? 'تم تطبيق خصم 10% بنجاح!' : '10% Discount Coupon Applied!'}</span>
                </div>
              )}

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-gray-600 border-t border-b border-[#F4EFE6] py-3">
                <div className="flex justify-between">
                  <span>{isAr ? 'المجموع الفرعي' : 'Subtotal'}</span>
                  <span className="font-bold text-[#121110]">{formatPrice(subtotalSAR, country, isAr)}</span>
                </div>
                {appliedCoupon && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>{isAr ? 'خصم القسيمة (10%)' : 'Coupon Discount (10%)'}</span>
                    <span>-{formatPrice(discountSAR, country, isAr)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>{isAr ? 'الشحن والتوصيل' : 'Shipping'}</span>
                  <span className="text-emerald-700 font-bold">{isAr ? 'مجاني' : 'FREE'}</span>
                </div>
                <div className="flex justify-between">
                  <span>{isAr ? `ضريبة القيمة المضافة (${(country.vatRate * 100).toFixed(0)}%)` : `VAT (${(country.vatRate * 100).toFixed(0)}%)`}</span>
                  <span>{formatPrice(vatSAR, country, isAr)}</span>
                </div>
                <div className="flex justify-between text-base font-extrabold text-[#121110] pt-2 border-t border-dashed border-[#EAE0D0]">
                  <span>{isAr ? 'الإجمالي' : 'Total'}</span>
                  <span className="text-[#C5A059] font-arabic-heading">{formatPrice(totalSAR, country, isAr)}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={() => {
                  onClose();
                  navigateTo('checkout');
                }}
                className="w-full flex items-center justify-center gap-3 bg-[#C5A059] hover:bg-[#A37C42] text-white py-3.5 px-6 rounded-2xl font-bold text-sm shadow-xl transition-all cursor-pointer hover:scale-[1.01]"
              >
                <span>{isAr ? 'إتمام الطلب السريع' : 'Proceed to Checkout'}</span>
                <ArrowIcon className="w-4 h-4" />
              </button>

            </div>
          )}

        </div>
      </div>
    </div>
  );
};
