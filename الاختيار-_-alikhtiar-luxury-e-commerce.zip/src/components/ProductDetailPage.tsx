import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS } from '../data/products';
import { formatPrice } from '../data/countries';
import { 
  Star, 
  Heart, 
  ShoppingBag, 
  Truck, 
  ShieldCheck, 
  RotateCcw, 
  Share2, 
  ArrowLeft, 
  ArrowRight,
  CheckCircle,
  Play,
  HelpCircle,
  MessageSquare
} from 'lucide-react';

export const ProductDetailPage: React.FC = () => {
  const { 
    selectedProductId, 
    language, 
    country, 
    addToCart, 
    toggleWishlist, 
    isInWishlist,
    navigateTo,
    showToast
  } = useApp();

  const product = PRODUCTS.find(p => p.id === selectedProductId) || PRODUCTS[0];
  const isWishlisted = isInWishlist(product.id);

  const [selectedImage, setSelectedImage] = useState(product.images[0]);
  const [selectedVariant, setSelectedVariant] = useState(product.variants?.[0]?.value || '');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'details' | 'reviews' | 'qna' | 'shipping' | 'returns'>('details');

  const ArrowIcon = language === 'ar' ? ArrowLeft : ArrowRight;

  const handleBuyNow = () => {
    addToCart(product, quantity, { color: selectedVariant });
    navigateTo('cart');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name_ar,
        url: window.location.href,
      }).catch(() => {});
    } else {
      showToast(
        language === 'ar' ? 'تم نسخ الرابط' : 'Link Copied',
        language === 'ar' ? 'تم نسخ رابط المنتج إلى المحفظة.' : 'Product link copied to clipboard.'
      );
    }
  };

  return (
    <div className="py-8 bg-[#FBF9F5]">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Breadcrumbs Navigation */}
        <div className="flex items-center gap-2 text-xs text-gray-500 mb-6">
          <button onClick={() => navigateTo('home')} className="hover:text-[#C5A059] cursor-pointer">
            {language === 'ar' ? 'الرئيسية' : 'Home'}
          </button>
          <span>/</span>
          <button 
            onClick={() => navigateTo('category', { categoryId: product.category })} 
            className="hover:text-[#C5A059] cursor-pointer capitalize"
          >
            {product.category}
          </button>
          <span>/</span>
          <span className="font-bold text-[#121110] truncate max-w-xs">
            {language === 'ar' ? product.name_ar : product.name_en}
          </span>
        </div>

        {/* Main Product Layout: 2 Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 bg-white rounded-3xl p-6 sm:p-10 border border-[#EAE0D0] shadow-sm mb-12">
          
          {/* Column 1: Gallery & Zoom Preview & Video Placeholder */}
          <div className="space-y-4">
            
            {/* Main Stage Image */}
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-[#F4EFE6]/50 border border-[#EAE0D0] group">
              <img
                src={selectedImage}
                alt={language === 'ar' ? product.name_ar : product.name_en}
                className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500"
              />

              {product.discountPercentage && (
                <span className="absolute top-4 right-4 bg-[#231F1D] text-[#DFBF7A] text-xs font-extrabold px-3 py-1 rounded-md border border-[#C5A059] dir-ltr shadow">
                  -{product.discountPercentage}%
                </span>
              )}

              {/* Video Tag */}
              <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-md text-white px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 cursor-pointer hover:bg-black">
                <Play className="w-3.5 h-3.5 text-[#DFBF7A]" />
                <span>{language === 'ar' ? 'فيديو المنتج 4K' : 'Product Video 4K'}</span>
              </div>
            </div>

            {/* Thumbnail Row */}
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(img)}
                  className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-all cursor-pointer flex-shrink-0 ${
                    selectedImage === img ? 'border-[#C5A059] ring-2 ring-[#C5A059]/30 scale-105' : 'border-[#EAE0D0] opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="thumbnail" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>

          </div>

          {/* Column 2: Specs, Pricing, Variants, Actions */}
          <div className="space-y-6 flex flex-col justify-between">
            
            <div className="space-y-4">
              
              <div className="flex items-center justify-between">
                <span className="text-xs font-serif-luxury font-bold text-[#C5A059] uppercase tracking-widest">
                  {product.brand}
                </span>

                <button
                  onClick={handleShare}
                  className="flex items-center gap-1 text-xs text-gray-500 hover:text-black transition-colors cursor-pointer"
                >
                  <Share2 className="w-4 h-4" />
                  <span>{language === 'ar' ? 'مشاركة' : 'Share'}</span>
                </button>
              </div>

              <h1 className="font-arabic-heading text-2xl sm:text-3xl font-extrabold text-[#121110]">
                {language === 'ar' ? product.name_ar : product.name_en}
              </h1>

              {/* Rating */}
              <div className="flex items-center gap-3 text-xs">
                <div className="flex items-center text-amber-500">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="font-bold text-[#121110] ms-1">{product.rating}</span>
                </div>
                <span className="text-gray-400">|</span>
                <span className="text-gray-600 font-medium">
                  {product.reviewCount} {language === 'ar' ? 'تقييم من العملاء' : 'verified reviews'}
                </span>
                <span className="text-gray-400">|</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
                  {language === 'ar' ? 'متوفر في المخزون' : 'In Stock'}
                </span>
              </div>

              {/* Price Block */}
              <div className="p-4 bg-[#F4EFE6]/60 rounded-2xl border border-[#EAE0D0] space-y-1">
                <div className="flex items-baseline gap-3">
                  <span className="font-arabic-heading font-black text-3xl text-[#121110]">
                    {formatPrice(product.priceSAR * quantity, country, language === 'ar')}
                  </span>
                  {product.originalPriceSAR && (
                    <span className="text-base text-gray-400 line-through">
                      {formatPrice(product.originalPriceSAR * quantity, country, language === 'ar')}
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500">
                  {language === 'ar' ? 'السعر يشمل جميع الضرائب وتكاليف الجمارك المستحقة' : 'Price includes all VAT and regional duties'}
                </p>
              </div>

              <p className="text-sm text-gray-700 leading-relaxed">
                {language === 'ar' ? product.description_ar : product.description_en}
              </p>

              {/* Variants Selector if available */}
              {product.variants && product.variants.length > 0 && (
                <div className="space-y-2 pt-2">
                  <label className="text-xs font-bold text-[#121110] block">
                    {language === 'ar' ? 'اختر الخيار / التشكيلة:' : 'Select Variant:'}
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.map((v) => {
                      const isSelected = selectedVariant === v.value;
                      return (
                        <button
                          key={v.id}
                          onClick={() => setSelectedVariant(v.value)}
                          className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            isSelected
                              ? 'border-[#C5A059] bg-[#231F1D] text-[#DFBF7A] ring-2 ring-[#C5A059]/30'
                              : 'border-[#EAE0D0] bg-white text-gray-700 hover:border-[#C5A059]'
                          }`}
                        >
                          {language === 'ar' ? v.name_ar : v.name_en}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Quantity Counter */}
              <div className="flex items-center justify-between pt-2">
                <span className="text-xs font-bold text-[#121110]">
                  {language === 'ar' ? 'الكمية المطلوبة:' : 'Quantity:'}
                </span>
                <div className="flex items-center border border-[#C5A059]/40 rounded-xl bg-white overflow-hidden shadow-sm">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-4 py-2 text-base font-bold text-gray-600 hover:bg-black/5"
                  >
                    -
                  </button>
                  <span className="px-5 py-2 text-sm font-bold text-[#121110]">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-4 py-2 text-base font-bold text-gray-600 hover:bg-black/5"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Delivery info box */}
              <div className="flex items-center gap-3 p-3.5 bg-[#F4EFE6] rounded-xl border border-[#EAE0D0] text-xs text-gray-700">
                <Truck className="w-5 h-5 text-[#C5A059] flex-shrink-0" />
                <div>
                  <span className="font-bold">
                    {language === 'ar' ? `التوصيل الفاخر إلى ${country.name_ar}:` : `Luxury Delivery to ${country.name_en}:`}
                  </span>
                  <span className="ms-1">{country.deliveryDays}</span>
                </div>
              </div>

            </div>

            {/* CTA Buttons Block */}
            <div className="space-y-3 pt-4 border-t border-[#EAE0D0]">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => addToCart(product, quantity, { color: selectedVariant })}
                  className="flex-1 flex items-center justify-center gap-2 bg-[#231F1D] hover:bg-[#121110] text-[#DFBF7A] py-4 px-6 rounded-2xl font-bold text-sm sm:text-base border border-[#C5A059] shadow-xl transition-all cursor-pointer hover:scale-[1.01]"
                >
                  <ShoppingBag className="w-5 h-5" />
                  <span>{language === 'ar' ? 'إضافة إلى سلة التسوق' : 'Add to Shopping Cart'}</span>
                </button>

                <button
                  onClick={handleBuyNow}
                  className="flex-1 bg-[#C5A059] hover:bg-[#A37C42] text-white py-4 px-6 rounded-2xl font-bold text-sm sm:text-base shadow-xl transition-all cursor-pointer hover:scale-[1.01]"
                >
                  {language === 'ar' ? 'شراء الآن' : 'Buy Now'}
                </button>

                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                    isWishlisted 
                      ? 'bg-[#C5A059] text-white border-[#C5A059]' 
                      : 'bg-white text-gray-700 border-[#EAE0D0] hover:border-[#C5A059]'
                  }`}
                >
                  <Heart className={`w-6 h-6 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Authenticity Guarantee */}
              <div className="flex items-center justify-center gap-2 text-xs text-gray-500 pt-1">
                <ShieldCheck className="w-4 h-4 text-[#C5A059]" />
                <span>{language === 'ar' ? 'منتجات أصلية 100% مباشرة من دور الموضة والعلامات العالمية' : '100% Genuine product directly from authorized brands'}</span>
              </div>
            </div>

          </div>

        </div>

        {/* Tabbed Product Details Section */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-[#EAE0D0] shadow-sm">
          
          {/* Tabs Bar */}
          <div className="flex items-center gap-4 overflow-x-auto border-b border-[#EAE0D0] pb-4 mb-8 no-scrollbar">
            {[
              { id: 'details', label_ar: 'تفاصيل المنتج', label_en: 'Product Details' },
              { id: 'reviews', label_ar: `التقييمات (${product.reviews?.length || product.reviewCount})`, label_en: `Reviews (${product.reviews?.length || product.reviewCount})` },
              { id: 'qna', label_ar: 'الأسئلة والأجوبة', label_en: 'Q & A' },
              { id: 'shipping', label_ar: 'الشحن والتوصيل', label_en: 'Shipping & Delivery' },
              { id: 'returns', label_ar: 'الإرجاع والاستبدال', label_en: 'Returns & Exchanges' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`pb-2 text-sm font-bold transition-all border-b-2 whitespace-nowrap cursor-pointer ${
                  activeTab === tab.id
                    ? 'border-[#C5A059] text-[#121110]'
                    : 'border-transparent text-gray-400 hover:text-gray-700'
                }`}
              >
                {language === 'ar' ? tab.label_ar : tab.label_en}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div>
            {activeTab === 'details' && (
              <div className="space-y-4">
                <h3 className="font-arabic-heading font-bold text-lg text-[#121110]">
                  {language === 'ar' ? 'مواصفات الفخامة والتشطيب' : 'Craftsmanship & Specifications'}
                </h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-gray-700">
                  {(language === 'ar' ? product.details_ar : product.details_en).map((detail, idx) => (
                    <li key={idx} className="flex items-center gap-2 p-3 bg-[#F4EFE6]/50 rounded-xl border border-[#EAE0D0]">
                      <CheckCircle className="w-4 h-4 text-[#C5A059] flex-shrink-0" />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {activeTab === 'reviews' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="font-arabic-heading font-bold text-lg text-[#121110]">
                    {language === 'ar' ? 'آراء العملاء الموثقة' : 'Verified Customer Reviews'}
                  </h3>
                  <div className="flex items-center gap-1 text-amber-500 font-bold text-sm">
                    <Star className="w-4 h-4 fill-current" />
                    <span>{product.rating} / 5</span>
                  </div>
                </div>

                <div className="space-y-4">
                  {product.reviews && product.reviews.length > 0 ? (
                    product.reviews.map((rev) => (
                      <div key={rev.id} className="p-5 bg-[#FBF9F5] rounded-2xl border border-[#EAE0D0] space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-[#121110]">{rev.author}</span>
                            <span className="text-xs text-gray-400">({rev.city})</span>
                            <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">
                              {language === 'ar' ? 'شراء مؤكد' : 'Verified Purchase'}
                            </span>
                          </div>
                          <span className="text-xs text-gray-400">{rev.date}</span>
                        </div>
                        <div className="flex text-amber-500">
                          {Array.from({ length: rev.rating }).map((_, i) => (
                            <Star key={i} className="w-3.5 h-3.5 fill-current" />
                          ))}
                        </div>
                        <h4 className="font-bold text-sm text-[#121110]">
                          {language === 'ar' ? rev.title_ar : rev.title_en}
                        </h4>
                        <p className="text-xs text-gray-600">
                          {language === 'ar' ? rev.comment_ar : rev.comment_en}
                        </p>
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-gray-500">{language === 'ar' ? 'لا يوجد تقييمات مكتوبة حتى الآن.' : 'No written reviews yet.'}</p>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'qna' && (
              <div className="space-y-4 text-xs text-gray-700">
                <div className="p-4 bg-[#F4EFE6]/60 rounded-xl border border-[#EAE0D0] space-y-1">
                  <p className="font-bold text-sm text-[#121110]">
                    س: هل المنتج أصلي ومعه ضمان؟
                  </p>
                  <p className="text-gray-600">
                    ج: نعم، جميع منتجات الاختيار مضمونة 100% ومرفقة بشهادات الأصالة والضمان الدولي الخاص بالعلامة التجارية.
                  </p>
                </div>
              </div>
            )}

            {activeTab === 'shipping' && (
              <div className="space-y-3 text-xs text-gray-700">
                <p className="font-bold text-[#121110] text-sm">
                  {language === 'ar' ? 'خدمة الشحن والتوصيل الفاخر' : 'Luxury Shipping Standard'}
                </p>
                <p>
                  {language === 'ar' 
                    ? `نوفر التوصيل المباشر في علب فاخرة ومحمية بختم الاختيار الملكي. يستغرق التوصيل في ${country.name_ar} ${country.deliveryDays}.`
                    : `We deliver directly in sealed luxury gift boxes. Delivery to ${country.name_en} takes ${country.deliveryDays}.`}
                </p>
              </div>
            )}

            {activeTab === 'returns' && (
              <div className="space-y-3 text-xs text-gray-700">
                <p className="font-bold text-[#121110] text-sm">
                  {language === 'ar' ? 'سياسة الإرجاع خلال 14 يوماً' : '14-Day Free Returns'}
                </p>
                <p>
                  {language === 'ar'
                    ? 'يمكنكم طلب إرجاع أو استبدال أي منتج بحالته الأصلية مجاناً خلال 14 يوماً من استلام الطلب مع استرداد كامل المبلغ.'
                    : 'You may return or exchange any item in its original condition within 14 days of receipt for a full refund.'}
                </p>
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
