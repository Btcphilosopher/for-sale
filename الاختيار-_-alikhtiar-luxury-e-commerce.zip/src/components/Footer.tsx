import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { BrandLogo } from './BrandLogo';
import { 
  Instagram, 
  Twitter, 
  Facebook, 
  Youtube, 
  Send, 
  ShieldCheck, 
  CreditCard,
  Lock,
  PhoneCall,
  Mail,
  MapPin,
  Sparkles
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { language, t, navigateTo, showToast } = useApp();
  const [newsletterEmail, setNewsletterEmail] = useState('');

  const isAr = language === 'ar';

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    showToast(
      isAr ? 'تم الاشتراك بنجاح' : 'Subscribed Successfully',
      isAr ? 'شكراً لاشتراكك في نشرة الاختيار الفاخرة.' : 'Thank you for joining ALIKHTIAR Privilege Club.'
    );
    setNewsletterEmail('');
  };

  return (
    <footer className="bg-[#1A1A1A] text-[#EAE3D8] pt-16 pb-12 border-t border-[#D1C9BC] relative overflow-hidden">
      
      <div className="max-w-7xl mx-auto px-6 relative z-10 space-y-12">
        
        {/* Newsletter Signup Banner */}
        <div className="bg-black/30 p-8 sm:p-10 border border-[#A89060]/30 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="space-y-2 text-center lg:text-start">
            <div className="inline-flex items-center gap-2 text-[#A89060] text-xs font-bold uppercase tracking-widest bg-black/40 px-3 py-1 border border-[#A89060]/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isAr ? 'نشرة الاختيار الفاخرة' : 'ALIKHTIAR Privilege Gazette'}</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white">
              {isAr ? 'اشترك للحصول على دعوات حصرية وعروض خاصة' : 'Subscribe for Private Invitations & First Access'}
            </h3>
            <p className="text-xs text-[#EAE3D8]/80 max-w-lg">
              {isAr ? 'استلم كود خصم 10% فور الاشتراك مع دعوات حصرية لمعاينات المجموعات الجديدة.' : 'Receive an instant 10% welcome code and private runway invitations.'}
            </p>
          </div>

          <form onSubmit={handleSubscribe} className="flex items-center w-full lg:w-auto max-w-md gap-2">
            <div className="relative flex-1">
              <input
                type="email"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder={isAr ? 'أدخل بريدك الإلكتروني هنا...' : 'Enter your email address...'}
                className="w-full py-3.5 px-4 bg-black/60 border border-[#A89060]/40 text-xs text-white placeholder-[#EAE3D8]/50 outline-none focus:border-[#A89060]"
                required
              />
            </div>
            <button
              type="submit"
              className="bg-[#A89060] hover:bg-white hover:text-[#1A1A1A] text-white px-6 py-3.5 font-bold text-xs tracking-widest transition-colors cursor-pointer flex-shrink-0"
            >
              {isAr ? 'اشترك الآن' : 'Subscribe'}
            </button>
          </form>
        </div>

        {/* Multi-Column Links Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 border-b border-[#D1C9BC]/20 pb-12">
          
          {/* Column 1: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <BrandLogo variant="light" size="lg" />
            <p className="text-xs text-[#EAE3D8]/70 leading-relaxed max-w-sm">
              {isAr 
                ? 'الاختيار هو وجهتك الشرق أوسطية الرائدة لأرقى العطور، الساعات، والأزياء العالمية والمحلية المصممة بعناية فائقة لتلائم الذوق الخليجي الرفيع.'
                : 'ALIKHTIAR is the Gulf’s definitive high-luxury retail sanctuary, curating rare fragrances, Swiss horology, and high fashion.'}
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a href="#" className="w-8 h-8 bg-black/40 hover:bg-[#A89060] hover:text-white text-[#A89060] flex items-center justify-center transition-colors border border-[#A89060]/30">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 bg-black/40 hover:bg-[#A89060] hover:text-white text-[#A89060] flex items-center justify-center transition-colors border border-[#A89060]/30">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 bg-black/40 hover:bg-[#A89060] hover:text-white text-[#A89060] flex items-center justify-center transition-colors border border-[#A89060]/30">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 bg-black/40 hover:bg-[#A89060] hover:text-white text-[#A89060] flex items-center justify-center transition-colors border border-[#A89060]/30">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Categories */}
          <div className="space-y-3">
            <h4 className="font-serif font-bold text-xs text-[#A89060] uppercase tracking-wider border-b border-[#A89060]/30 pb-2 inline-block">
              {isAr ? 'الأقسام الفاخرة' : 'Fine Collections'}
            </h4>
            <ul className="space-y-2 text-xs text-[#EAE3D8]/70">
              <li><button onClick={() => navigateTo('category', { categoryId: 'perfumes' })} className="hover:text-[#A89060] cursor-pointer">{isAr ? 'العود والعطور الملكية' : 'Royal Oud & Perfumes'}</button></li>
              <li><button onClick={() => navigateTo('category', { categoryId: 'watches' })} className="hover:text-[#A89060] cursor-pointer">{isAr ? 'الساعات السويسرية' : 'Swiss Timepieces'}</button></li>
              <li><button onClick={() => navigateTo('category', { categoryId: 'fashion' })} className="hover:text-[#A89060] cursor-pointer">{isAr ? 'الأزياء والعبايات' : 'Haute Fashion & Abayas'}</button></li>
              <li><button onClick={() => navigateTo('category', { categoryId: 'handbags' })} className="hover:text-[#A89060] cursor-pointer">{isAr ? 'الحقائب والجلديات' : 'Leather Handbags'}</button></li>
              <li><button onClick={() => navigateTo('category', { categoryId: 'home' })} className="hover:text-[#A89060] cursor-pointer">{isAr ? 'مستلزمات المنزل الفاخر' : 'Luxury Home Decor'}</button></li>
            </ul>
          </div>

          {/* Column 3: Customer Care */}
          <div className="space-y-3">
            <h4 className="font-serif font-bold text-xs text-[#A89060] uppercase tracking-wider border-b border-[#A89060]/30 pb-2 inline-block">
              {isAr ? 'خدمة العملاء' : 'Client Care'}
            </h4>
            <ul className="space-y-2 text-xs text-[#EAE3D8]/70">
              <li><button onClick={() => navigateTo('help-center')} className="hover:text-[#A89060] cursor-pointer">{isAr ? 'مركز المساعدة والأسئلة' : 'Help Center & FAQ'}</button></li>
              <li><button onClick={() => navigateTo('track-order')} className="hover:text-[#A89060] cursor-pointer">{isAr ? 'تتبع الشحنات والطلب' : 'Track Your Shipment'}</button></li>
              <li><button onClick={() => navigateTo('help-center')} className="hover:text-[#A89060] cursor-pointer">{isAr ? 'سياسة الشحن والتوصيل' : 'Shipping Policy'}</button></li>
              <li><button onClick={() => navigateTo('help-center')} className="hover:text-[#A89060] cursor-pointer">{isAr ? 'الإرجاع والاستبدال' : 'Returns & Exchanges'}</button></li>
              <li><button onClick={() => navigateTo('account')} className="hover:text-[#A89060] cursor-pointer">{isAr ? 'حسابي ونادي الولاء' : 'Privilege Account'}</button></li>
            </ul>
          </div>

          {/* Column 4: Regional Offices */}
          <div className="space-y-3">
            <h4 className="font-serif font-bold text-xs text-[#A89060] uppercase tracking-wider border-b border-[#A89060]/30 pb-2 inline-block">
              {isAr ? 'المقرات الإقليمية' : 'Gulf Headquarters'}
            </h4>
            <ul className="space-y-2 text-xs text-[#EAE3D8]/70">
              <li className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#A89060]" />
                <span>{isAr ? 'الرياض: برج المملكة، العليا' : 'Riyadh: Kingdom Tower'}</span>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#A89060]" />
                <span>{isAr ? 'دبي: وسط مدينة دبي، بوليفارد' : 'Dubai: Downtown Boulevard'}</span>
              </li>
              <li className="flex items-center gap-2">
                <PhoneCall className="w-3.5 h-3.5 text-[#A89060]" />
                <span className="dir-ltr">+966 800 124 9999</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#A89060]" />
                <span>care@alikhtiar.com</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Payment Badges & Copyright */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-[#EAE3D8]/50 pt-4">
          
          <div className="flex items-center gap-2 flex-wrap justify-center">
            <span className="font-bold text-[#EAE3D8]/70 me-2">{isAr ? 'طرق الدفع الآمنة:' : 'Accepted Payments:'}</span>
            {['Visa', 'Mastercard', 'AMEX', 'Apple Pay', 'stc pay', 'mada', 'Tabby', 'Tamara'].map((pay, i) => (
              <span key={i} className="bg-black/40 text-[#A89060] px-2.5 py-1 text-[10px] font-bold border border-[#A89060]/30">
                {pay}
              </span>
            ))}
          </div>

          <div className="flex items-center gap-4 text-center md:text-end">
            <span>© 2026 الاختيار (ALIKHTIAR). {isAr ? 'جميع الحقوق محفوظة.' : 'All Rights Reserved.'}</span>
            <span className="text-[#A89060] bg-black/40 px-2 py-0.5 text-[10px] font-bold flex items-center gap-1 border border-[#A89060]/30">
              <Lock className="w-3 h-3" />
              <span>SSL Secured</span>
            </span>
          </div>

        </div>

      </div>
    </footer>
  );
};
