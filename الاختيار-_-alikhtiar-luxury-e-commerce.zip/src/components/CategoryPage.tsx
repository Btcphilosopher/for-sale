import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { ProductCard } from './ProductCard';
import { Sparkles, SlidersHorizontal, Filter, X } from 'lucide-react';

export const CategoryPage: React.FC = () => {
  const { selectedCategoryId, language, country } = useApp();

  const [sortBy, setSortBy] = useState<string>('popular');
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [expressOnly, setExpressOnly] = useState<boolean>(false);

  const category = CATEGORIES.find(c => c.id === selectedCategoryId) || CATEGORIES[0];

  const categoryProducts = useMemo(() => {
    let list = PRODUCTS.filter(p => p.category === selectedCategoryId || selectedCategoryId === 'all');
    if (list.length === 0) list = PRODUCTS;

    if (selectedBrand !== 'all') {
      list = list.filter(p => p.brand === selectedBrand);
    }
    if (expressOnly) {
      list = list.filter(p => p.expressDelivery);
    }

    if (sortBy === 'price-low') {
      list.sort((a, b) => a.priceSAR - b.priceSAR);
    } else if (sortBy === 'price-high') {
      list.sort((a, b) => b.priceSAR - a.priceSAR);
    } else if (sortBy === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    }

    return list;
  }, [selectedCategoryId, selectedBrand, expressOnly, sortBy]);

  const brands = useMemo(() => {
    const set = new Set(PRODUCTS.map(p => p.brand));
    return Array.from(set);
  }, []);

  const isAr = language === 'ar';

  return (
    <div className="py-10 bg-[#FBF9F5]">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Category Header Banner */}
        <div className="bg-[#231F1D] text-white rounded-3xl p-8 sm:p-12 border border-[#C5A059]/40 shadow-xl mb-10 relative overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=1200&auto=format&fit=crop"
            alt="Category"
            className="absolute inset-0 w-full h-full object-cover opacity-20"
          />
          <div className="relative z-10 space-y-3">
            <span className="text-xs font-bold text-[#DFBF7A] uppercase tracking-widest bg-black/40 px-3 py-1 rounded-full border border-[#C5A059]/40">
              {isAr ? 'قسم حصرى' : 'Exclusive Department'}
            </span>
            <h1 className="font-arabic-heading text-3xl sm:text-5xl font-black">
              {isAr ? category.name_ar : category.name_en}
            </h1>
            <p className="text-xs sm:text-sm text-gray-300 max-w-xl">
              {isAr ? category.subtitle_ar : category.subtitle_en}
            </p>
          </div>
        </div>

        {/* Filters + Products Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Left/Right Filters Sidebar */}
          <div className="space-y-6 bg-white p-6 rounded-3xl border border-[#EAE0D0] h-fit">
            <div className="flex items-center justify-between border-b border-[#F4EFE6] pb-3">
              <h3 className="font-arabic-heading font-bold text-base text-[#121110] flex items-center gap-2">
                <Filter className="w-4 h-4 text-[#C5A059]" />
                <span>{isAr ? 'تصفية النتائج' : 'Filter Products'}</span>
              </h3>
              {(selectedBrand !== 'all' || expressOnly) && (
                <button
                  onClick={() => {
                    setSelectedBrand('all');
                    setExpressOnly(false);
                  }}
                  className="text-[11px] text-[#C5A059] font-bold hover:underline"
                >
                  {isAr ? 'إعادة ضبط' : 'Reset'}
                </button>
              )}
            </div>

            {/* Brand Filter */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-700 block">
                {isAr ? 'العلامة التجارية' : 'Brand'}
              </label>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="w-full p-2.5 bg-[#F4EFE6] border border-[#EAE0D0] text-xs font-bold rounded-xl outline-none"
              >
                <option value="all">{isAr ? 'جميع الماركات' : 'All Brands'}</option>
                {brands.map((b, idx) => (
                  <option key={idx} value={b}>{b}</option>
                ))}
              </select>
            </div>

            {/* Express Delivery Checkbox */}
            <div className="pt-2 border-t border-[#F4EFE6]">
              <label className="flex items-center gap-2 text-xs font-bold text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={expressOnly}
                  onChange={(e) => setExpressOnly(e.target.checked)}
                  className="rounded text-[#C5A059] focus:ring-[#C5A059]"
                />
                <span>{isAr ? 'توصيل سريع فقط (24h)' : 'Express 24h Delivery Only'}</span>
              </label>
            </div>
          </div>

          {/* Right/Left Product Grid */}
          <div className="lg:col-span-3 space-y-6">
            
            <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-[#EAE0D0]">
              <span className="text-xs font-bold text-gray-600">
                {isAr ? `تم العثور على ${categoryProducts.length} منتج` : `Showing ${categoryProducts.length} items`}
              </span>

              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500 hidden sm:inline">{isAr ? 'الترتيب:' : 'Sort:'}</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-[#F4EFE6] text-xs font-bold p-2 rounded-xl outline-none"
                >
                  <option value="popular">{isAr ? 'الأكثر شعبية' : 'Most Popular'}</option>
                  <option value="price-low">{isAr ? 'السعر: الأقل إلى الأعلى' : 'Price: Low to High'}</option>
                  <option value="price-high">{isAr ? 'السعر: الأعلى إلى الأقل' : 'Price: High to Low'}</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {categoryProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
