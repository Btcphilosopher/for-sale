import React from 'react';
import { useApp } from '../context/AppContext';

interface BrandLogoProps {
  variant?: 'light' | 'dark';
  size?: 'sm' | 'md' | 'lg';
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ variant = 'dark', size = 'md' }) => {
  const { navigateTo } = useApp();

  const isDark = variant === 'dark';
  const textColor = isDark ? 'text-[#1A1A1A]' : 'text-white';
  const subTextColor = isDark ? 'text-[#A89060]' : 'text-[#DFBF7A]';

  const logoSizes = {
    sm: 'text-xl',
    md: 'text-3xl',
    lg: 'text-4xl'
  };

  const iconSizes = {
    sm: 'w-5 h-5',
    md: 'w-7 h-7',
    lg: 'w-10 h-10'
  };

  return (
    <button 
      onClick={() => navigateTo('home')}
      className="flex items-center gap-3 group focus:outline-none cursor-pointer text-start"
      aria-label="ALIKHTIAR Home"
    >
      {/* Luxury Geometric Islamic Star Icon */}
      <div className={`relative flex items-center justify-center ${iconSizes[size]} text-[#A89060] transition-transform duration-300 group-hover:scale-105 shrink-0`}>
        <svg viewBox="0 0 100 100" className="w-full h-full fill-current" aria-hidden="true">
          <path d="M50 0 L64.6 14.6 L85.4 14.6 L85.4 35.4 L100 50 L85.4 64.6 L85.4 85.4 L64.6 85.4 L50 100 L35.4 85.4 L14.6 85.4 L14.6 64.6 L0 50 L14.6 35.4 L14.6 14.6 L35.4 14.6 Z" fill="none" stroke="currentColor" strokeWidth="3" />
          <polygon points="50,15 60,35 80,20 70,40 90,50 70,60 80,80 60,70 50,85 40,70 20,80 30,60 10,50 30,40 20,20 40,35" fill="none" stroke="currentColor" strokeWidth="3" />
          <polygon points="50,38 62,50 50,62 38,50" fill="currentColor" />
        </svg>
      </div>

      <div className="flex flex-col items-start leading-none">
        {/* Arabic Brand Wordmark */}
        <span className={`font-serif tracking-tighter ${logoSizes[size]} ${textColor} font-bold`}>
          الاختيار
        </span>
        {/* English Subtitle */}
        <span className={`text-[9px] tracking-[0.4em] ${subTextColor} font-light uppercase mt-0.5`}>
          ALIKHTIAR
        </span>
      </div>
    </button>
  );
};
