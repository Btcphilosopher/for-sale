import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS } from '../data/products';
import { formatPrice } from '../data/countries';
import { ProductCard } from './ProductCard';
import { 
  User, 
  Package, 
  Heart, 
  MapPin, 
  Settings, 
  Truck, 
  CheckCircle, 
  ChevronLeft, 
  ChevronRight,
  LogOut,
  Sparkles
} from 'lucide-react';

export const AccountDashboard: React.FC = () => {
  const { 
    user, 
    orders, 
    wishlist, 
    language, 
    country, 
    navigateTo, 
    toggleWishlist 
  } = useApp();

  const [activeSection, setActiveSection] = useState<'orders' | 'wishlist' | 'addresses' | 'settings'>('orders');

  const isAr = language === 'ar';
  const wishlistedProducts = PRODUCTS.filter(p => wishlist.includes(p.id));

  return (
    <div className="py-10 bg-[#FBF9F5]">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Profile Welcome Banner */}
        <div className="bg-gradient-to-r from-[#121110] via-[#231F1D] to-[#121110] rounded-3xl p-6 sm:p-10 border border-[#C5A059]/40 shadow-2xl text-white mb-8 flex flex-col md:flex-row items-center justify-between gap-6">
          
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-[#C5A059] text-white flex items-center justify-center font-black text-2xl shadow-lg border border-[#DFBF7A]">
              {user.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#DFBF7A] uppercase tracking-widest bg-black/40 px-2.5 py-0.5 rounded-full border border-[#C5A059]/30">
                  {isAr ? user.membershipTier_ar : user.membershipTier}
                </span>
              </div>
              <h2 className="font-arabic-heading text-2xl sm:text-3xl font-extrabold text-white mt-1">
                {isAr ? `أهلاً بك، ${user.name}` : `Welcome, ${user.name}`}
              </h2>
              <p className="text-xs text-gray-300">
                {user.email} | {user.phone}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-[#231F1D] px-4 py-2 rounded-2xl border border-[#C5A059]/30 text-center">
              <span className="text-[10px] text-gray-400 block">{isAr ? 'نقاط الولاء' : 'Loyalty Points'}</span>
              <span className="font-mono font-extrabold text-[#DFBF7A] text-lg">1,450</span>
            </div>

            <button
              onClick={() => navigateTo('home')}
              className="flex items-center gap-2 bg-[#C5A059] hover:bg-[#A37C42] text-white px-5 py-2.5 rounded-2xl text-xs font-bold transition-all shadow"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isAr ? 'تسوق الآن' : 'Shop Now'}</span>
            </button>
          </div>

        </div>

        {/* Dashboard Main Grid: Sidebar + Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Sidebar Menu */}
          <div className="space-y-2">
            {[
              { id: 'orders', label_ar: 'طلباتي والشحنات', label_en: 'My Orders & Deliveries', icon: Package, badge: orders.length },
              { id: 'wishlist', label_ar: 'قائمة الأمنيات', label_en: 'Wishlist', icon: Heart, badge: wishlist.length },
              { id: 'addresses', label_ar: 'العناوين المحفوظة', label_en: 'Saved Addresses', icon: MapPin },
              { id: 'settings', label_ar: 'إعدادات الحساب', label_en: 'Account Settings', icon: Settings },
            ].map((item) => {
              const IconComp = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id as any)}
                  className={`w-full flex items-center justify-between p-4 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#231F1D] text-[#DFBF7A] border border-[#C5A059] shadow-md'
                      : 'bg-white text-gray-700 border border-[#EAE0D0] hover:border-[#C5A059]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <IconComp className={`w-4 h-4 ${isActive ? 'text-[#C5A059]' : 'text-gray-400'}`} />
                    <span>{isAr ? item.label_ar : item.label_en}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${isActive ? 'bg-[#C5A059] text-white' : 'bg-gray-100 text-gray-600'}`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Main Display Box */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* ORDERS SECTION */}
            {activeSection === 'orders' && (
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE0D0] shadow-sm space-y-6">
                <h3 className="font-arabic-heading font-bold text-xl text-[#121110]">
                  {isAr ? 'سجل الطلبات والتتبع' : 'Orders History & Live Tracking'}
                </h3>

                {orders.length === 0 ? (
                  <p className="text-xs text-gray-500 py-8 text-center">{isAr ? 'لا توجد طلبات سابقة.' : 'No orders yet.'}</p>
                ) : (
                  orders.map((ord) => (
                    <div key={ord.id} className="p-6 bg-[#F4EFE6]/50 rounded-2xl border border-[#EAE0D0] space-y-4">
                      
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-[#EAE0D0] text-xs">
                        <div>
                          <span className="text-gray-400 block">{isAr ? 'رقم الطلب:' : 'Order ID:'}</span>
                          <span className="font-mono font-bold text-sm text-[#121110]">{ord.orderNumber}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block">{isAr ? 'التاريخ:' : 'Date:'}</span>
                          <span className="font-bold text-gray-700">{ord.createdAt}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block">{isAr ? 'حالة الشحنة:' : 'Status:'}</span>
                          <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                            {ord.status}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-400 block">{isAr ? 'كود التتبع:' : 'Tracking:'}</span>
                          <span className="font-mono font-bold text-[#C5A059]">{ord.trackingNumber}</span>
                        </div>
                      </div>

                      {/* Items in order */}
                      <div className="space-y-3">
                        {ord.items.map((it) => (
                          <div key={it.product.id} className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-3">
                              <img src={it.product.images[0]} alt="item" className="w-10 h-10 object-cover rounded-lg bg-gray-100" />
                              <div>
                                <span className="font-bold text-[#121110] block">
                                  {isAr ? it.product.name_ar : it.product.name_en}
                                </span>
                                <span className="text-gray-400 text-[10px]">Qty: {it.quantity}</span>
                              </div>
                            </div>
                            <span className="font-arabic-heading font-bold text-[#121110]">
                              {formatPrice(it.product.priceSAR * it.quantity, country, isAr)}
                            </span>
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-[#EAE0D0] text-xs font-bold">
                        <span>{isAr ? 'الإجمالي المدفوع:' : 'Total Paid:'}</span>
                        <span className="text-base text-[#C5A059] font-arabic-heading">
                          {formatPrice(ord.totalSAR, country, isAr)}
                        </span>
                      </div>

                    </div>
                  ))
                )}
              </div>
            )}

            {/* WISHLIST SECTION */}
            {activeSection === 'wishlist' && (
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE0D0] shadow-sm space-y-6">
                <h3 className="font-arabic-heading font-bold text-xl text-[#121110]">
                  {isAr ? 'قائمة المنتجات المفضلة' : 'My Saved Wishlist'}
                </h3>

                {wishlistedProducts.length === 0 ? (
                  <div className="text-center py-12 space-y-3">
                    <Heart className="w-12 h-12 text-gray-300 mx-auto" />
                    <p className="text-xs text-gray-500">{isAr ? 'لم تقم بـإضافة أي منتج للمفضلة بعد.' : 'No items added to your wishlist.'}</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {wishlistedProducts.map((p) => (
                      <ProductCard key={p.id} product={p} />
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ADDRESSES SECTION */}
            {activeSection === 'addresses' && (
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE0D0] shadow-sm space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="font-arabic-heading font-bold text-xl text-[#121110]">
                    {isAr ? 'العناوين المحفوظة للتوصيل' : 'Saved Delivery Addresses'}
                  </h3>
                  <button className="bg-[#231F1D] text-[#DFBF7A] text-xs font-bold px-4 py-2 rounded-xl border border-[#C5A059]">
                    {isAr ? '+ إضافة عنوان جديد' : '+ Add New Address'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  {user.savedAddresses.map((addr) => (
                    <div key={addr.id} className="p-5 bg-[#F4EFE6] rounded-2xl border border-[#C5A059]/40 space-y-2">
                      <div className="flex items-center justify-between font-bold text-sm text-[#C5A059]">
                        <span>{isAr ? addr.title_ar : addr.title_en}</span>
                        {addr.isDefault && (
                          <span className="text-[10px] bg-emerald-700 text-white px-2 py-0.5 rounded font-extrabold">
                            {isAr ? 'رئيسي' : 'Default'}
                          </span>
                        )}
                      </div>
                      <p className="font-bold text-[#121110]">{addr.name}</p>
                      <p className="text-gray-600">{addr.address}، {addr.city}</p>
                      <p className="text-gray-500 font-mono">{addr.phone}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SETTINGS SECTION */}
            {activeSection === 'settings' && (
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE0D0] shadow-sm space-y-6">
                <h3 className="font-arabic-heading font-bold text-xl text-[#121110]">
                  {isAr ? 'تفضيلات الحساب والدولة' : 'Account & Regional Preferences'}
                </h3>

                <div className="space-y-4 text-xs max-w-lg">
                  <div>
                    <label className="font-bold text-gray-700 block mb-1">{isAr ? 'الاسم الكامل' : 'Full Name'}</label>
                    <input type="text" defaultValue={user.name} className="w-full p-3 bg-[#F4EFE6] border border-[#EAE0D0] rounded-xl outline-none" />
                  </div>
                  <div>
                    <label className="font-bold text-gray-700 block mb-1">{isAr ? 'البريد الإلكتروني' : 'Email Address'}</label>
                    <input type="email" defaultValue={user.email} className="w-full p-3 bg-[#F4EFE6] border border-[#EAE0D0] rounded-xl outline-none" />
                  </div>
                  <div>
                    <label className="font-bold text-gray-700 block mb-1">{isAr ? 'الدولة والعملة المفضلة' : 'Default Country & Currency'}</label>
                    <input type="text" readOnly value={`${country.flag} ${isAr ? country.name_ar : country.name_en} (${country.currency})`} className="w-full p-3 bg-gray-100 border border-gray-300 rounded-xl outline-none" />
                  </div>
                  <button className="bg-[#C5A059] text-white px-6 py-3 rounded-xl font-bold">
                    {isAr ? 'حفظ التعديلات' : 'Save Settings'}
                  </button>
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
};
