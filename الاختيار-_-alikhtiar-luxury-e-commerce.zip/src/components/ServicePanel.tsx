import React from 'react';
import { useApp } from '../context/AppContext';
import { Truck, RotateCcw, ShieldCheck, Headphones } from 'lucide-react';

export const ServicePanel: React.FC = () => {
  const { t, language } = useApp();

  const services = [
    {
      icon: Truck,
      title: t.trustPanel.fastDeliveryTitle,
      desc: t.trustPanel.fastDeliveryDesc,
    },
    {
      icon: RotateCcw,
      title: t.trustPanel.freeReturnsTitle,
      desc: t.trustPanel.freeReturnsDesc,
    },
    {
      icon: ShieldCheck,
      title: t.trustPanel.securePaymentTitle,
      desc: t.trustPanel.securePaymentDesc,
    },
    {
      icon: Headphones,
      title: t.trustPanel.customerCareTitle,
      desc: t.trustPanel.customerCareDesc,
    },
  ];

  return (
    <section className="py-10 bg-[#EAE3D8] border-y border-[#D1C9BC]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <div 
                key={index}
                className="flex items-start gap-4 p-5 bg-white border border-[#D1C9BC] hover:border-[#A89060] transition-colors"
              >
                <div className="w-10 h-10 bg-[#1A1A1A] text-[#A89060] flex items-center justify-center flex-shrink-0">
                  <IconComponent className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-sm text-[#1A1A1A] mb-0.5">
                    {item.title}
                  </h4>
                  <p className="text-xs text-[#7D7463] leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
