import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, LayoutGrid, Heart, ShoppingBag, User } from 'lucide-react';

export const MobileBottomNav: React.FC<{ onOpenCart: () => void }> = ({ onOpenCart }) => {
  const { activePage, navigateTo, language, cart, wishlist } = useApp();

  const isAr = language === 'ar';
  const totalCartItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  const navItems = [
    { id: 'home', label_ar: 'الرئيسية', label_en: 'Home', icon: Home, action: () => navigateTo('home') },
    { id: 'category', label_ar: 'الأقسام', label_en: 'Categories', icon: LayoutGrid, action: () => navigateTo('category', { categoryId: 'fashion' }) },
    { id: 'wishlist', label_ar: 'المفضلة', label_en: 'Wishlist', icon: Heart, action: () => navigateTo('wishlist'), badge: wishlist.length },
    { id: 'cart', label_ar: 'السلة', label_en: 'Cart', icon: ShoppingBag, action: onOpenCart, badge: totalCartItems },
    { id: 'account', label_ar: 'حسابي', label_en: 'Account', icon: User, action: () => navigateTo('account') },
  ];

  return (
    <div className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-[#121110]/95 backdrop-blur-md border-t border-[#C5A059]/40 text-[#EAE0D0] py-2 px-3 shadow-2xl">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              onClick={item.action}
              className={`flex flex-col items-center justify-center py-1 px-3 min-w-[56px] min-h-[44px] transition-all cursor-pointer relative ${
                isActive ? 'text-[#DFBF7A] scale-105 font-bold' : 'text-gray-400 hover:text-white'
              }`}
            >
              <div className="relative">
                <IconComponent className="w-5 h-5 mb-1" />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-[#C5A059] text-white text-[9px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center shadow">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] leading-tight">
                {isAr ? item.label_ar : item.label_en}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
