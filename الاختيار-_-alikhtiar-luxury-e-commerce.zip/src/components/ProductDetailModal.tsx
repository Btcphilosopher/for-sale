import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';
import { formatPrice } from '../data/countries';
import { X, Star, Heart, ShoppingBag, Truck, ShieldCheck, Check } from 'lucide-react';

export const ProductDetailModal: React.FC = () => {
  const { 
    quickViewProduct, 
    closeQuickView, 
    language, 
    country, 
    addToCart, 
    toggleWishlist, 
    isInWishlist,
    navigateTo 
  } = useApp();

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState<string | null>(null);

  if (!quickViewProduct) return null;

  const product = quickViewProduct;
  const isWishlisted = isInWishlist(product.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div 
        className="bg-[#FBF9F5] rounded-3xl border border-[#C5A059]/40 w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={closeQuickView}
          className="absolute top-4 right-4 z-20 p-2 bg-white/80 hover:bg-white text-gray-700 hover:text-black rounded-full shadow transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 md:p-10">
          
          {/* Left/Right Media Gallery */}
          <div className="space-y-4">
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-white border border-[#EAE0D0]">
              <img
                src={product.images[selectedImageIndex] || product.images[0]}
                alt={language === 'ar' ? product.name_ar : product.name_en}
                className="w-full h-full object-cover"
              />
              {product.discountPercentage && (
                <span className="absolute top-4 right-4 bg-[#231F1D] text-[#DFBF7A] text-xs font-extrabold px-3 py-1 rounded-md border border-[#C5A059] dir-ltr">
                  -{product.discountPercentage}%
                </span>
              )}
            </div>

            {/* Thumbnail Row */}
            <div className="flex items-center gap-3 overflow-x-auto">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                    selectedImageIndex === idx ? 'border-[#C5A059] ring-2 ring-[#C5A059]/30' : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="thumb" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Right/Left Product Details */}
          <div className="space-y-5 flex flex-col justify-between">
            
            <div className="space-y-3">
              <span className="text-xs font-serif-luxury font-bold text-[#C5A059] tracking-widest uppercase">
                {product.brand}
              </span>

              <h2 className="font-arabic-heading text-2xl font-bold text-[#121110]">
                {language === 'ar' ? product.name_ar : product.name_en}
              </h2>

              {/* Rating */}
              <div className="flex items-center gap-2 text-xs">
                <div className="flex items-center text-amber-500">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="font-bold text-[#121110] ms-1">{product.rating}</span>
                </div>
                <span className="text-gray-400">({product.reviewCount} {language === 'ar' ? 'تقييم' : 'reviews'})</span>
              </div>

              {/* Price Block */}
              <div className="flex items-baseline gap-3 pt-2">
                <span className="font-arabic-heading font-black text-2xl text-[#121110]">
                  {formatPrice(product.priceSAR * quantity, country, language === 'ar')}
                </span>
                {product.originalPriceSAR && (
                  <span className="text-sm text-gray-400 line-through">
                    {formatPrice(product.originalPriceSAR * quantity, country, language === 'ar')}
                  </span>
                )}
                <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-semibold">
                  {language === 'ar' ? 'شامل ضريبة القيمة المضافة' : 'VAT Included'}
                </span>
              </div>

              <p className="text-xs text-gray-600 leading-relaxed pt-2">
                {language === 'ar' ? product.description_ar : product.description_en}
              </p>

              {/* Delivery Estimate */}
              <div className="p-3 bg-[#F4EFE6] rounded-xl flex items-center gap-2 text-xs text-gray-700 border border-[#EAE0D0]">
                <Truck className="w-4 h-4 text-[#C5A059]" />
                <span>
                  {language === 'ar' 
                    ? `التوصيل إلى ${country.name_ar}: ${country.deliveryDays}` 
                    : `Delivering to ${country.name_en}: ${country.deliveryDays}`}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-3 pt-4 border-t border-[#EAE0D0]">
              
              {/* Quantity Selector */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#121110]">
                  {language === 'ar' ? 'الكمية:' : 'Quantity:'}
                </span>
                <div className="flex items-center border border-[#C5A059]/40 rounded-xl bg-white overflow-hidden">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1 text-base font-bold text-gray-600 hover:bg-black/5"
                  >
                    -
                  </button>
                  <span className="px-4 py-1 text-sm font-bold text-[#121110]">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1 text-base font-bold text-gray-600 hover:bg-black/5"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Add to Cart & Wishlist */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    addToCart(product, quantity);
                    closeQuickView();
                  }}
                  className="flex-1 flex items-center justify-center gap-2 bg-[#231F1D] hover:bg-[#121110] text-[#DFBF7A] py-3 px-6 rounded-xl font-bold text-xs sm:text-sm border border-[#C5A059] shadow-lg transition-all cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{language === 'ar' ? 'إضافة لسلة التسوق' : 'Add to Shopping Cart'}</span>
                </button>

                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-3 rounded-xl border transition-colors cursor-pointer ${
                    isWishlisted 
                      ? 'bg-[#C5A059] text-white border-[#C5A059]' 
                      : 'bg-white text-gray-700 border-[#EAE0D0] hover:border-[#C5A059]'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Full Details Page Link */}
              <button
                onClick={() => {
                  closeQuickView();
                  navigateTo('product-detail', { productId: product.id });
                }}
                className="w-full text-center text-xs font-bold text-[#C5A059] hover:underline pt-2 cursor-pointer"
              >
                {language === 'ar' ? 'عرض الصفحة الكاملة للمنتج والتفاصيل' : 'View Full Product Details & Specs'}
              </button>

            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
